import { _ as b, T as f, g as m, s as y, a as w } from "./index-7YDlkBnY.js";
import {
  k as S,
  d as V,
  e as h,
  h as v,
  w as u,
  _ as c,
  i as P,
  t as k,
  E as T,
  r as $,
  p as r,
} from "./index-UoU16364.js";
const j = S({
  name: "Tooltip",
  components: { Trigger: f },
  props: {
    popupVisible: { type: Boolean, default: void 0 },
    defaultPopupVisible: { type: Boolean, default: !1 },
    content: String,
    position: { type: String, default: "top" },
    mini: { type: Boolean, default: !1 },
    backgroundColor: { type: String },
    contentClass: { type: [String, Array, Object] },
    contentStyle: { type: Object },
    arrowClass: { type: [String, Array, Object] },
    arrowStyle: { type: Object },
    popupContainer: { type: [String, Object] },
  },
  emits: { "update:popupVisible": (o) => !0, popupVisibleChange: (o) => !0 },
  setup(o, { emit: t }) {
    const e = m("tooltip"),
      a = $(o.defaultPopupVisible),
      l = r(() => {
        var n;
        return (n = o.popupVisible) != null ? n : a.value;
      }),
      p = (n) => {
        ((a.value = n), t("update:popupVisible", n), t("popupVisibleChange", n));
      },
      i = r(() => [`${e}-content`, o.contentClass, { [`${e}-mini`]: o.mini }]),
      d = r(() => {
        if (o.backgroundColor || o.contentStyle) return { backgroundColor: o.backgroundColor, ...o.contentStyle };
      }),
      g = r(() => [`${e}-popup-arrow`, o.arrowClass]),
      C = r(() => {
        if (o.backgroundColor || o.arrowStyle) return { backgroundColor: o.backgroundColor, ...o.arrowStyle };
      });
    return {
      prefixCls: e,
      computedPopupVisible: l,
      contentCls: i,
      computedContentStyle: d,
      arrowCls: g,
      computedArrowStyle: C,
      handlePopupVisibleChange: p,
    };
  },
});
function O(o, t, e, a, l, p) {
  const i = V("Trigger");
  return (
    v(),
    h(
      i,
      {
        class: T(o.prefixCls),
        trigger: "hover",
        position: o.position,
        "popup-visible": o.computedPopupVisible,
        "popup-offset": 10,
        "show-arrow": "",
        "content-class": o.contentCls,
        "content-style": o.computedContentStyle,
        "arrow-class": o.arrowCls,
        "arrow-style": o.computedArrowStyle,
        "popup-container": o.popupContainer,
        "animation-name": "zoom-in-fade-out",
        "auto-fit-transform-origin": "",
        role: "tooltip",
        onPopupVisibleChange: o.handlePopupVisibleChange,
      },
      {
        content: u(() => [c(o.$slots, "content", {}, () => [P(k(o.content), 1)])]),
        default: u(() => [c(o.$slots, "default")]),
        _: 3,
      },
      8,
      [
        "class",
        "position",
        "popup-visible",
        "content-class",
        "content-style",
        "arrow-class",
        "arrow-style",
        "popup-container",
        "onPopupVisibleChange",
      ],
    )
  );
}
var s = b(j, [["render", O]]);
const _ = Object.assign(s, {
  install: (o, t) => {
    y(o, t);
    const e = w(t);
    o.component(e + s.name, s);
  },
});
export { _ as T };
