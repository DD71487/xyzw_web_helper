import {
  k as C,
  c as i,
  h as n,
  a as e,
  s as v,
  x,
  p as y,
  r as T,
  o as D,
  f as S,
  t as c,
  u as k,
  b as p,
  w as _,
  d as B,
  F as $,
  g as z,
  i as h,
  e as A,
  j as M,
} from "./index-UoU16364.js";
import { _ as N } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { C as V } from "./Cube-CwoBO7fL.js";
import { A as q } from "./Add-CN1YrD24.js";
import { C as F } from "./CheckmarkCircle-DD5Vf_PL.js";
const L = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  W = e(
    "path",
    {
      d: "M396 432H136c-36.44 0-70.36-12.57-95.51-35.41C14.38 372.88 0 340 0 304c0-36.58 13.39-68.12 38.72-91.22c18.11-16.53 42.22-28.25 69.18-33.87a16 16 0 0 0 11.37-9.15a156.24 156.24 0 0 1 42.05-56C187.76 91.69 220.5 80 256 80a153.57 153.57 0 0 1 107.14 42.9c24.73 23.81 41.5 55.28 49.18 92a16 16 0 0 0 12.12 12.39C470 237.42 512 270.43 512 328c0 33.39-12.24 60.78-35.41 79.23C456.23 423.43 428.37 432 396 432z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  j = [W],
  E = C({
    name: "Cloud",
    render: function (t, d) {
      return (n(), i("svg", L, j));
    },
  }),
  H = { class: "dashboard-page" },
  I = { class: "dashboard-main" },
  Q = { class: "main-container" },
  R = { class: "welcome-section" },
  G = { class: "welcome-content" },
  J = { class: "welcome-text" },
  K = { class: "welcome-actions" },
  O = { class: "quick-actions-section" },
  P = { class: "actions-grid" },
  U = ["onClick"],
  X = { class: "action-icon" },
  Y = { class: "action-content" },
  Z = {
    __name: "Dashboard",
    setup(b) {
      const t = S(),
        d = v(),
        r = x(),
        f = y(() =>
          new Date().toLocaleDateString("zh-CN", { year: "numeric", month: "long", day: "numeric", weekday: "long" }),
        ),
        g = T([
          { id: 1, icon: V, title: "游戏功能", description: "访问所有游戏功能模块", action: "game-features" },
          { id: 2, icon: q, title: "添加Token", description: "快速添加新的游戏Token", action: "add-token" },
          { id: 3, icon: F, title: "批量任务", description: "批量执行任务", action: "batch-daily-tasks" },
          {
            id: 4,
            icon: E,
            title: "WebSocket测试",
            description: "测试WebSocket连接和游戏命令",
            action: "websocket-test",
          },
        ]),
        l = () => {
          try {
            t.push("/tokens");
          } catch (a) {
            (console.error("❌ 导航失败:", a), d.error("导航到Token管理页面失败"));
          }
        },
        w = (a) => {
          switch (a.action) {
            case "game-features":
              t.push("/admin/game-features");
              break;
            case "add-token":
              l();
              break;
            case "execute-tasks":
              t.push("/admin/game-features");
              break;
            case "websocket-test":
              t.push("/websocket-test");
              break;
            case "open-settings":
              t.push("/admin/profile");
              break;
            case "batch-daily-tasks":
              t.push("/admin/batch-daily-tasks");
              break;
          }
        };
      return (
        D(async () => {
          if (!r.hasTokens) {
            t.push("/tokens");
            return;
          }
          r.initTokenStore();
        }),
        (a, s) => {
          var m;
          const u = B("n-button");
          return (
            n(),
            i("div", H, [
              e("main", I, [
                e("div", Q, [
                  e("section", R, [
                    e("div", G, [
                      e("div", J, [
                        e(
                          "h1",
                          null,
                          " 欢迎回来，" + c(((m = k(r).selectedToken) == null ? void 0 : m.name) || "游戏玩家") + "！ ",
                          1,
                        ),
                        e("p", null, "今天是 " + c(f.value) + "，继续您的游戏管理之旅吧", 1),
                      ]),
                      e("div", K, [
                        p(
                          u,
                          {
                            type: "primary",
                            size: "large",
                            onClick: s[0] || (s[0] = (o) => k(t).push("/admin/game-features")),
                          },
                          { default: _(() => [...(s[1] || (s[1] = [h(" 进入游戏功能 ", -1)]))]), _: 1 },
                        ),
                        p(
                          u,
                          { size: "large", onClick: l },
                          { default: _(() => [...(s[2] || (s[2] = [h(" 管理Token ", -1)]))]), _: 1 },
                        ),
                      ]),
                    ]),
                  ]),
                  e("section", O, [
                    s[3] || (s[3] = e("h2", { class: "section-title" }, "快速操作", -1)),
                    e("div", P, [
                      (n(!0),
                      i(
                        $,
                        null,
                        z(
                          g.value,
                          (o) => (
                            n(),
                            i(
                              "div",
                              { key: o.id, class: "action-card", onClick: (ee) => w(o) },
                              [
                                e("div", X, [(n(), A(M(o.icon)))]),
                                e("div", Y, [e("h3", null, c(o.title), 1), e("p", null, c(o.description), 1)]),
                              ],
                              8,
                              U,
                            )
                          ),
                        ),
                        128,
                      )),
                    ]),
                  ]),
                ]),
              ]),
            ])
          );
        }
      );
    },
  },
  ce = N(Z, [["__scopeId", "data-v-01286b0c"]]);
export { ce as default };
