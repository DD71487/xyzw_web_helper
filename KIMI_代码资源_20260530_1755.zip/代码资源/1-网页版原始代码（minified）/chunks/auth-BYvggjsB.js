import { aF as h, r as c, p as u } from "./index-UoU16364.js";
import { u as k } from "./localTokenManager-BQJEcmfy.js";
const p = h("auth", () => {
  const s = c(null),
    t = c(localStorage.getItem("token") || null),
    o = c(!1),
    n = k(),
    i = u(() => !!t.value && !!s.value),
    m = u(() => s.value),
    g = async (e) => {
      try {
        o.value = !0;
        const r = {
            id: "local_user_" + Date.now(),
            username: e.username,
            email: e.email || `${e.username}@local.game`,
            avatar: "/icons/xiaoyugan.png",
            createdAt: new Date().toISOString(),
          },
          l = "local_token_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
        return (
          (t.value = l),
          (s.value = r),
          localStorage.setItem("token", t.value),
          localStorage.setItem("user", JSON.stringify(s.value)),
          n.setUserToken(l),
          { success: !0 }
        );
      } catch (r) {
        return (console.error("登录错误:", r), { success: !1, message: "本地认证失败" });
      } finally {
        o.value = !1;
      }
    },
    f = async (e) => {
      try {
        o.value = !0;
        const r = JSON.parse(localStorage.getItem("registeredUsers") || "[]");
        if (r.some((v) => v.username === e.username)) return { success: !1, message: "用户名已存在" };
        const S = { ...e, id: "user_" + Date.now(), createdAt: new Date().toISOString() };
        return (
          r.push(S),
          localStorage.setItem("registeredUsers", JSON.stringify(r)),
          { success: !0, message: "注册成功，请登录" }
        );
      } catch (r) {
        return (console.error("注册错误:", r), { success: !1, message: "本地注册失败" });
      } finally {
        o.value = !1;
      }
    },
    a = () => {
      ((s.value = null),
        (t.value = null),
        localStorage.removeItem("token"),
        localStorage.removeItem("user"),
        localStorage.removeItem("gameRoles"),
        n.clearUserToken(),
        n.clearAllGameTokens());
    };
  return {
    user: s,
    token: t,
    isLoading: o,
    isAuthenticated: i,
    userInfo: m,
    login: g,
    register: f,
    logout: a,
    fetchUserInfo: async () => {
      try {
        if (!t.value) return !1;
        const e = localStorage.getItem("user");
        if (e)
          try {
            return ((s.value = JSON.parse(e)), !0);
          } catch (r) {
            return (console.error("解析用户信息失败:", r), a(), !1);
          }
        else return (a(), !1);
      } catch (e) {
        return (console.error("获取用户信息失败:", e), a(), !1);
      }
    },
    initAuth: async () => {
      const e = localStorage.getItem("user");
      if (t.value && e)
        try {
          ((s.value = JSON.parse(e)), n.initTokenManager());
        } catch (r) {
          (console.error("初始化认证失败:", r), a());
        }
    },
  };
});
export { p as u };
