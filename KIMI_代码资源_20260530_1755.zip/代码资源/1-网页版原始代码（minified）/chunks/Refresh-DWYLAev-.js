import { k as o, c as t, a as e, h as n } from "./index-UoU16364.js";
const r = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  s = e(
    "path",
    {
      d: "M320 146s24.36-12-64-12a160 160 0 1 0 160 160",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-miterlimit": "10",
      "stroke-width": "32",
    },
    null,
    -1,
  ),
  l = e(
    "path",
    {
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "32",
      d: "M256 58l80 80l-80 80",
    },
    null,
    -1,
  ),
  i = [s, l],
  k = o({
    name: "Refresh",
    render: function (a, d) {
      return (n(), t("svg", r, i));
    },
  });
export { k as R };
