import {
  s as Y,
  x as Z,
  r as y,
  p as ee,
  o as te,
  M as se,
  c as I,
  b as a,
  w as t,
  d as f,
  h as v,
  e as W,
  A as S,
  i as u,
  t as _,
  a as M,
  F as ae,
  g as le,
  E as ne,
} from "./index-UoU16364.js";
import { _ as oe } from "./_plugin-vue_export-helper-DlAUqK2U.js";
const re = { class: "websocket-tester" },
  ue = { class: "message-log" },
  ce = { class: "message-header" },
  ie = { class: "message-content" },
  de = { key: 0, class: "no-messages" },
  ve = {
    __name: "WebSocketTester",
    setup(me) {
      const l = Y(),
        g = Z(),
        n = y(null),
        m = y("disconnected"),
        c = y(null),
        r = y(null),
        b = y("{}"),
        N = y(!1),
        U = y(!1),
        O = y(!1),
        C = y([]),
        q = ee(() => g.gameTokens.map((e) => ({ label: `${e.name} (${e.server})`, value: e.id }))),
        J = [
          { label: "获取角色信息", value: "role_getroleinfo" },
          { label: "获取数据包版本", value: "system_getdatabundlever" },
          { label: "签到奖励", value: "system_signinreward" },
          { label: "领取每日任务奖励", value: "task_claimdailyreward" },
          { label: "获取邮件列表", value: "mail_getlist" },
          { label: "领取所有邮件附件", value: "mail_claimallattachment" },
          { label: "获取军团信息", value: "legion_getinfo" },
          { label: "英雄招募", value: "hero_recruit" },
          { label: "领取挂机奖励", value: "system_claimhangupreward" },
        ],
        $ = (e) =>
          ({
            connected: "success",
            connecting: "warning",
            disconnected: "default",
            reconnecting: "info",
            error: "error",
          })[e] || "default",
        A = (e) =>
          ({
            connected: "已连接",
            connecting: "连接中",
            disconnected: "已断开",
            reconnecting: "重连中",
            error: "连接错误",
          })[e] || "未知状态",
        R = (e) => (e ? new Date(e).toLocaleString("zh-CN") : "-"),
        P = () => {
          D();
        },
        D = () => {
          if (!n.value) {
            ((m.value = "disconnected"), (c.value = null));
            return;
          }
          m.value = g.getWebSocketStatus(n.value);
          const e = g.wsConnections[n.value];
          e
            ? (c.value = { roleId: n.value, status: e.status, connectedAt: e.connectedAt, wsUrl: e.wsUrl })
            : (c.value = null);
        },
        B = async () => {
          if (!n.value) {
            l.error("请先选择Token");
            return;
          }
          try {
            m.value = "connecting";
            const e = g.gameTokens.find((s) => s.id === n.value);
            if (!e) {
              l.error("未找到Token数据");
              return;
            }
            (g.createWebSocketConnection(n.value, e.token, e.wsUrl), G(), l.success("WebSocket连接已启动"));
          } catch (e) {
            (console.error("WebSocket连接失败:", e), l.error("WebSocket连接失败: " + e.message));
          } finally {
            setTimeout(D, 1e3);
          }
        },
        E = () => {
          n.value &&
            (g.closeWebSocketConnection(n.value),
            (m.value = "disconnected"),
            (c.value = null),
            l.info("WebSocket连接已断开"));
        },
        V = async () => {
          if (!r.value) {
            l.error("请选择要发送的命令");
            return;
          }
          try {
            N.value = !0;
            let e = {};
            (b.value.trim() && (e = JSON.parse(b.value)),
              g.sendMessage(n.value, r.value, e)
                ? (h("sent", { command: r.value, params: e }), l.success("命令发送成功"))
                : l.error("命令发送失败"));
          } catch (e) {
            (console.error("发送命令失败:", e), l.error("发送命令失败: " + e.message));
          } finally {
            N.value = !1;
          }
        },
        F = async () => {
          if (!r.value) {
            l.error("请选择要发送的命令");
            return;
          }
          try {
            U.value = !0;
            let e = {};
            b.value.trim() && (e = JSON.parse(b.value));
            const s = await g.sendMessageWithPromise(n.value, r.value, e);
            (h("sent", { command: r.value, params: e }), h("received", s), l.success("命令执行成功，已收到响应"));
          } catch (e) {
            (console.error("发送命令失败:", e), l.error("发送命令失败: " + e.message));
          } finally {
            U.value = !1;
          }
        },
        j = async () => {
          if (!r.value) {
            l.error("请选择要发送的命令");
            return;
          }
          try {
            O.value = !0;
            let e = {};
            (b.value.trim() && (e = JSON.parse(b.value)),
              h("sent", { message: "开始并发测试：同时发送5个相同命令", command: r.value, params: e }));
            const s = [],
              T = Date.now();
            for (let o = 0; o < 5; o++) {
              const k = g
                .sendMessageWithPromise(n.value, r.value, { ...e, requestIndex: o + 1 })
                .then((x) => ({ requestIndex: o + 1, response: x, success: !0 }))
                .catch((x) => ({ requestIndex: o + 1, error: x.message, success: !1 }));
              s.push(k);
            }
            const p = await Promise.allSettled(s),
              w = Date.now(),
              i = p.filter((o) => o.status === "fulfilled" && o.value.success).length,
              z = p.length - i;
            (h("received", {
              message: "并发测试完成",
              totalRequests: 5,
              successCount: i,
              failCount: z,
              duration: `${w - T}ms`,
              results: p.map((o) => (o.status === "fulfilled" ? o.value : { error: o.reason })),
            }),
              i === 5
                ? l.success(`并发测试成功！5个请求全部正确响应，耗时${w - T}ms`)
                : i > 0
                  ? l.warning(`并发测试部分成功：${i}个成功，${z}个失败`)
                  : l.error("并发测试失败：所有请求都失败了"));
          } catch (e) {
            (console.error("并发测试失败:", e),
              l.error("并发测试失败: " + e.message),
              h("received", { message: "并发测试异常", error: e.message }));
          } finally {
            O.value = !1;
          }
        },
        G = () => {},
        h = (e, s) => {
          (C.value.unshift({ type: e, data: s, timestamp: new Date().toISOString() }),
            C.value.length > 100 && (C.value = C.value.slice(0, 100)));
        },
        H = () => {
          C.value = [];
        };
      let L = null;
      return (
        te(() => {
          L = setInterval(() => {
            n.value && D();
          }, 1e3);
        }),
        se(() => {
          L && clearInterval(L);
        }),
        (e, s) => {
          const T = f("n-tag"),
            p = f("n-button"),
            w = f("n-space"),
            i = f("n-card"),
            z = f("n-select"),
            o = f("n-form-item"),
            k = f("n-descriptions-item"),
            x = f("n-text"),
            K = f("n-descriptions"),
            Q = f("n-input");
          return (
            v(),
            I("div", re, [
              a(
                i,
                { title: "WebSocket连接测试", class: "mb-4" },
                {
                  default: t(() => [
                    a(
                      w,
                      { direction: "vertical", size: "large" },
                      {
                        default: t(() => [
                          a(
                            i,
                            { title: "连接状态", size: "small" },
                            {
                              default: t(() => [
                                a(
                                  w,
                                  { align: "center" },
                                  {
                                    default: t(() => [
                                      a(
                                        T,
                                        { type: $(m.value), size: "large" },
                                        { default: t(() => [u(_(A(m.value)), 1)]), _: 1 },
                                        8,
                                        ["type"],
                                      ),
                                      n.value && m.value !== "connected"
                                        ? (v(),
                                          W(
                                            p,
                                            { key: 0, type: "primary", loading: m.value === "connecting", onClick: B },
                                            {
                                              default: t(() => [...(s[3] || (s[3] = [u(" 连接WebSocket ", -1)]))]),
                                              _: 1,
                                            },
                                            8,
                                            ["loading"],
                                          ))
                                        : S("", !0),
                                      m.value === "connected"
                                        ? (v(),
                                          W(
                                            p,
                                            { key: 1, type: "error", onClick: E },
                                            { default: t(() => [...(s[4] || (s[4] = [u(" 断开连接 ", -1)]))]), _: 1 },
                                          ))
                                        : S("", !0),
                                    ]),
                                    _: 1,
                                  },
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          a(
                            o,
                            { label: "选择角色" },
                            {
                              default: t(() => [
                                a(
                                  z,
                                  {
                                    value: n.value,
                                    "onUpdate:value": [s[0] || (s[0] = (d) => (n.value = d)), P],
                                    placeholder: "请选择要测试的角色",
                                    options: q.value,
                                  },
                                  null,
                                  8,
                                  ["value", "options"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          c.value
                            ? (v(),
                              W(
                                i,
                                { key: 0, title: "连接详情", size: "small" },
                                {
                                  default: t(() => [
                                    a(
                                      K,
                                      { column: 2, bordered: "", size: "small" },
                                      {
                                        default: t(() => [
                                          a(
                                            k,
                                            { label: "角色ID" },
                                            { default: t(() => [u(_(c.value.roleId), 1)]), _: 1 },
                                          ),
                                          a(
                                            k,
                                            { label: "状态" },
                                            {
                                              default: t(() => [
                                                a(
                                                  T,
                                                  { type: $(c.value.status) },
                                                  { default: t(() => [u(_(A(c.value.status)), 1)]), _: 1 },
                                                  8,
                                                  ["type"],
                                                ),
                                              ]),
                                              _: 1,
                                            },
                                          ),
                                          a(
                                            k,
                                            { label: "WebSocket URL" },
                                            {
                                              default: t(() => [
                                                a(
                                                  x,
                                                  { code: "", style: { "font-size": "12px" } },
                                                  { default: t(() => [u(_(c.value.wsUrl), 1)]), _: 1 },
                                                ),
                                              ]),
                                              _: 1,
                                            },
                                          ),
                                          a(
                                            k,
                                            { label: "连接时间" },
                                            { default: t(() => [u(_(R(c.value.connectedAt)), 1)]), _: 1 },
                                          ),
                                          c.value.lastError
                                            ? (v(),
                                              W(
                                                k,
                                                { key: 0, label: "最后错误" },
                                                {
                                                  default: t(() => [
                                                    a(
                                                      x,
                                                      { type: "error" },
                                                      { default: t(() => [u(_(c.value.lastError), 1)]), _: 1 },
                                                    ),
                                                  ]),
                                                  _: 1,
                                                },
                                              ))
                                            : S("", !0),
                                          c.value.reconnectAttempt > 0
                                            ? (v(),
                                              W(
                                                k,
                                                { key: 1, label: "重连次数" },
                                                { default: t(() => [u(_(c.value.reconnectAttempt), 1)]), _: 1 },
                                              ))
                                            : S("", !0),
                                        ]),
                                        _: 1,
                                      },
                                    ),
                                  ]),
                                  _: 1,
                                },
                              ))
                            : S("", !0),
                          m.value === "connected"
                            ? (v(),
                              W(
                                i,
                                { key: 1, title: "游戏命令测试", size: "small" },
                                {
                                  default: t(() => [
                                    a(
                                      w,
                                      { direction: "vertical" },
                                      {
                                        default: t(() => [
                                          a(
                                            o,
                                            { label: "选择命令" },
                                            {
                                              default: t(() => [
                                                a(
                                                  z,
                                                  {
                                                    value: r.value,
                                                    "onUpdate:value": s[1] || (s[1] = (d) => (r.value = d)),
                                                    placeholder: "请选择要测试的命令",
                                                    options: J,
                                                  },
                                                  null,
                                                  8,
                                                  ["value"],
                                                ),
                                              ]),
                                              _: 1,
                                            },
                                          ),
                                          r.value
                                            ? (v(),
                                              W(
                                                o,
                                                { key: 0, label: "命令参数 (JSON)" },
                                                {
                                                  default: t(() => [
                                                    a(
                                                      Q,
                                                      {
                                                        value: b.value,
                                                        "onUpdate:value": s[2] || (s[2] = (d) => (b.value = d)),
                                                        type: "textarea",
                                                        placeholder: '例如: {"roleId": 123456}',
                                                        rows: 3,
                                                      },
                                                      null,
                                                      8,
                                                      ["value"],
                                                    ),
                                                  ]),
                                                  _: 1,
                                                },
                                              ))
                                            : S("", !0),
                                          a(w, null, {
                                            default: t(() => [
                                              a(
                                                p,
                                                { type: "primary", disabled: !r.value, loading: N.value, onClick: V },
                                                {
                                                  default: t(() => [...(s[5] || (s[5] = [u(" 发送命令 ", -1)]))]),
                                                  _: 1,
                                                },
                                                8,
                                                ["disabled", "loading"],
                                              ),
                                              a(
                                                p,
                                                { type: "success", disabled: !r.value, loading: U.value, onClick: F },
                                                {
                                                  default: t(() => [...(s[6] || (s[6] = [u(" 发送并等待响应 ", -1)]))]),
                                                  _: 1,
                                                },
                                                8,
                                                ["disabled", "loading"],
                                              ),
                                              a(
                                                p,
                                                { type: "warning", disabled: !r.value, loading: O.value, onClick: j },
                                                {
                                                  default: t(() => [...(s[7] || (s[7] = [u(" 测试并发请求 ", -1)]))]),
                                                  _: 1,
                                                },
                                                8,
                                                ["disabled", "loading"],
                                              ),
                                            ]),
                                            _: 1,
                                          }),
                                        ]),
                                        _: 1,
                                      },
                                    ),
                                  ]),
                                  _: 1,
                                },
                              ))
                            : S("", !0),
                          a(
                            i,
                            { title: "消息日志", size: "small" },
                            {
                              "header-extra": t(() => [
                                a(
                                  p,
                                  { size: "small", onClick: H },
                                  { default: t(() => [...(s[8] || (s[8] = [u(" 清空日志 ", -1)]))]), _: 1 },
                                ),
                              ]),
                              default: t(() => [
                                M("div", ue, [
                                  (v(!0),
                                  I(
                                    ae,
                                    null,
                                    le(
                                      C.value,
                                      (d, X) => (
                                        v(),
                                        I(
                                          "div",
                                          { key: X, class: ne(["message-item", `message-${d.type}`]) },
                                          [
                                            M("div", ce, [
                                              a(
                                                T,
                                                { type: d.type === "sent" ? "info" : "success", size: "small" },
                                                {
                                                  default: t(() => [u(_(d.type === "sent" ? "发送" : "接收"), 1)]),
                                                  _: 2,
                                                },
                                                1032,
                                                ["type"],
                                              ),
                                              a(
                                                x,
                                                { depth: "3", style: { "font-size": "12px" } },
                                                { default: t(() => [u(_(R(d.timestamp)), 1)]), _: 2 },
                                                1024,
                                              ),
                                            ]),
                                            M("div", ie, [M("pre", null, _(JSON.stringify(d.data, null, 2)), 1)]),
                                          ],
                                          2,
                                        )
                                      ),
                                    ),
                                    128,
                                  )),
                                  C.value.length === 0 ? (v(), I("div", de, " 暂无消息日志 ")) : S("", !0),
                                ]),
                              ]),
                              _: 1,
                            },
                          ),
                        ]),
                        _: 1,
                      },
                    ),
                  ]),
                  _: 1,
                },
              ),
            ])
          );
        }
      );
    },
  },
  _e = oe(ve, [["__scopeId", "data-v-7d8648b4"]]);
export { _e as default };
