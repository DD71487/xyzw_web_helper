import { H as Te, e as Se, t as Be, f as We } from "./legionWar-5YonzZw2.js";
import { g as ge, X as _e } from "./DateTimeUtils-CyGYuA3B.js";
import {
  x as Me,
  s as Pe,
  r as W,
  p as U,
  o as He,
  M as $e,
  c as ze,
  a as f,
  b as O,
  i as Z,
  w as ee,
  d as pe,
  t as ve,
  h as De,
  E as Re,
  u as Ae,
} from "./index-UoU16364.js";
import { _ as je } from "./_plugin-vue_export-helper-DlAUqK2U.js";
const Ee = { class: "legion-war-container" },
  Oe = { class: "legion-war-map" },
  Ne = { class: "map-title" },
  Fe = { class: "map-container" },
  Ue = { class: "legion-war-operation" },
  Ve = { class: "legion-war-operation-container" },
  Xe = { class: "legion-war-operation-item" },
  Ge = { class: "legion-war-operation-item" },
  Ye = { class: "legion-war-operation-item" },
  qe = { class: "legion-war-operation-item" },
  P = 13.25,
  he = 2.75,
  Ke = {
    __name: "LegionWar",
    setup(Je) {
      const b = Me(),
        A = Pe();
      let w = null;
      const N = W(null),
        j = W(!1),
        oe = W(ge("yyyy-MM-dd HH:mm:ss"));
      U(() => ((w == null ? void 0 : w.status) === "connected" ? "已连接" : "未连接"));
      const V = U(() => ((w == null ? void 0 : w.status) === "connected" ? "connected" : "disconnected")),
        be = U(() => (j.value ? "status-connected" : "status-disconnected"));
      U(() => (V == null ? void 0 : V.value) === "connected");
      const H = W(!1),
        X = W(!1),
        ne = function (e) {
          Y();
        },
        we = async function () {
          let e = Object.values(C.value.legionInfo);
          const n = [];
          for (let s = 0; s < 2; s++) {
            let c = "";
            for (let u = 0; u < 10; u++) {
              const o = e[u + s * 10];
              (u != 0 &&
                (c += `
`),
                (c += o.name + ":剩" + (150 - o.reviveCount)));
            }
            n.push(c);
          }
          const t = b.selectedToken.id,
            l = 1500;
          for (let s = 0; s < n.length; s++) {
            await new Promise((c) => setTimeout(c, l));
            try {
              await b.sendMessageToLegion(t, n[s]);
            } catch (c) {
              c.message.includes("频繁") &&
                (await new Promise((u) => setTimeout(u, l * 2)), await b.sendMessageToLegion(t, n[s]));
            }
          }
        },
        G = W(null);
      let i = null;
      const S = window.devicePixelRatio || 1;
      let F = null;
      const me = 2 * P,
        te = Math.sqrt(3) * P,
        a = Array.from({ length: 41 }, () => Array.from({ length: 41 }, () => 0));
      let I = [0, 0],
        C = W(null);
      const le = W(null),
        ye = (e, n, t) => {
          i.beginPath();
          for (let l = 0; l < 6; l++) {
            const s = ((2 * Math.PI) / 6) * l,
              c = e + P * Math.cos(s),
              u = n + P * Math.sin(s);
            (l === 0 ? i.moveTo(c, u) : i.lineTo(c, u), c >= I[0] && (I[0] = c), u >= I[1] && (I[1] = u));
          }
          (i.closePath(), (i.fillStyle = t), i.fill(), (i.strokeStyle = t), i.stroke());
        },
        Y = (e = 0, n = 0, t = "") => {
          (e !== 0 && n !== 0 ? se(e, n, t) : se(), Ie(), Ce(C.value));
        },
        se = (e = 0, n = 0, t = "") => {
          i.clearRect(0, 0, i.canvas.width / S, i.canvas.height / S);
          let l = Te.getInstance();
          if (
            (l.removeAllNode(),
            (C.value = Se(le.value, H.value)),
            C.value &&
              l.addNodeList(
                Object.values(C.value.buildingData).map((o) => ({
                  id: o.id,
                  type: o.type,
                  belongsLegionId: o.belongsLegionId,
                  hP: o.hP,
                  maxHP: o.maxHP,
                  point: o.point,
                  belongsLegionInfo: C.value.legionInfo[o.belongsLegionId],
                })),
              ),
            !C.value)
          )
            return;
          if (!H.value)
            Object.values(C.value.legionInfo).forEach((o) => {
              let r = Object.keys(o.buildings).sort((d, p) => {
                const [m, v] = d.split("_").map(Number),
                  [k, B] = p.split("_").map(Number),
                  _ = m - k;
                return _ !== 0 ? _ : v - B;
              });
              for (let d = 0; d < r.length; d++)
                for (let p = d; p < r.length; p++) {
                  let m = l.findShortestPath(r[d], r[p], o.id);
                  m &&
                    m.forEach((v) => {
                      ((v.belongsLegionId = o.id), (v.colorBg = o.color));
                    });
                }
            });
          else {
            let o = Object.values(C.value.legionInfo);
            for (let r = 0; r < o.length; r++) {
              let d = l.getNodeByCoords(o[r].strongholdId);
              ((d.belongsLegionId = o[r].id), (d.colorBg = o[r].color));
            }
          }
          (l.getAllNodes().forEach((o) => {
            let r = o.position.x,
              d = o.position.y;
            (H.value && o.type != 4 && ((o.belongsLegionId = -1), (o.colorBg = Be(9))),
              parseInt(r) >= 0 && parseInt(r) < 41 && parseInt(d) >= 0 && parseInt(d) < 32
                ? (a[parseInt(d)][parseInt(r)] = o)
                : console.warn(`坐标[${r},${d}]越界，跳过赋值`));
          }),
            H.value ||
              ((a[16][19].belongsLegionId = a[17][20].belongsLegionId),
              (a[17][19].belongsLegionId = a[17][20].belongsLegionId),
              (a[16][21].belongsLegionId = a[17][20].belongsLegionId),
              (a[17][21].belongsLegionId = a[17][20].belongsLegionId),
              (a[16][20].belongsLegionId = a[17][20].belongsLegionId),
              (a[18][20].belongsLegionId = a[17][20].belongsLegionId),
              (a[16][21].colorBg = a[17][20].colorBg),
              (a[17][21].colorBg = a[17][20].colorBg),
              (a[16][19].colorBg = a[17][20].colorBg),
              (a[17][19].colorBg = a[17][20].colorBg),
              (a[16][20].colorBg = a[17][20].colorBg),
              (a[18][20].colorBg = a[17][20].colorBg)));
          let c = {},
            u = [];
          for (let o = 0; o <= 31; o++)
            for (let r = 0; r <= 40; r++)
              if (o > 2 && a[o][r] != 0) {
                const d = r * (me * 0.75) + P + he * r,
                  p = o * te + (r % 2 === 1 ? te / 2 : 0) + he * o;
                let m = a[o][r].colorBg;
                if (e !== 0 && n !== 0) {
                  const v = Math.sqrt((e - d) ** 2 + (n - p) ** 2);
                  t === "mousemove" ? (m = v < P ? "#42b983" : m) : t === "click" && v < P && (c = a[o][r]);
                }
                if ((ye(d, p, m), a[o][r].type != 9)) {
                  let v = a[o][r].typeName.replace("据点", "");
                  (v == "大本营" && ((i.fillStyle = "#055138"), (v = C.value.legionInfo[a[o][r].belongsLegionId].name)),
                    u.push({ x: d - 13, y: p + 4, name: v }));
                }
              }
          for (let o = 0; o < u.length; o++)
            ((i.fillStyle = "black"), (i.font = "bold 12px Microsoft Yahei"), i.fillText(u[o].name, u[o].x, u[o].y));
          c.type != 9 && Object.keys(c).length > 0 && t === "click" && xe(e, n, c);
        },
        Ie = () => {
          (i.beginPath(),
            i.moveTo(I[0] + 10, I[1]),
            i.lineTo(I[0] + 10, 10),
            i.closePath(),
            (i.strokeStyle = "#000"),
            i.stroke());
        },
        Ce = (e) => {
          if (e) {
            let n = {};
            if (!X.value)
              ((e = Object.values(e.legionInfo)
                .sort((t, l) => l.score - t.score)
                .map((t) => [
                  t.name,
                  t.killCnt,
                  t.reviveCount + "/150",
                  t.score,
                  t.redCount,
                  We(t.power),
                  t.participantsCount + "/" + t.memberCount,
                  t.danCount,
                  t.blessingCount + "个共" + t.blessingScore + "分",
                  t.color,
                ])),
                (n = {
                  x: I[0] + 20,
                  y: 20,
                  columns: 9,
                  rows: 20,
                  headerData: ["俱乐部名称", "击杀数", "免费复活", "积分", "红数", "战力", "人数", "花费总丹", "四圣"],
                  tableData: e || [],
                  columnWidth: 78,
                  rowHeight: 37,
                  scale: 1,
                }));
            else {
              let t = [];
              (Object.values(e.memberInfo).forEach((l) => {
                var s, c;
                l.legionId ==
                  ((c = (s = b.gameData) == null ? void 0 : s.roleInfo) == null ? void 0 : c.role.legionId) &&
                  t.push([
                    l.name,
                    l.kill,
                    l.die,
                    l.revive + "/5",
                    l.score,
                    l.digGround,
                    l.dan,
                    parseFloat(l.kill / l.die).toFixed(2),
                  ]);
              }),
                (t = t.sort((l, s) => s[1] - l[1])),
                (n = {
                  x: I[0] + 20,
                  y: 20,
                  columns: 8,
                  rows: t ? t.length : 30,
                  headerData: ["名称", "击杀数", "死亡次数", "已复活次数", "积分", "刨地", "复活丹", "K/D"],
                  tableData: t || [],
                  columnWidth: 88,
                  rowHeight: 25,
                  scale: 1,
                }));
            }
            ke(i, n);
          }
        },
        ke = (e, n) => {
          var ue, fe;
          const l = {
              ...{
                columnWidth: 80,
                rowHeight: 25,
                headerBgColor: "#42b983",
                cellBgColor: "#ffffff",
                borderColor: "#333333",
                headerTextColor: "#ffffff",
                cellTextColor: "#373737",
                fontSize: 14,
                font: "Arial",
                scale: 1,
              },
              ...n,
            },
            {
              x: s,
              y: c,
              columns: u,
              rows: o,
              headerData: r,
              tableData: d,
              columnWidth: p,
              rowHeight: m,
              headerBgColor: v,
              cellBgColor: k,
              borderColor: B,
              headerTextColor: _,
              cellTextColor: q,
              fontSize: $,
              font: E,
              scale: z,
            } = l,
            L = window.innerWidth;
          let h = z;
          L < 768 ? (h = z * 0.7) : L < 1024 && (h = z * 0.85);
          let T = p * h;
          const g = m * h,
            D = $ * h,
            K = 1 * h;
          (e.save(), (e.strokeStyle = B), (e.lineWidth = K), e.strokeRect(s, c, u * T, (o + 1) * g));
          let M = s,
            ce = 20 * h,
            de = 20 * h;
          for (let x = 0; x < u; x++) {
            e.fillStyle = v;
            let y = x === 0 ? T + ce : T;
            ((y = x === 1 ? T - de : y),
              e.fillRect(M, c, y, g),
              e.strokeRect(M, c, y, g),
              (e.fillStyle = _),
              (e.font = `${D}px ${E}`),
              (e.textAlign = "center"),
              (e.textBaseline = "middle"),
              e.fillText(r[x] || "", M + y / 2, c + g / 2),
              (M += y));
          }
          for (let x = 0; x < o; x++) {
            M = s;
            for (let y = 0; y < u; y++) {
              let R = y === 0 ? T + ce : T;
              ((R = y === 1 ? T - de : R), (e.fillStyle = ((ue = d[x]) == null ? void 0 : ue[9]) || k));
              const J = M,
                Q = c + (x + 1) * g;
              (e.fillRect(J, Q, R, g),
                e.strokeRect(J, Q, R, g),
                (e.fillStyle = q),
                (e.font = `${D}px ${E}`),
                (e.textAlign = "center"),
                (e.textBaseline = "middle"),
                e.fillText(((fe = d[x]) == null ? void 0 : fe[y]) || "0", J + R / 2, Q + g / 2),
                (M += R));
            }
          }
          e.restore();
        },
        xe = (e, n, t, l = 1, s = 0, c = 0, u = {}) => {
          var T;
          const o = {
            boxWidth: 200,
            boxPadding: 10,
            bgColor: "rgba(0, 0, 0, 0.8)",
            borderColor: "#ffffff",
            borderWidth: 1,
            fontColor: "#ffffff",
            fontSize: 14,
            font: "Arial",
            gap: 10,
            ...u,
          };
          let r = "";
          if (typeof t == "object" && t !== null) {
            r = Object.entries(t).map(([D, K]) => `${D}: ${K}`).join(`
`);
            let g = t;
            r = `坐标:${g.id}
血量:${g.hP}/${g.maxHP}
类型:${g.typeName}
分数:${g.point}
所属俱乐部:${((T = C.value.legionInfo[g.belongsLegionId]) == null ? void 0 : T.name) || "无所属"}`;
          } else r = String(t || "无数据");
          const d = r.split(`
`),
            p = o.boxWidth * l,
            m = o.boxPadding * l,
            v = o.fontSize * l,
            k = o.borderWidth * l,
            B = o.gap * l,
            _ = v * 1.4,
            $ = d.length * _ + 2 * m,
            E = e * l + s,
            z = n * l + c;
          let L = E + B,
            h = z + B;
          (i.canvas.width / S,
            i.canvas.height / S,
            L + p > I[0] + 10 && (L = E - p - B),
            h + $ > I[1] + 20 && (h = z - $ - B),
            (L = Math.max(k, L)),
            (h = Math.max(k, h)),
            i.save(),
            (i.fillStyle = o.bgColor),
            i.fillRect(L - k, h - k, p + 2 * k, $ + 2 * k),
            (i.strokeStyle = o.borderColor),
            (i.lineWidth = k),
            i.strokeRect(L, h, p, $),
            (i.fillStyle = o.fontColor),
            (i.font = `${v}px ${o.font}`),
            (i.textBaseline = "top"),
            d.forEach((g, D) => {
              i.fillText(g, L + m, h + m + D * _);
            }),
            i.restore());
        };
      function ie(e) {
        const n = e.parentElement,
          t = n.clientWidth,
          l = n.clientHeight;
        ((e.width = t * S), (e.height = l * S), i.scale(S, S), Y());
      }
      const Le = () => {
          if (!b.selectedToken) {
            (A.warning("请先选择一个Token"), router.push("/tokens"));
            return;
          }
          try {
            const e = b.selectedToken.id,
              n = b.selectedToken.token;
            (b.createWebSocketConnection(e, n),
              A.info("正在建立 WebSocket 连接..."),
              setTimeout(async () => {
                if (b.getWebSocketStatus(e) === "connected") {
                  A.success("WebSocket 连接成功");
                  const l = await b.sendMessageWithPromise(e, "legion_getbattlefield", {}, 1e4);
                  re(l);
                }
              }, 2e3));
          } catch (e) {
            (console.error("WebSocket连接失败:", e), A.error("WebSocket连接失败"));
          }
        },
        re = async (e) => {
          if (b.selectedToken) {
            const n = b.selectedToken.id;
            if (b.getWebSocketStatus(b.selectedToken.id) !== "connected") {
              Le();
              return;
            }
            const l = `wss://xxz-xyzw-new.hortorgames.com/agent?p=${encodeURIComponent(b.selectedToken.token)}&e=x&sid2=${e == null ? void 0 : e.info.sid}&lang=chinese&sid2=${e == null ? void 0 : e.info.sid}`;
            ((N.value = e == null ? void 0 : e.info.battlefieldId),
              (w = new _e({ url: l, utils: null, hint: N.value, heartbeatMs: 5e3 })),
              (w.onConnect = async () => {
                try {
                  setTimeout(() => {
                    j.value = !0;
                    const s = w.send("war_enterbattlefield", { battlefieldId: N.value, useGzip: !0 });
                  }, 5e3);
                } catch (s) {
                  console.error(`初始请求盐场信息失败 [${n}]`, s);
                }
              }),
              w.setMessageListener((s) => {
                ((s == null ? void 0 : s.cmd) || "unknown").includes("war_getbattlefieldinfo") &&
                  (console.log(s.rawData), (le.value = s == null ? void 0 : s.rawData), ie(G.value));
              }),
              (w.onDisconnect = (s) => {
                (s.code === 1006 || s.reason, console.log(s));
              }),
              (w.onError = (s) => {
                console.log(s);
              }),
              w.init());
          }
        },
        ae = async () => {
          j.value
            ? (w.send("war_getbattlefieldinfo", { battlefieldId: N.value }), (oe.value = ge("")))
            : A.error("暂未进入战场,请稍后");
        };
      return (
        He(() => {
          re();
          const e = G.value;
          ((i = e.getContext("2d")),
            (F = () => ie(e)),
            F(),
            e.addEventListener("click", (n) => {
              const t = e.getBoundingClientRect(),
                l = n.clientX - t.left,
                s = n.clientY - t.top;
              ((i.font = "12px Arial"), (i.fillStyle = "rgb(0,0,0)"), Y(l, s, "click"));
            }),
            window.addEventListener("resize", F));
        }),
        $e(() => {
          window.removeEventListener("resize", F);
        }),
        (e, n) => {
          const t = pe("n-button"),
            l = pe("n-switch");
          return (
            De(),
            ze("div", Ee, [
              f("div", Oe, [
                f("div", Ne, [
                  n[3] || (n[3] = f("div", { class: "map-title-item" }, " 战场图示 ", -1)),
                  f("div", null, [
                    n[2] || (n[2] = f("span", null, "是否进入战场:", -1)),
                    O(
                      t,
                      { text: "", onClick: ae },
                      {
                        default: ee(() => [
                          f("span", { class: Re(Ae(be)) }, ve(j.value ? "已进入战场" : "重新进入战场"), 3),
                        ]),
                        _: 1,
                      },
                    ),
                    Z(" 当前时间-" + ve(oe.value), 1),
                  ]),
                ]),
                f("div", Fe, [f("canvas", { ref_key: "legionWarMapDom", ref: G, class: "mapCanvas" }, null, 512)]),
              ]),
              f("div", Ue, [
                n[10] ||
                  (n[10] = f(
                    "div",
                    { class: "legion-war-operation-title" },
                    [f("div", { class: "operation-title-item" }, " 操作面板 ")],
                    -1,
                  )),
                f("div", Ve, [
                  f("div", Xe, [
                    n[4] || (n[4] = f("div", null, " 占领布局 ", -1)),
                    f("div", null, [
                      O(l, { value: H.value, "onUpdate:value": [n[0] || (n[0] = (s) => (H.value = s)), ne] }, null, 8, [
                        "value",
                      ]),
                    ]),
                    n[5] || (n[5] = f("div", null, " 分布布局 ", -1)),
                  ]),
                  f("div", Ge, [
                    n[6] || (n[6] = f("div", null, " 战队战况 ", -1)),
                    f("div", null, [
                      O(l, { value: X.value, "onUpdate:value": [n[1] || (n[1] = (s) => (X.value = s)), ne] }, null, 8, [
                        "value",
                      ]),
                    ]),
                    n[7] || (n[7] = f("div", null, " 个人战况 ", -1)),
                  ]),
                  f("div", Ye, [
                    O(
                      t,
                      { type: "primary", onClick: ae, disabled: !j.value, style: { padding: "12px" } },
                      { default: ee(() => [...(n[8] || (n[8] = [Z(" 拉取数据(需进入战场后) ", -1)]))]), _: 1 },
                      8,
                      ["disabled"],
                    ),
                  ]),
                  f("div", qe, [
                    O(
                      t,
                      { type: "primary", onClick: we, style: { padding: "12px" } },
                      { default: ee(() => [...(n[9] || (n[9] = [Z(" 发送各战队免费复活到战队频道 ", -1)]))]), _: 1 },
                    ),
                  ]),
                ]),
              ]),
            ])
          );
        }
      );
    },
  },
  no = je(Ke, [["__scopeId", "data-v-1892cc19"]]);
export { no as default };
