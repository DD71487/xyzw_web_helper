import {
  k as C,
  x as y,
  s as x,
  r as v,
  z as I,
  e as k,
  w as s,
  u as l,
  aU as R,
  a as n,
  b as r,
  A as F,
  i as g,
  N as S,
  Q as U,
  au as i,
  aV as d,
  a7 as V,
  a6 as z,
  h as b,
  aZ as B,
} from "./index-UoU16364.js";
import { C as L } from "./CloudUpload-DBucip-_.js";
import { _ as h } from "./_plugin-vue_export-helper-DlAUqK2U.js";
const q = { class: "form-actions" },
  A = { class: "optional-fields" },
  M = C({
    __name: "url",
    emits: ["cancel", "ok"],
    setup(O, { emit: _ }) {
      const c = y(),
        u = x(),
        m = v(),
        p = v(!1),
        f = _,
        w = () => {
          f("cancel");
        },
        e = I({ name: "", url: "", server: "", wsUrl: "" }),
        N = {
          name: [
            { required: !0, message: "请输入角色名称", trigger: "blur" },
            { min: 1, max: 50, message: "名称长度应在1到50个字符之间", trigger: "blur" },
          ],
          url: [
            { required: !0, message: "请输入Token获取地址", trigger: "blur" },
            { type: "url", message: "请输入有效的URL地址", trigger: "blur" },
          ],
        },
        T = async () => {
          if (m.value) {
            try {
              await m.value.validate();
            } catch {
              u.error("请修正表单中的错误后再提交");
              return;
            }
            p.value = !0;
            try {
              const o = await B.get(e.url);
              if (o.status === 200 && o.data && o.data.token) {
                const a = {
                  name: e.name,
                  token: o.data.token,
                  server: e.server || "未知",
                  wsUrl: e.wsUrl || "",
                  id: Date.now().toString(),
                  sourceUrl: e.url,
                  importMethod: "url",
                };
                (c.addToken(a),
                  u.success("Token添加成功"),
                  (e.name = ""),
                  (e.url = ""),
                  (e.server = ""),
                  (e.wsUrl = ""),
                  f("ok"));
              } else u.error("接口返回数据格式不正确，未找到token字段");
            } catch {
              u.error("获取Token失败，请检查URL地址或网络连接");
            } finally {
              p.value = !1;
            }
          }
        };
      return (o, a) => (
        b(),
        k(
          l(R),
          { ref_key: "urlFormRef", ref: m, model: e, rules: N, "label-placement": "top", size: "large" },
          {
            default: s(() => [
              n("div", q, [
                r(
                  l(U),
                  { type: "primary", size: "large", block: "", loading: p.value, onClick: T },
                  {
                    icon: s(() => [r(l(S), null, { default: s(() => [r(l(L))]), _: 1 })]),
                    default: s(() => [a[4] || (a[4] = g(" 获取并添加Token ", -1))]),
                    _: 1,
                  },
                  8,
                  ["loading"],
                ),
                l(c).hasTokens
                  ? (b(),
                    k(
                      l(U),
                      { key: 0, size: "large", block: "", onClick: w },
                      { default: s(() => [...(a[5] || (a[5] = [g(" 取消 ", -1)]))]), _: 1 },
                    ))
                  : F("", !0),
              ]),
              r(
                l(d),
                { label: "游戏角色名称", path: "name" },
                {
                  default: s(() => [
                    r(
                      l(i),
                      {
                        value: e.name,
                        "onUpdate:value": a[0] || (a[0] = (t) => (e.name = t)),
                        placeholder: "例如：主号战士",
                        clearable: "",
                      },
                      null,
                      8,
                      ["value"],
                    ),
                  ]),
                  _: 1,
                },
              ),
              r(
                l(d),
                { label: "Token获取地址", path: "url" },
                {
                  feedback: s(() => [
                    ...(a[6] ||
                      (a[6] = [
                        n(
                          "div",
                          { class: "form-tips" },
                          [
                            n("span", { class: "form-tip" }, " 接口应返回包含token字段的JSON数据 "),
                            n(
                              "span",
                              { class: "form-tip cors-tip" },
                              " 注意：如果是跨域URL，服务器需要支持CORS，否则会被浏览器阻止 ",
                            ),
                          ],
                          -1,
                        ),
                      ])),
                  ]),
                  default: s(() => [
                    r(
                      l(i),
                      {
                        value: e.url,
                        "onUpdate:value": a[1] || (a[1] = (t) => (e.url = t)),
                        placeholder: "输入API接口地址...",
                        clearable: "",
                      },
                      null,
                      8,
                      ["value"],
                    ),
                  ]),
                  _: 1,
                },
              ),
              r(l(z), null, {
                default: s(() => [
                  r(
                    l(V),
                    { title: "角色详情 (可选)", name: "optional" },
                    {
                      default: s(() => [
                        n("div", A, [
                          r(
                            l(d),
                            { label: "服务器" },
                            {
                              default: s(() => [
                                r(
                                  l(i),
                                  {
                                    value: e.server,
                                    "onUpdate:value": a[2] || (a[2] = (t) => (e.server = t)),
                                    placeholder: "服务器名称",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          r(
                            l(d),
                            { label: "自定义连接地址" },
                            {
                              default: s(() => [
                                r(
                                  l(i),
                                  {
                                    value: e.wsUrl,
                                    "onUpdate:value": a[3] || (a[3] = (t) => (e.wsUrl = t)),
                                    placeholder: "留空使用默认连接",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                        ]),
                      ]),
                      _: 1,
                    },
                  ),
                ]),
                _: 1,
              }),
            ]),
            _: 1,
          },
          8,
          ["model"],
        )
      );
    },
  }),
  Q = h(M, [["__scopeId", "data-v-16a36d9b"]]);
export { Q as default };
