const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f || (m.f = ["assets/index-UoU16364.js", "assets/index-CM9NKNN3.css"]),
) => i.map((i) => d[i]);
import {
  x as ge,
  s as be,
  r as B,
  p as M,
  G as f,
  y as we,
  c as V,
  b as l,
  w as o,
  d as m,
  h as A,
  a as n,
  A as S,
  aK as Ae,
  u as L,
  e as J,
  i as c,
  t as v,
  F as ke,
  g as He,
  E as Ce,
  an as E,
} from "./index-UoU16364.js";
import { _ as Ve } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { A as Se } from "./AlertCircleOutline-BnovXsGQ.js";
const Oe = { class: "message-tester" },
  Be = { class: "space-y-4" },
  Me = { key: 0 },
  xe = { class: "grid grid-cols-2 gap-2" },
  Ne = { class: "grid grid-cols-2 gap-2" },
  ze = { class: "space-y-2" },
  De = { class: "flex items-center justify-between w-full" },
  je = { class: "flex items-center gap-2" },
  Te = { class: "message-history max-h-96 overflow-y-auto" },
  he = { class: "flex justify-between items-start mb-2" },
  Le = { class: "font-semibold" },
  Je = { class: "text-sm text-gray-500 ml-2" },
  $e = { key: 0, class: "flex flex-wrap items-center gap-1 mt-1" },
  Ue = { class: "flex items-center gap-1" },
  qe = { key: 0, class: "text-sm mb-2" },
  Ie = { class: "mb-2" },
  Re = { class: "text-xs text-gray-600 mb-1" },
  Ee = { class: "text-sm bg-gray-50 p-2 rounded border max-h-20 overflow-hidden message-preview" },
  Ze = { class: "mt-2" },
  Ge = { class: "json-display-container" },
  We = { class: "json-header" },
  Fe = { class: "json-content formatted" },
  Pe = { class: "json-display-container" },
  Ke = { class: "json-header" },
  Qe = { class: "json-content raw" },
  Xe = { class: "json-display-container" },
  Ye = { class: "json-header" },
  et = { class: "json-content compact" },
  tt = { key: 0, class: "text-center text-gray-500 p-8" },
  st = {
    __name: "MessageTester",
    setup(nt) {
      const _ = ge(),
        u = be(),
        k = B(""),
        x = B("{}"),
        g = B([]);
      B(0);
      const N = B(null),
        Z = (e) => {
          if (!e || typeof e != "object") return {};
          const t = e._raw || e,
            s = {};
          return (
            typeof t.seq == "number" && (s.seq = t.seq),
            typeof t.ack == "number" && (s.ack = t.ack),
            typeof t.resp == "number" && (s.resp = t.resp),
            typeof t.time == "number" && (s.time = t.time),
            s
          );
        },
        G = M(() => _.gameTokens.map((e) => ({ label: e.name, value: e.id }))),
        z = M(() => (f.value ? _.getWebSocketStatus(f.value) : "disconnected")),
        W = M(() => {
          switch (z.value) {
            case "connected":
              return "success";
            case "connecting":
              return "warning";
            case "error":
              return "error";
            default:
              return "default";
          }
        }),
        F = M(() => {
          switch (z.value) {
            case "connected":
              return "🟢 已连接";
            case "connecting":
              return "🟡 连接中";
            case "error":
              return "🔴 连接错误";
            default:
              return "⚪ 未连接";
          }
        }),
        b = M(() => f.value && z.value === "connected"),
        P = () => {
          if (!f.value) {
            u.error("请先选择一个token");
            return;
          }
          const e = _.gameTokens.find((t) => t.id === f.value);
          if (e) {
            console.log("🔧 MessageTester: 开始连接WebSocket", {
              tokenId: f.value,
              tokenName: e.name,
              hasToken: !!e.token,
            });
            try {
              (_.selectToken(f.value), u.success("正在建立WebSocket连接..."));
            } catch (t) {
              (console.error("❌ MessageTester: WebSocket连接失败", t), u.error("WebSocket连接失败: " + t.message));
            }
          } else u.error("找不到选中的token");
        },
        K = async (e) => {
          const { g_utils: t } = await E(
              async () => {
                const { g_utils: r } = await import("./index-UoU16364.js").then((i) => i.b4);
                return { g_utils: r };
              },
              __vite__mapDeps([0, 1]),
            ),
            s = e.target.files[0];
          if (!s) return;
          const a = new FileReader();
          (a.readAsArrayBuffer(s),
            (a.onload = (r) => {
              const i = event.target.result,
                C = new Uint8Array(i);
              t.bon.decode(C);
              const w = t.parse(C),
                y = t.bon.decode(w.body);
              (console.log(w, y),
                H(w.cmd, { testType: "BIN文件解码", input: Array.from(y), output: y, status: "success" }, w.cmd));
            }),
            (a.onerror = () => {
              u.error("读取文件失败，请重试");
            }));
        },
        Q = async () => {
          try {
            const { g_utils: e } = await E(
                async () => {
                  const { g_utils: s } = await import("./index-UoU16364.js").then((a) => a.b4);
                  return { g_utils: s };
                },
                __vite__mapDeps([0, 1]),
              ),
              t = new Uint8Array([8, 2, 5, 4, 114, 111, 108, 101]);
            if (
              (console.log("🧪 BON解码测试开始"),
              console.log("🔍 g_utils可用性检查:", {
                hasGUtils: !!e,
                hasBon: !!(e && e.bon),
                hasBonDecode: !!(e && e.bon && e.bon.decode),
              }),
              e && e.bon && e.bon.decode)
            ) {
              console.log("📥 测试数据:", t);
              const s = e.bon.decode(t);
              (console.log("✅ BON解码成功:", s),
                u.success(`BON解码器工作正常: ${JSON.stringify(s)}`),
                H(
                  "test",
                  { testType: "BON解码测试", input: Array.from(t), output: s, status: "success" },
                  "bon_decode_test",
                ));
            } else
              (console.error("❌ BON解码器不可用"),
                u.error("BON解码器不可用"),
                H("test", { testType: "BON解码测试", error: "BON解码器不可用", status: "error" }, "bon_decode_test"));
          } catch (e) {
            (console.error("❌ BON解码测试失败:", e),
              u.error("BON解码测试失败: " + e.message),
              H("test", { testType: "BON解码测试", error: e.message, status: "error" }, "bon_decode_test"));
          }
        },
        H = (e, t, s = null, a = {}) => {
          if (e !== "test" && (s === "_sys/ack" || s === "heartbeat")) return null;
          const r = { ...Z(t), ...a },
            i = { type: e, timestamp: new Date().toISOString(), cmd: s, data: t, meta: r };
          return (g.value.unshift(i), g.value.length > 50 && (g.value = g.value.slice(0, 50)), i);
        },
        X = () => {
          if (!b.value) return;
          _.sendHeartbeat(f.value) ? u.success("心跳消息已发送") : u.error("心跳消息发送失败");
        },
        Y = () => {
          if (!b.value) return;
          _.sendGetRoleInfo(f.value)
            ? (H("sent", { cmd: "role_getroleinfo" }, "role_getroleinfo"), u.success("角色信息请求已发送"))
            : u.error("角色信息请求发送失败");
        },
        ee = () => {
          if (!b.value) return;
          _.sendGameMessage(f.value, "system_getdatabundlever", { isAudit: !1 })
            ? (H("sent", { cmd: "system_getdatabundlever" }, "system_getdatabundlever"),
              u.success("数据版本请求已发送"))
            : u.error("数据版本请求发送失败");
        },
        te = () => {
          if (!b.value) return;
          _.sendGameMessage(f.value, "system_signinreward", {})
            ? (H("sent", { cmd: "system_signinreward" }, "system_signinreward"), u.success("签到请求已发送"))
            : u.error("签到请求发送失败");
        },
        se = () => {
          if (!(!b.value || !k.value))
            try {
              const e = JSON.parse(x.value || "{}");
              let t = null;
              const s = {};
              _.sendGameMessage(f.value, k.value, e, {
                onSent: (r = {}) => {
                  const i = {};
                  (typeof r.seq == "number" && (i.seq = r.seq),
                    typeof r.ack == "number" && (i.ack = r.ack),
                    typeof r.time == "number" && (i.time = r.time),
                    t ? (t.meta = { ...t.meta, ...i }) : Object.keys(i).length > 0 && Object.assign(s, i));
                },
              })
                ? ((t = H("sent", { cmd: k.value, body: e }, k.value, s) || null),
                  u.success(`自定义消息 ${k.value} 已发送`),
                  (k.value = ""),
                  (x.value = "{}"))
                : u.error("自定义消息发送失败");
            } catch (e) {
              u.error("消息体JSON格式错误: " + e.message);
            }
        },
        $ = (e) => new Date(e).toLocaleTimeString(),
        j = (e) => {
          var s, a;
          if (!e) return;
          if (((s = e.meta) == null ? void 0 : s.seq) !== void 0) return e.meta.seq;
          const t = ((a = e.data) == null ? void 0 : a._raw) || e.data;
          return typeof (t == null ? void 0 : t.seq) == "number" ? t.seq : void 0;
        },
        T = (e) => {
          var s, a;
          if (!e) return;
          if (((s = e.meta) == null ? void 0 : s.ack) !== void 0) return e.meta.ack;
          const t = ((a = e.data) == null ? void 0 : a._raw) || e.data;
          return typeof (t == null ? void 0 : t.ack) == "number" ? t.ack : void 0;
        },
        ne = (e) => j(e) !== void 0 || T(e) !== void 0,
        oe = (e) =>
          e
            ? e.includes("error") || e.includes("fail")
              ? "error"
              : e.includes("resp") || e.includes("response")
                ? "success"
                : e.includes("get") || e.includes("info")
                  ? "info"
                  : e.includes("send") || e.includes("start")
                    ? "primary"
                    : "default"
            : "default",
        U = (e) => {
          try {
            const t = JSON.stringify(e),
              s = new TextEncoder().encode(t).length;
            return s < 1024
              ? `${s}B`
              : s < 1024 * 1024
                ? `${(s / 1024).toFixed(1)}KB`
                : `${(s / 1024 / 1024).toFixed(1)}MB`;
          } catch {
            return "未知大小";
          }
        },
        re = (e) => {
          var t, s, a, r;
          if (!e) return "空数据";
          try {
            let i = e;
            ((t = e._raw) != null && t.decodedBody) || e.decodedBody
              ? (i = ((s = e._raw) == null ? void 0 : s.decodedBody) || e.decodedBody)
              : (((a = e._raw) != null && a.rawData) || e.rawData) &&
                (i = ((r = e._raw) == null ? void 0 : r.rawData) || e.rawData);
            const C = JSON.stringify(i);
            return C.length > 150 ? C.substring(0, 150) + "..." : C;
          } catch {
            return "数据解析失败";
          }
        },
        le = () => {
          ((g.value = []), (N.value = null), u.success("消息历史已清空"));
        },
        ae = () => {
          try {
            const e = { exportTime: new Date().toISOString(), tokenId: f.value, messages: g.value },
              t = JSON.stringify(e, null, 2),
              s = new Blob([t], { type: "application/json" }),
              a = URL.createObjectURL(s),
              r = document.createElement("a");
            ((r.href = a),
              (r.download = `message-history-${new Date().toISOString().slice(0, 19).replace(/:/g, "-")}.json`),
              document.body.appendChild(r),
              r.click(),
              document.body.removeChild(r),
              URL.revokeObjectURL(a),
              u.success("消息历史已导出"));
          } catch (e) {
            u.error("导出失败: " + e.message);
          }
        },
        O = async (e) => {
          try {
            (await navigator.clipboard.writeText(e), u.success("已复制到剪贴板"));
          } catch {
            const s = document.createElement("textarea");
            ((s.value = e),
              document.body.appendChild(s),
              s.select(),
              document.execCommand("copy"),
              document.body.removeChild(s),
              u.success("已复制到剪贴板"));
          }
        },
        ie = (e) => {
          const t = `[${e.type.toUpperCase()}] ${$(e.timestamp)} - ${e.cmd || "无命令"}
${JSON.stringify(e.data, null, 2)}`;
          O(t);
        },
        de = (e) => {
          O(JSON.stringify(e, null, 2));
        },
        ce = (e) => {
          O(R(e));
        },
        ue = (e) => {
          O(JSON.stringify(e, null, 2));
        },
        fe = (e) => {
          O(JSON.stringify(e));
        },
        q = (e) => {
          if (!e) return "null";
          if (Array.isArray(e)) return `[Array: ${e.length} items]`;
          if (e instanceof Uint8Array) return `[Uint8Array: ${e.length} bytes]`;
          if (typeof e == "object" && e.constructor === Object) {
            const t = Object.keys(e);
            if (t.every((s) => !isNaN(parseInt(s)))) return `[NumericObject: ${t.length} entries]`;
          }
          return "[Unknown format]";
        },
        I = (e) => {
          if (!e) return !1;
          if (Array.isArray(e) || e instanceof Uint8Array) return !0;
          if (typeof e == "object" && e.constructor === Object) {
            const t = Object.keys(e);
            return t.length > 0 && t.every((s) => !isNaN(parseInt(s)));
          }
          return !1;
        },
        R = (e, t = 10, s = 0) => {
          try {
            if (!e) return "null";
            if (s > t) return "[超出最大深度限制]";
            let a = e;
            const r = e._raw || e;
            if (r.decodedBody || e.decodedBody) {
              const y = r.decodedBody || e.decodedBody,
                p = r.body || e.body;
              e._raw
                ? (a = { ...e, _raw: { ...e._raw, body: y, _originalBody: q(p), _note: "body已自动BON解码" } })
                : (a = { ...e, body: y, _originalBody: q(p), _note: "body已自动BON解码" });
            } else if (r.rawData || e.rawData) {
              const y = r.rawData || e.rawData;
              e._raw
                ? (a = { ...e, _raw: { ...e._raw, body: y, _note: "body已使用rawData解码" } })
                : (a = { ...e, body: y, _note: "body已使用rawData解码" });
            } else
              ((r.body && I(r.body)) || (e.body && I(e.body))) &&
                (a = { ...e, _note: "body为原始数据，可能需要BON解码" });
            const i = new WeakSet();
            return JSON.stringify(
              a,
              (y, p) => {
                if (typeof p == "object" && p !== null) {
                  if (i.has(p)) return "[循环引用]";
                  i.add(p);
                }
                return (typeof p == "string" || Array.isArray(p), p);
              },
              2,
            );
          } catch (a) {
            return `[JSON序列化错误: ${a.message}]`;
          }
        };
      return (
        we(
          () => _.wsConnections,
          (e) => {
            if (!f.value || !e[f.value]) return;
            const t = e[f.value];
            if (t.lastMessage) {
              const s = t.lastMessage;
              if (N.value && N.value.timestamp === s.timestamp) return;
              const a = s.data || s,
                r = a.cmd || s.cmd;
              r && r !== "_sys/ack" && r !== "heartbeat" && (H("received", a, r), (N.value = s));
            }
          },
          { deep: !0 },
        ),
        (e, t) => {
          const s = m("n-select"),
            a = m("n-tag"),
            r = m("n-button"),
            i = m("n-icon"),
            C = m("n-popover"),
            w = m("n-divider"),
            y = m("n-input"),
            p = m("n-space"),
            h = m("n-tab-pane"),
            pe = m("n-tabs"),
            ye = m("n-collapse-item"),
            me = m("n-collapse"),
            ve = m("n-card");
          return (
            A(),
            V("div", Oe, [
              l(
                ve,
                { title: "消息加解密测试", class: "mb-4" },
                {
                  default: o(() => [
                    n("div", Be, [
                      n("div", null, [
                        l(
                          s,
                          {
                            value: L(f),
                            "onUpdate:value": t[0] || (t[0] = (d) => (Ae(f) ? (f.value = d) : null)),
                            options: G.value,
                            placeholder: "选择要测试的游戏Token",
                            class: "w-full",
                          },
                          null,
                          8,
                          ["value", "options"],
                        ),
                      ]),
                      L(f)
                        ? (A(),
                          V("div", Me, [
                            l(a, { type: W.value }, { default: o(() => [c(v(F.value), 1)]), _: 1 }, 8, ["type"]),
                            z.value !== "connected"
                              ? (A(),
                                J(
                                  r,
                                  { key: 0, type: "primary", size: "small", class: "ml-2", onClick: P },
                                  { default: o(() => [...(t[3] || (t[3] = [c(" 连接WebSocket ", -1)]))]), _: 1 },
                                ))
                              : S("", !0),
                            l(
                              r,
                              { type: "info", size: "small", class: "ml-2", onClick: Q },
                              { default: o(() => [...(t[4] || (t[4] = [c(" 🔓 测试BON解码 ", -1)]))]), _: 1 },
                            ),
                          ]))
                        : S("", !0),
                      l(
                        w,
                        { "title-placement": "left" },
                        {
                          default: o(() => [
                            t[6] || (t[6] = c(" bin文件消息测试 ", -1)),
                            l(
                              C,
                              { placement: "right", trigger: "hover" },
                              {
                                trigger: o(() => [l(i, { depth: 1 }, { default: o(() => [l(L(Se))]), _: 1 })]),
                                default: o(() => [
                                  t[5] || (t[5] = n("div", { class: "large-text" }, "用于方便抓包后分析bin文件", -1)),
                                ]),
                                _: 1,
                              },
                            ),
                          ]),
                          _: 1,
                        },
                      ),
                      n("div", xe, [
                        n("input", { type: "file", id: "binFileInput", accept: ".bin", onChange: K }, null, 32),
                      ]),
                      l(
                        w,
                        { "title-placement": "left" },
                        { default: o(() => [...(t[7] || (t[7] = [c(" 预设消息测试 ", -1)]))]), _: 1 },
                      ),
                      n("div", Ne, [
                        l(
                          r,
                          { disabled: !b.value, onClick: X },
                          { default: o(() => [...(t[8] || (t[8] = [c(" 💗 发送心跳 ", -1)]))]), _: 1 },
                          8,
                          ["disabled"],
                        ),
                        l(
                          r,
                          { disabled: !b.value, onClick: Y },
                          { default: o(() => [...(t[9] || (t[9] = [c(" 👤 获取角色信息 ", -1)]))]), _: 1 },
                          8,
                          ["disabled"],
                        ),
                        l(
                          r,
                          { disabled: !b.value, onClick: ee },
                          { default: o(() => [...(t[10] || (t[10] = [c(" 📦 获取数据版本 ", -1)]))]), _: 1 },
                          8,
                          ["disabled"],
                        ),
                        l(
                          r,
                          { disabled: !b.value, onClick: te },
                          { default: o(() => [...(t[11] || (t[11] = [c(" 📅 签到 ", -1)]))]), _: 1 },
                          8,
                          ["disabled"],
                        ),
                      ]),
                      l(
                        w,
                        { "title-placement": "left" },
                        { default: o(() => [...(t[12] || (t[12] = [c(" 自定义消息 ", -1)]))]), _: 1 },
                      ),
                      n("div", ze, [
                        l(
                          y,
                          {
                            value: k.value,
                            "onUpdate:value": t[1] || (t[1] = (d) => (k.value = d)),
                            placeholder: "命令 (例如: role_getroleinfo)",
                            class: "w-full",
                          },
                          null,
                          8,
                          ["value"],
                        ),
                        l(
                          y,
                          {
                            value: x.value,
                            "onUpdate:value": t[2] || (t[2] = (d) => (x.value = d)),
                            type: "textarea",
                            placeholder: '消息体 JSON (例如: {"clientVersion": "1.65.3-wx"})',
                            rows: 3,
                            class: "w-full",
                          },
                          null,
                          8,
                          ["value"],
                        ),
                        l(
                          r,
                          { disabled: !b.value || !k.value, type: "primary", onClick: se },
                          { default: o(() => [...(t[13] || (t[13] = [c(" 🚀 发送自定义消息 ", -1)]))]), _: 1 },
                          8,
                          ["disabled"],
                        ),
                      ]),
                      l(
                        w,
                        { "title-placement": "left" },
                        {
                          default: o(() => [
                            n("div", De, [
                              t[18] || (t[18] = n("span", null, "消息历史", -1)),
                              n("div", je, [
                                l(
                                  r,
                                  {
                                    size: "small",
                                    type: "error",
                                    secondary: "",
                                    onClick: le,
                                    disabled: g.value.length === 0,
                                  },
                                  {
                                    default: o(() => [
                                      l(
                                        i,
                                        { size: "14", class: "mr-1" },
                                        {
                                          default: o(() => [
                                            ...(t[14] ||
                                              (t[14] = [
                                                n(
                                                  "svg",
                                                  { viewBox: "0 0 24 24" },
                                                  [
                                                    n("path", {
                                                      fill: "currentColor",
                                                      d: "M19,4H15.5L14.5,3H9.5L8.5,4H5V6H19M6,19A2,2 0 0,0 8,21H16A2,2 0 0,0 18,19V7H6V19Z",
                                                    }),
                                                  ],
                                                  -1,
                                                ),
                                              ])),
                                          ]),
                                          _: 1,
                                        },
                                      ),
                                      t[15] || (t[15] = c(" 清空 ", -1)),
                                    ]),
                                    _: 1,
                                  },
                                  8,
                                  ["disabled"],
                                ),
                                l(
                                  r,
                                  {
                                    size: "small",
                                    type: "info",
                                    secondary: "",
                                    onClick: ae,
                                    disabled: g.value.length === 0,
                                  },
                                  {
                                    default: o(() => [
                                      l(
                                        i,
                                        { size: "14", class: "mr-1" },
                                        {
                                          default: o(() => [
                                            ...(t[16] ||
                                              (t[16] = [
                                                n(
                                                  "svg",
                                                  { viewBox: "0 0 24 24" },
                                                  [
                                                    n("path", {
                                                      fill: "currentColor",
                                                      d: "M14,2H6A2,2 0 0,0 4,4V20A2,2 0 0,0 6,22H18A2,2 0 0,0 20,20V8L14,2M18,20H6V4H13V9H18V20Z",
                                                    }),
                                                  ],
                                                  -1,
                                                ),
                                              ])),
                                          ]),
                                          _: 1,
                                        },
                                      ),
                                      t[17] || (t[17] = c(" 导出 ", -1)),
                                    ]),
                                    _: 1,
                                  },
                                  8,
                                  ["disabled"],
                                ),
                              ]),
                            ]),
                          ]),
                          _: 1,
                        },
                      ),
                      n("div", Te, [
                        (A(!0),
                        V(
                          ke,
                          null,
                          He(
                            g.value,
                            (d, _e) => (
                              A(),
                              V(
                                "div",
                                {
                                  key: _e,
                                  class: Ce([
                                    "message-item p-3 mb-2 rounded border",
                                    d.type === "sent"
                                      ? "bg-blue-50 border-blue-200"
                                      : d.type === "test"
                                        ? "bg-purple-50 border-purple-200"
                                        : "bg-green-50 border-green-200",
                                  ]),
                                },
                                [
                                  n("div", he, [
                                    n("div", null, [
                                      n("span", Le, [
                                        c(
                                          v(d.type === "sent" ? "📤 发送" : d.type === "test" ? "🧪 测试" : "📨 接收") +
                                            " ",
                                          1,
                                        ),
                                        n("span", Je, v($(d.timestamp)), 1),
                                      ]),
                                      ne(d)
                                        ? (A(),
                                          V("div", $e, [
                                            j(d) !== void 0
                                              ? (A(),
                                                J(
                                                  a,
                                                  { key: 0, size: "tiny", type: "info" },
                                                  { default: o(() => [c(" SEQ " + v(j(d)), 1)]), _: 2 },
                                                  1024,
                                                ))
                                              : S("", !0),
                                            T(d) !== void 0
                                              ? (A(),
                                                J(
                                                  a,
                                                  { key: 1, size: "tiny", type: "warning" },
                                                  { default: o(() => [c(" ACK " + v(T(d)), 1)]), _: 2 },
                                                  1024,
                                                ))
                                              : S("", !0),
                                          ]))
                                        : S("", !0),
                                    ]),
                                    n("div", Ue, [
                                      l(
                                        r,
                                        { size: "tiny", type: "tertiary", onClick: (D) => ie(d), title: "复制消息" },
                                        {
                                          default: o(() => [
                                            l(
                                              i,
                                              { size: "12" },
                                              {
                                                default: o(() => [
                                                  ...(t[19] ||
                                                    (t[19] = [
                                                      n(
                                                        "svg",
                                                        { viewBox: "0 0 24 24" },
                                                        [
                                                          n("path", {
                                                            fill: "currentColor",
                                                            d: "M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",
                                                          }),
                                                        ],
                                                        -1,
                                                      ),
                                                    ])),
                                                ]),
                                                _: 1,
                                              },
                                            ),
                                          ]),
                                          _: 1,
                                        },
                                        8,
                                        ["onClick"],
                                      ),
                                      l(
                                        r,
                                        {
                                          size: "tiny",
                                          type: "tertiary",
                                          onClick: (D) => de(d.data),
                                          title: "复制JSON数据",
                                        },
                                        {
                                          default: o(() => [
                                            l(
                                              i,
                                              { size: "12" },
                                              {
                                                default: o(() => [
                                                  ...(t[20] ||
                                                    (t[20] = [
                                                      n(
                                                        "svg",
                                                        { viewBox: "0 0 24 24" },
                                                        [
                                                          n("path", {
                                                            fill: "currentColor",
                                                            d: "M5,3H7V5H5V10A2,2 0 0,1 3,8V6A2,2 0 0,1 5,4V3M19,3V4A2,2 0 0,1 21,6V8A2,2 0 0,1 19,10V5H17V3H19M16,12A2,2 0 0,1 18,10H20A2,2 0 0,1 22,12A2,2 0 0,1 20,14H18A2,2 0 0,1 16,12M20,12V14H18V12H20M4,10A2,2 0 0,1 6,12A2,2 0 0,1 4,14H2A2,2 0 0,1 0,12A2,2 0 0,1 2,10H4M2,12V10H4V12H2M5,19V21H7V19H5V14A2,2 0 0,1 3,16V18A2,2 0 0,1 5,20V19M19,19V20A2,2 0 0,1 17,18V16A2,2 0 0,1 19,14V19H21V21H19Z",
                                                          }),
                                                        ],
                                                        -1,
                                                      ),
                                                    ])),
                                                ]),
                                                _: 1,
                                              },
                                            ),
                                          ]),
                                          _: 1,
                                        },
                                        8,
                                        ["onClick"],
                                      ),
                                    ]),
                                  ]),
                                  d.cmd
                                    ? (A(),
                                      V("div", qe, [
                                        t[21] || (t[21] = n("strong", null, "命令:", -1)),
                                        l(
                                          a,
                                          { size: "small", type: oe(d.cmd) },
                                          { default: o(() => [c(v(d.cmd), 1)]), _: 2 },
                                          1032,
                                          ["type"],
                                        ),
                                      ]))
                                    : S("", !0),
                                  n("div", Ie, [
                                    n("div", Re, " 消息预览 (" + v(U(d.data)) + "): ", 1),
                                    n("div", Ee, v(re(d.data)), 1),
                                  ]),
                                  n("div", Ze, [
                                    l(
                                      me,
                                      null,
                                      {
                                        default: o(() => [
                                          l(
                                            ye,
                                            { title: `详细数据 (${U(d.data)})`, name: "detail" },
                                            {
                                              default: o(() => [
                                                l(
                                                  pe,
                                                  { type: "card", size: "small", animated: "" },
                                                  {
                                                    default: o(() => [
                                                      l(
                                                        h,
                                                        { name: "formatted", "display-directive": "show:lazy" },
                                                        {
                                                          tab: o(() => [
                                                            l(
                                                              i,
                                                              { size: "14", class: "mr-1" },
                                                              {
                                                                default: o(() => [
                                                                  ...(t[22] ||
                                                                    (t[22] = [
                                                                      n(
                                                                        "svg",
                                                                        { viewBox: "0 0 24 24" },
                                                                        [
                                                                          n("path", {
                                                                            fill: "currentColor",
                                                                            d: "M14,17H7V15H14M17,13H7V11H17M17,9H7V7H17M19,3H5C3.89,3 3,3.89 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5C3.89,3 3,3.89 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5A2,2 0 0,0 19,3Z",
                                                                          }),
                                                                        ],
                                                                        -1,
                                                                      ),
                                                                    ])),
                                                                ]),
                                                                _: 1,
                                                              },
                                                            ),
                                                            t[23] || (t[23] = c(" 格式化显示 ", -1)),
                                                          ]),
                                                          default: o(() => [
                                                            n("div", Ge, [
                                                              n("div", We, [
                                                                l(
                                                                  p,
                                                                  { size: "small" },
                                                                  {
                                                                    default: o(() => [
                                                                      l(
                                                                        a,
                                                                        { size: "small", type: "info" },
                                                                        {
                                                                          default: o(() => [
                                                                            ...(t[24] || (t[24] = [c("格式化", -1)])),
                                                                          ]),
                                                                          _: 1,
                                                                        },
                                                                      ),
                                                                      l(
                                                                        r,
                                                                        {
                                                                          size: "tiny",
                                                                          type: "primary",
                                                                          ghost: "",
                                                                          onClick: (D) => ce(d.data),
                                                                          title: "复制格式化JSON",
                                                                        },
                                                                        {
                                                                          default: o(() => [
                                                                            l(
                                                                              i,
                                                                              { size: "12", class: "mr-1" },
                                                                              {
                                                                                default: o(() => [
                                                                                  ...(t[25] ||
                                                                                    (t[25] = [
                                                                                      n(
                                                                                        "svg",
                                                                                        { viewBox: "0 0 24 24" },
                                                                                        [
                                                                                          n("path", {
                                                                                            fill: "currentColor",
                                                                                            d: "M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",
                                                                                          }),
                                                                                        ],
                                                                                        -1,
                                                                                      ),
                                                                                    ])),
                                                                                ]),
                                                                                _: 1,
                                                                              },
                                                                            ),
                                                                            t[26] || (t[26] = c(" 复制 ", -1)),
                                                                          ]),
                                                                          _: 1,
                                                                        },
                                                                        8,
                                                                        ["onClick"],
                                                                      ),
                                                                    ]),
                                                                    _: 2,
                                                                  },
                                                                  1024,
                                                                ),
                                                              ]),
                                                              n("pre", Fe, v(R(d.data)), 1),
                                                            ]),
                                                          ]),
                                                          _: 2,
                                                        },
                                                        1024,
                                                      ),
                                                      l(
                                                        h,
                                                        { name: "raw", "display-directive": "show:lazy" },
                                                        {
                                                          tab: o(() => [
                                                            l(
                                                              i,
                                                              { size: "14", class: "mr-1" },
                                                              {
                                                                default: o(() => [
                                                                  ...(t[27] ||
                                                                    (t[27] = [
                                                                      n(
                                                                        "svg",
                                                                        { viewBox: "0 0 24 24" },
                                                                        [
                                                                          n("path", {
                                                                            fill: "currentColor",
                                                                            d: "M12,15.5A3.5,3.5 0 0,1 8.5,12A3.5,3.5 0 0,1 12,8.5A3.5,3.5 0 0,1 15.5,12A3.5,3.5 0 0,1 12,15.5M19.43,12.97C19.47,12.65 19.5,12.33 19.5,12C19.5,11.67 19.47,11.34 19.43,11L21.54,9.37C21.73,9.22 21.78,8.95 21.66,8.73L19.66,5.27C19.54,5.05 19.27,4.96 19.05,5.05L16.56,6.05C16.04,5.66 15.5,5.32 14.87,5.07L14.5,2.42C14.46,2.18 14.25,2 14,2H10C9.75,2 9.54,2.18 9.5,2.42L9.13,5.07C8.5,5.32 7.96,5.66 7.44,6.05L4.95,5.05C4.73,4.96 4.46,5.05 4.34,5.27L2.34,8.73C2.22,8.95 2.27,9.22 2.46,9.37L4.57,11C4.53,11.34 4.5,11.67 4.5,12C4.5,12.33 4.53,12.65 4.57,12.97L2.46,14.63C2.27,14.78 2.22,15.05 2.34,15.27L4.34,18.73C4.46,18.95 4.73,19.03 4.95,18.95L7.44,17.94C7.96,18.34 8.5,18.68 9.13,18.93L9.5,21.58C9.54,21.82 9.75,22 10,22H14C14.25,22 14.46,21.82 14.5,21.58L14.87,18.93C15.5,18.68 16.04,18.34 16.56,17.94L19.05,18.95C19.27,19.03 19.54,18.95 19.66,18.73L21.66,15.27C21.78,15.05 21.73,14.78 21.54,14.63L19.43,12.97Z",
                                                                          }),
                                                                        ],
                                                                        -1,
                                                                      ),
                                                                    ])),
                                                                ]),
                                                                _: 1,
                                                              },
                                                            ),
                                                            t[28] || (t[28] = c(" 原始数据 ", -1)),
                                                          ]),
                                                          default: o(() => [
                                                            n("div", Pe, [
                                                              n("div", Ke, [
                                                                l(
                                                                  p,
                                                                  { size: "small" },
                                                                  {
                                                                    default: o(() => [
                                                                      l(
                                                                        a,
                                                                        { size: "small", type: "warning" },
                                                                        {
                                                                          default: o(() => [
                                                                            ...(t[29] || (t[29] = [c("原始", -1)])),
                                                                          ]),
                                                                          _: 1,
                                                                        },
                                                                      ),
                                                                      l(
                                                                        r,
                                                                        {
                                                                          size: "tiny",
                                                                          type: "warning",
                                                                          ghost: "",
                                                                          onClick: (D) => ue(d.data),
                                                                          title: "复制原始JSON",
                                                                        },
                                                                        {
                                                                          default: o(() => [
                                                                            l(
                                                                              i,
                                                                              { size: "12", class: "mr-1" },
                                                                              {
                                                                                default: o(() => [
                                                                                  ...(t[30] ||
                                                                                    (t[30] = [
                                                                                      n(
                                                                                        "svg",
                                                                                        { viewBox: "0 0 24 24" },
                                                                                        [
                                                                                          n("path", {
                                                                                            fill: "currentColor",
                                                                                            d: "M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",
                                                                                          }),
                                                                                        ],
                                                                                        -1,
                                                                                      ),
                                                                                    ])),
                                                                                ]),
                                                                                _: 1,
                                                                              },
                                                                            ),
                                                                            t[31] || (t[31] = c(" 复制 ", -1)),
                                                                          ]),
                                                                          _: 1,
                                                                        },
                                                                        8,
                                                                        ["onClick"],
                                                                      ),
                                                                    ]),
                                                                    _: 2,
                                                                  },
                                                                  1024,
                                                                ),
                                                              ]),
                                                              n("pre", Qe, v(JSON.stringify(d.data, null, 2)), 1),
                                                            ]),
                                                          ]),
                                                          _: 2,
                                                        },
                                                        1024,
                                                      ),
                                                      l(
                                                        h,
                                                        { name: "compact", "display-directive": "show:lazy" },
                                                        {
                                                          tab: o(() => [
                                                            l(
                                                              i,
                                                              { size: "14", class: "mr-1" },
                                                              {
                                                                default: o(() => [
                                                                  ...(t[32] ||
                                                                    (t[32] = [
                                                                      n(
                                                                        "svg",
                                                                        { viewBox: "0 0 24 24" },
                                                                        [
                                                                          n("path", {
                                                                            fill: "currentColor",
                                                                            d: "M4,6H20V16H4M20,18A2,2 0 0,0 22,16V6C22,4.89 21.1,4 20,4H4C2.89,4 2,4.89 2,6V16A2,2 0 0,0 4,18H0V20H24V18H20Z",
                                                                          }),
                                                                        ],
                                                                        -1,
                                                                      ),
                                                                    ])),
                                                                ]),
                                                                _: 1,
                                                              },
                                                            ),
                                                            t[33] || (t[33] = c(" 紧凑显示 ", -1)),
                                                          ]),
                                                          default: o(() => [
                                                            n("div", Xe, [
                                                              n("div", Ye, [
                                                                l(
                                                                  p,
                                                                  { size: "small" },
                                                                  {
                                                                    default: o(() => [
                                                                      l(
                                                                        a,
                                                                        { size: "small", type: "success" },
                                                                        {
                                                                          default: o(() => [
                                                                            ...(t[34] || (t[34] = [c("紧凑", -1)])),
                                                                          ]),
                                                                          _: 1,
                                                                        },
                                                                      ),
                                                                      l(
                                                                        r,
                                                                        {
                                                                          size: "tiny",
                                                                          type: "success",
                                                                          ghost: "",
                                                                          onClick: (D) => fe(d.data),
                                                                          title: "复制紧凑JSON",
                                                                        },
                                                                        {
                                                                          default: o(() => [
                                                                            l(
                                                                              i,
                                                                              { size: "12", class: "mr-1" },
                                                                              {
                                                                                default: o(() => [
                                                                                  ...(t[35] ||
                                                                                    (t[35] = [
                                                                                      n(
                                                                                        "svg",
                                                                                        { viewBox: "0 0 24 24" },
                                                                                        [
                                                                                          n("path", {
                                                                                            fill: "currentColor",
                                                                                            d: "M19,21H8V7H19M19,5H8A2,2 0 0,0 6,7V21A2,2 0 0,0 8,23H19A2,2 0 0,0 21,21V7A2,2 0 0,0 19,5M16,1H4A2,2 0 0,0 2,3V17H4V3H16V1Z",
                                                                                          }),
                                                                                        ],
                                                                                        -1,
                                                                                      ),
                                                                                    ])),
                                                                                ]),
                                                                                _: 1,
                                                                              },
                                                                            ),
                                                                            t[36] || (t[36] = c(" 复制 ", -1)),
                                                                          ]),
                                                                          _: 1,
                                                                        },
                                                                        8,
                                                                        ["onClick"],
                                                                      ),
                                                                    ]),
                                                                    _: 2,
                                                                  },
                                                                  1024,
                                                                ),
                                                              ]),
                                                              n("pre", et, v(JSON.stringify(d.data)), 1),
                                                            ]),
                                                          ]),
                                                          _: 2,
                                                        },
                                                        1024,
                                                      ),
                                                    ]),
                                                    _: 2,
                                                  },
                                                  1024,
                                                ),
                                              ]),
                                              _: 2,
                                            },
                                            1032,
                                            ["title"],
                                          ),
                                        ]),
                                        _: 2,
                                      },
                                      1024,
                                    ),
                                  ]),
                                ],
                                2,
                              )
                            ),
                          ),
                          128,
                        )),
                        g.value.length === 0
                          ? (A(),
                            V("div", tt, [
                              ...(t[37] ||
                                (t[37] = [
                                  n("div", { class: "text-lg mb-2" }, "📭", -1),
                                  n("div", null, "暂无消息历史", -1),
                                  n("div", { class: "text-xs mt-1" }, "发送消息后将在此显示", -1),
                                ])),
                            ]))
                          : S("", !0),
                      ]),
                    ]),
                  ]),
                  _: 1,
                },
              ),
            ])
          );
        }
      );
    },
  },
  at = Ve(st, [["__scopeId", "data-v-eab730dc"]]);
export { at as default };
