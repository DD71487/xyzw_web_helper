import { _ as Ae } from "./ServerRoleList-J82O2iip.js";
import {
  k as F,
  c as N,
  a as l,
  h as R,
  x as De,
  q as Me,
  a_ as ze,
  s as Le,
  r as p,
  z as He,
  o as Oe,
  M as Pe,
  b as u,
  w as d,
  u as m,
  Q as P,
  N as V,
  E as Ve,
  t as q,
  aU as je,
  a$ as Be,
  aX as Ge,
  aL as W,
  i as v,
  aV as _e,
  au as Xe,
  F as We,
  g as Fe,
  e as Je,
  aW as Ke,
  H as Qe,
} from "./index-UoU16364.js";
import { L as Ye, a as Ze } from "./index-CgWPhAzx.js";
import { C as $e } from "./CloudUpload-DBucip-_.js";
import { R as et } from "./Refresh-DWYLAev-.js";
import { _ as tt } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import "./legionWar-5YonzZw2.js";
import "./Search-D4B4lpJB.js";
import "./index-7YDlkBnY.js";
import "./grid-col-GTGOUscx.js";
import "./index-DMjs3mWk.js";
const nt = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  ot = l(
    "path",
    {
      d: "M289.94 256l95-95A24 24 0 0 0 351 127l-95 95l-95-95a24 24 0 0 0-34 34l95 95l-95 95a24 24 0 1 0 34 34l95-95l95 95a24 24 0 0 0 34-34z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  st = [ot],
  rt = F({
    name: "Close",
    render: function (j, S) {
      return (R(), N("svg", nt, st));
    },
  }),
  at = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", viewBox: "0 0 512 512" },
  it = l(
    "path",
    {
      d: "M342 444h46a56 56 0 0 0 56-56v-46",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "44",
    },
    null,
    -1,
  ),
  lt = l(
    "path",
    {
      d: "M444 170v-46a56 56 0 0 0-56-56h-46",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "44",
    },
    null,
    -1,
  ),
  ct = l(
    "path",
    {
      d: "M170 444h-46a56 56 0 0 1-56-56v-46",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "44",
    },
    null,
    -1,
  ),
  ut = l(
    "path",
    {
      d: "M68 170v-46a56 56 0 0 1 56-56h46",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "44",
    },
    null,
    -1,
  ),
  dt = [it, lt, ct, ut],
  pt = F({
    name: "Scan",
    render: function (j, S) {
      return (R(), N("svg", at, dt));
    },
  }),
  mt = { class: "wx-qrcode-import" },
  ft = { class: "form-actions" },
  wt = { class: "qrcode-container" },
  gt = ["src"],
  ht = { class: "form-actions" },
  vt = { style: { display: "flex", "justify-content": "space-between", "align-items": "center", width: "100%" } },
  xt = { style: { "word-break": "break-all" } },
  re = 12e4,
  z = "https://f9b333f0.xyzw-web-helper-ena.pages.dev",
  yt = F({
    __name: "wxqrcode",
    emits: ["cancel", "ok"],
    setup(J, { emit: j }) {
      const S = De(),
        { storeArrayBuffer: ae } = Me(),
        x = (() => {
          try {
            const e = navigator.userAgent;
            return /Android/.test(e) && /wv|WebView/.test(e);
          } catch {
            return !1;
          }
        })(),
        y = (() => {
          try {
            return ze();
          } catch {
            return !1;
          }
        })(),
        T = Be,
        ie = { text: (e) => e },
        le = {
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 7.0; Mi-4c Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.49 Mobile MQQBrowser/6.2 TBS/043632 Safari/537.36 MicroMessenger/6.6.1.1220(0x26060135) NetType/WIFI Language/zh_CN",
          Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
          Referer: "https://open.weixin.qq.com/",
        },
        ce = {
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 7.0; Mi-4c Build/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/53.0.2785.49 Mobile MQQBrowser/6.2 TBS/043632 Safari/537.36 MicroMessenger/6.6.1.1220(0x26060135) NetType/WIFI Language/zh_CN",
          Accept: "*/*",
          Referer: "https://open.weixin.qq.com/",
        },
        ue = {
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 12; 23117RK66C Build/V417IR; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/95.0.4638.74 Mobile Safari/537.36",
          Accept: "*/*",
          "Content-Type": "text/plain; charset=utf-8",
          Origin: "https://open.weixin.qq.com",
          Referer: "https://open.weixin.qq.com/",
        },
        f = Le(),
        de = p(!1),
        C = He({ name: "", server: "", wsUrl: "", nameTemplate: "{name}-{index}-{id}" }),
        pe = j,
        me = (e) => {
          b.value.splice(e, 1);
        },
        U = p(null),
        E = p(null),
        I = p(!1),
        K = p("点击获取微信登录二维码"),
        Q = p("info"),
        fe = p(null),
        B = p(!1),
        L = p(null),
        Y = p(null),
        H = p([]),
        we = p(null),
        Z = p(""),
        A = p(null),
        b = p([]),
        ge = (e) => {
          if (!A.value) {
            f.error("Bin数据缺失，请重新扫码");
            return;
          }
          try {
            const t = { ...A.value };
            t.serverId = e.serverId;
            const o = W.encode(t);
            let a = Number(e.serverId),
              i = 0;
            a >= 2e6 ? ((i = 2), (a -= 2e6)) : a >= 1e6 && ((i = 1), (a -= 1e6));
            const s = `bin-${a - 27}服${i}-${e.roleId}-${e.name}.bin`;
            (Ce(s, o), f.success(`已开始下载: ${s}`));
          } catch (t) {
            (console.error("下载失败", t), f.error("下载失败: " + t.message));
          }
        },
        he = async (e) => {
          if (!A.value) {
            f.error("Bin数据缺失，请重新上传");
            return;
          }
          try {
            const t = { ...A.value };
            t.serverId = e.serverId;
            const o = W.encode(t),
              a = Ke(o),
              i = await Qe(o),
              n = e.name || `角色_${e.roleId}`;
            ae(a, o);
            let s = Number(e.serverId),
              r = 0;
            s >= 2e6 ? ((r = 2), (s -= 2e6)) : s >= 1e6 && ((r = 1), (s -= 1e6));
            const c = s - 27,
              k = (C.nameTemplate || "{name}-{index}-{id}")
                .replace(/{name}/g, () => n)
                .replace(/{index}/g, () => String(r))
                .replace(/{id}/g, () => String(e.roleId))
                .replace(/{server}/g, () => `${c}服`);
            if (b.value.some((M) => M.roleId === e.roleId && M.name === k)) {
              f.warning(`角色 ${k} 已在待添加列表中`);
              return;
            }
            (b.value.push({
              id: a,
              roleId: e.roleId,
              token: i,
              name: k,
              server: `${c}服`,
              roleIndex: r,
              wsUrl: C.wsUrl || "",
              importMethod: "wxQrcode",
            }),
              f.success(`已添加角色: ${k}`));
          } catch (t) {
            (console.error("添加角色失败", t), f.error("添加角色失败: " + t.message));
          }
        },
        $ = async () => {
          try {
            if (((I.value = !0), w("正在获取二维码...", "info"), G(), !(await xe()))) throw new Error("二维码获取失败");
          } catch (e) {
            (w("二维码获取失败：" + ((e == null ? void 0 : e.message) || "未知错误"), "error"),
              console.error("获取二维码失败", e));
          } finally {
            I.value = !1;
          }
        },
        ve = [
          (e) =>
            e.includes("open.weixin.qq.com")
              ? `${z}/api/weixin${new URL(e).pathname}${new URL(e).search}`
              : e.includes("long.open.weixin.qq.com")
                ? `${z}/api/weixin-long${new URL(e).pathname}${new URL(e).search}`
                : e.includes("comb-platform.hortorgames.com")
                  ? `${z}/api/hortor${new URL(e).pathname}${new URL(e).search}`
                  : e,
        ],
        xe = async () => {
          var e;
          try {
            let t;
            y
              ? (t =
                  "https://open.weixin.qq.com/connect/app/qrconnect?appid=wxfb0d5667e5cb1c44&bundleid=com.hortor.games.xyzw&scope=snsapi_base,snsapi_userinfo,snsapi_friend,snsapi_message&state=weixin")
              : x
                ? (t = ve[0](
                    "https://open.weixin.qq.com/connect/app/qrconnect?appid=wxfb0d5667e5cb1c44&bundleid=com.hortor.games.xyzw&scope=snsapi_base,snsapi_userinfo,snsapi_friend,snsapi_message&state=weixin",
                  ))
                : (t =
                    "/api/weixin/connect/app/qrconnect?appid=wxfb0d5667e5cb1c44&bundleid=com.hortor.games.xyzw&scope=snsapi_base,snsapi_userinfo,snsapi_friend,snsapi_message&state=weixin");
            let o;
            if ((y || x) && T && y) {
              const n = await T(t, { method: "GET", headers: le });
              if (!n.ok) throw new Error("HTTP 状态码：" + n.status);
              o = await n.text();
            } else {
              const n = await new Promise((s, r) => {
                const c = new XMLHttpRequest();
                (c.open("GET", t, !0),
                  (c.timeout = 3e4),
                  c.setRequestHeader("Accept", "text/html"),
                  x && (c.withCredentials = !1),
                  (c.onload = () => s(c)),
                  (c.onerror = () => r(new Error("网络错误"))),
                  (c.ontimeout = () => r(new Error("请求超时(30s),请检查网络连接"))),
                  c.send());
              });
              if (n.status !== 200) throw new Error("HTTP 状态码：" + n.status);
              if (
                ((o = n.responseText),
                (!o || (!o.includes("<html") && !o.includes("<!doctype"))) &&
                  console.warn("代理返回非HTML内容,长度:", o == null ? void 0 : o.length),
                o && o.includes("你使用的浏览器暂不支持微信登录"))
              )
                throw (console.error("微信返回浏览器不支持错误,尝试切换代理"), new Error("BROWSER_NOT_SUPPORTED"));
            }
            let i =
              (e = new DOMParser().parseFromString(o, "text/html").querySelector("img.auth_qrcode")) == null
                ? void 0
                : e.src;
            if (!i) {
              const n = o.match(/https:\/\/[^"']*qrcode[^"']*/i);
              n && (i = n[0]);
            }
            if (!i) throw new Error("未找到二维码图片地址1:" + o);
            return (
              (E.value = i.split("/").pop().split("?")[0]),
              (U.value = i),
              w("请使用微信扫码登录", "success"),
              ye(),
              !0
            );
          } catch (t) {
            return (
              console.error("二维码解析失败", t),
              (t == null ? void 0 : t.message) === "BROWSER_NOT_SUPPORTED" && x
                ? w("微信登录需要特定浏览器环境,当前代理无法模拟", "error")
                : w("二维码获取失败：" + ((t == null ? void 0 : t.message) || "未知错误"), "error"),
              !1
            );
          }
        },
        ye = () => {
          B.value ||
            ((B.value = !0),
            (Y.value = Date.now()),
            (L.value = setInterval(() => {
              be();
            }, 1e3)));
        },
        be = async () => {
          try {
            if (!E.value) return;
            const e = Date.now() - Y.value;
            if (e > re) {
              (w("二维码已超时，请重新获取", "error"), D(), G());
              return;
            }
            const t = y
              ? `https://long.open.weixin.qq.com/connect/l/qrconnect?uuid=${E.value}&f=url&_=${Date.now()}`
              : x
                ? `${z}/api/weixin-long/connect/l/qrconnect?uuid=${E.value}&f=url&_=${Date.now()}`
                : `/api/weixin-long/connect/l/qrconnect?uuid=${E.value}&f=url&_=${Date.now()}`;
            let o,
              a = !1;
            if (y && T) {
              const n = await T(t, { method: "GET", headers: ce });
              ((a = n.ok), (o = await n.text()));
            } else {
              const n = await new Promise((s) => {
                const r = new XMLHttpRequest();
                (r.open("GET", t, !0),
                  (r.timeout = 6e4),
                  r.setRequestHeader("Accept", "*/*"),
                  x && (r.withCredentials = !1),
                  (r.onload = () => s(r)),
                  (r.onerror = () => s({ status: 0 })),
                  (r.ontimeout = () => s({ status: 0 })),
                  r.send());
              });
              ((a = n.status === 200), (o = n.responseText));
            }
            if (a) {
              if (o.includes("window.wx_errcode=405")) {
                const n = o.match(/wx_redirecturl='[^']*code=([a-zA-Z0-9]+)/),
                  s = o.match(/window\.wx_nickname\s*=\s*['"]([^'"]+)['"]/);
                if (n) {
                  const r = n[1],
                    c = s ? s[1] : "";
                  (D(), w(`扫码成功，正在登录... 用户：${c || "未知用户"}`, "success"), await ke(r, c));
                  return;
                }
              }
              if (o.includes("window.wx_errcode=408")) {
                (w("二维码已过期，请重新生成", "error"), D(), G());
                return;
              }
            }
            const i = Math.ceil((re - e) / 1e3);
            i % 30 === 0 && w(`请扫码，剩余 ${i} 秒`, "info");
          } catch (e) {
            console.error("扫码状态检查失败", e);
          }
        },
        D = () => {
          ((B.value = !1), L.value && (clearInterval(L.value), (L.value = null)));
        },
        ke = async (e, t = "") => {
          try {
            I.value = !0;
            const o = await Re(e);
            o && (await qe(o.buffer, t));
          } catch (o) {
            (w("处理失败：" + o.message, "error"), console.error("扫码处理失败:", o));
          } finally {
            I.value = !1;
          }
        },
        Re = async (e) => {
          var _, k, X, M;
          const o = JSON.stringify({
            gameId: "xyzwapp",
            code: e,
            gameTp: "app",
            sysInfo: '{"system":"Android","hortorSDKVersion":"4.0.6-cn","model":"22081212C","brand":"Redmi"}',
            channel: "android",
            appFrom: "com.tencent.mm",
            noLogin: "2",
            distinctId: "DID-a38175b7-14ce-4b36-aa89-3e092ea03ea6",
            state: "hortor",
            packageName: "com.hortor.games.xyzw",
            tp: "app-we",
            signPrint: "E6:F7:FE:A9:EC:8E:24:D0:4F:2A:32:50:28:78:E1:C5:5E:70:81:13",
          });
          console.log("原始登录 JSON:", o);
          const a = ee(o);
          try {
            (console.log("加密后的登录 JSON:", a), console.log("解密:", Se(a)));
          } catch {}
          const i = y
            ? `https://comb-platform.hortorgames.com/comb-login-server/api/v1/login?gameId=xyzwapp&timestamp=${Date.now()}&version=android-4.2.1-cn-release&cryptVersion=1.1.0&gameTp=app&system=android&deviceUniqueId=DID-0e782e88-2f3b-4f5b-9020-47f5e5a5a026&packageName=com.hortorgames.xyzw`
            : x
              ? `${z}/api/hortor/comb-login-server/api/v1/login?gameId=xyzwapp&timestamp=${Date.now()}&version=android-4.2.1-cn-release&cryptVersion=1.1.0&gameTp=app&system=android&deviceUniqueId=DID-0e782e88-2f3b-4f5b-9020-47f5e5a5a026&packageName=com.hortorgames.xyzw`
              : `/api/hortor/comb-login-server/api/v1/login?gameId=xyzwapp&timestamp=${Date.now()}&version=android-4.2.1-cn-release&cryptVersion=1.1.0&gameTp=app&system=android&deviceUniqueId=DID-0e782e88-2f3b-4f5b-9020-47f5e5a5a026&packageName=com.hortorgames.xyzw`;
          let n;
          if (y && T) {
            const h = await T(i, { method: "POST", headers: ue, body: ie.text(a) });
            if (!h.ok) throw new Error("HTTP 状态码：" + h.status);
            n = await h.json();
          } else {
            const h = await new Promise((Ue, se) => {
              const g = new XMLHttpRequest();
              (g.open("POST", i, !0),
                (g.timeout = 15e3),
                g.setRequestHeader("Accept", "*/*"),
                g.setRequestHeader("Content-Type", "text/plain; charset=utf-8"),
                (g.onload = () => Ue(g)),
                (g.onerror = () => se(new Error("登录失败"))),
                (g.ontimeout = () => se(new Error("登录超时"))),
                g.send(a));
            });
            if (h.status !== 200) throw new Error("HTTP 状态码：" + h.status);
            n = JSON.parse(h.responseText);
          }
          if (((_ = n.meta) == null ? void 0 : _.errCode) !== 0)
            throw new Error("登录失败：" + ((k = n.meta) == null ? void 0 : k.errMsg));
          const s = (X = n.data) == null ? void 0 : X.combUser;
          if (!s) throw new Error("登录响应结构异常");
          console.log("combUser:", s);
          const r = (M = window.__require) == null ? void 0 : M.call(window, "13");
          if (!(r != null && r.encMsg) || !(r != null && r.lz4XorEncode))
            throw new Error("游戏加密模块未加载，无法生成bin");
          const c = r.encMsg(
            { platform: "hortor", platformExt: "mix", info: s, serverId: null, scene: 0, referrerInfo: "" },
            { decrypt: r.lz4XorDecode, encrypt: r.lz4XorEncode },
          );
          return new Uint8Array(c);
        },
        ee = (e) => {
          const t =
            "BYLWeIPgSMOI2VsgfNGDHSilLpVgxgzIjqMiW0bJqX2HafZDOWZOcJyLTMSn66O6s86nnbXY0BWsEcDsINuxmPlwjx8nAsqKysGnWhwrceWZ8QPZNXPcj21uRFo3QvHrzBh4mb4ug426VRYoqERUWNOv7Xov7qBqfkZA7AnHQsWw4ABzX5e4vLOWzYhsQVHpoOE48lQivLYyxqvszdrxMCuFNNHu0eAE5i3tQlMtnciAsuyRnPUxIcGLb47GV6L9Vhu1vDpICktscWatrZlx3eypnNlWA4K8TU7sia19xAeN2yl7Y2H1LvrdWfrOES0QPB5XidvTJs6mvk0eC94jPr5WhG3AQZu649O5PY2XhToswKN5OhKxHELeFcgkPHy7ZqdEbG8tgJBIbVFf7E3MHzAkVauOvqeXA2qJpQHnZi9RQzJPlXkGKOllalIBlJXhVdUVBIEQ8z2qBTz0DZRah1CcdCAIvY5rSsK6pkDYPfeuwF2jN4zYxp0W2bVIY6RHCTYRLL2iyG6tmCnZwuQrucHbYa0hyADhBu1y8eYldlj3Biv6qbXjSpxRAv59qTQDqgtyNRgWw3VnbFkzyutdjFcToJjpYu2P59ASngIIMb0Z9P8E4SdFQcPtD3XdvFO3HrlOzHIX2ivxkonGrHz8EmnqDOVGjxixSQzgX6dM1fU2jxciZ9o6C0FjETnZrzvB5wdby1oaQLXTzc0G1tTPnIEdHamdj1kJM3mkFDvlMYGrQZZzVE6ALELT0aEkPOeL5Op6AStjjwxEPGG3dHqKQzL5ItJrZipYk8Kb8lIqJ7gVKPeAc1EtmQTGNSHV4DvySDQMiGPNzrPleg8qKOv66fwlD9Dt1DuiTL0OpotakaN0lntPPb09yBTMZpyonJ8cHTpyUmAXi0MytClcOm2cT9VkpsYBeW4ULOyZbN5m4OIii9rNDFFsOsZzBHzDtGdXEi2bje2gDOAtStYqAfHVD8S8WIEi5UsiROVje6lwaJ3BSilgSY3A2BtR7tSuqei22UX6fCDWzi7DkYdepE2NlCji9FR0YQCFZ9JXpSY2BCKayNslEYKX4sAgedoRpKihSTGL8PeTOkYRofOI7MnWJ770m0PmzEewNigjrPloxmJyjiLG53zQbck4kwhUS4l0YmME77hLen7NFayWweAAWHdwOCf0atzW9U9AgUzRM2eptP4nGTmCsGnocULKy7X6CqIj9uD0yi6sirebNN3O1C2NXkVS17gPTUDtLHVO9ddejoglg6H2P8L0pZtzurpRI9yudDFXyPVSYr7fF7114n4R69g1zwGCFzVvzuH7N4ArzJcgjkQOJywJfeWWD6oIIqlx55sSV4nKGsIWr6UNmjFIC5ZFG3hCUoRgO7AiIZOP22B2JjStsWJU5y7eOMyA4Km82ivotGGL4iQqJyhs03dOh5s9mbPjISLvRJhDfaVtZ5HMhoMBnOfZNw13eRqiNCcTchxvUpVd6vpMf9SNOiYuiJvkGOujw9jVjVXLn8RSo3eq0ZyGdNXbggVEqkWMV4xkGc2KLQPkTIWUgzUCFz3RzkNaLfPChW0ZSw7yeqIeZ1XvEZ3f2O1Q4ztXqrufoqKv7KVVEf2T5MkD2fqVVGBjizxP5kK5Tn6lNR3y1L44cCHOBmDaxT9mpK8BGmxp9Pw7vqIG4Gz7JRn4eG1w7e5w9rJprXsO5WLEM6JYWTThlv6N4FlyJsBSiKgzTyOuPlAlu6Nz8dCnLdyyHe52Ta6PLzPOcFn0gk5Hk30nymrV25NSFiUfo1gEseT4D4RjQfxHJUSgIx3vbcJcgUpLn3joK1K1PwBH5PqhAbS7r4TN6DHpE7dMbkeH876FSWJEG9nZ3s3Gelg0UNG7Y8fb16PZQaP5b38tJGZxVUkUkL2KM6bQUBmNGs8h6J9wUxLWIThPhOv4w0wuiwZBcwrBn4SdwXkafE0wX5GF5vnjuhTl3TL3QGnc5GxdWCctHp1LdImc9mHMVAVSjfwPjRN8WxB6UTwIKtt4W8DDDFheahGjGjVXgBrsjAuGjIr47rmbOU4rx05HyCM8AUNFShPA6Y3CsSZj8qyM2fmgpenLvzhSXhkYfFWZqnqdebslIRJyxF84SuJuMkB3EpY0IgTnbco3Fhiwiaj2SfRcxFs1HKlznKAVLaeY5aRqDPxLXFWE51ISu6u8cXH8aN8nVUSXI5tVuX5z4yfzSVI98U9uEPerR6EYfE47sCKXR9dmQhGgtpKRqwmjQkn1QRAEGI6VWElj5eTVgCVB3BjmdBLEbhs05v9hpo8WpfpTH3kBRTeo92rLfWSpRSY2SqBujk8moOlmeMPod8G3EPUjE8tN1x2W8xmYvvq56UI5n7x6Z1H5tPSfo0b1Uj0vSixUwbqZa4GEqfUy794oN5VJz9S9ve2NyDnyrkvgSLI0AJrb7V3urYpq0dqhhEeK8tGqxmLt6vs9HrH3BBoPRCUMXpSAXs1UZEFmFbohGkgHMYmCobej9LwUs4g1Q2Y9re72oEhiItfjSyOFRpDhzDlXHAWg42NXbNwOdRE999kaFU4cjnr2lmVTF2NYDzTFIcOyU8zJP5irbfXmAgkrJ1FIezfvjdpN1YCgYVHlYGwCG1Ipii7gGRtNcjTAhVCyx9eJx08Q3cD4Kzf9zxKSMe6zR8CSZtg5YPaTUE6P7htOMzHtHGU3nHVKaGbltqCDs3xtzymzdnDVShkaeIxCFQNR3hNXmJZPWJrjSBe8RMVAgk0Gkx71CqmHCPmE3a4yDOUsjtKlbmbvqtPxfW66JwIZBFRil7ND3lQ5gluWaNsCcKEu0Ur7wKEkwCXLXAr8Qqoh2ArXMQpHinDW3gkbZ0xYjJMm03D0cUOWWKA1J7QrEmo037RVQa5NRjytfNrwqyewQbw92sx1OaBR7wkZlpw4sDfQV8fGK5AVyUZj1Nd6s37gCrCH8eRMGEuBo73oGNwHHWcHMaQYquxTxIOPKGpeAKNluABUWJQqwT0CogsvDDfXLpUkHxy5Acu3IDREX5jZMi9ykMPz84dEawv05jqJAO5NZrbVJy6ahCa4pDdBEVBqQBH1JlLRCHk9nWRawdoHvhxvUyvS8jKip3AxUh8y1hbsuRMzn1IRf8RtS090J6wKwHAALKxHa8aPHhq1SAm4gSHR8RBsa2i9SWB0zNP9mtJ5patCUKrm5XLDi71szt5vpbbSMco36RLX7IEuVQzj379wmvMuUQbwqJNovXR85XF3dJ5GuOOGQMXoP9In4ruALwGIaz8rLK6zG0xqpGd3EX14ewYSMc8vYOnJTkrdnF6nuoNknOQBXwsicyZXKp9DVvNF083IO8TzH9mWGxvEyCeXIfNcmKAxAzORdoOoSFKoDw3bRPQN6ESerYfSPRAVYXiKQbmvFs940bhEVn1euMtME2BMMhbcO6Ys9w5Rkhx108jBfRNsgDX2HFFAe88IQYEvOydftcZellhehEC7aJs2VwgIZtbH0UEfKPLV6bzpearD9lewhEsiTAY7PE9i1bPMGvm6dvsY0iORqI6Nzf9IjWUf8axjgKYxqpZja4NrTUjaawti42TboHSo9lo1s0vjV7efGUYnWXGGleb9OlF1uPjAByK0ybDj3uEgZqABVoZx0vr5BzEYfUoyyINnfmY080a8RLnsjgc38uVVMeRCcyiHF0KLCVQbcMbFHaaJ53IfPucP1KgiMEdlU2XIoD1ErScWufhcyLVwRCXjjEciuWwHDGoXid6uzjqlBo83NCZ6u3mvWfHgZ8TEY5ohcb3h47NpN4o07vZLyVQhPRijkq2Hxb9mErju4HmVc9UUadDRVtY7ys1NqRyYm22lvhHjgwYKIdLG3l5AV6j6lUDkCO9SHsA6tsF8HZ2ZvQdl05cT2eXKnIL5LRRGFiIydmdkR2BYzUbNMXGrASfVIjgYR5GINty8e3iCF63C0VGXj2RJ7CG5758fr5zJZIQX1As8zpVnTvrSRx9ZhajaXy7r5SNI1V084vX9zyG2FnT8VPLvgZ1OmEyo9JgEu5WbrPa0el7WXM7Wlijrr6S7wMioX97Tsihg43PyRtyV5JjR0YdKenXVeCPMl2bAzjroriO7";
          console.log("原始文本长度:", e.length);
          const n = Te(e, t, 6, 3, 1);
          console.log("codeBase64:", (n == null ? void 0 : n.substring(0, 100)) + "...");
          const s = te(n);
          return (console.log("编码结果长度:", s == null ? void 0 : s.length), s);
        },
        Se = (e) => {
          const i = ee.toString().match(/const cipherTable = "([^"]+)"/)[1],
            n = atob(e),
            s = O(i, 6),
            r = ne(s, 3),
            c = oe(n, r, 1);
          return decodeURIComponent(escape(atob(c)));
        },
        Te = (e, t, o, a, i) => {
          const n = te(e);
          {
            const s = O(t, o),
              r = ne(s, a);
            return oe(n, r, i);
          }
        },
        te = (e) => (e ? btoa(unescape(encodeURIComponent(e))) : null),
        O = (e, t) => {
          if (t <= 0) return e;
          if (e.length % 2 !== 0) return null;
          const o = Ee(e),
            a = Ie(e);
          return O(o, t - 1) + O(a, t - 1);
        },
        Ee = (e) => (e.length % 2 !== 0 ? null : e.substring(Math.floor(e.length / 2))),
        Ie = (e) => (e.length % 2 !== 0 ? null : e.substring(0, Math.floor(e.length / 2))),
        ne = (e, t) => {
          const o = e.split(""),
            a = [],
            i = Math.floor(e.length / t);
          for (let n = 0; n < i; n++) a.push(o[n * t]);
          return a.join("");
        },
        oe = (e, t, o) => {
          if (!e || !t) return null;
          const a = e.split(""),
            i = t.split(""),
            n = new Array(a.length);
          let s = i.length >> o;
          for (let r = 0; r < a.length; r++)
            (s >= i.length && (s = 0), (n[r] = String.fromCharCode(a[r].charCodeAt(0) ^ i[s].charCodeAt(0))), s++);
          return n.join("");
        },
        qe = async (e, t = "") => {
          var i;
          let o = (i = fe.value) == null ? void 0 : i.trim();
          console.log("name:", o);
          const a = new Uint8Array(e);
          we.value = a.buffer;
          try {
            const n = await Ge(a.buffer),
              s = JSON.parse(n);
            (s && typeof s == "object"
              ? (H.value = Object.values(s).sort((r, c) => c.power - r.power))
              : (H.value = []),
              console.log("Server List:", s),
              f.success("获取服务器角色列表成功，请选择角色添加"));
          } catch (n) {
            (console.error("Failed to get server list", n), f.warning("获取服务器角色列表失败"), (H.value = []));
          }
          try {
            const n = W.parse(a.buffer);
            let s = n.getData();
            (!s && n._raw && (console.log("Bin文件 getData() 为空，尝试使用_raw"), (s = { ...n._raw })),
              console.log("Bin文件解析:", s),
              (Z.value = JSON.stringify(s, null, 2)),
              (A.value = s));
          } catch (n) {
            (console.error("Bin文件解析失败", n), (Z.value = "Bin文件解析失败: " + (n.message || n)));
          }
        },
        Ne = async () => {
          if (b.value.length === 0) {
            f.error("请先上传 bin 文件");
            return;
          }
          (b.value.forEach((e) => {
            const t = S.gameTokens.find((o) => o.id === e.id);
            t ? (console.log("更新同名token:", t), S.updateToken(t.id, { ...e })) : S.addToken({ ...e });
          }),
            console.log("当前Token列表:", S.gameTokens),
            f.success("Token添加成功"),
            (b.value = []),
            pe("ok"));
        },
        Ce = (e, t) => {
          const o = new Blob([new Uint8Array(t)], { type: "application/octet-stream" }),
            a = URL.createObjectURL(o),
            i = document.createElement("a");
          ((i.href = a),
            (i.download = e),
            document.body.appendChild(i),
            i.click(),
            document.body.removeChild(i),
            URL.revokeObjectURL(a));
        },
        w = (e, t = "info") => {
          ((K.value = e), (Q.value = t));
        },
        G = () => {
          (D(), (E.value = null), (U.value = null), w("点击获取微信登录二维码", "info"));
        };
      return (
        Oe(() => {}),
        Pe(() => {
          D();
        }),
        (e, t) => {
          const o = Ae,
            a = Ze,
            i = Ye;
          return (
            R(),
            N("div", mt, [
              l("div", ft, [
                u(
                  m(P),
                  { type: "primary", size: "large", block: "", loading: de.value, onClick: Ne },
                  {
                    icon: d(() => [u(m(V), null, { default: d(() => [u(m($e))]), _: 1 })]),
                    default: d(() => [t[2] || (t[2] = v(" 添加Token ", -1))]),
                    _: 1,
                  },
                  8,
                  ["loading"],
                ),
                u(
                  m(P),
                  { block: "", onClick: t[0] || (t[0] = (n) => e.$emit("cancel")), disabled: I.value },
                  {
                    icon: d(() => [u(m(V), null, { default: d(() => [u(m(rt))]), _: 1 })]),
                    default: d(() => [t[3] || (t[3] = v(" 取消 ", -1))]),
                    _: 1,
                  },
                  8,
                  ["disabled"],
                ),
              ]),
              t[14] ||
                (t[14] = l(
                  "div",
                  { class: "login-flow-info" },
                  [
                    l("h3", null, "微信扫码登录流程"),
                    l("ol", { class: "flow-steps" }, [
                      l("li", null, "点击下方按钮获取微信登录二维码"),
                      l("li", null, "使用微信扫码并确认登录"),
                      l("li", null, "系统将获取该微信下所有角色的 Token 信息"),
                    ]),
                  ],
                  -1,
                )),
              l("div", wt, [
                U.value
                  ? (R(),
                    N(
                      "img",
                      { key: 1, id: "qr-image", src: U.value, alt: "微信登录二维码", class: "qr-image" },
                      null,
                      8,
                      gt,
                    ))
                  : (R(),
                    N("div", { key: 0, id: "qr-placeholder", class: "qr-placeholder", onClick: $ }, [
                      u(m(V), { size: "48", color: "var(--text-tertiary)" }, { default: d(() => [u(m(pt))]), _: 1 }),
                      t[4] || (t[4] = l("p", null, "点击获取微信登录二维码", -1)),
                    ])),
                l("div", { id: "qr-status", class: Ve(["qr-status", Q.value]) }, q(K.value), 3),
              ]),
              l("div", ht, [
                u(
                  m(P),
                  { type: "primary", block: "", onClick: $, loading: I.value },
                  {
                    icon: d(() => [u(m(V), null, { default: d(() => [u(m(et))]), _: 1 })]),
                    default: d(() => [v(" " + q(U.value ? "刷新二维码" : "获取二维码"), 1)]),
                    _: 1,
                  },
                  8,
                  ["loading"],
                ),
              ]),
              u(
                m(je),
                { model: C, "label-placement": "top", "show-label": !0, style: { "margin-top": "16px" } },
                {
                  default: d(() => [
                    u(
                      m(_e),
                      { label: "角色命名格式", "show-label": !0 },
                      {
                        feedback: d(() => [
                          ...(t[5] ||
                            (t[5] = [v(" 支持变量: {name}角色名, {id}角色ID, {index}角色序号, {server}区服 ", -1)])),
                        ]),
                        default: d(() => [
                          u(
                            m(Xe),
                            {
                              value: C.nameTemplate,
                              "onUpdate:value": t[1] || (t[1] = (n) => (C.nameTemplate = n)),
                              placeholder: "{name}-{index}-{id}",
                            },
                            null,
                            8,
                            ["value"],
                          ),
                        ]),
                        _: 1,
                      },
                    ),
                  ]),
                  _: 1,
                },
                8,
                ["model"],
              ),
              u(
                o,
                { data: H.value, "server-column-title": "服务器ID", "max-height": "50vh", onAdd: he, onDownload: ge },
                null,
                8,
                ["data"],
              ),
              u(i, null, {
                default: d(() => [
                  (R(!0),
                  N(
                    We,
                    null,
                    Fe(
                      b.value,
                      (n, s) => (
                        R(),
                        Je(
                          a,
                          { key: s },
                          {
                            default: d(() => [
                              l("div", vt, [
                                l("div", null, [
                                  t[6] || (t[6] = l("strong", null, "角色名称:", -1)),
                                  v(" " + q(n.name || "未命名角色"), 1),
                                  t[7] || (t[7] = l("br", null, null, -1)),
                                  t[8] || (t[8] = l("strong", null, "Token:", -1)),
                                  l("span", xt, q(n.token), 1),
                                  t[9] || (t[9] = l("br", null, null, -1)),
                                  t[10] || (t[10] = l("strong", null, "服务器:", -1)),
                                  v(" " + q(n.server || "未指定"), 1),
                                  t[11] || (t[11] = l("br", null, null, -1)),
                                  t[12] || (t[12] = l("strong", null, "角色序号:", -1)),
                                  v(" " + q(n.roleIndex), 1),
                                ]),
                                u(
                                  m(P),
                                  { type: "error", size: "small", onClick: (r) => me(s) },
                                  { default: d(() => [...(t[13] || (t[13] = [v(" 删除 ", -1)]))]), _: 1 },
                                  8,
                                  ["onClick"],
                                ),
                              ]),
                            ]),
                            _: 2,
                          },
                          1024,
                        )
                      ),
                    ),
                    128,
                  )),
                ]),
                _: 1,
              }),
            ])
          );
        }
      );
    },
  }),
  At = tt(yt, [["__scopeId", "data-v-f549e16e"]]);
export { At as default };
