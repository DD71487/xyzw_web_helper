import {
  ah as M,
  p as h,
  z as Pe,
  r as p,
  aO as Yt,
  b0 as Zt,
  k as w,
  c as C,
  h as g,
  _ as j,
  E,
  a as X,
  X as J,
  d as Z,
  e as I,
  A as Me,
  aP as Re,
  n as ue,
  al as ct,
  y as N,
  o as U,
  b1 as xe,
  aa as je,
  b2 as Kt,
  b3 as Xt,
  b as F,
  aI as Jt,
  ag as Ut,
  ad as Qt,
  ab as Rt,
  ac as en,
  F as tn,
  $ as et,
} from "./index-UoU16364.js";
const T = Object.prototype.toString;
function se(e) {
  return T.call(e) === "[object Array]";
}
function Do(e) {
  return T.call(e) === "[object Null]";
}
function Oo(e) {
  return T.call(e) === "[object Boolean]";
}
function dt(e) {
  return T.call(e) === "[object Object]";
}
const zo = (e) => T.call(e) === "[object Promise]";
function Ie(e) {
  return T.call(e) === "[object String]";
}
function Q(e) {
  return T.call(e) === "[object Number]" && e === e;
}
function Ce(e) {
  return e === void 0;
}
function Ne(e) {
  return typeof e == "function";
}
function Ao(e) {
  return dt(e) && Object.keys(e).length === 0;
}
const Mo = (e) => (e == null ? void 0 : e.$) !== void 0,
  To = (e) => /\[Q]Q/.test(e);
function Lo(e) {
  return dt(e) && "$y" in e && "$M" in e && "$D" in e && "$d" in e && "$H" in e && "$m" in e && "$s" in e;
}
const ae = Symbol("ArcoConfigProvider"),
  oe = {
    formatYear: "YYYY 年",
    formatMonth: "YYYY 年 MM 月",
    today: "今天",
    view: { month: "月", year: "年", week: "周", day: "日" },
    month: {
      long: {
        January: "一月",
        February: "二月",
        March: "三月",
        April: "四月",
        May: "五月",
        June: "六月",
        July: "七月",
        August: "八月",
        September: "九月",
        October: "十月",
        November: "十一月",
        December: "十二月",
      },
      short: {
        January: "一月",
        February: "二月",
        March: "三月",
        April: "四月",
        May: "五月",
        June: "六月",
        July: "七月",
        August: "八月",
        September: "九月",
        October: "十月",
        November: "十一月",
        December: "十二月",
      },
    },
    week: {
      long: {
        self: "周",
        monday: "周一",
        tuesday: "周二",
        wednesday: "周三",
        thursday: "周四",
        friday: "周五",
        saturday: "周六",
        sunday: "周日",
      },
      short: {
        self: "周",
        monday: "一",
        tuesday: "二",
        wednesday: "三",
        thursday: "四",
        friday: "五",
        saturday: "六",
        sunday: "日",
      },
    },
  },
  nn = {
    locale: "zh-CN",
    empty: { description: "暂无数据" },
    drawer: { okText: "确定", cancelText: "取消" },
    popconfirm: { okText: "确定", cancelText: "取消" },
    modal: { okText: "确定", cancelText: "取消" },
    pagination: { goto: "前往", page: "页", countPerPage: "条/页", total: "共 {0} 条" },
    table: { okText: "确定", resetText: "重置" },
    upload: {
      start: "开始",
      cancel: "取消",
      delete: "删除",
      retry: "点击重试",
      buttonText: "点击上传",
      preview: "预览",
      drag: "点击或拖拽文件到此处上传",
      dragHover: "释放文件并开始上传",
      error: "上传失败",
    },
    calendar: oe,
    datePicker: {
      view: oe.view,
      month: oe.month,
      week: oe.week,
      placeholder: {
        date: "请选择日期",
        week: "请选择周",
        month: "请选择月份",
        year: "请选择年份",
        quarter: "请选择季度",
        time: "请选择时间",
      },
      rangePlaceholder: {
        date: ["开始日期", "结束日期"],
        week: ["开始周", "结束周"],
        month: ["开始月份", "结束月份"],
        year: ["开始年份", "结束年份"],
        quarter: ["开始季度", "结束季度"],
        time: ["开始时间", "结束时间"],
      },
      selectTime: "选择时间",
      today: "今天",
      now: "此刻",
      ok: "确定",
    },
    image: { loading: "加载中" },
    imagePreview: {
      fullScreen: "全屏",
      rotateRight: "向右旋转",
      rotateLeft: "向左旋转",
      zoomIn: "放大",
      zoomOut: "缩小",
      originalSize: "原始尺寸",
    },
    typography: { copied: "已复制", copy: "复制", expand: "展开", collapse: "折叠", edit: "编辑" },
    form: {
      validateMessages: {
        required: "#{field} 是必填项",
        type: {
          string: "#{field} 不是合法的文本类型",
          number: "#{field} 不是合法的数字类型",
          boolean: "#{field} 不是合法的布尔类型",
          array: "#{field} 不是合法的数组类型",
          object: "#{field} 不是合法的对象类型",
          url: "#{field} 不是合法的 url 地址",
          email: "#{field} 不是合法的邮箱地址",
          ip: "#{field} 不是合法的 IP 地址",
        },
        number: {
          min: "`#{value}` 小于最小值 `#{min}`",
          max: "`#{value}` 大于最大值 `#{max}`",
          equal: "`#{value}` 不等于 `#{equal}`",
          range: "`#{value}` 不在 `#{min} ~ #{max}` 范围内",
          positive: "`#{value}` 不是正数",
          negative: "`#{value}` 不是负数",
        },
        array: {
          length: "`#{field}` 个数不等于 #{length}",
          minLength: "`#{field}` 个数最少为 #{minLength}",
          maxLength: "`#{field}` 个数最多为 #{maxLength}",
          includes: "#{field} 不包含 #{includes}",
          deepEqual: "#{field} 不等于 #{deepEqual}",
          empty: "`#{field}` 不是空数组",
        },
        string: {
          minLength: "字符数最少为 #{minLength}",
          maxLength: "字符数最多为 #{maxLength}",
          length: "字符数必须是 #{length}",
          match: "`#{value}` 不符合模式 #{pattern}",
          uppercase: "`#{value}` 必须全大写",
          lowercase: "`#{value}` 必须全小写",
        },
        object: {
          deepEqual: "`#{field}` 不等于期望值",
          hasKeys: "`#{field}` 不包含必须字段",
          empty: "`#{field}` 不是对象",
        },
        boolean: { true: "期望是 `true`", false: "期望是 `false`" },
      },
    },
    colorPicker: { history: "最近使用颜色", preset: "系统预设颜色", empty: "暂无" },
  },
  on = p("zh-CN"),
  rn = Pe({ "zh-CN": nn }),
  Po = () => {
    const e = M(ae, void 0),
      t = h(() => {
        var r;
        return (r = e == null ? void 0 : e.locale) != null ? r : rn[on.value];
      }),
      n = h(() => t.value.locale);
    return {
      i18nMessage: t,
      locale: n,
      t: (r, ...i) => {
        const l = r.split(".");
        let s = t.value;
        for (const a of l) {
          if (!s[a]) return r;
          s = s[a];
        }
        return Ie(s) && i.length > 0
          ? s.replace(/{(\d+)}/g, (a, d) => {
              var f;
              return (f = i[d]) != null ? f : a;
            })
          : s;
      },
    };
  },
  ln = "A",
  un = "arco",
  Te = "$arco",
  ft = (e) => {
    var t;
    return (t = e == null ? void 0 : e.componentPrefix) != null ? t : ln;
  },
  ht = (e, t) => {
    var n;
    t &&
      t.classPrefix &&
      (e.config.globalProperties[Te] = {
        ...((n = e.config.globalProperties[Te]) != null ? n : {}),
        classPrefix: t.classPrefix,
      });
  },
  S = (e) => {
    var t, n, o;
    const r = Yt(),
      i = M(ae, void 0),
      l =
        (o =
          (n = i == null ? void 0 : i.prefixCls) != null
            ? n
            : (t = r == null ? void 0 : r.appContext.config.globalProperties[Te]) == null
              ? void 0
              : t.classPrefix) != null
          ? o
          : un;
    return e ? `${l}-${e}` : l;
  };
var vt = (function () {
    if (typeof Map < "u") return Map;
    function e(t, n) {
      var o = -1;
      return (
        t.some(function (r, i) {
          return r[0] === n ? ((o = i), !0) : !1;
        }),
        o
      );
    }
    return (function () {
      function t() {
        this.__entries__ = [];
      }
      return (
        Object.defineProperty(t.prototype, "size", {
          get: function () {
            return this.__entries__.length;
          },
          enumerable: !0,
          configurable: !0,
        }),
        (t.prototype.get = function (n) {
          var o = e(this.__entries__, n),
            r = this.__entries__[o];
          return r && r[1];
        }),
        (t.prototype.set = function (n, o) {
          var r = e(this.__entries__, n);
          ~r ? (this.__entries__[r][1] = o) : this.__entries__.push([n, o]);
        }),
        (t.prototype.delete = function (n) {
          var o = this.__entries__,
            r = e(o, n);
          ~r && o.splice(r, 1);
        }),
        (t.prototype.has = function (n) {
          return !!~e(this.__entries__, n);
        }),
        (t.prototype.clear = function () {
          this.__entries__.splice(0);
        }),
        (t.prototype.forEach = function (n, o) {
          o === void 0 && (o = null);
          for (var r = 0, i = this.__entries__; r < i.length; r++) {
            var l = i[r];
            n.call(o, l[1], l[0]);
          }
        }),
        t
      );
    })();
  })(),
  Le = typeof window < "u" && typeof document < "u" && window.document === document,
  ie = (function () {
    return typeof global < "u" && global.Math === Math
      ? global
      : typeof self < "u" && self.Math === Math
        ? self
        : typeof window < "u" && window.Math === Math
          ? window
          : Function("return this")();
  })(),
  sn = (function () {
    return typeof requestAnimationFrame == "function"
      ? requestAnimationFrame.bind(ie)
      : function (e) {
          return setTimeout(function () {
            return e(Date.now());
          }, 1e3 / 60);
        };
  })(),
  an = 2;
function cn(e, t) {
  var n = !1,
    o = !1,
    r = 0;
  function i() {
    (n && ((n = !1), e()), o && s());
  }
  function l() {
    sn(i);
  }
  function s() {
    var a = Date.now();
    if (n) {
      if (a - r < an) return;
      o = !0;
    } else ((n = !0), (o = !1), setTimeout(l, t));
    r = a;
  }
  return s;
}
var dn = 20,
  fn = ["top", "right", "bottom", "left", "width", "height", "size", "weight"],
  hn = typeof MutationObserver < "u",
  vn = (function () {
    function e() {
      ((this.connected_ = !1),
        (this.mutationEventsAdded_ = !1),
        (this.mutationsObserver_ = null),
        (this.observers_ = []),
        (this.onTransitionEnd_ = this.onTransitionEnd_.bind(this)),
        (this.refresh = cn(this.refresh.bind(this), dn)));
    }
    return (
      (e.prototype.addObserver = function (t) {
        (~this.observers_.indexOf(t) || this.observers_.push(t), this.connected_ || this.connect_());
      }),
      (e.prototype.removeObserver = function (t) {
        var n = this.observers_,
          o = n.indexOf(t);
        (~o && n.splice(o, 1), !n.length && this.connected_ && this.disconnect_());
      }),
      (e.prototype.refresh = function () {
        var t = this.updateObservers_();
        t && this.refresh();
      }),
      (e.prototype.updateObservers_ = function () {
        var t = this.observers_.filter(function (n) {
          return (n.gatherActive(), n.hasActive());
        });
        return (
          t.forEach(function (n) {
            return n.broadcastActive();
          }),
          t.length > 0
        );
      }),
      (e.prototype.connect_ = function () {
        !Le ||
          this.connected_ ||
          (document.addEventListener("transitionend", this.onTransitionEnd_),
          window.addEventListener("resize", this.refresh),
          hn
            ? ((this.mutationsObserver_ = new MutationObserver(this.refresh)),
              this.mutationsObserver_.observe(document, {
                attributes: !0,
                childList: !0,
                characterData: !0,
                subtree: !0,
              }))
            : (document.addEventListener("DOMSubtreeModified", this.refresh), (this.mutationEventsAdded_ = !0)),
          (this.connected_ = !0));
      }),
      (e.prototype.disconnect_ = function () {
        !Le ||
          !this.connected_ ||
          (document.removeEventListener("transitionend", this.onTransitionEnd_),
          window.removeEventListener("resize", this.refresh),
          this.mutationsObserver_ && this.mutationsObserver_.disconnect(),
          this.mutationEventsAdded_ && document.removeEventListener("DOMSubtreeModified", this.refresh),
          (this.mutationsObserver_ = null),
          (this.mutationEventsAdded_ = !1),
          (this.connected_ = !1));
      }),
      (e.prototype.onTransitionEnd_ = function (t) {
        var n = t.propertyName,
          o = n === void 0 ? "" : n,
          r = fn.some(function (i) {
            return !!~o.indexOf(i);
          });
        r && this.refresh();
      }),
      (e.getInstance = function () {
        return (this.instance_ || (this.instance_ = new e()), this.instance_);
      }),
      (e.instance_ = null),
      e
    );
  })(),
  mt = function (e, t) {
    for (var n = 0, o = Object.keys(t); n < o.length; n++) {
      var r = o[n];
      Object.defineProperty(e, r, { value: t[r], enumerable: !1, writable: !1, configurable: !0 });
    }
    return e;
  },
  W = function (e) {
    var t = e && e.ownerDocument && e.ownerDocument.defaultView;
    return t || ie;
  },
  pt = ce(0, 0, 0, 0);
function le(e) {
  return parseFloat(e) || 0;
}
function tt(e) {
  for (var t = [], n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
  return t.reduce(function (o, r) {
    var i = e["border-" + r + "-width"];
    return o + le(i);
  }, 0);
}
function mn(e) {
  for (var t = ["top", "right", "bottom", "left"], n = {}, o = 0, r = t; o < r.length; o++) {
    var i = r[o],
      l = e["padding-" + i];
    n[i] = le(l);
  }
  return n;
}
function pn(e) {
  var t = e.getBBox();
  return ce(0, 0, t.width, t.height);
}
function gn(e) {
  var t = e.clientWidth,
    n = e.clientHeight;
  if (!t && !n) return pt;
  var o = W(e).getComputedStyle(e),
    r = mn(o),
    i = r.left + r.right,
    l = r.top + r.bottom,
    s = le(o.width),
    a = le(o.height);
  if (
    (o.boxSizing === "border-box" &&
      (Math.round(s + i) !== t && (s -= tt(o, "left", "right") + i),
      Math.round(a + l) !== n && (a -= tt(o, "top", "bottom") + l)),
    !yn(e))
  ) {
    var d = Math.round(s + i) - t,
      f = Math.round(a + l) - n;
    (Math.abs(d) !== 1 && (s -= d), Math.abs(f) !== 1 && (a -= f));
  }
  return ce(r.left, r.top, s, a);
}
var bn = (function () {
  return typeof SVGGraphicsElement < "u"
    ? function (e) {
        return e instanceof W(e).SVGGraphicsElement;
      }
    : function (e) {
        return e instanceof W(e).SVGElement && typeof e.getBBox == "function";
      };
})();
function yn(e) {
  return e === W(e).document.documentElement;
}
function Cn(e) {
  return Le ? (bn(e) ? pn(e) : gn(e)) : pt;
}
function En(e) {
  var t = e.x,
    n = e.y,
    o = e.width,
    r = e.height,
    i = typeof DOMRectReadOnly < "u" ? DOMRectReadOnly : Object,
    l = Object.create(i.prototype);
  return (mt(l, { x: t, y: n, width: o, height: r, top: n, right: t + o, bottom: r + n, left: t }), l);
}
function ce(e, t, n, o) {
  return { x: e, y: t, width: n, height: o };
}
var wn = (function () {
    function e(t) {
      ((this.broadcastWidth = 0), (this.broadcastHeight = 0), (this.contentRect_ = ce(0, 0, 0, 0)), (this.target = t));
    }
    return (
      (e.prototype.isActive = function () {
        var t = Cn(this.target);
        return ((this.contentRect_ = t), t.width !== this.broadcastWidth || t.height !== this.broadcastHeight);
      }),
      (e.prototype.broadcastRect = function () {
        var t = this.contentRect_;
        return ((this.broadcastWidth = t.width), (this.broadcastHeight = t.height), t);
      }),
      e
    );
  })(),
  kn = (function () {
    function e(t, n) {
      var o = En(n);
      mt(this, { target: t, contentRect: o });
    }
    return e;
  })(),
  Bn = (function () {
    function e(t, n, o) {
      if (((this.activeObservations_ = []), (this.observations_ = new vt()), typeof t != "function"))
        throw new TypeError("The callback provided as parameter 1 is not a function.");
      ((this.callback_ = t), (this.controller_ = n), (this.callbackCtx_ = o));
    }
    return (
      (e.prototype.observe = function (t) {
        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
        if (!(typeof Element > "u" || !(Element instanceof Object))) {
          if (!(t instanceof W(t).Element)) throw new TypeError('parameter 1 is not of type "Element".');
          var n = this.observations_;
          n.has(t) || (n.set(t, new wn(t)), this.controller_.addObserver(this), this.controller_.refresh());
        }
      }),
      (e.prototype.unobserve = function (t) {
        if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
        if (!(typeof Element > "u" || !(Element instanceof Object))) {
          if (!(t instanceof W(t).Element)) throw new TypeError('parameter 1 is not of type "Element".');
          var n = this.observations_;
          n.has(t) && (n.delete(t), n.size || this.controller_.removeObserver(this));
        }
      }),
      (e.prototype.disconnect = function () {
        (this.clearActive(), this.observations_.clear(), this.controller_.removeObserver(this));
      }),
      (e.prototype.gatherActive = function () {
        var t = this;
        (this.clearActive(),
          this.observations_.forEach(function (n) {
            n.isActive() && t.activeObservations_.push(n);
          }));
      }),
      (e.prototype.broadcastActive = function () {
        if (this.hasActive()) {
          var t = this.callbackCtx_,
            n = this.activeObservations_.map(function (o) {
              return new kn(o.target, o.broadcastRect());
            });
          (this.callback_.call(t, n, t), this.clearActive());
        }
      }),
      (e.prototype.clearActive = function () {
        this.activeObservations_.splice(0);
      }),
      (e.prototype.hasActive = function () {
        return this.activeObservations_.length > 0;
      }),
      e
    );
  })(),
  gt = typeof WeakMap < "u" ? new WeakMap() : new vt(),
  bt = (function () {
    function e(t) {
      if (!(this instanceof e)) throw new TypeError("Cannot call a class as a function.");
      if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
      var n = vn.getInstance(),
        o = new Bn(t, n, this);
      gt.set(this, o);
    }
    return e;
  })();
["observe", "unobserve", "disconnect"].forEach(function (e) {
  bt.prototype[e] = function () {
    var t;
    return (t = gt.get(this))[e].apply(t, arguments);
  };
});
var yt = (function () {
  return typeof ie.ResizeObserver < "u" ? ie.ResizeObserver : bt;
})();
const de = (e) => !!(e && e.shapeFlag & 1),
  fe = (e, t) => !!(e && e.shapeFlag & 6),
  Fn = (e, t) => !!(e && e.shapeFlag & 8),
  We = (e, t) => !!(e && e.shapeFlag & 16),
  Ct = (e, t) => !!(e && e.shapeFlag & 32),
  Ee = (e) => {
    var t, n;
    if (e)
      for (const o of e) {
        if (de(o) || fe(o)) return o;
        if (We(o, o.children)) {
          const r = Ee(o.children);
          if (r) return r;
        } else if (Ct(o, o.children)) {
          const r = (n = (t = o.children).default) == null ? void 0 : n.call(t);
          if (r) {
            const i = Ee(r);
            if (i) return i;
          }
        } else if (se(o)) {
          const r = Ee(o);
          if (r) return r;
        }
      }
  },
  Sn = (e) => {
    if (!e) return !0;
    for (const t of e) if (t.children) return !1;
    return !0;
  },
  Et = (e, t) => {
    if (e && e.length > 0)
      for (let n = 0; n < e.length; n++) {
        const o = e[n];
        if (de(o) || fe(o)) {
          const i = Ne(t) ? t(o) : t;
          return ((e[n] = Zt(o, i, !0)), !0);
        }
        const r = wt(o);
        if (r && r.length > 0 && Et(r, t)) return !0;
      }
    return !1;
  },
  wt = (e) => {
    if (We(e, e.children)) return e.children;
    if (se(e)) return e;
  },
  kt = (e) => {
    var t, n;
    if (de(e)) return e.el;
    if (fe(e)) {
      if (((t = e.el) == null ? void 0 : t.nodeType) === 1) return e.el;
      if ((n = e.component) != null && n.subTree) {
        const o = kt(e.component.subTree);
        if (o) return o;
      }
    } else {
      const o = wt(e);
      return Bt(o);
    }
  },
  Bt = (e) => {
    if (e && e.length > 0)
      for (const t of e) {
        const n = kt(t);
        if (n) return n;
      }
  },
  we = (e, t = !1) => {
    var n, o;
    const r = [];
    for (const i of e ?? [])
      de(i) || fe(i) || (t && Fn(i, i.children))
        ? r.push(i)
        : We(i, i.children)
          ? r.push(...we(i.children, t))
          : Ct(i, i.children)
            ? r.push(...we((o = (n = i.children).default) == null ? void 0 : o.call(n), t))
            : se(i) && r.push(...we(i, t));
    return r;
  },
  xo = (e) => {
    if (e) return Ne(e) ? e : () => e;
  },
  Ft = typeof window > "u" ? global : window,
  _n = Ft.requestAnimationFrame,
  nt = Ft.cancelAnimationFrame;
function ot(e) {
  let t = 0;
  const n = (...o) => {
    (t && nt(t),
      (t = _n(() => {
        (e(...o), (t = 0));
      })));
  };
  return (
    (n.cancel = () => {
      (nt(t), (t = 0));
    }),
    n
  );
}
const Ve = () => {},
  St = () => {
    const { body: e } = document,
      t = document.documentElement;
    let n;
    try {
      n = (window.top || window.self || window).document.body;
    } catch {}
    return {
      height: Math.max(
        e.scrollHeight,
        e.offsetHeight,
        t.clientHeight,
        t.scrollHeight,
        t.offsetHeight,
        (n == null ? void 0 : n.scrollHeight) || 0,
        (n == null ? void 0 : n.clientHeight) || 0,
      ),
      width: Math.max(
        e.scrollWidth,
        e.offsetWidth,
        t.clientWidth,
        t.scrollWidth,
        t.offsetWidth,
        (n == null ? void 0 : n.scrollWidth) || 0,
        (n == null ? void 0 : n.clientWidth) || 0,
      ),
    };
  },
  He = (() => {
    try {
      return !(typeof window < "u" && document !== void 0);
    } catch {
      return !0;
    }
  })(),
  ke = He
    ? Ve
    : (e, t, n, o = !1) => {
        e.addEventListener(t, n, o);
      },
  rt = He
    ? Ve
    : (e, t, n, o = !1) => {
        e.removeEventListener(t, n, o);
      },
  jo = (e, t) => {
    if (!e || !t) return !1;
    let n = t;
    for (; n; ) {
      if (n === e) return !0;
      n = n.parentNode;
    }
    return !1;
  },
  Io = (e) => {
    const t = document.createElement("div");
    return (t.setAttribute("class", `arco-overlay arco-overlay-${e}`), t);
  },
  $n = (e, t) => {
    var n;
    return He ? Ve() : (n = document.querySelector(e)) != null ? n : void 0;
  },
  it = (e, t) => {
    if (Ie(e)) {
      const n = e[0] === "#" ? `[id='${e.slice(1)}']` : e;
      return $n(n);
    }
    return e;
  },
  No = (e, t) => {
    const n = e.getBoundingClientRect(),
      o = t.getBoundingClientRect();
    return {
      top: n.top - o.top,
      bottom: o.bottom - n.bottom,
      left: n.left - o.left,
      right: o.right - n.right,
      width: n.width,
      height: n.height,
    };
  },
  Wo = (e) =>
    e.tagName === "BODY" ? document.documentElement.scrollHeight > window.innerHeight : e.scrollHeight > e.offsetHeight,
  Vo = (e) => (e.tagName === "BODY" ? window.innerWidth - St().width : e.offsetWidth - e.clientWidth);
var $ = (e, t) => {
  for (const [n, o] of t) e[n] = o;
  return e;
};
const Dn = w({
  name: "IconHover",
  props: {
    prefix: { type: String },
    size: { type: String, default: "medium" },
    disabled: { type: Boolean, default: !1 },
  },
  setup() {
    return { prefixCls: S("icon-hover") };
  },
});
function On(e, t, n, o, r, i) {
  return (
    g(),
    C(
      "span",
      {
        class: E([
          e.prefixCls,
          {
            [`${e.prefix}-icon-hover`]: e.prefix,
            [`${e.prefixCls}-size-${e.size}`]: e.size !== "medium",
            [`${e.prefixCls}-disabled`]: e.disabled,
          },
        ]),
      },
      [j(e.$slots, "default")],
      2,
    )
  );
}
var Ho = $(Dn, [["render", On]]);
const zn = w({
    name: "IconClose",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = S("icon"),
        o = h(() => [n, `${n}-close`, { [`${n}-spin`]: e.spin }]),
        r = h(() => {
          const l = {};
          return (
            e.size && (l.fontSize = Q(e.size) ? `${e.size}px` : e.size),
            e.rotate && (l.transform = `rotate(${e.rotate}deg)`),
            l
          );
        });
      return {
        cls: o,
        innerStyle: r,
        onClick: (l) => {
          t("click", l);
        },
      };
    },
  }),
  An = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Mn(e, t, n, o, r, i) {
  return (
    g(),
    C(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: E(e.cls),
        style: J(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...l) => e.onClick && e.onClick(...l)),
      },
      t[1] ||
        (t[1] = [
          X("path", { d: "M9.857 9.858 24 24m0 0 14.142 14.142M24 24 38.142 9.858M24 24 9.857 38.142" }, null, -1),
        ]),
      14,
      An,
    )
  );
}
var Be = $(zn, [["render", Mn]]);
const qo = Object.assign(Be, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + Be.name, Be);
    },
  }),
  Tn = w({
    name: "IconCheckCircleFill",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = S("icon"),
        o = h(() => [n, `${n}-check-circle-fill`, { [`${n}-spin`]: e.spin }]),
        r = h(() => {
          const l = {};
          return (
            e.size && (l.fontSize = Q(e.size) ? `${e.size}px` : e.size),
            e.rotate && (l.transform = `rotate(${e.rotate}deg)`),
            l
          );
        });
      return {
        cls: o,
        innerStyle: r,
        onClick: (l) => {
          t("click", l);
        },
      };
    },
  }),
  Ln = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Pn(e, t, n, o, r, i) {
  return (
    g(),
    C(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: E(e.cls),
        style: J(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...l) => e.onClick && e.onClick(...l)),
      },
      t[1] ||
        (t[1] = [
          X(
            "path",
            {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20Zm10.207-24.379a1 1 0 0 0 0-1.414l-1.414-1.414a1 1 0 0 0-1.414 0L22 26.172l-4.878-4.88a1 1 0 0 0-1.415 0l-1.414 1.415a1 1 0 0 0 0 1.414l7 7a1 1 0 0 0 1.414 0l11.5-11.5Z",
              fill: "currentColor",
              stroke: "none",
            },
            null,
            -1,
          ),
        ]),
      14,
      Ln,
    )
  );
}
var Fe = $(Tn, [["render", Pn]]);
const xn = Object.assign(Fe, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + Fe.name, Fe);
    },
  }),
  jn = w({
    name: "IconExclamationCircleFill",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = S("icon"),
        o = h(() => [n, `${n}-exclamation-circle-fill`, { [`${n}-spin`]: e.spin }]),
        r = h(() => {
          const l = {};
          return (
            e.size && (l.fontSize = Q(e.size) ? `${e.size}px` : e.size),
            e.rotate && (l.transform = `rotate(${e.rotate}deg)`),
            l
          );
        });
      return {
        cls: o,
        innerStyle: r,
        onClick: (l) => {
          t("click", l);
        },
      };
    },
  }),
  In = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Nn(e, t, n, o, r, i) {
  return (
    g(),
    C(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: E(e.cls),
        style: J(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...l) => e.onClick && e.onClick(...l)),
      },
      t[1] ||
        (t[1] = [
          X(
            "path",
            {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20Zm-2-11a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v2Zm4-18a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1V15Z",
              fill: "currentColor",
              stroke: "none",
            },
            null,
            -1,
          ),
        ]),
      14,
      In,
    )
  );
}
var Se = $(jn, [["render", Nn]]);
const Wn = Object.assign(Se, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + Se.name, Se);
    },
  }),
  Vn = w({
    name: "IconCloseCircleFill",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = S("icon"),
        o = h(() => [n, `${n}-close-circle-fill`, { [`${n}-spin`]: e.spin }]),
        r = h(() => {
          const l = {};
          return (
            e.size && (l.fontSize = Q(e.size) ? `${e.size}px` : e.size),
            e.rotate && (l.transform = `rotate(${e.rotate}deg)`),
            l
          );
        });
      return {
        cls: o,
        innerStyle: r,
        onClick: (l) => {
          t("click", l);
        },
      };
    },
  }),
  Hn = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function qn(e, t, n, o, r, i) {
  return (
    g(),
    C(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: E(e.cls),
        style: J(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...l) => e.onClick && e.onClick(...l)),
      },
      t[1] ||
        (t[1] = [
          X(
            "path",
            {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20Zm4.955-27.771-4.95 4.95-4.95-4.95a1 1 0 0 0-1.414 0l-1.414 1.414a1 1 0 0 0 0 1.414l4.95 4.95-4.95 4.95a1 1 0 0 0 0 1.414l1.414 1.414a1 1 0 0 0 1.414 0l4.95-4.95 4.95 4.95a1 1 0 0 0 1.414 0l1.414-1.414a1 1 0 0 0 0-1.414l-4.95-4.95 4.95-4.95a1 1 0 0 0 0-1.414l-1.414-1.414a1 1 0 0 0-1.414 0Z",
              fill: "currentColor",
              stroke: "none",
            },
            null,
            -1,
          ),
        ]),
      14,
      Hn,
    )
  );
}
var _e = $(Vn, [["render", qn]]);
const Gn = Object.assign(_e, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + _e.name, _e);
    },
  }),
  Go = ["info", "success", "warning", "error"],
  Yo = [
    "onFocus",
    "onFocusin",
    "onFocusout",
    "onBlur",
    "onChange",
    "onBeforeinput",
    "onInput",
    "onReset",
    "onSubmit",
    "onInvalid",
    "onKeydown",
    "onKeypress",
    "onKeyup",
    "onCopy",
    "onCut",
    "onPaste",
    "onCompositionstart",
    "onCompositionupdate",
    "onCompositionend",
    "onSelect",
    "autocomplete",
    "autofocus",
    "maxlength",
    "minlength",
    "name",
    "pattern",
    "readonly",
    "required",
  ],
  Yn = w({
    name: "IconLoading",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = S("icon"),
        o = h(() => [n, `${n}-loading`, { [`${n}-spin`]: e.spin }]),
        r = h(() => {
          const l = {};
          return (
            e.size && (l.fontSize = Q(e.size) ? `${e.size}px` : e.size),
            e.rotate && (l.transform = `rotate(${e.rotate}deg)`),
            l
          );
        });
      return {
        cls: o,
        innerStyle: r,
        onClick: (l) => {
          t("click", l);
        },
      };
    },
  }),
  Zn = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Kn(e, t, n, o, r, i) {
  return (
    g(),
    C(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: E(e.cls),
        style: J(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...l) => e.onClick && e.onClick(...l)),
      },
      t[1] || (t[1] = [X("path", { d: "M42 24c0 9.941-8.059 18-18 18S6 33.941 6 24 14.059 6 24 6" }, null, -1)]),
      14,
      Zn,
    )
  );
}
var $e = $(Yn, [["render", Kn]]);
const _t = Object.assign($e, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + $e.name, $e);
    },
  }),
  Xn = w({
    name: "FeedbackIcon",
    components: { IconLoading: _t, IconCheckCircleFill: xn, IconExclamationCircleFill: Wn, IconCloseCircleFill: Gn },
    props: { type: { type: String } },
    setup(e) {
      const t = S("feedback-icon");
      return { cls: h(() => [t, `${t}-status-${e.type}`]) };
    },
  });
function Jn(e, t, n, o, r, i) {
  const l = Z("icon-loading"),
    s = Z("icon-check-circle-fill"),
    a = Z("icon-exclamation-circle-fill"),
    d = Z("icon-close-circle-fill");
  return (
    g(),
    C(
      "span",
      { class: E(e.cls) },
      [
        e.type === "validating"
          ? (g(), I(l, { key: 0 }))
          : e.type === "success"
            ? (g(), I(s, { key: 1 }))
            : e.type === "warning"
              ? (g(), I(a, { key: 2 }))
              : e.type === "error"
                ? (g(), I(d, { key: 3 }))
                : Me("v-if", !0),
      ],
      2,
    )
  );
}
var Zo = $(Xn, [["render", Jn]]);
const Un = (e, t) => {
  const n = { ...e };
  for (const o of t) o in n && delete n[o];
  return n;
};
function Ko(e, t) {
  const n = {};
  return (
    t.forEach((o) => {
      const r = o;
      o in e && (n[r] = e[r]);
    }),
    n
  );
}
const Qn = Symbol("ArcoFormItemContext"),
  Xo = Symbol("ArcoFormContext"),
  Rn = ({ size: e, disabled: t, error: n, uninject: o } = {}) => {
    const r = o ? {} : M(Qn, {}),
      i = h(() => {
        var f;
        return (f = e == null ? void 0 : e.value) != null ? f : r.size;
      }),
      l = h(() => (t == null ? void 0 : t.value) || r.disabled),
      s = h(() => (n == null ? void 0 : n.value) || r.error),
      a = Re(r, "feedback"),
      d = Re(r, "eventHandlers");
    return { formItemCtx: r, mergedSize: i, mergedDisabled: l, mergedError: s, feedback: a, eventHandlers: d };
  },
  eo = (e, { defaultValue: t = "medium" } = {}) => {
    const n = M(ae, void 0);
    return {
      mergedSize: h(() => {
        var r, i;
        return (i = (r = e == null ? void 0 : e.value) != null ? r : n == null ? void 0 : n.size) != null ? i : t;
      }),
    };
  },
  $t = Symbol("ArcoButtonGroup"),
  to = w({
    name: "Button",
    components: { IconLoading: _t },
    props: {
      type: { type: String },
      shape: { type: String },
      status: { type: String },
      size: { type: String },
      long: { type: Boolean, default: !1 },
      loading: { type: Boolean, default: !1 },
      disabled: { type: Boolean },
      htmlType: { type: String, default: "button" },
      autofocus: { type: Boolean, default: !1 },
      href: String,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const { size: n, disabled: o } = ue(e),
        r = S("btn"),
        i = M($t, void 0),
        l = h(() => {
          var b;
          return (b = n.value) != null ? b : i == null ? void 0 : i.size;
        }),
        s = h(() => !!(o.value || (i != null && i.disabled))),
        { mergedSize: a, mergedDisabled: d } = Rn({ size: l, disabled: s }),
        { mergedSize: f } = eo(a),
        v = h(() => {
          var b, V, D, H, q, G;
          return [
            r,
            `${r}-${(V = (b = e.type) != null ? b : i == null ? void 0 : i.type) != null ? V : "secondary"}`,
            `${r}-shape-${(H = (D = e.shape) != null ? D : i == null ? void 0 : i.shape) != null ? H : "square"}`,
            `${r}-size-${f.value}`,
            `${r}-status-${(G = (q = e.status) != null ? q : i == null ? void 0 : i.status) != null ? G : "normal"}`,
            {
              [`${r}-long`]: e.long,
              [`${r}-loading`]: e.loading,
              [`${r}-disabled`]: d.value,
              [`${r}-link`]: Ie(e.href),
            },
          ];
        });
      return {
        prefixCls: r,
        cls: v,
        mergedDisabled: d,
        handleClick: (b) => {
          if (e.disabled || e.loading) {
            b.preventDefault();
            return;
          }
          t("click", b);
        },
      };
    },
  }),
  no = ["href"],
  oo = ["type", "disabled", "autofocus"];
function ro(e, t, n, o, r, i) {
  const l = Z("icon-loading");
  return e.href
    ? (g(),
      C(
        "a",
        {
          key: 0,
          class: E([e.cls, { [`${e.prefixCls}-only-icon`]: e.$slots.icon && !e.$slots.default }]),
          href: e.mergedDisabled || e.loading ? void 0 : e.href,
          onClick: t[0] || (t[0] = (...s) => e.handleClick && e.handleClick(...s)),
        },
        [
          e.loading || e.$slots.icon
            ? (g(),
              C(
                "span",
                { key: 0, class: E(`${e.prefixCls}-icon`) },
                [e.loading ? (g(), I(l, { key: 0, spin: "true" })) : j(e.$slots, "icon", { key: 1 })],
                2,
              ))
            : Me("v-if", !0),
          j(e.$slots, "default"),
        ],
        10,
        no,
      ))
    : (g(),
      C(
        "button",
        {
          key: 1,
          class: E([e.cls, { [`${e.prefixCls}-only-icon`]: e.$slots.icon && !e.$slots.default }]),
          type: e.htmlType,
          disabled: e.mergedDisabled,
          autofocus: e.autofocus,
          onClick: t[1] || (t[1] = (...s) => e.handleClick && e.handleClick(...s)),
        },
        [
          e.loading || e.$slots.icon
            ? (g(),
              C(
                "span",
                { key: 0, class: E(`${e.prefixCls}-icon`) },
                [e.loading ? (g(), I(l, { key: 0, spin: !0 })) : j(e.$slots, "icon", { key: 1 })],
                2,
              ))
            : Me("v-if", !0),
          j(e.$slots, "default"),
        ],
        10,
        oo,
      ));
}
var De = $(to, [["render", ro]]);
const io = w({
  name: "ButtonGroup",
  props: {
    type: { type: String },
    status: { type: String },
    shape: { type: String },
    size: { type: String },
    disabled: { type: Boolean },
  },
  setup(e) {
    const { type: t, size: n, status: o, disabled: r, shape: i } = ue(e),
      l = S("btn-group");
    return (ct($t, Pe({ type: t, size: n, shape: i, status: o, disabled: r })), { prefixCls: l });
  },
});
function lo(e, t, n, o, r, i) {
  return (g(), C("div", { class: E(e.prefixCls) }, [j(e.$slots, "default")], 2));
}
var Oe = $(io, [["render", lo]]);
const Jo = Object.assign(De, {
  Group: Oe,
  install: (e, t) => {
    ht(e, t);
    const n = ft(t);
    (e.component(n + De.name, De), e.component(n + Oe.name, Oe));
  },
});
function uo(e) {
  const t = p(e);
  return [
    t,
    (o) => {
      t.value = o;
    },
  ];
}
function Uo(e, t) {
  const { value: n } = ue(t),
    [o, r] = uo(Ce(n.value) ? e : n.value);
  return (
    N(n, (l) => {
      Ce(l) && r(void 0);
    }),
    [h(() => (Ce(n.value) ? o.value : n.value)), r, o]
  );
}
const so = () => {
    const { height: e, width: t } = St();
    return { width: Math.min(t, window.innerWidth), height: Math.min(e, window.innerHeight) };
  },
  lt = (e, t) => {
    var n, o;
    const r = e.getBoundingClientRect();
    return {
      top: r.top,
      bottom: r.bottom,
      left: r.left,
      right: r.right,
      scrollTop: r.top - t.top,
      scrollBottom: r.bottom - t.top,
      scrollLeft: r.left - t.left,
      scrollRight: r.right - t.left,
      width: (n = e.offsetWidth) != null ? n : e.clientWidth,
      height: (o = e.offsetHeight) != null ? o : e.clientHeight,
    };
  },
  ao = (e) => {
    switch (e) {
      case "top":
      case "tl":
      case "tr":
        return "top";
      case "bottom":
      case "bl":
      case "br":
        return "bottom";
      case "left":
      case "lt":
      case "lb":
        return "left";
      case "right":
      case "rt":
      case "rb":
        return "right";
      default:
        return "top";
    }
  },
  re = (e, t) => {
    switch (t) {
      case "top":
        switch (e) {
          case "bottom":
            return "top";
          case "bl":
            return "tl";
          case "br":
            return "tr";
          default:
            return e;
        }
      case "bottom":
        switch (e) {
          case "top":
            return "bottom";
          case "tl":
            return "bl";
          case "tr":
            return "br";
          default:
            return e;
        }
      case "left":
        switch (e) {
          case "right":
            return "left";
          case "rt":
            return "lt";
          case "rb":
            return "lb";
          default:
            return e;
        }
      case "right":
        switch (e) {
          case "left":
            return "right";
          case "lt":
            return "rt";
          case "lb":
            return "rb";
          default:
            return e;
        }
      default:
        return e;
    }
  },
  co = (e, t, { containerRect: n, triggerRect: o, popupRect: r, offset: i, translate: l }) => {
    const s = ao(e),
      a = so(),
      d = {
        top: n.top + t.top,
        bottom: a.height - (n.top + t.top + r.height),
        left: n.left + t.left,
        right: a.width - (n.left + t.left + r.width),
      };
    let f = e;
    if (s === "top" && d.top < 0)
      if (o.top > r.height) t.top = -n.top;
      else {
        const v = K("bottom", o, r, { offset: i, translate: l });
        a.height - (n.top + v.top + r.height) > 0 && ((f = re(e, "bottom")), (t.top = v.top));
      }
    if (s === "bottom" && d.bottom < 0)
      if (a.height - o.bottom > r.height) t.top = -n.top + (a.height - r.height);
      else {
        const v = K("top", o, r, { offset: i, translate: l });
        n.top + v.top > 0 && ((f = re(e, "top")), (t.top = v.top));
      }
    if (s === "left" && d.left < 0)
      if (o.left > r.width) t.left = -n.left;
      else {
        const v = K("right", o, r, { offset: i, translate: l });
        a.width - (n.left + v.left + r.width) > 0 && ((f = re(e, "right")), (t.left = v.left));
      }
    if (s === "right" && d.right < 0)
      if (a.width - o.right > r.width) t.left = -n.left + (a.width - r.width);
      else {
        const v = K("left", o, r, { offset: i, translate: l });
        n.left + v.left > 0 && ((f = re(e, "left")), (t.left = v.left));
      }
    return (
      (s === "top" || s === "bottom") &&
        (d.left < 0 ? (t.left = -n.left) : d.right < 0 && (t.left = -n.left + (a.width - r.width))),
      (s === "left" || s === "right") &&
        (d.top < 0 ? (t.top = -n.top) : d.bottom < 0 && (t.top = -n.top + (a.height - r.height))),
      { popupPosition: t, position: f }
    );
  },
  K = (e, t, n, { offset: o = 0, translate: r = [0, 0] } = {}) => {
    var i;
    const l = (i = se(r) ? r : r[e]) != null ? i : [0, 0];
    switch (e) {
      case "top":
        return {
          left: t.scrollLeft + Math.round(t.width / 2) - Math.round(n.width / 2) + l[0],
          top: t.scrollTop - n.height - o + l[1],
        };
      case "tl":
        return { left: t.scrollLeft + l[0], top: t.scrollTop - n.height - o + l[1] };
      case "tr":
        return { left: t.scrollRight - n.width + l[0], top: t.scrollTop - n.height - o + l[1] };
      case "bottom":
        return {
          left: t.scrollLeft + Math.round(t.width / 2) - Math.round(n.width / 2) + l[0],
          top: t.scrollBottom + o + l[1],
        };
      case "bl":
        return { left: t.scrollLeft + l[0], top: t.scrollBottom + o + l[1] };
      case "br":
        return { left: t.scrollRight - n.width + l[0], top: t.scrollBottom + o + l[1] };
      case "left":
        return {
          left: t.scrollLeft - n.width - o + l[0],
          top: t.scrollTop + Math.round(t.height / 2) - Math.round(n.height / 2) + l[1],
        };
      case "lt":
        return { left: t.scrollLeft - n.width - o + l[0], top: t.scrollTop + l[1] };
      case "lb":
        return { left: t.scrollLeft - n.width - o + l[0], top: t.scrollBottom - n.height + l[1] };
      case "right":
        return {
          left: t.scrollRight + o + l[0],
          top: t.scrollTop + Math.round(t.height / 2) - Math.round(n.height / 2) + l[1],
        };
      case "rt":
        return { left: t.scrollRight + o + l[0], top: t.scrollTop + l[1] };
      case "rb":
        return { left: t.scrollRight + o + l[0], top: t.scrollBottom - n.height + l[1] };
      default:
        return { left: 0, top: 0 };
    }
  },
  fo = (e) => {
    let t = "0";
    ["top", "bottom"].includes(e) ? (t = "50%") : ["left", "lt", "lb", "tr", "br"].includes(e) && (t = "100%");
    let n = "0";
    return (
      ["left", "right"].includes(e) ? (n = "50%") : ["top", "tl", "tr", "lb", "rb"].includes(e) && (n = "100%"),
      `${t} ${n}`
    );
  },
  ho = (e, t, n, o, { offset: r = 0, translate: i = [0, 0], customStyle: l = {}, autoFitPosition: s = !1 } = {}) => {
    let a = e,
      d = K(e, n, o, { offset: r, translate: i });
    if (s) {
      const v = co(e, d, { containerRect: t, popupRect: o, triggerRect: n, offset: r, translate: i });
      ((d = v.popupPosition), (a = v.position));
    }
    return { style: { left: `${d.left}px`, top: `${d.top}px`, ...l }, position: a };
  },
  vo = (e, t, n, { customStyle: o = {} }) => {
    if (["top", "tl", "tr", "bottom", "bl", "br"].includes(e)) {
      let i = Math.abs(t.scrollLeft + t.width / 2 - n.scrollLeft);
      return (
        i > n.width - 8 && (t.width > n.width ? (i = n.width / 2) : (i = n.width - 8)),
        ["top", "tl", "tr"].includes(e)
          ? { left: `${i}px`, bottom: "0", transform: "translate(-50%,50%) rotate(45deg)", ...o }
          : { left: `${i}px`, top: "0", transform: "translate(-50%,-50%) rotate(45deg)", ...o }
      );
    }
    let r = Math.abs(t.scrollTop + t.height / 2 - n.scrollTop);
    return (
      r > n.height - 8 && (t.height > n.height ? (r = n.height / 2) : (r = n.height - 8)),
      ["left", "lt", "lb"].includes(e)
        ? { top: `${r}px`, right: "0", transform: "translate(50%,-50%) rotate(45deg)", ...o }
        : { top: `${r}px`, left: "0", transform: "translate(-50%,-50%) rotate(45deg)", ...o }
    );
  },
  mo = (e) => e.scrollHeight > e.offsetHeight || e.scrollWidth > e.offsetWidth,
  ut = (e) => {
    var t;
    const n = [];
    let o = e;
    for (; o && o !== document.documentElement; )
      (mo(o) && n.push(o), (o = (t = o.parentElement) != null ? t : void 0));
    return n;
  },
  Dt = () => {
    const e = {},
      t = p(),
      n = () => {
        const o = Bt(e.value);
        o !== t.value && (t.value = o);
      };
    return (U(() => n()), xe(() => n()), { children: e, firstElement: t });
  };
var st = w({
  name: "ResizeObserver",
  props: { watchOnUpdated: Boolean },
  emits: ["resize"],
  setup(e, { emit: t, slots: n }) {
    const { children: o, firstElement: r } = Dt();
    let i;
    const l = (a) => {
        a &&
          ((i = new yt((d) => {
            const f = d[0];
            t("resize", f);
          })),
          i.observe(a));
      },
      s = () => {
        i && (i.disconnect(), (i = null));
      };
    return (
      N(r, (a) => {
        (i && s(), a && l(a));
      }),
      je(() => {
        i && s();
      }),
      () => {
        var a;
        return ((o.value = (a = n.default) == null ? void 0 : a.call(n)), o.value);
      }
    );
  },
});
function po(e, t) {
  const n = p(e[t]);
  return (
    xe(() => {
      const o = e[t];
      n.value !== o && (n.value = o);
    }),
    n
  );
}
const at = Symbol("ArcoTrigger"),
  go = 1e3,
  bo = 5e3,
  yo = 1;
class Co {
  constructor() {
    ((this.popupStack = { popup: new Set(), dialog: new Set(), message: new Set() }),
      (this.getNextZIndex = (t) =>
        (t === "message"
          ? Array.from(this.popupStack.message).pop() || bo
          : Array.from(this.popupStack.popup).pop() || go) + yo),
      (this.add = (t) => {
        const n = this.getNextZIndex(t);
        return (this.popupStack[t].add(n), t === "dialog" && this.popupStack.popup.add(n), n);
      }),
      (this.delete = (t, n) => {
        (this.popupStack[n].delete(t), n === "dialog" && this.popupStack.popup.delete(t));
      }),
      (this.isLastDialog = (t) =>
        this.popupStack.dialog.size > 1 ? t === Array.from(this.popupStack.dialog).pop() : !0));
  }
}
const ze = new Co();
function Eo(e, { visible: t, runOnMounted: n } = {}) {
  const o = p(0),
    r = () => {
      o.value = ze.add(e);
    },
    i = () => {
      ze.delete(o.value, e);
    },
    l = () => (e === "dialog" ? ze.isLastDialog(o.value) : !1);
  return (
    N(
      () => (t == null ? void 0 : t.value),
      (s) => {
        s ? r() : i();
      },
      { immediate: !0 },
    ),
    n &&
      (U(() => {
        r();
      }),
      je(() => {
        i();
      })),
    { zIndex: Kt(o), open: r, close: i, isLastDialog: l }
  );
}
const wo = ({ elementRef: e, onResize: t }) => {
  let n;
  return {
    createResizeObserver: () => {
      e.value &&
        ((n = new yt((i) => {
          const l = i[0];
          Ne(t) && t(l);
        })),
        n.observe(e.value));
    },
    destroyResizeObserver: () => {
      n && (n.disconnect(), (n = null));
    },
  };
};
var ko = w({
  name: "ClientOnly",
  setup(e, { slots: t }) {
    const n = p(!1);
    return (
      U(() => (n.value = !0)),
      () => {
        var o;
        return n.value ? ((o = t.default) == null ? void 0 : o.call(t)) : null;
      }
    );
  },
});
const Bo = ({ popupContainer: e, visible: t, defaultContainer: n = "body", documentContainer: o }) => {
    const r = p(e.value),
      i = p(),
      l = () => {
        const s = it(e.value),
          a = s ? e.value : n,
          d = s ?? (o ? document.documentElement : it(n));
        (a !== r.value && (r.value = a), d !== i.value && (i.value = d));
      };
    return (
      U(() => l()),
      N(t, (s) => {
        r.value !== e.value && s && l();
      }),
      { teleportContainer: r, containerRef: i }
    );
  },
  Fo = ["onClick", "onMouseenter", "onMouseleave", "onFocusin", "onFocusout", "onContextmenu"];
var Ae = w({
  name: "Trigger",
  inheritAttrs: !1,
  props: {
    popupVisible: { type: Boolean, default: void 0 },
    defaultPopupVisible: { type: Boolean, default: !1 },
    trigger: { type: [String, Array], default: "hover" },
    position: { type: String, default: "bottom" },
    disabled: { type: Boolean, default: !1 },
    popupOffset: { type: Number, default: 0 },
    popupTranslate: { type: [Array, Object] },
    showArrow: { type: Boolean, default: !1 },
    alignPoint: { type: Boolean, default: !1 },
    popupHoverStay: { type: Boolean, default: !0 },
    blurToClose: { type: Boolean, default: !0 },
    clickToClose: { type: Boolean, default: !0 },
    clickOutsideToClose: { type: Boolean, default: !0 },
    unmountOnClose: { type: Boolean, default: !0 },
    contentClass: { type: [String, Array, Object] },
    contentStyle: { type: Object },
    arrowClass: { type: [String, Array, Object] },
    arrowStyle: { type: Object },
    popupStyle: { type: Object },
    animationName: { type: String, default: "fade-in" },
    duration: { type: [Number, Object] },
    mouseEnterDelay: { type: Number, default: 100 },
    mouseLeaveDelay: { type: Number, default: 100 },
    focusDelay: { type: Number, default: 0 },
    autoFitPopupWidth: { type: Boolean, default: !1 },
    autoFitPopupMinWidth: { type: Boolean, default: !1 },
    autoFixPosition: { type: Boolean, default: !0 },
    popupContainer: { type: [String, Object] },
    updateAtScroll: { type: Boolean, default: !1 },
    autoFitTransformOrigin: { type: Boolean, default: !1 },
    hideEmpty: { type: Boolean, default: !1 },
    openedClass: { type: [String, Array, Object] },
    autoFitPosition: { type: Boolean, default: !0 },
    renderToBody: { type: Boolean, default: !0 },
    preventFocus: { type: Boolean, default: !1 },
    scrollToClose: { type: Boolean, default: !1 },
    scrollToCloseDistance: { type: Number, default: 0 },
  },
  emits: {
    "update:popupVisible": (e) => !0,
    popupVisibleChange: (e) => !0,
    show: () => !0,
    hide: () => !0,
    resize: () => !0,
  },
  setup(e, { emit: t, slots: n, attrs: o }) {
    const { popupContainer: r } = ue(e),
      i = S("trigger"),
      l = h(() => Un(o, Fo)),
      s = M(ae, void 0),
      a = h(() => [].concat(e.trigger)),
      d = new Set(),
      f = M(at, void 0),
      { children: v, firstElement: L } = Dt(),
      b = p(),
      V = p(e.defaultPopupVisible),
      D = p(e.position),
      H = p({}),
      q = p({}),
      G = p({}),
      Ot = p(),
      _ = p({ top: 0, left: 0 });
    let R = null,
      ee = null;
    const m = h(() => {
        var u;
        return (u = e.popupVisible) != null ? u : V.value;
      }),
      { teleportContainer: zt, containerRef: he } = Bo({ popupContainer: r, visible: m, documentContainer: !0 }),
      { zIndex: At } = Eo("popup", { visible: m });
    let Y = 0,
      O = !1,
      ve = !1;
    const Mt = () => {
        Y && (window.clearTimeout(Y), (Y = 0));
      },
      me = (u) => {
        if (e.alignPoint) {
          const { pageX: c, pageY: y } = u;
          _.value = { top: y, left: c };
        }
      },
      z = () => {
        if (!L.value || !b.value || !he.value) return;
        const u = he.value.getBoundingClientRect(),
          c = e.alignPoint
            ? {
                top: _.value.top,
                bottom: _.value.top,
                left: _.value.left,
                right: _.value.left,
                scrollTop: _.value.top,
                scrollBottom: _.value.top,
                scrollLeft: _.value.left,
                scrollRight: _.value.left,
                width: 0,
                height: 0,
              }
            : lt(L.value, u),
          y = () => lt(b.value, u),
          P = y(),
          { style: A, position: x } = ho(e.position, u, c, P, {
            offset: e.popupOffset,
            translate: e.popupTranslate,
            customStyle: e.popupStyle,
            autoFitPosition: e.autoFitPosition,
          });
        (e.autoFitTransformOrigin && (q.value = { transformOrigin: fo(x) }),
          e.autoFitPopupMinWidth ? (A.minWidth = `${c.width}px`) : e.autoFitPopupWidth && (A.width = `${c.width}px`),
          D.value !== x && (D.value = x),
          (H.value = A),
          e.showArrow &&
            et(() => {
              G.value = vo(x, c, y(), { customStyle: e.arrowStyle });
            }));
      },
      k = (u, c) => {
        if (u === m.value && Y === 0) return;
        const y = () => {
          ((V.value = u),
            t("update:popupVisible", u),
            t("popupVisibleChange", u),
            u &&
              et(() => {
                z();
              }));
        };
        (u || ((R = null), (ee = null)), c ? (Mt(), u !== m.value && (Y = window.setTimeout(y, c))) : y());
      },
      Tt = (u) => {
        var c;
        ((c = o.onClick) == null || c.call(o, u),
          !(e.disabled || (m.value && !e.clickToClose)) &&
            (a.value.includes("click") ? (me(u), k(!m.value)) : a.value.includes("contextMenu") && m.value && k(!1)));
      },
      qe = (u) => {
        var c;
        ((c = o.onMouseenter) == null || c.call(o, u),
          !(e.disabled || !a.value.includes("hover")) && (me(u), k(!0, e.mouseEnterDelay)));
      },
      Ge = (u) => {
        (f == null || f.onMouseenter(u), qe(u));
      },
      Ye = (u) => {
        var c;
        ((c = o.onMouseleave) == null || c.call(o, u),
          !(e.disabled || !a.value.includes("hover")) && k(!1, e.mouseLeaveDelay));
      },
      Ze = (u) => {
        (f == null || f.onMouseleave(u), Ye(u));
      },
      Lt = (u) => {
        var c;
        ((c = o.onFocusin) == null || c.call(o, u), !(e.disabled || !a.value.includes("focus")) && k(!0, e.focusDelay));
      },
      Pt = (u) => {
        var c;
        ((c = o.onFocusout) == null || c.call(o, u),
          !(e.disabled || !a.value.includes("focus")) && e.blurToClose && k(!1));
      },
      xt = (u) => {
        var c;
        ((c = o.onContextmenu) == null || c.call(o, u),
          !(e.disabled || !a.value.includes("contextMenu") || (m.value && !e.clickToClose)) &&
            (me(u), k(!m.value), u.preventDefault()));
      };
    ct(
      at,
      Pe({
        onMouseenter: Ge,
        onMouseleave: Ze,
        addChildRef: (u) => {
          (d.add(u), f == null || f.addChildRef(u));
        },
        removeChildRef: (u) => {
          (d.delete(u), f == null || f.removeChildRef(u));
        },
      }),
    );
    const pe = () => {
        (rt(document.documentElement, "mousedown", ge), (O = !1));
      },
      Ke = po(n, "content"),
      jt = h(() => {
        var u;
        return e.hideEmpty && Sn((u = Ke.value) == null ? void 0 : u.call(Ke));
      }),
      ge = (u) => {
        var c, y, P;
        if (!(((c = L.value) != null && c.contains(u.target)) || ((y = b.value) != null && y.contains(u.target)))) {
          for (const A of d) if ((P = A.value) != null && P.contains(u.target)) return;
          (pe(), k(!1));
        }
      },
      Xe = (u, c) => {
        const [y, P] = u,
          { scrollTop: A, scrollLeft: x } = c;
        return Math.abs(A - y) >= e.scrollToCloseDistance || Math.abs(x - P) >= e.scrollToCloseDistance;
      },
      te = ot((u) => {
        if (m.value)
          if (e.scrollToClose || (s != null && s.scrollToClose)) {
            const c = u.target;
            (R || (R = [c.scrollTop, c.scrollLeft]), Xe(R, c) ? k(!1) : z());
          } else z();
      }),
      Je = () => {
        (rt(window, "scroll", Ue), (ve = !1));
      },
      Ue = ot((u) => {
        const c = u.target.documentElement;
        (ee || (ee = [c.scrollTop, c.scrollLeft]), Xe(ee, c) && (k(!1), Je()));
      }),
      be = () => {
        m.value && z();
      },
      It = () => {
        (be(), t("resize"));
      },
      Nt = (u) => {
        e.preventFocus && u.preventDefault();
      };
    f == null || f.addChildRef(b);
    const Wt = h(() => (m.value ? e.openedClass : void 0));
    let B;
    (N(m, (u) => {
      if (
        (e.clickOutsideToClose &&
          (!u && O ? pe() : u && !O && (ke(document.documentElement, "mousedown", ge), (O = !0))),
        (e.scrollToClose || (s != null && s.scrollToClose)) && (ke(window, "scroll", Ue), (ve = !0)),
        e.updateAtScroll || (s != null && s.updateAtScroll))
      ) {
        if (u) {
          B = ut(L.value);
          for (const c of B) c.addEventListener("scroll", te);
        } else if (B) {
          for (const c of B) c.removeEventListener("scroll", te);
          B = void 0;
        }
      }
      u && (ye.value = !0);
    }),
      N(
        () => [e.autoFitPopupWidth, e.autoFitPopupMinWidth],
        () => {
          m.value && z();
        },
      ));
    const { createResizeObserver: Vt, destroyResizeObserver: Ht } = wo({ elementRef: he, onResize: be });
    (U(() => {
      if (
        (Vt(),
        m.value &&
          (z(),
          e.clickOutsideToClose && !O && (ke(document.documentElement, "mousedown", ge), (O = !0)),
          e.updateAtScroll || (s != null && s.updateAtScroll)))
      ) {
        B = ut(L.value);
        for (const u of B) u.addEventListener("scroll", te);
      }
    }),
      xe(() => {
        m.value && z();
      }),
      Xt(() => {
        k(!1);
      }),
      je(() => {
        if ((f == null || f.removeChildRef(b), Ht(), O && pe(), ve && Je(), B)) {
          for (const u of B) u.removeEventListener("scroll", te);
          B = void 0;
        }
      }));
    const ye = p(m.value),
      ne = p(!1),
      Qe = () => {
        ne.value = !0;
      },
      qt = () => {
        ((ne.value = !1), m.value && t("show"));
      },
      Gt = () => {
        ((ne.value = !1), m.value || ((ye.value = !1), t("hide")));
      };
    return () => {
      var u, c;
      return (
        (v.value = (c = (u = n.default) == null ? void 0 : u.call(n)) != null ? c : []),
        Et(v.value, {
          class: Wt.value,
          onClick: Tt,
          onMouseenter: qe,
          onMouseleave: Ye,
          onFocusin: Lt,
          onFocusout: Pt,
          onContextmenu: xt,
        }),
        F(tn, null, [
          e.autoFixPosition ? F(st, { onResize: It }, { default: () => [v.value] }) : v.value,
          F(ko, null, {
            default: () => [
              F(
                Jt,
                { to: zt.value, disabled: !e.renderToBody },
                {
                  default: () => [
                    (!e.unmountOnClose || m.value || ye.value) &&
                      !jt.value &&
                      F(
                        st,
                        { onResize: be },
                        {
                          default: () => [
                            F(
                              "div",
                              Ut(
                                {
                                  ref: b,
                                  class: [`${i}-popup`, `${i}-position-${D.value}`],
                                  style: { ...H.value, zIndex: At.value, pointerEvents: ne.value ? "none" : "auto" },
                                  "trigger-placement": D.value,
                                  onMouseenter: Ge,
                                  onMouseleave: Ze,
                                  onMousedown: Nt,
                                },
                                l.value,
                              ),
                              [
                                F(
                                  Qt,
                                  {
                                    name: e.animationName,
                                    duration: e.duration,
                                    appear: !0,
                                    onBeforeEnter: Qe,
                                    onAfterEnter: qt,
                                    onBeforeLeave: Qe,
                                    onAfterLeave: Gt,
                                  },
                                  {
                                    default: () => {
                                      var y;
                                      return [
                                        Rt(
                                          F("div", { class: `${i}-popup-wrapper`, style: q.value }, [
                                            F(
                                              "div",
                                              { class: [`${i}-content`, e.contentClass], style: e.contentStyle },
                                              [(y = n.content) == null ? void 0 : y.call(n)],
                                            ),
                                            e.showArrow &&
                                              F(
                                                "div",
                                                { ref: Ot, class: [`${i}-arrow`, e.arrowClass], style: G.value },
                                                null,
                                              ),
                                          ]),
                                          [[en, m.value]],
                                        ),
                                      ];
                                    },
                                  },
                                ),
                              ],
                            ),
                          ],
                        },
                      ),
                  ],
                },
              ),
            ],
          }),
        ])
      );
    };
  },
});
const Qo = Object.assign(Ae, {
  install: (e, t) => {
    ht(e, t);
    const n = ft(t);
    e.component(n + Ae.name, Ae);
  },
});
export {
  Do as $,
  Wn as A,
  Jo as B,
  xn as C,
  ko as D,
  Bo as E,
  Zo as F,
  Eo as G,
  it as H,
  qo as I,
  zo as J,
  jo as K,
  Io as L,
  Go as M,
  xo as N,
  Xo as O,
  Qn as P,
  dt as Q,
  st as R,
  $n as S,
  Qo as T,
  Ie as U,
  ot as V,
  Ve as W,
  Mo as X,
  Ee as Y,
  yt as Z,
  $ as _,
  ft as a,
  No as a0,
  Yo as a1,
  Ao as a2,
  we as b,
  Q as c,
  To as d,
  Lo as e,
  Ce as f,
  S as g,
  Ho as h,
  se as i,
  Rn as j,
  eo as k,
  Ne as l,
  Po as m,
  Uo as n,
  _t as o,
  Un as p,
  Ko as q,
  Oo as r,
  ht as s,
  ae as t,
  uo as u,
  Vo as v,
  Wo as w,
  ke as x,
  rt as y,
  Gn as z,
};
