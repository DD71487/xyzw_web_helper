import {
  k as d,
  c as f,
  a as u,
  h as x,
  n as G,
  p as w,
  z as j,
  b as n,
  al as T,
  ah as L,
  o as A,
  _ as E,
  E as O,
} from "./index-UoU16364.js";
import { g as y, k as P, b as V, _ as N, s as D, a as H } from "./index-7YDlkBnY.js";
import { S as k } from "./grid-col-GTGOUscx.js";
const I = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  K = u(
    "path",
    {
      d: "M459.94 53.25a16.06 16.06 0 0 0-23.22-.56L424.35 65a8 8 0 0 0 0 11.31l11.34 11.32a8 8 0 0 0 11.34 0l12.06-12c6.1-6.09 6.67-16.01.85-22.38z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  R = u(
    "path",
    {
      d: "M399.34 90L218.82 270.2a9 9 0 0 0-2.31 3.93L208.16 299a3.91 3.91 0 0 0 4.86 4.86l24.85-8.35a9 9 0 0 0 3.93-2.31L422 112.66a9 9 0 0 0 0-12.66l-9.95-10a9 9 0 0 0-12.71 0z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  q = u(
    "path",
    {
      d: "M386.34 193.66L264.45 315.79A41.08 41.08 0 0 1 247.58 326l-25.9 8.67a35.92 35.92 0 0 1-44.33-44.33l8.67-25.9a41.08 41.08 0 0 1 10.19-16.87l122.13-121.91a8 8 0 0 0-5.65-13.66H104a56 56 0 0 0-56 56v240a56 56 0 0 0 56 56h240a56 56 0 0 0 56-56V199.31a8 8 0 0 0-13.66-5.65z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  F = [K, R, q],
  re = d({
    name: "Create",
    render: function (e, a) {
      return (x(), f("svg", I, F));
    },
  }),
  J = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", viewBox: "0 0 512 512" },
  Q = u(
    "path",
    {
      d: "M256 48C141.13 48 48 141.13 48 256s93.13 208 208 208s208-93.13 208-208S370.87 48 256 48zm83.69 282.65a112.24 112.24 0 0 1-195-61.29a16 16 0 0 1-20.13-24.67l23.6-23.6a16 16 0 0 1 22.37-.25l24.67 23.6a16 16 0 0 1-18 26a80.25 80.25 0 0 0 138.72 38.83a16 16 0 0 1 23.77 21.41zm47.76-63.34l-23.6 23.6a16 16 0 0 1-22.37.25l-24.67-23.6a16 16 0 0 1 17.68-26.11A80.17 80.17 0 0 0 196 202.64a16 16 0 1 1-23.82-21.37a112.17 112.17 0 0 1 194.88 61.57a16 16 0 0 1 20.39 24.47z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  U = [Q],
  oe = d({
    name: "SyncCircle",
    render: function (e, a) {
      return (x(), f("svg", J, U));
    },
  }),
  W = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", viewBox: "0 0 512 512" },
  X = u("rect", { x: "32", y: "48", width: "448", height: "80", rx: "32", ry: "32", fill: "currentColor" }, null, -1),
  Y = u(
    "path",
    {
      d: "M74.45 160a8 8 0 0 0-8 8.83l26.31 252.56a1.5 1.5 0 0 0 0 .22A48 48 0 0 0 140.45 464h231.09a48 48 0 0 0 47.67-42.39v-.21l26.27-252.57a8 8 0 0 0-8-8.83zm248.86 180.69a16 16 0 1 1-22.63 22.62L256 318.63l-44.69 44.68a16 16 0 0 1-22.63-22.62L233.37 296l-44.69-44.69a16 16 0 0 1 22.63-22.62L256 273.37l44.68-44.68a16 16 0 0 1 22.63 22.62L278.62 296z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  Z = [X, Y],
  ie = d({
    name: "TrashBin",
    render: function (e, a) {
      return (x(), f("svg", W, Z));
    },
  }),
  b = Symbol("ArcoCard");
var $ = d({
    name: "Card",
    components: { Spin: k },
    props: {
      bordered: { type: Boolean, default: !0 },
      loading: { type: Boolean, default: !1 },
      hoverable: { type: Boolean, default: !1 },
      size: { type: String },
      headerStyle: { type: Object, default: () => ({}) },
      bodyStyle: { type: Object, default: () => ({}) },
      title: { type: String },
      extra: { type: String },
    },
    setup(t, { slots: e }) {
      const a = y("card"),
        { size: l } = G(t),
        { mergedSize: s } = P(l),
        h = w(() => (s.value === "small" || s.value === "mini" ? "small" : "medium")),
        v = (r) => {
          const o = V(r);
          return n("div", { class: `${a}-actions` }, [
            n("div", { class: `${a}-actions-right` }, [
              o.map((i, m) => n("span", { key: `action-${m}`, class: `${a}-actions-item` }, [i])),
            ]),
          ]);
        },
        c = j({ hasMeta: !1, hasGrid: !1, slots: e, renderActions: v });
      T(b, c);
      const _ = w(() => [
        a,
        `${a}-size-${h.value}`,
        {
          [`${a}-loading`]: t.loading,
          [`${a}-bordered`]: t.bordered,
          [`${a}-hoverable`]: t.hoverable,
          [`${a}-contain-grid`]: c.hasGrid,
        },
      ]);
      return () => {
        var r, o, i, m, S, z, B;
        const g = !!((r = e.title) != null ? r : t.title),
          M = !!((o = e.extra) != null ? o : t.extra);
        return n("div", { class: _.value }, [
          (g || M) &&
            n("div", { class: [`${a}-header`, { [`${a}-header-no-title`]: !g }], style: t.headerStyle }, [
              g &&
                n("div", { class: `${a}-header-title` }, [
                  (m = (i = e.title) == null ? void 0 : i.call(e)) != null ? m : t.title,
                ]),
              M &&
                n("div", { class: `${a}-header-extra` }, [
                  (z = (S = e.extra) == null ? void 0 : S.call(e)) != null ? z : t.extra,
                ]),
            ]),
          e.cover && n("div", { class: `${a}-cover` }, [e.cover()]),
          n("div", { class: `${a}-body`, style: t.bodyStyle }, [
            t.loading ? n(k, null, null) : (B = e.default) == null ? void 0 : B.call(e),
            e.actions && !c.hasMeta && v(e.actions()),
          ]),
        ]);
      };
    },
  }),
  p = d({
    name: "CardMeta",
    props: { title: { type: String }, description: { type: String } },
    setup(t, { slots: e }) {
      const a = y("card-meta"),
        l = L(b);
      return (
        A(() => {
          l && (l.hasMeta = !0);
        }),
        () => {
          var s, h, v, c, _, r;
          const o = !!((s = e.title) != null ? s : t.title),
            i = !!((h = e.description) != null ? h : t.description);
          return n("div", { class: a }, [
            (o || i) &&
              n("div", { class: `${a}-content` }, [
                o &&
                  n("div", { class: `${a}-title` }, [
                    (c = (v = e.title) == null ? void 0 : v.call(e)) != null ? c : t.title,
                  ]),
                i &&
                  n("div", { class: `${a}-description` }, [
                    (r = (_ = e.description) == null ? void 0 : _.call(e)) != null ? r : t.description,
                  ]),
              ]),
            (e.avatar || (l == null ? void 0 : l.slots.actions)) &&
              n("div", { class: [`${a}-footer `, { [`${a}-footer-only-actions`]: !e.avatar }] }, [
                e.avatar && n("div", { class: `${a}-avatar` }, [e.avatar()]),
                l && l.slots.actions && l.renderActions(l.slots.actions()),
              ]),
          ]);
        }
      );
    },
  });
const ee = d({
  name: "CardGrid",
  props: { hoverable: { type: Boolean, default: !1 } },
  setup(t) {
    const e = y("card-grid"),
      a = L(b);
    return (
      A(() => {
        a && (a.hasGrid = !0);
      }),
      { cls: w(() => [e, { [`${e}-hoverable`]: t.hoverable }]) }
    );
  },
});
function ae(t, e, a, l, s, h) {
  return (x(), f("div", { class: O(t.cls) }, [E(t.$slots, "default")], 2));
}
var C = N(ee, [["render", ae]]);
const se = Object.assign($, {
  Meta: p,
  Grid: C,
  install: (t, e) => {
    D(t, e);
    const a = H(e);
    (t.component(a + $.name, $), t.component(a + p.name, p), t.component(a + C.name, C));
  },
});
export { re as C, oe as S, ie as T, se as a };
