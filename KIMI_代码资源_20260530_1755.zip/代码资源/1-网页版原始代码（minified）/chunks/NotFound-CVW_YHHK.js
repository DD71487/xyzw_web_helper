import { c as _, a as t, b as s, w as e, d as i, u as n, f as c, h as p, i as d } from "./index-UoU16364.js";
import { _ as f } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { S as m } from "./Search-D4B4lpJB.js";
const v = { class: "not-found-page" },
  b = { class: "container" },
  x = { class: "error-content" },
  k = { class: "error-visual" },
  N = { class: "error-icon" },
  C = { class: "error-actions" },
  g = {
    __name: "NotFound",
    setup(z) {
      const r = c();
      return (B, o) => {
        const l = i("n-icon"),
          a = i("n-button");
        return (
          p(),
          _("div", v, [
            t("div", b, [
              t("div", x, [
                t("div", k, [
                  o[2] || (o[2] = t("div", { class: "error-number" }, "404", -1)),
                  t("div", N, [s(l, { size: "120" }, { default: e(() => [s(n(m))]), _: 1 })]),
                ]),
                o[5] ||
                  (o[5] = t(
                    "div",
                    { class: "error-text" },
                    [t("h1", null, "页面未找到"), t("p", null, "抱歉，您访问的页面不存在或已被移除。")],
                    -1,
                  )),
                t("div", C, [
                  s(
                    a,
                    { type: "primary", size: "large", onClick: o[0] || (o[0] = (u) => n(r).push("/")) },
                    { default: e(() => [...(o[3] || (o[3] = [d(" 返回首页 ", -1)]))]), _: 1 },
                  ),
                  s(
                    a,
                    { size: "large", onClick: o[1] || (o[1] = (u) => n(r).back()) },
                    { default: e(() => [...(o[4] || (o[4] = [d(" 返回上一页 ", -1)]))]), _: 1 },
                  ),
                ]),
              ]),
            ]),
          ])
        );
      };
    },
  },
  F = f(g, [["__scopeId", "data-v-642fb8f8"]]);
export { F as default };
