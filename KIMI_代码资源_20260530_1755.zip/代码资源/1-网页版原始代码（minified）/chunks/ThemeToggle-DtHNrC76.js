import {
  k as c,
  c as s,
  h as t,
  a as h,
  l as u,
  L as m,
  e as l,
  w as r,
  u as a,
  d as _,
  b as p,
} from "./index-UoU16364.js";
import { _ as w } from "./_plugin-vue_export-helper-DlAUqK2U.js";
const f = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  x = h(
    "path",
    {
      d: "M261.56 101.28a8 8 0 0 0-11.06 0L66.4 277.15a8 8 0 0 0-2.47 5.79L63.9 448a32 32 0 0 0 32 32H192a16 16 0 0 0 16-16V328a8 8 0 0 1 8-8h80a8 8 0 0 1 8 8v136a16 16 0 0 0 16 16h96.06a32 32 0 0 0 32-32V282.94a8 8 0 0 0-2.47-5.79z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  g = h(
    "path",
    {
      d: "M490.91 244.15l-74.8-71.56V64a16 16 0 0 0-16-16h-48a16 16 0 0 0-16 16v32l-57.92-55.38C272.77 35.14 264.71 32 256 32c-8.68 0-16.72 3.14-22.14 8.63l-212.7 203.5c-6.22 6-7 15.87-1.34 22.37A16 16 0 0 0 43 267.56L250.5 69.28a8 8 0 0 1 11.06 0l207.52 198.28a16 16 0 0 0 22.59-.44c6.14-6.36 5.63-16.86-.76-22.97z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  C = [x, g],
  S = c({
    name: "Home",
    render: function (e, o) {
      return (t(), s("svg", f, C));
    },
  }),
  v = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", viewBox: "0 0 512 512" },
  k = h(
    "path",
    {
      d: "M264 480A232 232 0 0 1 32 248c0-94 54-178.28 137.61-214.67a16 16 0 0 1 21.06 21.06C181.07 76.43 176 104.66 176 136c0 110.28 89.72 200 200 200c31.34 0 59.57-5.07 81.61-14.67a16 16 0 0 1 21.06 21.06C442.28 426 358 480 264 480z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  M = [k],
  z = c({
    name: "Moon",
    render: function (e, o) {
      return (t(), s("svg", v, M));
    },
  }),
  B = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", viewBox: "0 0 512 512" },
  T = u(
    '<path d="M256 118a22 22 0 0 1-22-22V48a22 22 0 0 1 44 0v48a22 22 0 0 1-22 22z" fill="currentColor"></path><path d="M256 486a22 22 0 0 1-22-22v-48a22 22 0 0 1 44 0v48a22 22 0 0 1-22 22z" fill="currentColor"></path><path d="M369.14 164.86a22 22 0 0 1-15.56-37.55l33.94-33.94a22 22 0 0 1 31.11 31.11l-33.94 33.94a21.93 21.93 0 0 1-15.55 6.44z" fill="currentColor"></path><path d="M108.92 425.08a22 22 0 0 1-15.55-37.56l33.94-33.94a22 22 0 1 1 31.11 31.11l-33.94 33.94a21.94 21.94 0 0 1-15.56 6.45z" fill="currentColor"></path><path d="M464 278h-48a22 22 0 0 1 0-44h48a22 22 0 0 1 0 44z" fill="currentColor"></path><path d="M96 278H48a22 22 0 0 1 0-44h48a22 22 0 0 1 0 44z" fill="currentColor"></path><path d="M403.08 425.08a21.94 21.94 0 0 1-15.56-6.45l-33.94-33.94a22 22 0 0 1 31.11-31.11l33.94 33.94a22 22 0 0 1-15.55 37.56z" fill="currentColor"></path><path d="M142.86 164.86a21.89 21.89 0 0 1-15.55-6.44l-33.94-33.94a22 22 0 0 1 31.11-31.11l33.94 33.94a22 22 0 0 1-15.56 37.55z" fill="currentColor"></path><path d="M256 358a102 102 0 1 1 102-102a102.12 102.12 0 0 1-102 102z" fill="currentColor"></path>',
    9,
  ),
  V = [T],
  H = c({
    name: "Sunny",
    render: function (e, o) {
      return (t(), s("svg", B, V));
    },
  }),
  $ = {
    __name: "ThemeToggle",
    setup(n) {
      const { isDark: e, toggleTheme: o } = m();
      return (b, y) => {
        const i = _("n-icon"),
          d = _("n-button");
        return (
          t(),
          l(
            d,
            { circle: "", size: "medium", class: "theme-toggle", onClick: a(o) },
            {
              icon: r(() => [
                a(e)
                  ? (t(), l(i, { key: 0 }, { default: r(() => [p(a(H))]), _: 1 }))
                  : (t(), l(i, { key: 1 }, { default: r(() => [p(a(z))]), _: 1 })),
              ]),
              _: 1,
            },
            8,
            ["onClick"],
          )
        );
      };
    },
  },
  A = w($, [["__scopeId", "data-v-8808456b"]]);
export { S as H, A as T };
