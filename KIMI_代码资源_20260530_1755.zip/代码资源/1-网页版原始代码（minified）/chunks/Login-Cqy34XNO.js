import {
  s as z,
  r as F,
  z as $,
  o as B,
  f as N,
  c as x,
  a as s,
  l as Q,
  b as o,
  w as t,
  d as i,
  u as l,
  F as V,
  g as D,
  h as _,
  D as U,
  i as d,
  e as W,
  j as X,
  t as C,
} from "./index-UoU16364.js";
import { _ as Y } from "./xiaoyugan-Dwisk7G8.js";
import { u as Z } from "./auth-BYvggjsB.js";
import { _ as A } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { P as m } from "./PersonCircle-CkW3zhXQ.js";
import { C as K } from "./Cube-CwoBO7fL.js";
import { R as P } from "./Ribbon-CequGJWg.js";
import { S as j } from "./Settings-BMY43FOw.js";
import "./localTokenManager-BQJEcmfy.js";
const E = { class: "login-page" },
  I = { class: "login-container" },
  T = { class: "login-card glass" },
  G = { class: "card-body" },
  H = { class: "form-options" },
  J = { class: "social-login" },
  O = { class: "register-prompt" },
  ee = { class: "features-showcase" },
  se = { class: "features-list" },
  oe = { class: "feature-icon" },
  te = { class: "feature-content" },
  ne = {
    __name: "Login",
    setup(re) {
      const u = N(),
        f = z(),
        v = Z(),
        g = F(null),
        r = $({ username: "", password: "", rememberMe: !1 }),
        h = {
          username: [{ required: !0, message: "请输入用户名或邮箱", trigger: ["input", "blur"] }],
          password: [
            { required: !0, message: "请输入密码", trigger: ["input", "blur"] },
            { min: 6, message: "密码长度不能少于6位", trigger: ["input", "blur"] },
          ],
        },
        L = [
          { id: 1, icon: m, title: "多角色管理", description: "统一管理多个游戏角色，随时切换查看" },
          { id: 2, icon: K, title: "任务自动化", description: "智能执行日常任务，解放双手节省时间" },
          { id: 3, icon: P, title: "数据统计", description: "详细的进度统计，让游戏数据一目了然" },
          { id: 4, icon: j, title: "个性化配置", description: "灵活的设置选项，打造专属管理方案" },
        ],
        b = async () => {
          if (g.value)
            try {
              await g.value.validate();
              const a = await v.login({ username: r.username, password: r.password, rememberMe: r.rememberMe });
              if (a.success) {
                f.success("登录成功");
                const e = u.currentRoute.value.query.redirect || "/admin/dashboard";
                u.push(e);
              } else f.error(a.message);
            } catch (a) {
              console.error("Login validation failed:", a);
            }
        },
        w = (a) => {
          f.info(`${a === "qq" ? "QQ" : "微信"}登录功能开发中...`);
        };
      return (
        B(() => {
          v.isAuthenticated && u.push("/admin/dashboard");
        }),
        (a, e) => {
          const p = i("n-icon"),
            k = i("n-input"),
            y = i("n-form-item"),
            q = i("Lock"),
            M = i("n-checkbox"),
            c = i("n-button"),
            R = i("n-form"),
            S = i("n-divider");
          return (
            _(),
            x("div", E, [
              s("div", I, [
                s("div", T, [
                  e[15] ||
                    (e[15] = Q(
                      '<div class="card-header" data-v-f2fda67e><div class="brand" data-v-f2fda67e><img src="' +
                        Y +
                        '" alt="XYZW" class="brand-logo" data-v-f2fda67e><h1 class="brand-title" data-v-f2fda67e>XYZW 游戏管理系统</h1></div><p class="welcome-text" data-v-f2fda67e>欢迎回来，请登录您的账户</p></div>',
                      1,
                    )),
                  s("div", G, [
                    o(
                      R,
                      { ref_key: "loginFormRef", ref: g, model: r, rules: h, size: "large", "show-label": !1 },
                      {
                        default: t(() => [
                          o(
                            y,
                            { path: "username" },
                            {
                              default: t(() => [
                                o(
                                  k,
                                  {
                                    value: r.username,
                                    "onUpdate:value": e[0] || (e[0] = (n) => (r.username = n)),
                                    placeholder: "用户名或邮箱",
                                    "input-props": { autocomplete: "username" },
                                  },
                                  { prefix: t(() => [o(p, null, { default: t(() => [o(l(m))]), _: 1 })]), _: 1 },
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          o(
                            y,
                            { path: "password" },
                            {
                              default: t(() => [
                                o(
                                  k,
                                  {
                                    value: r.password,
                                    "onUpdate:value": e[1] || (e[1] = (n) => (r.password = n)),
                                    type: "password",
                                    placeholder: "密码",
                                    "input-props": { autocomplete: "current-password" },
                                    onKeydown: U(b, ["enter"]),
                                  },
                                  { prefix: t(() => [o(p, null, { default: t(() => [o(q)]), _: 1 })]), _: 1 },
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          s("div", H, [
                            o(
                              M,
                              { checked: r.rememberMe, "onUpdate:checked": e[2] || (e[2] = (n) => (r.rememberMe = n)) },
                              { default: t(() => [...(e[7] || (e[7] = [d(" 记住我 ", -1)]))]), _: 1 },
                              8,
                              ["checked"],
                            ),
                            o(
                              c,
                              {
                                text: "",
                                type: "primary",
                                onClick: e[3] || (e[3] = (n) => l(u).push("/forgot-password")),
                              },
                              { default: t(() => [...(e[8] || (e[8] = [d(" 忘记密码？ ", -1)]))]), _: 1 },
                            ),
                          ]),
                          o(
                            c,
                            {
                              type: "primary",
                              size: "large",
                              block: "",
                              loading: l(v).isLoading,
                              class: "login-button",
                              onClick: b,
                            },
                            { default: t(() => [...(e[9] || (e[9] = [d(" 登录 ", -1)]))]), _: 1 },
                            8,
                            ["loading"],
                          ),
                        ]),
                        _: 1,
                      },
                      8,
                      ["model"],
                    ),
                    o(S, null, {
                      default: t(() => [
                        ...(e[10] || (e[10] = [s("span", { class: "divider-text" }, "其他登录方式", -1)])),
                      ]),
                      _: 1,
                    }),
                    s("div", J, [
                      o(
                        c,
                        { size: "large", class: "social-button", onClick: e[4] || (e[4] = (n) => w("qq")) },
                        {
                          icon: t(() => [o(p, null, { default: t(() => [o(l(m))]), _: 1 })]),
                          default: t(() => [e[11] || (e[11] = d(" QQ登录 ", -1))]),
                          _: 1,
                        },
                      ),
                      o(
                        c,
                        { size: "large", class: "social-button", onClick: e[5] || (e[5] = (n) => w("wechat")) },
                        {
                          icon: t(() => [o(p, null, { default: t(() => [o(l(m))]), _: 1 })]),
                          default: t(() => [e[12] || (e[12] = d(" 微信登录 ", -1))]),
                          _: 1,
                        },
                      ),
                    ]),
                    s("div", O, [
                      e[14] || (e[14] = s("span", null, "还没有账户？", -1)),
                      o(
                        c,
                        { text: "", type: "primary", onClick: e[6] || (e[6] = (n) => l(u).push("/register")) },
                        { default: t(() => [...(e[13] || (e[13] = [d(" 立即注册 ", -1)]))]), _: 1 },
                      ),
                    ]),
                  ]),
                ]),
                s("div", ee, [
                  e[16] ||
                    (e[16] = s(
                      "div",
                      { class: "showcase-header" },
                      [s("h2", null, "为什么选择 XYZW？"), s("p", null, "专业的游戏管理平台，让游戏变得更轻松")],
                      -1,
                    )),
                  s("div", se, [
                    (_(),
                    x(
                      V,
                      null,
                      D(L, (n) =>
                        s("div", { key: n.id, class: "feature-item" }, [
                          s("div", oe, [(_(), W(X(n.icon)))]),
                          s("div", te, [s("h3", null, C(n.title), 1), s("p", null, C(n.description), 1)]),
                        ]),
                      ),
                      64,
                    )),
                  ]),
                ]),
              ]),
              e[17] ||
                (e[17] = s(
                  "div",
                  { class: "background-decoration" },
                  [
                    s("div", { class: "decoration-circle circle-1" }),
                    s("div", { class: "decoration-circle circle-2" }),
                    s("div", { class: "decoration-circle circle-3" }),
                  ],
                  -1,
                )),
            ])
          );
        }
      );
    },
  },
  ve = A(ne, [["__scopeId", "data-v-f2fda67e"]]);
export { ve as default };
