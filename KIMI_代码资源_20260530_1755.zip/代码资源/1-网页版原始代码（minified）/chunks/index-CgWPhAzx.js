import {
  X as tt,
  Y as nt,
  Z as Lt,
  _ as oe,
  g as J,
  c as le,
  m as nl,
  t as jl,
  s as Ce,
  a as Se,
  x as dl,
  y as Gl,
  R as Tt,
  Q as se,
  r as Ll,
  h as Ke,
  j as je,
  i as ze,
  f as xe,
  $ as Tl,
  U as El,
  l as Pe,
  a0 as Et,
  k as Ee,
  p as Qe,
  a1 as el,
  q as at,
  o as ot,
  I as Al,
  F as ut,
  T as Kl,
  a2 as At,
  B as Wl,
  b as Ft,
} from "./index-7YDlkBnY.js";
import {
  S as rt,
  E as it,
  B as Dt,
  b as Ht,
  I as Gt,
  u as He,
  G as st,
  c as ct,
  C as vl,
  R as fl,
} from "./grid-col-GTGOUscx.js";
import {
  k as Z,
  r as z,
  p as s,
  y as ae,
  o as we,
  M as dt,
  b0 as vt,
  c as Y,
  h as E,
  a as fe,
  X as ge,
  E as D,
  ah as Me,
  b as g,
  ag as ne,
  e as ce,
  w as be,
  B as ft,
  ad as Kt,
  d as me,
  A as re,
  _ as ee,
  ab as pt,
  j as Ne,
  ac as mt,
  n as de,
  $ as ye,
  al as ll,
  z as ke,
  i as Re,
  t as Ie,
  b1 as gt,
  aO as ht,
  aa as bt,
  F as Ae,
  g as Wt,
  aT as qt,
  am as tl,
  aY as Ge,
} from "./index-UoU16364.js";
import { g as yt, K as Te, I as Ut, a as Zt } from "./index-DMjs3mWk.js";
var Yt = Z({
  name: "ResizeObserver",
  emits: ["resize"],
  setup(e, { emit: l, slots: t }) {
    let n;
    const u = z(),
      o = s(() => (tt(u.value) ? u.value.$el : u.value)),
      a = (c) => {
        c &&
          ((n = new Lt((d) => {
            const v = d[0];
            l("resize", v);
          })),
          n.observe(c));
      },
      r = () => {
        n && (n.disconnect(), (n = null));
      };
    return (
      ae(o, (c) => {
        (n && r(), c && a(c));
      }),
      we(() => {
        o.value && a(o.value);
      }),
      dt(() => {
        r();
      }),
      () => {
        var c, d;
        const v = nt((d = (c = t.default) == null ? void 0 : c.call(t)) != null ? d : []);
        return v ? vt(v, { ref: u }, !0) : null;
      }
    );
  },
});
const Jt = Z({
    name: "IconEmpty",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: l }) {
      const t = J("icon"),
        n = s(() => [t, `${t}-empty`, { [`${t}-spin`]: e.spin }]),
        u = s(() => {
          const a = {};
          return (
            e.size && (a.fontSize = le(e.size) ? `${e.size}px` : e.size),
            e.rotate && (a.transform = `rotate(${e.rotate}deg)`),
            a
          );
        });
      return {
        cls: n,
        innerStyle: u,
        onClick: (a) => {
          l("click", a);
        },
      };
    },
  }),
  Xt = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Qt(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: D(e.cls),
        style: ge(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: l[0] || (l[0] = (...a) => e.onClick && e.onClick(...a)),
      },
      l[1] ||
        (l[1] = [
          fe(
            "path",
            {
              d: "M24 5v6m7 1 4-4m-18 4-4-4m28.5 22H28s-1 3-4 3-4-3-4-3H6.5M40 41H8a2 2 0 0 1-2-2v-8.46a2 2 0 0 1 .272-1.007l6.15-10.54A2 2 0 0 1 14.148 18H33.85a2 2 0 0 1 1.728.992l6.149 10.541A2 2 0 0 1 42 30.541V39a2 2 0 0 1-2 2Z",
            },
            null,
            -1,
          ),
        ]),
      14,
      Xt,
    )
  );
}
var pl = oe(Jt, [["render", Qt]]);
const en = Object.assign(pl, {
  install: (e, l) => {
    var t;
    const n = (t = l == null ? void 0 : l.iconPrefix) != null ? t : "";
    e.component(n + pl.name, pl);
  },
});
var ml = Z({
  name: "Empty",
  inheritAttrs: !1,
  props: { description: String, imgSrc: String, inConfigProvider: { type: Boolean, default: !1 } },
  setup(e, { slots: l, attrs: t }) {
    const n = J("empty"),
      { t: u } = nl(),
      o = Me(jl, void 0);
    return () => {
      var a, r, c, d;
      return !e.inConfigProvider && o != null && o.slots.empty && !(l.image || e.imgSrc || e.description)
        ? o.slots.empty({ component: "empty" })
        : g("div", ne({ class: n }, t), [
            g("div", { class: `${n}-image` }, [
              (r = (a = l.image) == null ? void 0 : a.call(l)) != null
                ? r
                : e.imgSrc
                  ? g("img", { src: e.imgSrc, alt: e.description || "empty" }, null)
                  : g(en, null, null),
            ]),
            g("div", { class: `${n}-description` }, [
              (d = (c = l.default) == null ? void 0 : c.call(l)) != null ? d : e.description || u("empty.description"),
            ]),
          ]);
    };
  },
});
const $t = Object.assign(ml, {
    install: (e, l) => {
      Ce(e, l);
      const t = Se(l);
      e.component(t + ml.name, ml);
    },
  }),
  ln = Z({
    name: "Thumb",
    props: {
      data: { type: Object },
      direction: { type: String, default: "horizontal" },
      alwaysShow: { type: Boolean, default: !1 },
      both: { type: Boolean, default: !1 },
    },
    emits: ["scroll"],
    setup(e, { emit: l }) {
      const t = J("scrollbar"),
        n = z(!1),
        u = z(),
        o = z(),
        a = s(() =>
          e.direction === "horizontal"
            ? { size: "width", direction: "left", offset: "offsetWidth", client: "clientX" }
            : { size: "height", direction: "top", offset: "offsetHeight", client: "clientY" },
        ),
        r = z(0),
        c = z(!1),
        d = z(0),
        v = s(() => {
          var _, $;
          return {
            [a.value.size]: `${($ = (_ = e.data) == null ? void 0 : _.thumbSize) != null ? $ : 0}px`,
            [a.value.direction]: `${r.value}px`,
          };
        }),
        w = (_) => {
          (_.preventDefault(),
            o.value &&
              ((d.value = _[a.value.client] - o.value.getBoundingClientRect()[a.value.direction]),
              (c.value = !0),
              dl(window, "mousemove", m),
              dl(window, "mouseup", C),
              dl(window, "contextmenu", C)));
        },
        h = (_) => {
          var $, b, V, i;
          if ((_.preventDefault(), o.value)) {
            const f = S(
              _[a.value.client] > o.value.getBoundingClientRect()[a.value.direction]
                ? r.value + ((b = ($ = e.data) == null ? void 0 : $.thumbSize) != null ? b : 0)
                : r.value - ((i = (V = e.data) == null ? void 0 : V.thumbSize) != null ? i : 0),
            );
            f !== r.value && ((r.value = f), l("scroll", f));
          }
        },
        S = (_) => (_ < 0 ? 0 : e.data && _ > e.data.max ? e.data.max : _),
        m = (_) => {
          if (u.value && o.value) {
            const $ = S(_[a.value.client] - u.value.getBoundingClientRect()[a.value.direction] - d.value);
            $ !== r.value && ((r.value = $), l("scroll", $));
          }
        },
        C = () => {
          ((c.value = !1), Gl(window, "mousemove", m), Gl(window, "mouseup", C));
        },
        k = (_) => {
          c.value || ((_ = S(_)), _ !== r.value && (r.value = _));
        },
        M = s(() => [`${t}-thumb`, `${t}-thumb-direction-${e.direction}`, { [`${t}-thumb-dragging`]: c.value }]);
      return {
        visible: n,
        trackRef: u,
        thumbRef: o,
        prefixCls: t,
        thumbCls: M,
        thumbStyle: v,
        handleThumbMouseDown: w,
        handleTrackClick: h,
        setOffset: k,
      };
    },
  });
function tn(e, l, t, n, u, o) {
  return (
    E(),
    ce(Kt, null, {
      default: be(() => [
        fe(
          "div",
          {
            ref: "trackRef",
            class: D([`${e.prefixCls}-track`, `${e.prefixCls}-track-direction-${e.direction}`]),
            onMousedown: l[1] || (l[1] = ft((...a) => e.handleTrackClick && e.handleTrackClick(...a), ["self"])),
          },
          [
            fe(
              "div",
              {
                ref: "thumbRef",
                class: D(e.thumbCls),
                style: ge(e.thumbStyle),
                onMousedown: l[0] || (l[0] = (...a) => e.handleThumbMouseDown && e.handleThumbMouseDown(...a)),
              },
              [fe("div", { class: D(`${e.prefixCls}-thumb-bar`) }, null, 2)],
              38,
            ),
          ],
          34,
        ),
      ]),
      _: 1,
    })
  );
}
var nn = oe(ln, [["render", tn]]);
const ql = 20,
  Ue = 15,
  an = Z({
    name: "Scrollbar",
    components: { ResizeObserver: Tt, Thumb: nn },
    inheritAttrs: !1,
    props: {
      type: { type: String, default: "embed" },
      outerClass: [String, Object, Array],
      outerStyle: { type: [String, Object, Array] },
      hide: { type: Boolean, default: !1 },
      disableHorizontal: { type: Boolean, default: !1 },
      disableVertical: { type: Boolean, default: !1 },
    },
    emits: { scroll: (e) => !0 },
    setup(e, { emit: l }) {
      const t = J("scrollbar"),
        n = z(),
        u = z(),
        o = z(),
        a = z(),
        r = z(),
        c = z(!1),
        d = z(!1),
        v = s(() => c.value && !e.disableHorizontal),
        w = s(() => d.value && !e.disableVertical),
        h = z(!1),
        S = () => {
          var b, V, i, f, P, j;
          if (n.value) {
            const {
              clientWidth: x,
              clientHeight: B,
              offsetWidth: G,
              offsetHeight: q,
              scrollWidth: O,
              scrollHeight: R,
              scrollTop: T,
              scrollLeft: A,
            } = n.value;
            ((c.value = O > x), (d.value = R > B), (h.value = v.value && w.value));
            const F = e.type === "embed" && h.value ? G - Ue : G,
              X = e.type === "embed" && h.value ? q - Ue : q,
              ve = Math.round(F / Math.min(O / x, F / ql)),
              y = F - ve,
              H = (O - x) / y,
              K = Math.round(X / Math.min(R / B, X / ql)),
              te = X - K,
              he = (R - B) / te;
            if (
              ((u.value = { ratio: H, thumbSize: ve, max: y }), (o.value = { ratio: he, thumbSize: K, max: te }), T > 0)
            ) {
              const ue = Math.round(T / ((V = (b = o.value) == null ? void 0 : b.ratio) != null ? V : 1));
              (i = r.value) == null || i.setOffset(ue);
            }
            if (A > 0) {
              const ue = Math.round(A / ((P = (f = o.value) == null ? void 0 : f.ratio) != null ? P : 1));
              (j = a.value) == null || j.setOffset(ue);
            }
          }
        };
      we(() => {
        S();
      });
      const m = () => {
          S();
        },
        C = (b) => {
          var V, i, f, P, j, x;
          if (n.value) {
            if (v.value && !e.disableHorizontal) {
              const B = Math.round(
                n.value.scrollLeft / ((i = (V = u.value) == null ? void 0 : V.ratio) != null ? i : 1),
              );
              (f = a.value) == null || f.setOffset(B);
            }
            if (w.value && !e.disableVertical) {
              const B = Math.round(
                n.value.scrollTop / ((j = (P = o.value) == null ? void 0 : P.ratio) != null ? j : 1),
              );
              (x = r.value) == null || x.setOffset(B);
            }
          }
          l("scroll", b);
        },
        k = (b) => {
          var V, i;
          n.value && n.value.scrollTo({ left: b * ((i = (V = u.value) == null ? void 0 : V.ratio) != null ? i : 1) });
        },
        M = (b) => {
          var V, i;
          n.value && n.value.scrollTo({ top: b * ((i = (V = o.value) == null ? void 0 : V.ratio) != null ? i : 1) });
        },
        _ = s(() => {
          const b = {};
          return (
            e.type === "track" && (v.value && (b.paddingBottom = `${Ue}px`), w.value && (b.paddingRight = `${Ue}px`)),
            [b, e.outerStyle]
          );
        }),
        $ = s(() => [`${t}`, `${t}-type-${e.type}`, { [`${t}-both`]: h.value }, e.outerClass]);
      return {
        prefixCls: t,
        cls: $,
        style: _,
        containerRef: n,
        horizontalThumbRef: a,
        verticalThumbRef: r,
        horizontalData: u,
        verticalData: o,
        isBoth: h,
        hasHorizontalScrollbar: v,
        hasVerticalScrollbar: w,
        handleResize: m,
        handleScroll: C,
        handleHorizontalScroll: k,
        handleVerticalScroll: M,
      };
    },
    methods: {
      scrollTo(e, l) {
        var t, n;
        se(e)
          ? (t = this.$refs.containerRef) == null || t.scrollTo(e)
          : (e || l) && ((n = this.$refs.containerRef) == null || n.scrollTo(e, l));
      },
      scrollTop(e) {
        var l;
        (l = this.$refs.containerRef) == null || l.scrollTo({ top: e });
      },
      scrollLeft(e) {
        var l;
        (l = this.$refs.containerRef) == null || l.scrollTo({ left: e });
      },
    },
  });
function on(e, l, t, n, u, o) {
  const a = me("ResizeObserver"),
    r = me("thumb");
  return (
    E(),
    Y(
      "div",
      { class: D(e.cls), style: ge(e.style) },
      [
        g(
          a,
          { onResize: e.handleResize },
          {
            default: be(() => [
              fe(
                "div",
                ne({ ref: "containerRef", class: `${e.prefixCls}-container` }, e.$attrs, {
                  onScroll: l[0] || (l[0] = (...c) => e.handleScroll && e.handleScroll(...c)),
                }),
                [
                  g(a, { onResize: e.handleResize }, { default: be(() => [ee(e.$slots, "default")]), _: 3 }, 8, [
                    "onResize",
                  ]),
                ],
                16,
              ),
            ]),
            _: 3,
          },
          8,
          ["onResize"],
        ),
        !e.hide && e.hasHorizontalScrollbar
          ? (E(),
            ce(
              r,
              {
                key: 0,
                ref: "horizontalThumbRef",
                data: e.horizontalData,
                direction: "horizontal",
                both: e.isBoth,
                onScroll: e.handleHorizontalScroll,
              },
              null,
              8,
              ["data", "both", "onScroll"],
            ))
          : re("v-if", !0),
        !e.hide && e.hasVerticalScrollbar
          ? (E(),
            ce(
              r,
              {
                key: 1,
                ref: "verticalThumbRef",
                data: e.verticalData,
                direction: "vertical",
                both: e.isBoth,
                onScroll: e.handleVerticalScroll,
              },
              null,
              8,
              ["data", "both", "onScroll"],
            ))
          : re("v-if", !0),
      ],
      6,
    )
  );
}
var gl = oe(an, [["render", on]]);
const Ct = Object.assign(gl, {
    install: (e, l) => {
      Ce(e, l);
      const t = Se(l);
      e.component(t + gl.name, gl);
    },
  }),
  St = (e) => {
    const l = z(),
      t = () => (tt(l.value) ? l.value.$refs[e] : l.value),
      n = z();
    return (
      we(() => {
        n.value = t();
      }),
      ae([l], () => {
        n.value = t();
      }),
      { componentRef: l, elementRef: n }
    );
  },
  kt = (e) => {
    const l = s(() => !!e.value),
      t = s(() => {
        if (e.value) return { type: "embed", ...(Ll(e.value) ? void 0 : e.value) };
      });
    return { displayScrollbar: l, scrollbarProps: t };
  },
  un = Z({
    name: "SelectDropdown",
    components: { ScrollbarComponent: Ct, Empty: $t, Spin: rt },
    props: {
      loading: Boolean,
      empty: Boolean,
      virtualList: Boolean,
      bottomOffset: { type: Number, default: 0 },
      scrollbar: { type: [Boolean, Object], default: !0 },
      onScroll: { type: [Function, Array] },
      onReachBottom: { type: [Function, Array] },
      showHeaderOnEmpty: { type: Boolean, default: !1 },
      showFooterOnEmpty: { type: Boolean, default: !1 },
    },
    emits: ["scroll", "reachBottom"],
    setup(e, { emit: l, slots: t }) {
      var n, u, o;
      const { scrollbar: a } = de(e),
        r = J("select-dropdown"),
        c = Me(jl, void 0),
        d =
          (o = (u = c == null ? void 0 : (n = c.slots).empty) == null ? void 0 : u.call(n, { component: "select" })) ==
          null
            ? void 0
            : o[0],
        { componentRef: v, elementRef: w } = St("containerRef"),
        { displayScrollbar: h, scrollbarProps: S } = kt(a),
        m = (k) => {
          const { scrollTop: M, scrollHeight: _, offsetHeight: $ } = k.target;
          (_ - (M + $) <= e.bottomOffset && l("reachBottom", k), l("scroll", k));
        },
        C = s(() => [r, { [`${r}-has-header`]: !!t.header, [`${r}-has-footer`]: !!t.footer }]);
      return {
        prefixCls: r,
        SelectEmpty: d,
        cls: C,
        wrapperRef: w,
        wrapperComRef: v,
        handleScroll: m,
        displayScrollbar: h,
        scrollbarProps: S,
      };
    },
  });
function rn(e, l, t, n, u, o) {
  const a = me("spin");
  return (
    E(),
    Y(
      "div",
      { class: D(e.cls) },
      [
        e.$slots.header && (!e.empty || e.showHeaderOnEmpty)
          ? (E(), Y("div", { key: 0, class: D(`${e.prefixCls}-header`) }, [ee(e.$slots, "header")], 2))
          : re("v-if", !0),
        e.loading
          ? (E(), ce(a, { key: 1, class: D(`${e.prefixCls}-loading`) }, null, 8, ["class"]))
          : e.empty
            ? (E(),
              Y(
                "div",
                { key: 2, class: D(`${e.prefixCls}-empty`) },
                [ee(e.$slots, "empty", {}, () => [(E(), ce(Ne(e.SelectEmpty ? e.SelectEmpty : "Empty")))])],
                2,
              ))
            : re("v-if", !0),
        e.virtualList && !e.loading && !e.empty ? ee(e.$slots, "virtual-list", { key: 3 }) : re("v-if", !0),
        e.virtualList
          ? re("v-if", !0)
          : pt(
              (E(),
              ce(
                Ne(e.displayScrollbar ? "ScrollbarComponent" : "div"),
                ne({ key: 4, ref: "wrapperComRef", class: `${e.prefixCls}-list-wrapper` }, e.scrollbarProps, {
                  onScroll: e.handleScroll,
                }),
                {
                  default: be(() => [fe("ul", { class: D(`${e.prefixCls}-list`) }, [ee(e.$slots, "default")], 2)]),
                  _: 3,
                },
                16,
                ["class", "onScroll"],
              )),
              [[mt, !e.loading && !e.empty]],
            ),
        e.$slots.footer && (!e.empty || e.showFooterOnEmpty)
          ? (E(), Y("div", { key: 5, class: D(`${e.prefixCls}-footer`) }, [ee(e.$slots, "footer")], 2))
          : re("v-if", !0),
      ],
      2,
    )
  );
}
var sn = oe(un, [["render", rn]]),
  Ul = Z({
    name: "IconCheck",
    render() {
      return g(
        "svg",
        {
          "aria-hidden": "true",
          focusable: "false",
          viewBox: "0 0 1024 1024",
          width: "200",
          height: "200",
          fill: "currentColor",
        },
        [
          g(
            "path",
            {
              d: "M877.44815445 206.10060629a64.72691371 64.72691371 0 0 0-95.14856334 4.01306852L380.73381888 685.46812814 235.22771741 533.48933518a64.72691371 64.72691371 0 0 0-92.43003222-1.03563036l-45.82665557 45.82665443a64.72691371 64.72691371 0 0 0-0.90617629 90.61767965l239.61903446 250.10479331a64.72691371 64.72691371 0 0 0 71.19960405 15.14609778 64.33855261 64.33855261 0 0 0 35.08198741-21.23042702l36.24707186-42.71976334 40.5190474-40.77795556-3.36579926-3.49525333 411.40426297-486.74638962a64.72691371 64.72691371 0 0 0-3.88361443-87.64024149l-45.3088404-45.43829334z",
              "p-id": "840",
            },
            null,
          ),
        ],
      );
    },
  });
const wt = Symbol("ArcoCheckboxGroup");
var Ye = Z({
    name: "Checkbox",
    components: { IconCheck: Ul, IconHover: Ke },
    props: {
      modelValue: { type: [Boolean, Array], default: void 0 },
      defaultChecked: { type: Boolean, default: !1 },
      value: { type: [String, Number, Boolean] },
      disabled: { type: Boolean, default: !1 },
      indeterminate: { type: Boolean, default: !1 },
      uninjectGroupContext: { type: Boolean, default: !1 },
    },
    emits: { "update:modelValue": (e) => !0, change: (e, l) => !0 },
    setup(e, { emit: l, slots: t }) {
      const { disabled: n, modelValue: u } = de(e),
        o = J("checkbox"),
        a = z(),
        r = e.uninjectGroupContext ? void 0 : Me(wt, void 0),
        c = (r == null ? void 0 : r.name) === "ArcoCheckboxGroup",
        { mergedDisabled: d, eventHandlers: v } = je({ disabled: n }),
        w = z(e.defaultChecked),
        h = s(() => {
          var b;
          return c ? (r == null ? void 0 : r.computedValue) : (b = e.modelValue) != null ? b : w.value;
        }),
        S = s(() => {
          var b;
          return ze(h.value) ? h.value.includes((b = e.value) != null ? b : !0) : h.value;
        }),
        m = s(
          () =>
            (r == null ? void 0 : r.disabled) ||
            (d == null ? void 0 : d.value) ||
            (!S.value && (r == null ? void 0 : r.isMaxed)),
        ),
        C = (b) => {
          b.stopPropagation();
        },
        k = (b) => {
          var V, i, f, P;
          const { checked: j } = b.target;
          let x = j;
          if (ze(h.value)) {
            const B = new Set(h.value);
            (j ? B.add((V = e.value) != null ? V : !0) : B.delete((i = e.value) != null ? i : !0), (x = Array.from(B)));
          }
          ((w.value = j),
            c && ze(x)
              ? r == null || r.handleChange(x, b)
              : (l("update:modelValue", x),
                l("change", x, b),
                (P = (f = v.value) == null ? void 0 : f.onChange) == null || P.call(f, b)),
            ye(() => {
              a.value && a.value.checked !== S.value && (a.value.checked = S.value);
            }));
        },
        M = s(() => [
          o,
          { [`${o}-checked`]: S.value, [`${o}-indeterminate`]: e.indeterminate, [`${o}-disabled`]: m.value },
        ]),
        _ = (b) => {
          var V, i;
          (i = (V = v.value) == null ? void 0 : V.onFocus) == null || i.call(V, b);
        },
        $ = (b) => {
          var V, i;
          (i = (V = v.value) == null ? void 0 : V.onBlur) == null || i.call(V, b);
        };
      return (
        ae(u, (b) => {
          (xe(b) || Tl(b)) && (w.value = !1);
        }),
        ae(h, (b) => {
          var V;
          let i;
          (ze(b) ? (i = b.includes((V = e.value) != null ? V : !0)) : (i = b),
            w.value !== i && (w.value = i),
            a.value && a.value.checked !== i && (a.value.checked = i));
        }),
        () => {
          var b, V, i, f;
          return g("label", { "aria-disabled": m.value, class: M.value }, [
            g(
              "input",
              {
                ref: a,
                type: "checkbox",
                checked: S.value,
                value: e.value,
                class: `${o}-target`,
                disabled: m.value,
                onClick: C,
                onChange: k,
                onFocus: _,
                onBlur: $,
              },
              null,
            ),
            (f =
              (i = (V = t.checkbox) != null ? V : (b = r == null ? void 0 : r.slots) == null ? void 0 : b.checkbox) ==
              null
                ? void 0
                : i({ checked: S.value, disabled: m.value })) != null
              ? f
              : g(
                  Ke,
                  { class: `${o}-icon-hover`, disabled: m.value || S.value },
                  {
                    default: () => [
                      g("div", { class: `${o}-icon` }, [S.value && g(Ul, { class: `${o}-icon-check` }, null)]),
                    ],
                  },
                ),
            t.default && g("span", { class: `${o}-label` }, [t.default()]),
          ]);
        }
      );
    },
  }),
  hl = Z({
    name: "CheckboxGroup",
    props: {
      modelValue: { type: Array, default: void 0 },
      defaultValue: { type: Array, default: () => [] },
      max: { type: Number },
      options: { type: Array },
      direction: { type: String, default: "horizontal" },
      disabled: { type: Boolean, default: !1 },
    },
    emits: { "update:modelValue": (e) => !0, change: (e, l) => !0 },
    setup(e, { emit: l, slots: t }) {
      const { disabled: n } = de(e),
        u = J("checkbox-group"),
        { mergedDisabled: o, eventHandlers: a } = je({ disabled: n }),
        r = z(e.defaultValue),
        c = s(() => (ze(e.modelValue) ? e.modelValue : r.value)),
        d = s(() => (e.max === void 0 ? !1 : c.value.length >= e.max)),
        v = s(() => {
          var m;
          return ((m = e.options) != null ? m : []).map((C) => (El(C) || le(C) ? { label: C, value: C } : C));
        });
      ll(
        wt,
        ke({
          name: "ArcoCheckboxGroup",
          computedValue: c,
          disabled: o,
          isMaxed: d,
          slots: t,
          handleChange: (m, C) => {
            var k, M;
            ((r.value = m),
              l("update:modelValue", m),
              l("change", m, C),
              (M = (k = a.value) == null ? void 0 : k.onChange) == null || M.call(k, C));
          },
        }),
      );
      const h = s(() => [u, `${u}-direction-${e.direction}`]);
      ae(
        () => e.modelValue,
        (m) => {
          ze(m) ? (r.value = [...m]) : (r.value = []);
        },
      );
      const S = () =>
        v.value.map((m) => {
          const C = c.value.includes(m.value);
          return g(
            Ye,
            {
              key: m.value,
              value: m.value,
              disabled: m.disabled || (!C && d.value),
              indeterminate: m.indeterminate,
              modelValue: C,
            },
            { default: () => [t.label ? t.label({ data: m }) : Pe(m.label) ? m.label() : m.label] },
          );
        });
      return () => {
        var m;
        return g("span", { class: h.value }, [v.value.length > 0 ? S() : (m = t.default) == null ? void 0 : m.call(t)]);
      };
    },
  });
const cn = Object.assign(Ye, {
    Group: hl,
    install: (e, l) => {
      Ce(e, l);
      const t = Se(l);
      (e.component(t + Ye.name, Ye), e.component(t + hl.name, hl));
    },
  }),
  _t = Symbol("ArcoSelectContext"),
  dn = (e) => se(e) && "isGroup" in e,
  zt = (e) => se(e) && "isGroup" in e,
  vn = (e, l = "value") => String(se(e) ? e[l] : e),
  We = (e, l = "value") =>
    se(e) ? `__arco__option__object__${e[l]}` : e || le(e) || El(e) || Ll(e) ? `__arco__option__${typeof e}-${e}` : "",
  fn = (e) => e.has("__arco__option__string-"),
  pn = (e, { valueKey: l, fieldNames: t, origin: n, index: u = -1 }) => {
    var o;
    if (se(e)) {
      const r = e[t.value];
      return {
        raw: e,
        index: u,
        key: We(r, l),
        origin: n,
        value: r,
        label: (o = e[t.label]) != null ? o : vn(r, l),
        render: e[t.render],
        disabled: !!e[t.disabled],
        tagProps: e[t.tagProps],
      };
    }
    const a = { value: e, label: String(e), disabled: !1 };
    return { raw: a, index: u, key: We(e, l), origin: n, ...a };
  },
  Nl = (e, { valueKey: l, fieldNames: t, origin: n, optionInfoMap: u }) => {
    var o;
    const a = [];
    for (const r of e)
      if (dn(r)) {
        const c = Nl((o = r.options) != null ? o : [], { valueKey: l, fieldNames: t, origin: n, optionInfoMap: u });
        c.length > 0 && a.push({ ...r, key: `__arco__group__${r.label}`, options: c });
      } else {
        const c = pn(r, { valueKey: l, fieldNames: t, origin: n });
        (a.push(c), u.get(c.key) || u.set(c.key, c));
      }
    return a;
  },
  Zl = (e, { inputValue: l, filterOption: t }) => {
    const n = (u) => {
      var o;
      const a = [];
      for (const r of u)
        if (zt(r)) {
          const c = n((o = r.options) != null ? o : []);
          c.length > 0 && a.push({ ...r, options: c });
        } else al(r, { inputValue: l, filterOption: t }) && a.push(r);
      return a;
    };
    return n(e);
  },
  al = (e, { inputValue: l, filterOption: t }) =>
    Pe(t) ? !l || t(l, e.raw) : t ? e.label.toLowerCase().includes((l ?? "").toLowerCase()) : !0,
  mn = (e, l) => {
    if (!e || !l || e.length !== l.length) return !1;
    for (const t of Object.keys(e)) if (!Fl(e[t], l[t])) return !1;
    return !0;
  },
  gn = (e, l) => {
    if (!e || !l) return !1;
    const { length: t } = e;
    if (t !== l.length) return !1;
    for (let n = 0; n < t; n++) if (!Fl(e[n], l[n])) return !1;
    return !0;
  },
  Fl = (e, l) => {
    const t = Object.prototype.toString.call(e);
    return t !== Object.prototype.toString.call(l)
      ? !1
      : t === "[object Object]"
        ? mn(e, l)
        : t === "[object Array]"
          ? gn(e, l)
          : t === "[object Function]"
            ? e === l
              ? !0
              : e.toString() === l.toString()
            : e === l;
  },
  hn = Z({
    name: "Option",
    components: { Checkbox: cn },
    props: {
      value: { type: [String, Number, Boolean, Object], default: void 0 },
      label: String,
      disabled: Boolean,
      tagProps: { type: Object },
      extra: { type: Object },
      index: { type: Number },
      internal: Boolean,
    },
    setup(e) {
      const { disabled: l, tagProps: t, index: n } = de(e),
        u = J("select-option"),
        o = Me(_t, void 0),
        a = ht(),
        r = z(),
        c = z(t.value);
      ae(t, (i, f) => {
        Fl(i, f) || (c.value = i);
      });
      const d = z(""),
        v = s(() => {
          var i, f;
          return (f = (i = e.value) != null ? i : e.label) != null ? f : d.value;
        }),
        w = s(() => {
          var i;
          return (i = e.label) != null ? i : d.value;
        }),
        h = s(() => We(v.value, o == null ? void 0 : o.valueKey)),
        S = s(() => {
          var i;
          return (i = o == null ? void 0 : o.component) != null ? i : "li";
        }),
        m = () => {
          var i;
          if (!e.label && r.value) {
            const f = (i = r.value.textContent) != null ? i : "";
            d.value !== f && (d.value = f);
          }
        };
      (we(() => m()), gt(() => m()));
      const C = s(() => {
          var i;
          return (i = o == null ? void 0 : o.valueKeys.includes(h.value)) != null ? i : !1;
        }),
        k = s(() => (o == null ? void 0 : o.activeKey) === h.value);
      let M = z(!0);
      if (!e.internal) {
        const i = ke({
          raw: { value: v, label: w, disabled: l, tagProps: c },
          ref: r,
          index: n,
          key: h,
          origin: "slot",
          value: v,
          label: w,
          disabled: l,
          tagProps: c,
        });
        ((M = s(() =>
          al(i, { inputValue: o == null ? void 0 : o.inputValue, filterOption: o == null ? void 0 : o.filterOption }),
        )),
          a && (o == null || o.addSlotOptionInfo(a.uid, i)),
          bt(() => {
            a && (o == null || o.removeSlotOptionInfo(a.uid));
          }));
      }
      const _ = (i) => {
          e.disabled || o == null || o.onSelect(h.value, i);
        },
        $ = () => {
          e.disabled || o == null || o.setActiveKey(h.value);
        },
        b = () => {
          e.disabled || o == null || o.setActiveKey();
        },
        V = s(() => [
          u,
          {
            [`${u}-disabled`]: e.disabled,
            [`${u}-selected`]: C.value,
            [`${u}-active`]: k.value,
            [`${u}-multiple`]: o == null ? void 0 : o.multiple,
          },
        ]);
      return {
        prefixCls: u,
        cls: V,
        selectCtx: o,
        itemRef: r,
        component: S,
        isSelected: C,
        isValid: M,
        handleClick: _,
        handleMouseEnter: $,
        handleMouseLeave: b,
      };
    },
  });
function bn(e, l, t, n, u, o) {
  const a = me("checkbox");
  return pt(
    (E(),
    ce(
      Ne(e.component),
      {
        ref: "itemRef",
        class: D([e.cls, { [`${e.prefixCls}-has-suffix`]: !!e.$slots.suffix }]),
        onClick: e.handleClick,
        onMouseenter: e.handleMouseEnter,
        onMouseleave: e.handleMouseLeave,
      },
      {
        default: be(() => [
          e.$slots.icon
            ? (E(), Y("span", { key: 0, class: D(`${e.prefixCls}-icon`) }, [ee(e.$slots, "icon")], 2))
            : re("v-if", !0),
          e.selectCtx && e.selectCtx.multiple
            ? (E(),
              ce(
                a,
                {
                  key: 1,
                  class: D(`${e.prefixCls}-checkbox`),
                  "model-value": e.isSelected,
                  disabled: e.disabled,
                  "uninject-group-context": "",
                },
                { default: be(() => [ee(e.$slots, "default", {}, () => [Re(Ie(e.label), 1)])]), _: 3 },
                8,
                ["class", "model-value", "disabled"],
              ))
            : (E(),
              Y(
                "span",
                { key: 2, class: D(`${e.prefixCls}-content`) },
                [ee(e.$slots, "default", {}, () => [Re(Ie(e.label), 1)])],
                2,
              )),
          e.$slots.suffix
            ? (E(), Y("span", { key: 3, class: D(`${e.prefixCls}-suffix`) }, [ee(e.$slots, "suffix")], 2))
            : re("v-if", !0),
        ]),
        _: 3,
      },
      40,
      ["class", "onClick", "onMouseenter", "onMouseleave"],
    )),
    [[mt, e.isValid]],
  );
}
var Je = oe(hn, [["render", bn]]);
const yn = { value: "value", label: "label", disabled: "disabled", tagProps: "tagProps", render: "render" },
  $n = ({
    options: e,
    extraOptions: l,
    inputValue: t,
    filterOption: n,
    showExtraOptions: u,
    valueKey: o,
    fieldNames: a,
  }) => {
    const r = s(() => ({ ...yn, ...(a == null ? void 0 : a.value) })),
      c = ke(new Map()),
      d = s(() => Array.from(c.values()).sort(($, b) => (le($.index) && le(b.index) ? $.index - b.index : 0))),
      v = s(() => {
        var $, b;
        const V = new Map();
        return {
          optionInfos: Nl(($ = e == null ? void 0 : e.value) != null ? $ : [], {
            valueKey: (b = o == null ? void 0 : o.value) != null ? b : "value",
            fieldNames: r.value,
            origin: "options",
            optionInfoMap: V,
          }),
          optionInfoMap: V,
        };
      }),
      w = s(() => {
        var $, b;
        const V = new Map();
        return {
          optionInfos: Nl(($ = l == null ? void 0 : l.value) != null ? $ : [], {
            valueKey: (b = o == null ? void 0 : o.value) != null ? b : "value",
            fieldNames: r.value,
            origin: "extraOptions",
            optionInfoMap: V,
          }),
          optionInfoMap: V,
        };
      }),
      h = ke(new Map());
    ae(
      [d, e ?? z([]), l ?? z([]), o ?? z("value")],
      () => {
        (h.clear(),
          d.value.forEach(($, b) => {
            h.set($.key, { ...$, index: b });
          }),
          v.value.optionInfoMap.forEach(($) => {
            h.has($.key) || (($.index = h.size), h.set($.key, $));
          }),
          w.value.optionInfoMap.forEach(($) => {
            h.has($.key) || (($.index = h.size), h.set($.key, $));
          }));
      },
      { immediate: !0, deep: !0 },
    );
    const S = s(() => {
        var $;
        const b = Zl(v.value.optionInfos, {
          inputValue: t == null ? void 0 : t.value,
          filterOption: n == null ? void 0 : n.value,
        });
        return (
          (($ = u == null ? void 0 : u.value) == null || $) &&
            b.push(
              ...Zl(w.value.optionInfos, {
                inputValue: t == null ? void 0 : t.value,
                filterOption: n == null ? void 0 : n.value,
              }),
            ),
          b
        );
      }),
      m = s(() =>
        Array.from(h.values()).filter(($) =>
          $.origin === "extraOptions" && (u == null ? void 0 : u.value) === !1
            ? !1
            : al($, { inputValue: t == null ? void 0 : t.value, filterOption: n == null ? void 0 : n.value }),
        ),
      ),
      C = s(() => m.value.filter(($) => !$.disabled).map(($) => $.key));
    return {
      validOptions: S,
      optionInfoMap: h,
      validOptionInfos: m,
      enabledOptionKeys: C,
      getNextSlotOptionIndex: () => c.size,
      addSlotOptionInfo: ($, b) => {
        c.set($, b);
      },
      removeSlotOptionInfo: ($) => {
        c.delete($);
      },
    };
  },
  Cn = ({
    multiple: e,
    options: l,
    extraOptions: t,
    inputValue: n,
    filterOption: u,
    showExtraOptions: o,
    component: a,
    valueKey: r,
    fieldNames: c,
    loading: d,
    popupVisible: v,
    valueKeys: w,
    dropdownRef: h,
    optionRefs: S,
    virtualListRef: m,
    onSelect: C,
    onPopupVisibleChange: k,
    enterToOpen: M = !0,
    defaultActiveFirstOption: _,
  }) => {
    const {
        validOptions: $,
        optionInfoMap: b,
        validOptionInfos: V,
        enabledOptionKeys: i,
        getNextSlotOptionIndex: f,
        addSlotOptionInfo: P,
        removeSlotOptionInfo: j,
      } = $n({
        options: l,
        extraOptions: t,
        inputValue: n,
        filterOption: u,
        showExtraOptions: o,
        valueKey: r,
        fieldNames: c,
      }),
      x = z();
    ae(i, (R) => {
      (!x.value || !R.includes(x.value)) && (x.value = R[0]);
    });
    const B = (R) => {
        x.value = R;
      },
      G = (R) => {
        const T = i.value.length;
        if (T === 0) return;
        if (!x.value) return R === "down" ? i.value[0] : i.value[T - 1];
        const A = i.value.indexOf(x.value),
          F = (T + A + (R === "up" ? -1 : 1)) % T;
        return i.value[F];
      },
      q = (R) => {
        var T, A;
        m != null && m.value && m.value.scrollTo({ key: R });
        const F = b.get(R),
          X = (T = h == null ? void 0 : h.value) == null ? void 0 : T.wrapperRef,
          ve = (A = S == null ? void 0 : S.value[R]) != null ? A : F == null ? void 0 : F.ref;
        if (!X || !ve || X.scrollHeight === X.offsetHeight) return;
        const y = Et(ve, X),
          H = X.scrollTop;
        y.top < 0 ? X.scrollTo(0, H + y.top) : y.bottom < 0 && X.scrollTo(0, H - y.bottom);
      };
    ae(v, (R) => {
      var T;
      if (R) {
        const A = w.value[w.value.length - 1];
        let F = (T = _ == null ? void 0 : _.value) == null || T ? i.value[0] : void 0;
        (i.value.includes(A) && (F = A),
          F !== x.value && (x.value = F),
          ye(() => {
            x.value && q(x.value);
          }));
      }
    });
    const O = yt(
      new Map([
        [
          Te.ENTER,
          (R) => {
            !(d != null && d.value) &&
              !R.isComposing &&
              (v.value ? x.value && (C(x.value, R), R.preventDefault()) : M && (k(!0), R.preventDefault()));
          },
        ],
        [
          Te.ESC,
          (R) => {
            v.value && (k(!1), R.preventDefault());
          },
        ],
        [
          Te.ARROW_DOWN,
          (R) => {
            if (v.value) {
              const T = G("down");
              (T && ((x.value = T), q(T)), R.preventDefault());
            }
          },
        ],
        [
          Te.ARROW_UP,
          (R) => {
            if (v.value) {
              const T = G("up");
              (T && ((x.value = T), q(T)), R.preventDefault());
            }
          },
        ],
      ]),
    );
    return (
      ll(
        _t,
        ke({
          multiple: e,
          valueKey: r,
          inputValue: n,
          filterOption: u,
          component: a,
          valueKeys: w,
          activeKey: x,
          setActiveKey: B,
          onSelect: C,
          getNextSlotOptionIndex: f,
          addSlotOptionInfo: P,
          removeSlotOptionInfo: j,
        }),
      ),
      {
        validOptions: $,
        optionInfoMap: b,
        validOptionInfos: V,
        enabledOptionKeys: i,
        activeKey: x,
        setActiveKey: B,
        addSlotOptionInfo: P,
        removeSlotOptionInfo: j,
        getNextActiveKey: G,
        scrollIntoView: q,
        handleKeyDown: O,
      }
    );
  },
  Sn = ({ dataKeys: e, contentRef: l, fixedSize: t, estimatedSize: n, buffer: u }) => {
    const o = z(0),
      a = new Map(),
      r = s(() => e.value.length),
      c = z(0),
      d = s(() => {
        const f = c.value + u.value * 3;
        return f > r.value ? r.value : f;
      }),
      v = s(() => {
        const f = r.value - u.value * 3;
        return f < 0 ? 0 : f;
      }),
      w = (f) => {
        f < 0 ? (c.value = 0) : f > v.value ? (c.value = v.value) : (c.value = f);
      },
      h = z(t.value),
      S = s(() => (n.value !== 30 ? n.value : o.value || n.value)),
      m = (f, P) => {
        a.set(f, P);
      },
      C = (f) => {
        var P;
        if (h.value) return S.value;
        const j = e.value[f];
        return (P = a.get(j)) != null ? P : S.value;
      },
      k = (f) => a.has(f);
    we(() => {
      const f = Array.from(a.values()).reduce((P, j) => P + j, 0);
      f > 0 && (o.value = f / a.size);
    });
    const M = (f) => (h.value ? S.value * f : _(0, f)),
      _ = (f, P) => {
        let j = 0;
        for (let x = f; x < P; x++) j += C(x);
        return j;
      },
      $ = s(() => (h.value ? S.value * c.value : _(0, c.value))),
      b = (f) => {
        const P = f >= $.value;
        let j = Math.abs(f - $.value);
        const x = P ? c.value : c.value - 1;
        let B = 0;
        for (; j > 0; ) ((j -= C(x + B)), P ? B++ : B--);
        return B;
      },
      V = (f) => {
        const P = b(f),
          j = c.value + P - u.value;
        return j < 0 ? 0 : j > v.value ? v.value : j;
      },
      i = s(() => (h.value ? S.value * (r.value - d.value) : _(d.value, r.value)));
    return {
      frontPadding: $,
      behindPadding: i,
      start: c,
      end: d,
      getStartByScroll: V,
      setItemSize: m,
      hasItemSize: k,
      setStart: w,
      getScrollOffset: M,
    };
  };
var kn = Z({
  name: "VirtualListItem",
  props: { hasItemSize: { type: Function, required: !0 }, setItemSize: { type: Function, required: !0 } },
  setup(e, { slots: l }) {
    var t;
    const n = (t = ht()) == null ? void 0 : t.vnode.key,
      u = z(),
      o = () => {
        var a, r, c, d;
        const v = (r = (a = u.value) == null ? void 0 : a.$el) != null ? r : u.value,
          w =
            (d = (c = v == null ? void 0 : v.getBoundingClientRect) == null ? void 0 : c.call(v).height) != null
              ? d
              : v == null
                ? void 0
                : v.offsetHeight;
        w && e.setItemSize(n, w);
      };
    return (
      we(() => o()),
      bt(() => o()),
      () => {
        var a;
        const r = nt((a = l.default) == null ? void 0 : a.call(l));
        return r ? vt(r, { ref: u }, !0) : null;
      }
    );
  },
});
const wn = Z({
  name: "VirtualList",
  components: { VirtualListItem: kn },
  props: {
    height: { type: [Number, String], default: 200 },
    data: { type: Array, default: () => [] },
    threshold: { type: Number, default: 0 },
    itemKey: { type: String, default: "key" },
    fixedSize: { type: Boolean, default: !1 },
    estimatedSize: { type: Number, default: 30 },
    buffer: { type: Number, default: 10 },
    component: { type: [String, Object], default: "div" },
    listAttrs: { type: Object },
    contentAttrs: { type: Object },
    paddingPosition: { type: String, default: "content" },
  },
  emits: { scroll: (e) => !0, reachBottom: (e) => !0 },
  setup(e, { emit: l }) {
    const { data: t, itemKey: n, fixedSize: u, estimatedSize: o, buffer: a, height: r } = de(e),
      c = J("virtual-list"),
      d = s(() =>
        se(e.component)
          ? { container: "div", list: "div", content: "div", ...e.component }
          : { container: e.component, list: "div", content: "div" },
      ),
      v = z(),
      w = z(),
      h = s(() => ({ height: le(r.value) ? `${r.value}px` : r.value, overflow: "auto" })),
      S = s(() =>
        t.value.map((x, B) => {
          var G;
          return (G = x[n.value]) != null ? G : B;
        }),
      ),
      {
        frontPadding: m,
        behindPadding: C,
        start: k,
        end: M,
        getStartByScroll: _,
        setItemSize: $,
        hasItemSize: b,
        setStart: V,
        getScrollOffset: i,
      } = Sn({ dataKeys: S, contentRef: w, fixedSize: u, estimatedSize: o, buffer: a }),
      f = s(() => (e.threshold && t.value.length <= e.threshold ? t.value : t.value.slice(k.value, M.value))),
      P = (x) => {
        const { scrollTop: B, scrollHeight: G, offsetHeight: q } = x.target,
          O = _(B);
        (O !== k.value &&
          (V(O),
          ye(() => {
            j(B);
          })),
          l("scroll", x),
          Math.floor(G - (B + q)) <= 0 && l("reachBottom", x));
      },
      j = (x) => {
        var B, G;
        if (v.value)
          if (le(x)) v.value.scrollTop = x;
          else {
            const q = (G = x.index) != null ? G : S.value.indexOf((B = x.key) != null ? B : "");
            (V(q - a.value),
              (v.value.scrollTop = i(q)),
              ye(() => {
                if (v.value) {
                  const O = i(q);
                  O !== v.value.scrollTop && (v.value.scrollTop = O);
                }
              }));
          }
      };
    return {
      prefixCls: c,
      containerRef: v,
      contentRef: w,
      frontPadding: m,
      currentList: f,
      behindPadding: C,
      onScroll: P,
      setItemSize: $,
      hasItemSize: b,
      start: k,
      scrollTo: j,
      style: h,
      mergedComponent: d,
    };
  },
});
function _n(e, l, t, n, u, o) {
  const a = me("VirtualListItem");
  return (
    E(),
    ce(
      Ne(e.mergedComponent.container),
      { ref: "containerRef", class: D(e.prefixCls), style: ge(e.style), onScroll: e.onScroll },
      {
        default: be(() => [
          (E(),
          ce(
            Ne(e.mergedComponent.list),
            ne(e.listAttrs, {
              style:
                e.paddingPosition === "list"
                  ? { paddingTop: `${e.frontPadding}px`, paddingBottom: `${e.behindPadding}px` }
                  : {},
            }),
            {
              default: be(() => [
                (E(),
                ce(
                  Ne(e.mergedComponent.content),
                  ne({ ref: "contentRef" }, e.contentAttrs, {
                    style:
                      e.paddingPosition === "content"
                        ? { paddingTop: `${e.frontPadding}px`, paddingBottom: `${e.behindPadding}px` }
                        : {},
                  }),
                  {
                    default: be(() => [
                      (E(!0),
                      Y(
                        Ae,
                        null,
                        Wt(e.currentList, (r, c) => {
                          var d;
                          return (
                            E(),
                            ce(
                              a,
                              {
                                key: (d = r[e.itemKey]) != null ? d : e.start + c,
                                "has-item-size": e.hasItemSize,
                                "set-item-size": e.setItemSize,
                              },
                              { default: be(() => [ee(e.$slots, "item", { item: r, index: e.start + c })]), _: 2 },
                              1032,
                              ["has-item-size", "set-item-size"],
                            )
                          );
                        }),
                        128,
                      )),
                    ]),
                    _: 3,
                  },
                  16,
                  ["style"],
                )),
              ]),
              _: 3,
            },
            16,
            ["style"],
          )),
        ]),
        _: 3,
      },
      40,
      ["class", "style", "onScroll"],
    )
  );
}
var It = oe(wn, [["render", _n]]);
const zn = ({ itemRef: e, selector: l, index: t, parentClassName: n }) => {
    const u = z(-1),
      o = s(() => {
        var d;
        return (d = t == null ? void 0 : t.value) != null ? d : u.value;
      }),
      a = z(),
      r = () => {
        var d, v, w;
        let h = (v = (d = e.value) == null ? void 0 : d.parentElement) != null ? v : void 0;
        if (n) for (; h && !h.className.includes(n); ) h = (w = h.parentElement) != null ? w : void 0;
        return h;
      },
      c = () => {
        if (xe(t == null ? void 0 : t.value) && a.value && e.value) {
          const d = Array.from(a.value.querySelectorAll(l)).indexOf(e.value);
          d !== u.value && (u.value = d);
        }
      };
    return (
      ae(e, () => {
        e.value && !a.value && (a.value = r());
      }),
      we(() => {
        (e.value && (a.value = r()), c());
      }),
      gt(() => c()),
      { computedIndex: o }
    );
  },
  In = Z({
    name: "IconMore",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: l }) {
      const t = J("icon"),
        n = s(() => [t, `${t}-more`, { [`${t}-spin`]: e.spin }]),
        u = s(() => {
          const a = {};
          return (
            e.size && (a.fontSize = le(e.size) ? `${e.size}px` : e.size),
            e.rotate && (a.transform = `rotate(${e.rotate}deg)`),
            a
          );
        });
      return {
        cls: n,
        innerStyle: u,
        onClick: (a) => {
          l("click", a);
        },
      };
    },
  }),
  Bn = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function On(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: D(e.cls),
        style: ge(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: l[0] || (l[0] = (...a) => e.onClick && e.onClick(...a)),
      },
      l[1] ||
        (l[1] = [
          fe(
            "path",
            { d: "M38 25v-2h2v2h-2ZM23 25v-2h2v2h-2ZM8 25v-2h2v2H8Z", fill: "currentColor", stroke: "none" },
            null,
            -1,
          ),
          fe("path", { d: "M38 25v-2h2v2h-2ZM23 25v-2h2v2h-2ZM8 25v-2h2v2H8Z" }, null, -1),
        ]),
      14,
      Bn,
    )
  );
}
var bl = oe(In, [["render", On]]);
const Vn = Object.assign(bl, {
    install: (e, l) => {
      var t;
      const n = (t = l == null ? void 0 : l.iconPrefix) != null ? t : "";
      e.component(n + bl.name, bl);
    },
  }),
  Pn = Z({
    name: "IconDown",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: l }) {
      const t = J("icon"),
        n = s(() => [t, `${t}-down`, { [`${t}-spin`]: e.spin }]),
        u = s(() => {
          const a = {};
          return (
            e.size && (a.fontSize = le(e.size) ? `${e.size}px` : e.size),
            e.rotate && (a.transform = `rotate(${e.rotate}deg)`),
            a
          );
        });
      return {
        cls: n,
        innerStyle: u,
        onClick: (a) => {
          l("click", a);
        },
      };
    },
  }),
  xn = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Nn(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: D(e.cls),
        style: ge(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: l[0] || (l[0] = (...a) => e.onClick && e.onClick(...a)),
      },
      l[1] || (l[1] = [fe("path", { d: "M39.6 17.443 24.043 33 8.487 17.443" }, null, -1)]),
      14,
      xn,
    )
  );
}
var yl = oe(Pn, [["render", Nn]]);
const Bt = Object.assign(yl, {
    install: (e, l) => {
      var t;
      const n = (t = l == null ? void 0 : l.iconPrefix) != null ? t : "";
      e.component(n + yl.name, yl);
    },
  }),
  Mn = ({ popupVisible: e, defaultPopupVisible: l, emit: t }) => {
    var n;
    const u = z((n = l == null ? void 0 : l.value) != null ? n : !1),
      o = s(() => {
        var r;
        return (r = e == null ? void 0 : e.value) != null ? r : u.value;
      }),
      a = (r) => {
        r !== o.value && ((u.value = r), t("update:popupVisible", r), t("popupVisibleChange", r));
      };
    return (
      ae(o, (r) => {
        u.value !== r && (u.value = r);
      }),
      { computedPopupVisible: o, handlePopupVisibleChange: a }
    );
  },
  Rn = ({
    defaultValue: e,
    modelValue: l,
    emit: t,
    eventName: n = "input",
    updateEventName: u = "update:modelValue",
    eventHandlers: o,
  }) => {
    var a;
    const r = z(),
      c = z((a = e == null ? void 0 : e.value) != null ? a : ""),
      d = z(!1),
      v = z(!1),
      w = z("");
    let h;
    const S = s(() => {
        var i;
        return (i = l == null ? void 0 : l.value) != null ? i : c.value;
      }),
      m = (i, f) => {
        ((c.value = i), t(u, i), t(n, i, f));
      },
      C = (i) => {
        const { value: f } = i.target;
        v.value ||
          (m(f, i),
          ye(() => {
            r.value && S.value !== r.value.value && (r.value.value = S.value);
          }));
      },
      k = (i) => {
        n === "input" && S.value !== h && ((h = S.value), t("change", S.value, i));
      },
      M = (i) => {
        var f;
        const { value: P } = i.target;
        i.type === "compositionend"
          ? ((v.value = !1),
            (w.value = ""),
            m(P, i),
            ye(() => {
              r.value && S.value !== r.value.value && (r.value.value = S.value);
            }))
          : ((v.value = !0), (w.value = S.value + ((f = i.data) != null ? f : "")));
      },
      _ = (i) => {
        var f, P;
        ((d.value = !0),
          (h = S.value),
          t("focus", i),
          (P = (f = o == null ? void 0 : o.value) == null ? void 0 : f.onFocus) == null || P.call(f, i));
      },
      $ = (i) => {
        var f, P;
        ((d.value = !1),
          t("blur", i),
          (P = (f = o == null ? void 0 : o.value) == null ? void 0 : f.onBlur) == null || P.call(f, i),
          k(i));
      },
      b = (i) => {
        const f = i.key || i.code;
        !v.value && f === it.key && (t("pressEnter", i), k(i));
      },
      V = (i) => {
        r.value && i.target !== r.value && (i.preventDefault(), r.value.focus());
      };
    return (
      ae(S, (i) => {
        r.value && i !== r.value.value && (r.value.value = i);
      }),
      {
        inputRef: r,
        _value: c,
        _focused: d,
        isComposition: v,
        compositionValue: w,
        computedValue: S,
        handleInput: C,
        handleComposition: M,
        handleFocus: _,
        handleBlur: $,
        handleKeyDown: b,
        handleMousedown: V,
      }
    );
  };
var jn = Z({
  name: "InputLabel",
  inheritAttrs: !1,
  props: {
    modelValue: Object,
    inputValue: { type: String, default: "" },
    enabledInput: Boolean,
    formatLabel: Function,
    placeholder: String,
    retainInputValue: Boolean,
    disabled: Boolean,
    baseCls: String,
    size: String,
    error: Boolean,
    focused: Boolean,
    uninjectFormItemContext: Boolean,
  },
  emits: ["update:inputValue", "inputValueChange", "focus", "blur"],
  setup(e, { attrs: l, emit: t, slots: n }) {
    var u;
    const { size: o, disabled: a, error: r, inputValue: c, uninjectFormItemContext: d } = de(e),
      v = (u = e.baseCls) != null ? u : J("input-label"),
      {
        mergedSize: w,
        mergedDisabled: h,
        mergedError: S,
        eventHandlers: m,
      } = je({ size: o, disabled: a, error: r, uninject: d == null ? void 0 : d.value }),
      { mergedSize: C } = Ee(w),
      {
        inputRef: k,
        _focused: M,
        computedValue: _,
        handleInput: $,
        handleComposition: b,
        handleFocus: V,
        handleBlur: i,
        handleMousedown: f,
      } = Rn({
        modelValue: c,
        emit: t,
        eventName: "inputValueChange",
        updateEventName: "update:inputValue",
        eventHandlers: m,
      }),
      P = s(() => {
        var A;
        return (A = e.focused) != null ? A : M.value;
      }),
      j = s(() => (e.enabledInput && M.value) || !e.modelValue),
      x = () => {
        var A, F;
        return e.modelValue
          ? (F = (A = e.formatLabel) == null ? void 0 : A.call(e, e.modelValue)) != null
            ? F
            : e.modelValue.label
          : "";
      },
      B = s(() => (e.enabledInput && e.modelValue ? x() : e.placeholder)),
      G = () => {
        var A, F;
        return e.modelValue
          ? (F = (A = n.default) == null ? void 0 : A.call(n, { data: e.modelValue })) != null
            ? F
            : x()
          : null;
      },
      q = s(() => [
        v,
        `${v}-size-${C.value}`,
        {
          [`${v}-search`]: e.enabledInput,
          [`${v}-focus`]: P.value,
          [`${v}-disabled`]: h.value,
          [`${v}-error`]: S.value,
        },
      ]),
      O = s(() => Qe(l, el)),
      R = s(() => at(l, el));
    return {
      inputRef: k,
      render: () =>
        g("span", ne(O.value, { class: q.value, title: x(), onMousedown: f }), [
          n.prefix && g("span", { class: `${v}-prefix` }, [n.prefix()]),
          g(
            "input",
            ne(R.value, {
              ref: k,
              class: [`${v}-input`, { [`${v}-input-hidden`]: !j.value }],
              value: _.value,
              readonly: !e.enabledInput,
              placeholder: B.value,
              disabled: h.value,
              onInput: $,
              onFocus: V,
              onBlur: i,
              onCompositionstart: b,
              onCompositionupdate: b,
              onCompositionend: b,
            }),
            null,
          ),
          g("span", { class: [`${v}-value`, { [`${v}-value-hidden`]: j.value }] }, [G()]),
          n.suffix && g("span", { class: `${v}-suffix` }, [n.suffix()]),
        ]),
    };
  },
  methods: {
    focus() {
      var e;
      (e = this.inputRef) == null || e.focus();
    },
    blur() {
      var e;
      (e = this.inputRef) == null || e.blur();
    },
  },
  render() {
    return this.render();
  },
});
const Ln = (e, l) => {
    const t = [];
    for (const n of e)
      if (se(n))
        t.push({ raw: n, value: n[l.value], label: n[l.label], closable: n[l.closable], tagProps: n[l.tagProps] });
      else if (e || le(e)) {
        const u = { value: n, label: String(n), closable: !0 };
        t.push({ raw: u, ...u });
      }
    return t;
  },
  Yl = [
    "red",
    "orangered",
    "orange",
    "gold",
    "lime",
    "green",
    "cyan",
    "blue",
    "arcoblue",
    "purple",
    "pinkpurple",
    "magenta",
    "gray",
  ],
  Tn = Z({
    name: "Tag",
    components: { IconHover: Ke, IconClose: Al, IconLoading: ot },
    props: {
      color: { type: String },
      size: { type: String },
      bordered: { type: Boolean, default: !1 },
      visible: { type: Boolean, default: void 0 },
      defaultVisible: { type: Boolean, default: !0 },
      loading: { type: Boolean, default: !1 },
      closable: { type: Boolean, default: !1 },
      checkable: { type: Boolean, default: !1 },
      checked: { type: Boolean, default: void 0 },
      defaultChecked: { type: Boolean, default: !0 },
      nowrap: { type: Boolean, default: !1 },
    },
    emits: { "update:visible": (e) => !0, "update:checked": (e) => !0, close: (e) => !0, check: (e, l) => !0 },
    setup(e, { emit: l }) {
      const { size: t } = de(e),
        n = J("tag"),
        u = s(() => e.color && Yl.includes(e.color)),
        o = s(() => e.color && !Yl.includes(e.color)),
        a = z(e.defaultVisible),
        r = z(e.defaultChecked),
        c = s(() => {
          var k;
          return (k = e.visible) != null ? k : a.value;
        }),
        d = s(() => {
          var k;
          return e.checkable ? ((k = e.checked) != null ? k : r.value) : !0;
        }),
        { mergedSize: v } = Ee(t),
        w = s(() => (v.value === "mini" ? "small" : v.value)),
        h = (k) => {
          ((a.value = !1), l("update:visible", !1), l("close", k));
        },
        S = (k) => {
          if (e.checkable) {
            const M = !d.value;
            ((r.value = M), l("update:checked", M), l("check", M, k));
          }
        },
        m = s(() => [
          n,
          `${n}-size-${w.value}`,
          {
            [`${n}-loading`]: e.loading,
            [`${n}-hide`]: !c.value,
            [`${n}-${e.color}`]: u.value,
            [`${n}-bordered`]: e.bordered,
            [`${n}-checkable`]: e.checkable,
            [`${n}-checked`]: d.value,
            [`${n}-custom-color`]: o.value,
          },
        ]),
        C = s(() => {
          if (o.value) return { backgroundColor: e.color };
        });
      return { prefixCls: n, cls: m, style: C, computedVisible: c, computedChecked: d, handleClick: S, handleClose: h };
    },
  });
function En(e, l, t, n, u, o) {
  const a = me("icon-close"),
    r = me("icon-hover"),
    c = me("icon-loading");
  return e.computedVisible
    ? (E(),
      Y(
        "span",
        {
          key: 0,
          class: D(e.cls),
          style: ge(e.style),
          onClick: l[0] || (l[0] = (...d) => e.handleClick && e.handleClick(...d)),
        },
        [
          e.$slots.icon
            ? (E(), Y("span", { key: 0, class: D(`${e.prefixCls}-icon`) }, [ee(e.$slots, "icon")], 2))
            : re("v-if", !0),
          e.nowrap
            ? (E(), Y("span", { key: 1, class: D(`${e.prefixCls}-text`) }, [ee(e.$slots, "default")], 2))
            : ee(e.$slots, "default", { key: 2 }),
          e.closable
            ? (E(),
              ce(
                r,
                {
                  key: 3,
                  role: "button",
                  "aria-label": "Close",
                  prefix: e.prefixCls,
                  class: D(`${e.prefixCls}-close-btn`),
                  onClick: ft(e.handleClose, ["stop"]),
                },
                { default: be(() => [ee(e.$slots, "close-icon", {}, () => [g(a)])]), _: 3 },
                8,
                ["prefix", "class", "onClick"],
              ))
            : re("v-if", !0),
          e.loading ? (E(), Y("span", { key: 4, class: D(`${e.prefixCls}-loading-icon`) }, [g(c)], 2)) : re("v-if", !0),
        ],
        6,
      ))
    : re("v-if", !0);
}
var $l = oe(Tn, [["render", En]]);
const An = Object.assign($l, {
    install: (e, l) => {
      Ce(e, l);
      const t = Se(l);
      e.component(t + $l.name, $l);
    },
  }),
  Fn = { value: "value", label: "label", closable: "closable", tagProps: "tagProps" };
var Cl = Z({
  name: "InputTag",
  inheritAttrs: !1,
  props: {
    modelValue: { type: Array },
    defaultValue: { type: Array, default: () => [] },
    inputValue: String,
    defaultInputValue: { type: String, default: "" },
    placeholder: String,
    disabled: { type: Boolean, default: !1 },
    error: { type: Boolean, default: !1 },
    readonly: { type: Boolean, default: !1 },
    allowClear: { type: Boolean, default: !1 },
    size: { type: String },
    maxTagCount: { type: Number, default: 0 },
    retainInputValue: { type: [Boolean, Object], default: !1 },
    formatTag: { type: Function },
    uniqueValue: { type: Boolean, default: !1 },
    fieldNames: { type: Object },
    tagNowrap: { type: Boolean, default: !1 },
    baseCls: String,
    focused: Boolean,
    disabledInput: Boolean,
    uninjectFormItemContext: Boolean,
  },
  emits: {
    "update:modelValue": (e) => !0,
    "update:inputValue": (e) => !0,
    change: (e, l) => !0,
    inputValueChange: (e, l) => !0,
    pressEnter: (e, l) => !0,
    remove: (e, l) => !0,
    clear: (e) => !0,
    focus: (e) => !0,
    blur: (e) => !0,
  },
  setup(e, { emit: l, slots: t, attrs: n }) {
    const { size: u, disabled: o, error: a, uninjectFormItemContext: r, modelValue: c } = de(e),
      d = e.baseCls || J("input-tag"),
      v = z(),
      w = z(),
      {
        mergedSize: h,
        mergedDisabled: S,
        mergedError: m,
        feedback: C,
        eventHandlers: k,
      } = je({ size: u, disabled: o, error: a, uninject: r == null ? void 0 : r.value }),
      { mergedSize: M } = Ee(h),
      _ = s(() => ({ ...Fn, ...e.fieldNames })),
      $ = z(!1),
      b = z(e.defaultValue),
      V = z(e.defaultInputValue),
      i = z(!1),
      f = z(""),
      P = s(() =>
        se(e.retainInputValue)
          ? { create: !1, blur: !1, ...e.retainInputValue }
          : { create: e.retainInputValue, blur: e.retainInputValue },
      ),
      j = ke({ width: "12px" }),
      x = s(() => e.focused || $.value),
      B = (I, W) => {
        ((V.value = I), l("update:inputValue", I), l("inputValueChange", I, W));
      },
      G = (I) => {
        var W;
        const { value: Q } = I.target;
        I.type === "compositionend"
          ? ((i.value = !1),
            (f.value = ""),
            B(Q, I),
            ye(() => {
              v.value && O.value !== v.value.value && (v.value.value = O.value);
            }))
          : ((i.value = !0), (f.value = O.value + ((W = I.data) != null ? W : "")));
      },
      q = s(() => {
        var I;
        return (I = e.modelValue) != null ? I : b.value;
      }),
      O = s(() => {
        var I;
        return (I = e.inputValue) != null ? I : V.value;
      });
    ae(c, (I) => {
      (xe(I) || Tl(I)) && (b.value = []);
    });
    const R = (I) => {
        v.value && I.target !== v.value && (I.preventDefault(), v.value.focus());
      },
      T = (I) => {
        const { value: W } = I.target;
        i.value ||
          (B(W, I),
          ye(() => {
            v.value && O.value !== v.value.value && (v.value.value = O.value);
          }));
      },
      A = s(() => Ln(q.value, _.value)),
      F = s(() => {
        if (e.maxTagCount > 0) {
          const I = A.value.length - e.maxTagCount;
          if (I > 0) {
            const W = A.value.slice(0, e.maxTagCount),
              Q = { value: "__arco__more", label: `+${I}...`, closable: !1 };
            return (W.push({ raw: Q, ...Q }), W);
          }
        }
        return A.value;
      }),
      X = (I, W) => {
        var Q, pe;
        ((b.value = I),
          l("update:modelValue", I),
          l("change", I, W),
          (pe = (Q = k.value) == null ? void 0 : Q.onChange) == null || pe.call(Q, W));
      },
      ve = (I, W, Q) => {
        var pe;
        const ie = (pe = q.value) == null ? void 0 : pe.filter((Fe, Le) => Le !== W);
        (X(ie, Q), l("remove", I, Q));
      },
      y = (I) => {
        (X([], I), l("clear", I));
      },
      H = s(() => !S.value && !e.readonly && e.allowClear && !!q.value.length),
      K = (I) => {
        var W;
        if (O.value) {
          if ((I.preventDefault(), e.uniqueValue && (W = q.value) != null && W.includes(O.value))) {
            l("pressEnter", O.value, I);
            return;
          }
          const Q = q.value.concat(O.value);
          (X(Q, I), l("pressEnter", O.value, I), P.value.create || B("", I));
        }
      },
      te = (I) => {
        var W, Q;
        (($.value = !0), l("focus", I), (Q = (W = k.value) == null ? void 0 : W.onFocus) == null || Q.call(W, I));
      },
      he = (I) => {
        var W, Q;
        (($.value = !1),
          !P.value.blur && O.value && B("", I),
          l("blur", I),
          (Q = (W = k.value) == null ? void 0 : W.onBlur) == null || Q.call(W, I));
      },
      ue = () => {
        for (let I = A.value.length - 1; I >= 0; I--) if (A.value[I].closable) return I;
        return -1;
      },
      ul = (I) => {
        if (S.value || e.readonly) return;
        const W = I.key || I.code;
        if ((!i.value && O.value && W === it.key && K(I), !i.value && F.value.length > 0 && !O.value && W === Dt.key)) {
          const Q = ue();
          Q >= 0 && ve(A.value[Q].value, Q, I);
        }
      },
      _e = (I) => {
        I > 12 ? (j.width = `${I}px`) : (j.width = "12px");
      };
    we(() => {
      w.value && _e(w.value.offsetWidth);
    });
    const Oe = () => {
      w.value && _e(w.value.offsetWidth);
    };
    ae(O, (I) => {
      v.value && !i.value && I !== v.value.value && (v.value.value = I);
    });
    const rl = s(() => [
        d,
        `${d}-size-${M.value}`,
        {
          [`${d}-disabled`]: S.value,
          [`${d}-disabled-input`]: e.disabledInput,
          [`${d}-error`]: m.value,
          [`${d}-focus`]: x.value,
          [`${d}-readonly`]: e.readonly,
          [`${d}-has-tag`]: F.value.length > 0,
          [`${d}-has-prefix`]: !!t.prefix,
          [`${d}-has-suffix`]: !!t.suffix || H.value || C.value,
          [`${d}-has-placeholder`]: !q.value.length,
        },
      ]),
      il = s(() => Qe(n, el)),
      sl = s(() => at(n, el));
    return {
      inputRef: v,
      render: () => {
        var I;
        return g("span", ne({ class: rl.value, onMousedown: R }, il.value), [
          g(
            Yt,
            { onResize: Oe },
            {
              default: () => [
                g("span", { ref: w, class: `${d}-mirror` }, [
                  F.value.length > 0 ? f.value || O.value : f.value || O.value || e.placeholder,
                ]),
              ],
            },
          ),
          t.prefix && g("span", { class: `${d}-prefix` }, [t.prefix()]),
          g(
            qt,
            { tag: "span", name: "input-tag-zoom", class: [`${d}-inner`, { [`${d}-nowrap`]: e.tagNowrap }] },
            {
              default: () => [
                F.value.map((W, Q) =>
                  g(
                    An,
                    ne(
                      {
                        key: `tag-${W.value}`,
                        class: `${d}-tag`,
                        closable: !S.value && !e.readonly && W.closable,
                        visible: !0,
                        nowrap: e.tagNowrap,
                      },
                      W.tagProps,
                      { onClose: (pe) => ve(W.value, Q, pe) },
                    ),
                    {
                      default: () => {
                        var pe, ie, Fe, Le;
                        return [
                          (Le =
                            (Fe = (pe = t.tag) == null ? void 0 : pe.call(t, { data: W.raw })) != null
                              ? Fe
                              : (ie = e.formatTag) == null
                                ? void 0
                                : ie.call(e, W.raw)) != null
                            ? Le
                            : W.label,
                        ];
                      },
                    },
                  ),
                ),
                g(
                  "input",
                  ne(sl.value, {
                    ref: v,
                    key: "input-tag-input",
                    class: `${d}-input`,
                    style: j,
                    placeholder: F.value.length === 0 ? e.placeholder : void 0,
                    disabled: S.value,
                    readonly: e.readonly || e.disabledInput,
                    onInput: T,
                    onKeydown: ul,
                    onFocus: te,
                    onBlur: he,
                    onCompositionstart: G,
                    onCompositionupdate: G,
                    onCompositionend: G,
                  }),
                  null,
                ),
              ],
            },
          ),
          H.value &&
            g(
              Ke,
              { class: `${d}-clear-btn`, onClick: y, onMousedown: (W) => W.stopPropagation() },
              { default: () => [g(Al, null, null)] },
            ),
          (t.suffix || !!C.value) &&
            g("span", { class: `${d}-suffix` }, [
              (I = t.suffix) == null ? void 0 : I.call(t),
              !!C.value && g(ut, { type: C.value }, null),
            ]),
        ]);
      },
    };
  },
  methods: {
    focus() {
      var e;
      (e = this.inputRef) == null || e.focus();
    },
    blur() {
      var e;
      (e = this.inputRef) == null || e.blur();
    },
  },
  render() {
    return this.render();
  },
});
const Dn = Object.assign(Cl, {
  install: (e, l) => {
    Ce(e, l);
    const t = Se(l);
    e.component(t + Cl.name, Cl);
  },
});
var Jl = Z({
  name: "SelectView",
  props: {
    modelValue: { type: Array, required: !0 },
    inputValue: String,
    placeholder: String,
    disabled: { type: Boolean, default: !1 },
    error: { type: Boolean, default: !1 },
    loading: { type: Boolean, default: !1 },
    opened: { type: Boolean, default: !1 },
    size: { type: String },
    bordered: { type: Boolean, default: !0 },
    multiple: { type: Boolean, default: !1 },
    allowClear: { type: Boolean, default: !1 },
    allowCreate: { type: Boolean, default: !1 },
    allowSearch: { type: Boolean, default: (e) => ze(e.modelValue) },
    maxTagCount: { type: Number, default: 0 },
    tagNowrap: { type: Boolean, default: !1 },
    retainInputValue: { type: Boolean, default: !1 },
  },
  emits: ["remove", "clear", "focus", "blur"],
  setup(e, { emit: l, slots: t }) {
    const { size: n, disabled: u, error: o } = de(e),
      a = J("select-view"),
      {
        feedback: r,
        eventHandlers: c,
        mergedDisabled: d,
        mergedSize: v,
        mergedError: w,
      } = je({ size: n, disabled: u, error: o }),
      { mergedSize: h } = Ee(v),
      { opened: S } = de(e),
      m = z(),
      C = s(() => {
        var B;
        return (B = m.value) == null ? void 0 : B.inputRef;
      }),
      k = s(() => e.modelValue.length === 0),
      M = s(() => e.allowSearch || e.allowCreate),
      _ = s(() => e.allowClear && !e.disabled && !k.value),
      $ = (B) => {
        var G, q;
        (l("focus", B), (q = (G = c.value) == null ? void 0 : G.onFocus) == null || q.call(G, B));
      },
      b = (B) => {
        var G, q;
        (l("blur", B), (q = (G = c.value) == null ? void 0 : G.onBlur) == null || q.call(G, B));
      },
      V = (B) => {
        l("remove", B);
      },
      i = (B) => {
        l("clear", B);
      },
      f = () => {
        var B, G, q, O;
        return e.loading
          ? (G = (B = t["loading-icon"]) == null ? void 0 : B.call(t)) != null
            ? G
            : g(ot, null, null)
          : e.allowSearch && e.opened
            ? (O = (q = t["search-icon"]) == null ? void 0 : q.call(t)) != null
              ? O
              : g(Ht, null, null)
            : t["arrow-icon"]
              ? t["arrow-icon"]()
              : g(Bt, { class: `${a}-arrow-icon` }, null);
      },
      P = () =>
        g(Ae, null, [
          _.value &&
            g(
              Ke,
              { class: `${a}-clear-btn`, onClick: i, onMousedown: (B) => B.stopPropagation() },
              { default: () => [g(Al, null, null)] },
            ),
          g("span", { class: `${a}-icon` }, [f()]),
          !!r.value && g(ut, { type: r.value }, null),
        ]);
    ae(S, (B) => {
      !B && C.value && C.value.isSameNode(document.activeElement) && C.value.blur();
    });
    const j = s(() => [
      `${a}-${e.multiple ? "multiple" : "single"}`,
      { [`${a}-opened`]: e.opened, [`${a}-borderless`]: !e.bordered },
    ]);
    return {
      inputRef: C,
      handleFocus: $,
      handleBlur: b,
      render: () =>
        e.multiple
          ? g(
              Dn,
              {
                ref: m,
                baseCls: a,
                class: j.value,
                modelValue: e.modelValue,
                inputValue: e.inputValue,
                focused: e.opened,
                placeholder: e.placeholder,
                disabled: d.value,
                size: h.value,
                error: w.value,
                maxTagCount: e.maxTagCount,
                disabledInput: !e.allowSearch && !e.allowCreate,
                tagNowrap: e.tagNowrap,
                retainInputValue: !0,
                uninjectFormItemContext: !0,
                onRemove: V,
                onFocus: $,
                onBlur: b,
              },
              { prefix: t.prefix, suffix: P, tag: t.label },
            )
          : g(
              jn,
              {
                ref: m,
                baseCls: a,
                class: j.value,
                modelValue: e.modelValue[0],
                inputValue: e.inputValue,
                focused: e.opened,
                placeholder: e.placeholder,
                disabled: d.value,
                size: h.value,
                error: w.value,
                enabledInput: M.value,
                uninjectFormItemContext: !0,
                onFocus: $,
                onBlur: b,
              },
              { default: t.label, prefix: t.prefix, suffix: P },
            ),
    };
  },
  methods: {
    focus() {
      this.inputRef && this.inputRef.focus();
    },
    blur() {
      this.inputRef && this.inputRef.blur();
    },
  },
  render() {
    return this.render();
  },
});
const Hn = Z({
  name: "Optgroup",
  props: { label: { type: String } },
  setup() {
    return { prefixCls: J("select-group") };
  },
});
function Gn(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      Ae,
      null,
      [
        fe("li", { class: D(`${e.prefixCls}-title`) }, [ee(e.$slots, "label", {}, () => [Re(Ie(e.label), 1)])], 2),
        ee(e.$slots, "default"),
      ],
      64,
    )
  );
}
var Xe = oe(Hn, [["render", Gn]]);
const Xl = typeof window > "u" ? global : window;
function Kn(e, l) {
  let t = 0;
  return (...n) => {
    (t && Xl.clearTimeout(t),
      (t = Xl.setTimeout(() => {
        ((t = 0), e(...n));
      }, l)));
  };
}
function Wn(e) {
  return typeof e == "function" || (Object.prototype.toString.call(e) === "[object Object]" && !Ge(e));
}
const qn = { value: "value", label: "label", disabled: "disabled", tagProps: "tagProps", render: "render" };
var Sl = Z({
  name: "Select",
  components: { Trigger: Kl, SelectView: Jl },
  inheritAttrs: !1,
  props: {
    multiple: { type: Boolean, default: !1 },
    modelValue: { type: [String, Number, Boolean, Object, Array], default: void 0 },
    defaultValue: { type: [String, Number, Boolean, Object, Array], default: (e) => (xe(e.multiple) ? "" : []) },
    inputValue: { type: String },
    defaultInputValue: { type: String, default: "" },
    size: { type: String },
    placeholder: String,
    loading: { type: Boolean, default: !1 },
    disabled: { type: Boolean, default: !1 },
    error: { type: Boolean, default: !1 },
    allowClear: { type: Boolean, default: !1 },
    allowSearch: { type: [Boolean, Object], default: (e) => !!e.multiple },
    allowCreate: { type: Boolean, default: !1 },
    maxTagCount: { type: Number, default: 0 },
    popupContainer: { type: [String, Object] },
    bordered: { type: Boolean, default: !0 },
    defaultActiveFirstOption: { type: Boolean, default: !0 },
    popupVisible: { type: Boolean, default: void 0 },
    defaultPopupVisible: { type: Boolean, default: !1 },
    unmountOnClose: { type: Boolean, default: !1 },
    filterOption: { type: [Boolean, Function], default: !0 },
    options: { type: Array, default: () => [] },
    virtualListProps: { type: Object },
    triggerProps: { type: Object },
    formatLabel: { type: Function },
    fallbackOption: { type: [Boolean, Function], default: !0 },
    showExtraOptions: { type: Boolean, default: !0 },
    valueKey: { type: String, default: "value" },
    searchDelay: { type: Number, default: 500 },
    limit: { type: Number, default: 0 },
    fieldNames: { type: Object },
    scrollbar: { type: [Boolean, Object], default: !0 },
    showHeaderOnEmpty: { type: Boolean, default: !1 },
    showFooterOnEmpty: { type: Boolean, default: !1 },
    tagNowrap: { type: Boolean, default: !1 },
  },
  emits: {
    "update:modelValue": (e) => !0,
    "update:inputValue": (e) => !0,
    "update:popupVisible": (e) => !0,
    change: (e) => !0,
    inputValueChange: (e) => !0,
    popupVisibleChange: (e) => !0,
    clear: (e) => !0,
    remove: (e) => !0,
    search: (e) => !0,
    dropdownScroll: (e) => !0,
    dropdownReachBottom: (e) => !0,
    exceedLimit: (e, l) => !0,
  },
  setup(e, { slots: l, emit: t, attrs: n }) {
    const {
        size: u,
        disabled: o,
        error: a,
        options: r,
        filterOption: c,
        valueKey: d,
        multiple: v,
        popupVisible: w,
        defaultPopupVisible: h,
        showExtraOptions: S,
        modelValue: m,
        fieldNames: C,
        loading: k,
        defaultActiveFirstOption: M,
      } = de(e),
      _ = J("select"),
      { mergedSize: $, mergedDisabled: b, mergedError: V, eventHandlers: i } = je({ size: u, disabled: o, error: a }),
      f = s(() => (e.virtualListProps ? "div" : "li")),
      P = s(() => se(e.allowSearch) && !!e.allowSearch.retainInputValue);
    s(() => {
      if (Pe(e.formatLabel))
        return (p) => {
          const N = ie.get(p.value);
          return e.formatLabel(N);
        };
    });
    const j = z(),
      x = z({}),
      B = z(),
      { computedPopupVisible: G, handlePopupVisibleChange: q } = Mn({
        popupVisible: w,
        defaultPopupVisible: h,
        emit: t,
      }),
      O = z(e.defaultValue),
      R = s(() => {
        var p;
        const N = (p = e.modelValue) != null ? p : O.value;
        return (ze(N) ? N : N || le(N) || El(N) || Ll(N) ? [N] : []).map((U) => ({ value: U, key: We(U, e.valueKey) }));
      });
    ae(m, (p) => {
      (xe(p) || Tl(p)) && (O.value = v.value ? [] : p);
    });
    const T = s(() => R.value.map((p) => p.key)),
      A = s(() => ({ ...qn, ...(C == null ? void 0 : C.value) })),
      F = z(),
      X = (p) => {
        const N = {};
        return (
          p.forEach((L) => {
            N[L] = ie.get(L);
          }),
          N
        );
      },
      ve = (p) => {
        F.value = X(p);
      },
      y = (p) =>
        Pe(e.fallbackOption)
          ? e.fallbackOption(p)
          : { [A.value.value]: p, [A.value.label]: String(se(p) ? p[d == null ? void 0 : d.value] : p) },
      H = () => {
        const p = [],
          N = [];
        if (e.allowCreate || e.fallbackOption) {
          for (const L of R.value)
            if (!N.includes(L.key) && L.value !== "") {
              const U = ie.get(L.key);
              (!U || U.origin === "extraOptions") && (p.push(L), N.push(L.key));
            }
        }
        if (e.allowCreate && ue.value) {
          const L = We(ue.value);
          if (!N.includes(L)) {
            const U = ie.get(L);
            (!U || U.origin === "extraOptions") && p.push({ value: ue.value, key: L });
          }
        }
        return p;
      },
      K = z([]),
      te = s(() =>
        K.value.map((p) => {
          var N;
          let L = y(p.value);
          const U = (N = F.value) == null ? void 0 : N[p.key];
          return (!xe(U) && !At(U) && (L = { ...L, ...U }), L);
        }),
      );
    ye(() => {
      tl(() => {
        var p;
        const N = H();
        if (N.length !== K.value.length) K.value = N;
        else if (N.length > 0) {
          for (let L = 0; L < N.length; L++)
            if (N[L].key !== ((p = K.value[L]) == null ? void 0 : p.key)) {
              K.value = N;
              break;
            }
        }
      });
    });
    const he = z(""),
      ue = s(() => {
        var p;
        return (p = e.inputValue) != null ? p : he.value;
      });
    ae(G, (p) => {
      !p && !P.value && ue.value && Oe("");
    });
    const ul = (p) => {
        var N, L;
        return e.multiple
          ? p.map((U) => {
              var De, Ve;
              return (Ve = (De = ie.get(U)) == null ? void 0 : De.value) != null ? Ve : "";
            })
          : (L = (N = ie.get(p[0])) == null ? void 0 : N.value) != null
            ? L
            : fn(ie)
              ? void 0
              : "";
      },
      _e = (p) => {
        var N, L;
        const U = ul(p);
        ((O.value = U),
          t("update:modelValue", U),
          t("change", U),
          (L = (N = i.value) == null ? void 0 : N.onChange) == null || L.call(N),
          ve(p));
      },
      Oe = (p) => {
        ((he.value = p), t("update:inputValue", p), t("inputValueChange", p));
      },
      rl = (p, N) => {
        if (e.multiple) {
          if (T.value.includes(p)) {
            const L = T.value.filter((U) => U !== p);
            _e(L);
          } else if (Le.value.includes(p))
            if (e.limit > 0 && T.value.length >= e.limit) {
              const L = ie.get(p);
              t("exceedLimit", L == null ? void 0 : L.value, N);
            } else {
              const L = T.value.concat(p);
              _e(L);
            }
          P.value || Oe("");
        } else {
          if ((p !== T.value[0] && _e([p]), P.value)) {
            const L = ie.get(p);
            L && Oe(L.label);
          }
          q(!1);
        }
      },
      il = Kn((p) => {
        t("search", p);
      }, e.searchDelay),
      sl = (p) => {
        p !== ue.value && (G.value || q(!0), Oe(p), e.allowSearch && il(p));
      },
      Hl = (p) => {
        const N = ie.get(p),
          L = T.value.filter((U) => U !== p);
        (_e(L), t("remove", N == null ? void 0 : N.value));
      },
      I = (p) => {
        p == null || p.stopPropagation();
        const N = T.value.filter((L) => {
          var U;
          return (U = ie.get(L)) == null ? void 0 : U.disabled;
        });
        (_e(N), Oe(""), t("clear", p));
      },
      W = (p) => {
        t("dropdownScroll", p);
      },
      Q = (p) => {
        t("dropdownReachBottom", p);
      },
      {
        validOptions: pe,
        optionInfoMap: ie,
        validOptionInfos: Fe,
        enabledOptionKeys: Le,
        handleKeyDown: xt,
      } = Cn({
        multiple: v,
        options: r,
        extraOptions: te,
        inputValue: ue,
        filterOption: c,
        showExtraOptions: S,
        component: f,
        valueKey: d,
        fieldNames: C,
        loading: k,
        popupVisible: G,
        valueKeys: T,
        dropdownRef: j,
        optionRefs: x,
        virtualListRef: B,
        defaultActiveFirstOption: M,
        onSelect: rl,
        onPopupVisibleChange: q,
      }),
      Nt = s(() => {
        var p;
        const N = [];
        for (const L of R.value) {
          const U = ie.get(L.key);
          U &&
            N.push({
              ...U,
              value: L.key,
              label:
                (p = U == null ? void 0 : U.label) != null
                  ? p
                  : String(se(L.value) ? L.value[d == null ? void 0 : d.value] : L.value),
              closable: !(U != null && U.disabled),
              tagProps: U == null ? void 0 : U.tagProps,
            });
        }
        return N;
      }),
      Mt = (p) => {
        if (Pe(l.option)) {
          const N = l.option;
          return () => N({ data: p.raw });
        }
        return Pe(p.render) ? p.render : () => p.label;
      },
      cl = (p) => {
        if (zt(p)) {
          let N;
          return g(
            Xe,
            { key: p.key, label: p.label },
            Wn((N = p.options.map((L) => cl(L)))) ? N : { default: () => [N] },
          );
        }
        return al(p, { inputValue: ue.value, filterOption: c == null ? void 0 : c.value })
          ? g(
              Je,
              {
                ref: (N) => {
                  N != null && N.$el && (x.value[p.key] = N.$el);
                },
                key: p.key,
                value: p.value,
                label: p.label,
                disabled: p.disabled,
                internal: !0,
              },
              { default: Mt(p) },
            )
          : null;
      },
      Rt = () =>
        g(
          sn,
          {
            ref: j,
            loading: e.loading,
            empty: Fe.value.length === 0,
            virtualList: !!e.virtualListProps,
            scrollbar: e.scrollbar,
            showHeaderOnEmpty: e.showHeaderOnEmpty,
            showFooterOnEmpty: e.showFooterOnEmpty,
            onScroll: W,
            onReachBottom: Q,
          },
          {
            default: () => {
              var p, N;
              return [...((N = (p = l.default) == null ? void 0 : p.call(l)) != null ? N : []), ...pe.value.map(cl)];
            },
            "virtual-list": () =>
              g(It, ne(e.virtualListProps, { ref: B, data: pe.value }), { item: ({ item: p }) => cl(p) }),
            empty: l.empty,
            header: l.header,
            footer: l.footer,
          },
        ),
      jt = ({ data: p }) => {
        var N, L, U, De;
        if ((l.label || Pe(e.formatLabel)) && p) {
          const Ve = ie.get(p.value);
          if (Ve != null && Ve.raw)
            return (U = (N = l.label) == null ? void 0 : N.call(l, { data: Ve.raw })) != null
              ? U
              : (L = e.formatLabel) == null
                ? void 0
                : L.call(e, Ve.raw);
        }
        return (De = p == null ? void 0 : p.label) != null ? De : "";
      };
    return () =>
      g(
        Kl,
        ne(
          {
            trigger: "click",
            position: "bl",
            popupOffset: 4,
            animationName: "slide-dynamic-origin",
            hideEmpty: !0,
            preventFocus: !0,
            autoFitPopupWidth: !0,
            autoFitTransformOrigin: !0,
            disabled: b.value,
            popupVisible: G.value,
            unmountOnClose: e.unmountOnClose,
            clickToClose: !(e.allowSearch || e.allowCreate),
            popupContainer: e.popupContainer,
            onPopupVisibleChange: q,
          },
          e.triggerProps,
        ),
        {
          default: () => {
            var p, N;
            return [
              (N = (p = l.trigger) == null ? void 0 : p.call(l)) != null
                ? N
                : g(
                    Jl,
                    ne(
                      {
                        class: _,
                        modelValue: Nt.value,
                        inputValue: ue.value,
                        multiple: e.multiple,
                        disabled: b.value,
                        error: V.value,
                        loading: e.loading,
                        allowClear: e.allowClear,
                        allowCreate: e.allowCreate,
                        allowSearch: !!e.allowSearch,
                        opened: G.value,
                        maxTagCount: e.maxTagCount,
                        placeholder: e.placeholder,
                        bordered: e.bordered,
                        size: $.value,
                        tagNowrap: e.tagNowrap,
                        onInputValueChange: sl,
                        onRemove: Hl,
                        onClear: I,
                        onKeydown: xt,
                      },
                      n,
                    ),
                    {
                      label: jt,
                      prefix: l.prefix,
                      "arrow-icon": l["arrow-icon"],
                      "loading-icon": l["loading-icon"],
                      "search-icon": l["search-icon"],
                    },
                  ),
            ];
          },
          content: Rt,
        },
      );
  },
});
const Un = Object.assign(Sl, {
    Option: Je,
    OptGroup: Xe,
    install: (e, l) => {
      Ce(e, l);
      const t = Se(l);
      (e.component(t + Sl.name, Sl), e.component(t + Je.name, Je), e.component(t + Xe.name, Xe));
    },
  }),
  Zn = Z({
    name: "IconUp",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: l }) {
      const t = J("icon"),
        n = s(() => [t, `${t}-up`, { [`${t}-spin`]: e.spin }]),
        u = s(() => {
          const a = {};
          return (
            e.size && (a.fontSize = le(e.size) ? `${e.size}px` : e.size),
            e.rotate && (a.transform = `rotate(${e.rotate}deg)`),
            a
          );
        });
      return {
        cls: n,
        innerStyle: u,
        onClick: (a) => {
          l("click", a);
        },
      };
    },
  }),
  Yn = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Jn(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: D(e.cls),
        style: ge(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: l[0] || (l[0] = (...a) => e.onClick && e.onClick(...a)),
      },
      l[1] || (l[1] = [fe("path", { d: "M39.6 30.557 24.043 15 8.487 30.557" }, null, -1)]),
      14,
      Yn,
    )
  );
}
var kl = oe(Zn, [["render", Jn]]);
const Xn = Object.assign(kl, {
  install: (e, l) => {
    var t;
    const n = (t = l == null ? void 0 : l.iconPrefix) != null ? t : "";
    e.component(n + kl.name, kl);
  },
});
function Dl(e, l) {
  return (l === void 0 && (l = 15), +parseFloat(Number(e).toPrecision(l)));
}
function $e(e) {
  var l = e.toString().split(/[eE]/),
    t = (l[0].split(".")[1] || "").length - +(l[1] || 0);
  return t > 0 ? t : 0;
}
function qe(e) {
  if (e.toString().indexOf("e") === -1) return Number(e.toString().replace(".", ""));
  var l = $e(e);
  return l > 0 ? Dl(Number(e) * Math.pow(10, l)) : Number(e);
}
function Ml(e) {
  Vt &&
    (e > Number.MAX_SAFE_INTEGER || e < Number.MIN_SAFE_INTEGER) &&
    console.warn(e + " is beyond boundary when transfer to integer, the results may not be accurate");
}
function ol(e) {
  return function () {
    for (var l = [], t = 0; t < arguments.length; t++) l[t] = arguments[t];
    var n = l[0],
      u = l.slice(1);
    return u.reduce(function (o, a) {
      return e(o, a);
    }, n);
  };
}
var Be = ol(function (e, l) {
    var t = qe(e),
      n = qe(l),
      u = $e(e) + $e(l),
      o = t * n;
    return (Ml(o), o / Math.pow(10, u));
  }),
  Qn = ol(function (e, l) {
    var t = Math.pow(10, Math.max($e(e), $e(l)));
    return (Be(e, t) + Be(l, t)) / t;
  }),
  ea = ol(function (e, l) {
    var t = Math.pow(10, Math.max($e(e), $e(l)));
    return (Be(e, t) - Be(l, t)) / t;
  }),
  Ot = ol(function (e, l) {
    var t = qe(e),
      n = qe(l);
    return (Ml(t), Ml(n), Be(t / n, Dl(Math.pow(10, $e(l) - $e(e)))));
  });
function la(e, l) {
  var t = Math.pow(10, l),
    n = Ot(Math.round(Math.abs(Be(e, t))), t);
  return (e < 0 && n !== 0 && (n = Be(n, -1)), n);
}
var Vt = !0;
function ta(e) {
  (e === void 0 && (e = !0), (Vt = e));
}
var Rl = {
  strip: Dl,
  plus: Qn,
  minus: ea,
  times: Be,
  divide: Ot,
  round: la,
  digitLength: $e,
  float2Fixed: qe,
  enableBoundaryChecking: ta,
};
const na = Z({
    name: "IconPlus",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: l }) {
      const t = J("icon"),
        n = s(() => [t, `${t}-plus`, { [`${t}-spin`]: e.spin }]),
        u = s(() => {
          const a = {};
          return (
            e.size && (a.fontSize = le(e.size) ? `${e.size}px` : e.size),
            e.rotate && (a.transform = `rotate(${e.rotate}deg)`),
            a
          );
        });
      return {
        cls: n,
        innerStyle: u,
        onClick: (a) => {
          l("click", a);
        },
      };
    },
  }),
  aa = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function oa(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: D(e.cls),
        style: ge(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: l[0] || (l[0] = (...a) => e.onClick && e.onClick(...a)),
      },
      l[1] || (l[1] = [fe("path", { d: "M5 24h38M24 5v38" }, null, -1)]),
      14,
      aa,
    )
  );
}
var wl = oe(na, [["render", oa]]);
const ua = Object.assign(wl, {
    install: (e, l) => {
      var t;
      const n = (t = l == null ? void 0 : l.iconPrefix) != null ? t : "";
      e.component(n + wl.name, wl);
    },
  }),
  ra = Z({
    name: "IconMinus",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: l }) {
      const t = J("icon"),
        n = s(() => [t, `${t}-minus`, { [`${t}-spin`]: e.spin }]),
        u = s(() => {
          const a = {};
          return (
            e.size && (a.fontSize = le(e.size) ? `${e.size}px` : e.size),
            e.rotate && (a.transform = `rotate(${e.rotate}deg)`),
            a
          );
        });
      return {
        cls: n,
        innerStyle: u,
        onClick: (a) => {
          l("click", a);
        },
      };
    },
  }),
  ia = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function sa(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: D(e.cls),
        style: ge(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: l[0] || (l[0] = (...a) => e.onClick && e.onClick(...a)),
      },
      l[1] || (l[1] = [fe("path", { d: "M5 24h38" }, null, -1)]),
      14,
      ia,
    )
  );
}
var _l = oe(ra, [["render", sa]]);
const ca = Object.assign(_l, {
    install: (e, l) => {
      var t;
      const n = (t = l == null ? void 0 : l.iconPrefix) != null ? t : "";
      e.component(n + _l.name, _l);
    },
  }),
  da = 800,
  va = 150;
Rl.enableBoundaryChecking(!1);
var zl = Z({
  name: "InputNumber",
  props: {
    modelValue: Number,
    defaultValue: Number,
    mode: { type: String, default: "embed" },
    precision: Number,
    step: { type: Number, default: 1 },
    disabled: { type: Boolean, default: !1 },
    error: { type: Boolean, default: !1 },
    max: { type: Number, default: 1 / 0 },
    min: { type: Number, default: -1 / 0 },
    formatter: { type: Function },
    parser: { type: Function },
    placeholder: String,
    hideButton: { type: Boolean, default: !1 },
    size: { type: String },
    allowClear: { type: Boolean, default: !1 },
    modelEvent: { type: String, default: "change" },
    readOnly: { type: Boolean, default: !1 },
    inputAttrs: { type: Object },
  },
  emits: {
    "update:modelValue": (e) => !0,
    change: (e, l) => !0,
    focus: (e) => !0,
    blur: (e) => !0,
    clear: (e) => !0,
    input: (e, l, t) => !0,
    keydown: (e) => !0,
  },
  setup(e, { emit: l, slots: t }) {
    var n;
    const { size: u, disabled: o } = de(e),
      a = J("input-number"),
      r = z(),
      { mergedSize: c, mergedDisabled: d, eventHandlers: v } = je({ size: u, disabled: o }),
      { mergedSize: w } = Ee(c),
      h = s(() => {
        if (le(e.precision)) {
          const y = `${e.step}`.split(".")[1],
            H = (y && y.length) || 0;
          return Math.max(H, e.precision);
        }
      }),
      S = (y) => {
        var H, K;
        if (!le(y)) return "";
        const te = h.value ? y.toFixed(h.value) : String(y);
        return (K = (H = e.formatter) == null ? void 0 : H.call(e, te)) != null ? K : te;
      },
      m = z(S((n = e.modelValue) != null ? n : e.defaultValue)),
      C = s(() => {
        var y, H;
        if (!m.value) return;
        const K = Number((H = (y = e.parser) == null ? void 0 : y.call(e, m.value)) != null ? H : m.value);
        return Number.isNaN(K) ? void 0 : K;
      }),
      k = z(le(C.value) && C.value <= e.min),
      M = z(le(C.value) && C.value >= e.max);
    let _ = 0;
    const $ = () => {
        _ && (window.clearTimeout(_), (_ = 0));
      },
      b = (y) => {
        if (!xe(y))
          return (
            le(e.min) && y < e.min && (y = e.min),
            le(e.max) && y > e.max && (y = e.max),
            le(h.value) ? Rl.round(y, h.value) : y
          );
      },
      V = (y) => {
        let H = !1,
          K = !1;
        (le(y) && (y <= e.min && (H = !0), y >= e.max && (K = !0)),
          M.value !== K && (M.value = K),
          k.value !== H && (k.value = H));
      },
      i = () => {
        const y = b(C.value),
          H = S(y);
        ((y !== C.value || m.value !== H) && (m.value = H), l("update:modelValue", y));
      };
    ae(
      () => [e.max, e.min],
      () => {
        (i(), V(C.value));
      },
    );
    const f = (y, H) => {
        if (d.value || (y === "plus" && M.value) || (y === "minus" && k.value)) return;
        let K;
        (le(C.value) ? (K = b(Rl[y](C.value, e.step))) : (K = e.min === -1 / 0 ? 0 : e.min),
          (m.value = S(K)),
          V(K),
          l("update:modelValue", K),
          l("change", K, H));
      },
      P = (y, H, K = !1) => {
        var te;
        (y.preventDefault(),
          !e.readOnly &&
            ((te = r.value) == null || te.focus(),
            f(H, y),
            K && (_ = window.setTimeout(() => y.target.dispatchEvent(y), _ ? va : da))));
      },
      j = (y, H) => {
        var K, te, he, ue;
        ((y = y.trim().replace(/。/g, ".")),
          (y = (te = (K = e.parser) == null ? void 0 : K.call(e, y)) != null ? te : y),
          (le(Number(y)) || /^(\.|-)$/.test(y)) &&
            ((m.value = (ue = (he = e.formatter) == null ? void 0 : he.call(e, y)) != null ? ue : y),
            V(C.value),
            l("input", C.value, m.value, H),
            e.modelEvent === "input" && (l("update:modelValue", C.value), l("change", C.value, H))));
      },
      x = (y) => {
        l("focus", y);
      },
      B = (y, H) => {
        (H instanceof MouseEvent && !y) || (i(), l("change", C.value, H));
      },
      G = (y) => {
        l("blur", y);
      },
      q = (y) => {
        var H, K;
        ((m.value = ""),
          l("update:modelValue", void 0),
          l("change", void 0, y),
          (K = (H = v.value) == null ? void 0 : H.onChange) == null || K.call(H, y),
          l("clear", y));
      },
      O = yt(
        new Map([
          [
            Te.ARROW_UP,
            (y) => {
              (y.preventDefault(), !e.readOnly && f("plus", y));
            },
          ],
          [
            Te.ARROW_DOWN,
            (y) => {
              (y.preventDefault(), !e.readOnly && f("minus", y));
            },
          ],
        ]),
      ),
      R = (y) => {
        (l("keydown", y), y.defaultPrevented || O(y));
      };
    ae(
      () => e.modelValue,
      (y) => {
        y !== C.value && ((m.value = S(y)), V(y));
      },
    );
    const T = () => {
        var y, H, K;
        return e.readOnly
          ? null
          : g(Ae, null, [
              t.suffix && g("div", { class: `${a}-suffix` }, [(y = t.suffix) == null ? void 0 : y.call(t)]),
              g("div", { class: `${a}-step` }, [
                g(
                  "button",
                  {
                    class: [`${a}-step-button`, { [`${a}-step-button-disabled`]: d.value || M.value }],
                    type: "button",
                    tabindex: "-1",
                    disabled: d.value || M.value,
                    onMousedown: (te) => P(te, "plus", !0),
                    onMouseup: $,
                    onMouseleave: $,
                  },
                  [t.plus ? ((H = t.plus) == null ? void 0 : H.call(t)) : g(Xn, null, null)],
                ),
                g(
                  "button",
                  {
                    class: [`${a}-step-button`, { [`${a}-step-button-disabled`]: d.value || k.value }],
                    type: "button",
                    tabindex: "-1",
                    disabled: d.value || k.value,
                    onMousedown: (te) => P(te, "minus", !0),
                    onMouseup: $,
                    onMouseleave: $,
                  },
                  [t.minus ? ((K = t.minus) == null ? void 0 : K.call(t)) : g(Bt, null, null)],
                ),
              ]),
            ]);
      },
      A = s(() => [a, `${a}-mode-${e.mode}`, `${a}-size-${w.value}`, { [`${a}-readonly`]: e.readOnly }]),
      F = () =>
        g(
          Wl,
          {
            size: w.value,
            tabindex: "-1",
            class: `${a}-step-button`,
            disabled: d.value || k.value,
            onMousedown: (y) => P(y, "minus", !0),
            onMouseup: $,
            onMouseleave: $,
          },
          { icon: () => g(ca, null, null) },
        ),
      X = () =>
        g(
          Wl,
          {
            size: w.value,
            tabindex: "-1",
            class: `${a}-step-button`,
            disabled: d.value || M.value,
            onMousedown: (y) => P(y, "plus", !0),
            onMouseup: $,
            onMouseleave: $,
          },
          { icon: () => g(ua, null, null) },
        );
    return {
      inputRef: r,
      render: () => {
        const y =
          e.mode === "embed"
            ? { prepend: t.prepend, prefix: t.prefix, suffix: e.hideButton ? t.suffix : T, append: t.append }
            : {
                prepend: e.hideButton ? t.prepend : F,
                prefix: t.prefix,
                suffix: t.suffix,
                append: e.hideButton ? t.append : X,
              };
        return g(
          Gt,
          {
            key: `__arco__${e.mode}`,
            ref: r,
            class: A.value,
            type: "text",
            allowClear: e.allowClear,
            size: w.value,
            modelValue: m.value,
            placeholder: e.placeholder,
            disabled: d.value,
            readonly: e.readOnly,
            error: e.error,
            inputAttrs: {
              role: "spinbutton",
              "aria-valuemax": e.max,
              "aria-valuemin": e.min,
              "aria-valuenow": m.value,
              ...e.inputAttrs,
            },
            onInput: j,
            onFocus: x,
            onBlur: G,
            onClear: q,
            onChange: B,
            onKeydown: R,
          },
          y,
        );
      },
    };
  },
  methods: {
    focus() {
      var e;
      (e = this.inputRef) == null || e.focus();
    },
    blur() {
      var e;
      (e = this.inputRef) == null || e.blur();
    },
  },
  render() {
    return this.render();
  },
});
const fa = Object.assign(zl, {
  install: (e, l) => {
    Ce(e, l);
    const t = Se(l);
    e.component(t + zl.name, zl);
  },
});
function pa(e, l) {
  var t, n;
  const u = (t = l.span) != null ? t : 1,
    o = (n = l.offset) != null ? n : 0,
    a = Math.min(o, e);
  return { span: Math.min(a > 0 ? u + o : u, e), offset: a, suffix: "suffix" in l ? l.suffix !== !1 : !1 };
}
function ma({ cols: e, collapsed: l, collapsedRows: t, itemDataList: n }) {
  let u = !1,
    o = [];
  function a(r) {
    return Math.ceil(r / e) > t;
  }
  if (l) {
    let r = 0;
    for (let c = 0; c < n.length; c++) n[c].suffix && ((r += n[c].span), o.push(c));
    if (!a(r)) {
      let c = 0;
      for (; c < n.length; ) {
        const d = n[c];
        if (!d.suffix) {
          if (((r += d.span), a(r))) break;
          o.push(c);
        }
        c++;
      }
    }
    u = n.some((c, d) => !c.suffix && !o.includes(d));
  } else o = n.map((r, c) => c);
  return { overflow: u, displayIndexList: o };
}
const ga = Z({
  name: "Grid",
  props: {
    cols: { type: [Number, Object], default: 24 },
    rowGap: { type: [Number, Object], default: 0 },
    colGap: { type: [Number, Object], default: 0 },
    collapsed: { type: Boolean, default: !1 },
    collapsedRows: { type: Number, default: 1 },
  },
  setup(e) {
    const { cols: l, rowGap: t, colGap: n, collapsedRows: u, collapsed: o } = de(e),
      a = He(l, 24),
      r = He(n, 0),
      c = He(t, 0),
      d = J("grid"),
      v = s(() => [d]),
      w = s(() => [
        { gap: `${c.value}px ${r.value}px`, "grid-template-columns": `repeat(${a.value}, minmax(0px, 1fr))` },
      ]),
      h = ke(new Map()),
      S = s(() => {
        const C = [];
        for (const [k, M] of h.entries()) C[k] = M;
        return C;
      }),
      m = ke({ overflow: !1, displayIndexList: [], cols: a.value, colGap: r.value });
    return (
      tl(() => {
        ((m.cols = a.value), (m.colGap = r.value));
      }),
      tl(() => {
        const C = ma({ cols: a.value, collapsed: o.value, collapsedRows: u.value, itemDataList: S.value });
        ((m.overflow = C.overflow), (m.displayIndexList = C.displayIndexList));
      }),
      ll(st, m),
      ll(ct, {
        collectItemData(C, k) {
          h.set(C, k);
        },
        removeItemData(C) {
          h.delete(C);
        },
      }),
      { classNames: v, style: w }
    );
  },
});
function ha(e, l, t, n, u, o) {
  return (E(), Y("div", { class: D(e.classNames), style: ge(e.style) }, [ee(e.$slots, "default")], 6));
}
var Il = oe(ga, [["render", ha]]);
const ba = Z({
  name: "GridItem",
  props: {
    span: { type: [Number, Object], default: 1 },
    offset: { type: [Number, Object], default: 0 },
    suffix: { type: Boolean, default: !1 },
  },
  setup(e) {
    const l = J("grid-item"),
      t = z(),
      { computedIndex: n } = zn({ itemRef: t, selector: `.${l}` }),
      u = Me(st, { overflow: !1, displayIndexList: [], cols: 24, colGap: 0 }),
      o = Me(ct),
      a = s(() => {
        var k;
        return (k = u == null ? void 0 : u.displayIndexList) == null ? void 0 : k.includes(n.value);
      }),
      { span: r, offset: c } = de(e),
      d = He(r, 1),
      v = He(c, 0),
      w = s(() => pa(u.cols, { ...e, span: d.value, offset: v.value })),
      h = s(() => [l]),
      S = s(() => {
        const { offset: k, span: M } = w.value,
          { colGap: _ } = u;
        return k > 0 ? { "margin-left": `calc((${`(100% - ${_ * (M - 1)}px) / ${M}`} * ${k}) + ${_ * k}px)` } : {};
      }),
      m = s(() => {
        const { suffix: k, span: M } = w.value,
          { cols: _ } = u;
        return k ? `${_ - M + 1}` : `span ${M}`;
      }),
      C = s(() => {
        const { span: k } = w.value;
        return t.value
          ? [{ "grid-column": `${m.value} / span ${k}` }, S.value, !a.value || k === 0 ? { display: "none" } : {}]
          : [];
      });
    return (
      tl(() => {
        n.value !== -1 && (o == null || o.collectItemData(n.value, w.value));
      }),
      dt(() => {
        n.value !== -1 && (o == null || o.removeItemData(n.value));
      }),
      { classNames: h, style: C, domRef: t, overflow: s(() => u.overflow) }
    );
  },
});
function ya(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      "div",
      { ref: "domRef", class: D(e.classNames), style: ge(e.style) },
      [ee(e.$slots, "default", { overflow: e.overflow })],
      6,
    )
  );
}
var Bl = oe(ba, [["render", ya]]);
const Ze = Object.assign(Il, {
    Row: fl,
    Col: vl,
    Item: Bl,
    install: (e, l) => {
      Ce(e, l);
      const t = Se(l);
      (e.component(t + fl.name, fl),
        e.component(t + vl.name, vl),
        e.component(t + Il.name, Il),
        e.component(t + Bl.name, Bl));
    },
  }),
  $a = Z({
    name: "Pager",
    props: {
      pageNumber: { type: Number },
      current: { type: Number },
      disabled: { type: Boolean, default: !1 },
      style: { type: Object },
      activeStyle: { type: Object },
    },
    emits: ["click"],
    setup(e, { emit: l }) {
      const t = J("pagination-item"),
        n = s(() => e.current === e.pageNumber),
        u = (r) => {
          e.disabled || l("click", e.pageNumber, r);
        },
        o = s(() => [t, { [`${t}-active`]: n.value }]),
        a = s(() => (n.value ? e.activeStyle : e.style));
      return { prefixCls: t, cls: o, mergedStyle: a, handleClick: u };
    },
  });
function Ca(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      "li",
      {
        class: D(e.cls),
        style: ge(e.mergedStyle),
        onClick: l[0] || (l[0] = (...a) => e.handleClick && e.handleClick(...a)),
      },
      [ee(e.$slots, "default", { page: e.pageNumber }, () => [Re(Ie(e.pageNumber), 1)])],
      6,
    )
  );
}
var Sa = oe($a, [["render", Ca]]);
const Pt = (e, { min: l, max: t }) => (e < l ? l : e > t ? t : e),
  ka = Z({
    name: "StepPager",
    components: { IconLeft: Zt, IconRight: Ut },
    props: {
      pages: { type: Number, required: !0 },
      current: { type: Number, required: !0 },
      type: { type: String, required: !0 },
      disabled: { type: Boolean, default: !1 },
      simple: { type: Boolean, default: !1 },
    },
    emits: ["click"],
    setup(e, { emit: l }) {
      const t = J("pagination-item"),
        n = e.type === "next",
        u = s(() => (e.disabled ? e.disabled : !e.pages || (n && e.current === e.pages) ? !0 : !n && e.current <= 1)),
        o = s(() => Pt(e.current + (n ? 1 : -1), { min: 1, max: e.pages })),
        a = (c) => {
          u.value || l("click", o.value);
        },
        r = s(() => [t, `${t}-${e.type}`, { [`${t}-disabled`]: u.value }]);
      return { prefixCls: t, cls: r, isNext: n, handleClick: a };
    },
  });
function wa(e, l, t, n, u, o) {
  const a = me("icon-right"),
    r = me("icon-left");
  return (
    E(),
    ce(
      Ne(e.simple ? "span" : "li"),
      { class: D(e.cls), onClick: e.handleClick },
      {
        default: be(() => [
          ee(e.$slots, "default", { type: e.isNext ? "next" : "previous" }, () => [
            e.isNext ? (E(), ce(a, { key: 0 })) : (E(), ce(r, { key: 1 })),
          ]),
        ]),
        _: 3,
      },
      8,
      ["class", "onClick"],
    )
  );
}
var Ql = oe(ka, [["render", wa]]);
const _a = Z({
  name: "EllipsisPager",
  components: { IconMore: Vn },
  props: {
    current: { type: Number, required: !0 },
    step: { type: Number, default: 5 },
    pages: { type: Number, required: !0 },
  },
  emits: ["click"],
  setup(e, { emit: l }) {
    const t = J("pagination-item"),
      n = s(() => Pt(e.current + e.step, { min: 1, max: e.pages })),
      u = (a) => {
        l("click", n.value);
      },
      o = s(() => [t, `${t}-ellipsis`]);
    return { prefixCls: t, cls: o, handleClick: u };
  },
});
function za(e, l, t, n, u, o) {
  const a = me("icon-more");
  return (
    E(),
    Y(
      "li",
      { class: D(e.cls), onClick: l[0] || (l[0] = (...r) => e.handleClick && e.handleClick(...r)) },
      [ee(e.$slots, "default", {}, () => [g(a)])],
      2,
    )
  );
}
var Ia = oe(_a, [["render", za]]);
const Ba = Z({
  name: "PageJumper",
  components: { InputNumber: fa },
  props: {
    current: { type: Number, required: !0 },
    simple: { type: Boolean, default: !1 },
    disabled: { type: Boolean, default: !1 },
    pages: { type: Number, required: !0 },
    size: { type: String },
    onChange: { type: Function },
  },
  emits: ["change"],
  setup(e, { emit: l }) {
    const t = J("pagination-jumper"),
      { t: n } = nl(),
      u = z(e.simple ? e.current : void 0),
      o = (c) => {
        const d = parseInt(c.toString(), 10);
        return Number.isNaN(d) ? void 0 : String(d);
      },
      a = (c) => {
        (l("change", u.value),
          ye(() => {
            e.simple || (u.value = void 0);
          }));
      };
    ae(
      () => e.current,
      (c) => {
        e.simple && c !== u.value && (u.value = c);
      },
    );
    const r = s(() => [t, { [`${t}-simple`]: e.simple }]);
    return { prefixCls: t, cls: r, t: n, inputValue: u, handleChange: a, handleFormatter: o };
  },
});
function Oa(e, l, t, n, u, o) {
  const a = me("input-number");
  return (
    E(),
    Y(
      "span",
      { class: D(e.cls) },
      [
        e.simple
          ? re("v-if", !0)
          : (E(),
            Y(
              "span",
              { key: 0, class: D([`${e.prefixCls}-prepend`, `${e.prefixCls}-text-goto`]) },
              [ee(e.$slots, "jumper-prepend", {}, () => [Re(Ie(e.t("pagination.goto")), 1)])],
              2,
            )),
        g(
          a,
          {
            modelValue: e.inputValue,
            "onUpdate:modelValue": l[0] || (l[0] = (r) => (e.inputValue = r)),
            class: D(`${e.prefixCls}-input`),
            min: 1,
            max: e.pages,
            size: e.size,
            disabled: e.disabled,
            "hide-button": "",
            formatter: e.handleFormatter,
            onChange: e.handleChange,
          },
          null,
          8,
          ["modelValue", "class", "max", "size", "disabled", "formatter", "onChange"],
        ),
        e.$slots["jumper-append"]
          ? (E(), Y("span", { key: 1, class: D(`${e.prefixCls}-append`) }, [ee(e.$slots, "jumper-append")], 2))
          : re("v-if", !0),
        e.simple
          ? (E(),
            Y(
              Ae,
              { key: 2 },
              [
                fe("span", { class: D(`${e.prefixCls}-separator`) }, "/", 2),
                fe("span", { class: D(`${e.prefixCls}-total-page`) }, Ie(e.pages), 3),
              ],
              64,
            ))
          : re("v-if", !0),
      ],
      2,
    )
  );
}
var et = oe(Ba, [["render", Oa]]);
const Va = Z({
  name: "PageOptions",
  components: { ArcoSelect: Un },
  props: {
    sizeOptions: { type: Array, required: !0 },
    pageSize: Number,
    disabled: Boolean,
    size: { type: String },
    onChange: { type: Function },
    selectProps: { type: Object },
  },
  emits: ["change"],
  setup(e, { emit: l }) {
    const t = J("pagination-options"),
      { t: n } = nl(),
      u = s(() => e.sizeOptions.map((a) => ({ value: a, label: `${a} ${n("pagination.countPerPage")}` })));
    return {
      prefixCls: t,
      options: u,
      handleChange: (a) => {
        l("change", a);
      },
    };
  },
});
function Pa(e, l, t, n, u, o) {
  const a = me("arco-select");
  return (
    E(),
    Y(
      "span",
      { class: D(e.prefixCls) },
      [
        g(
          a,
          ne({ "model-value": e.pageSize, options: e.options, size: e.size, disabled: e.disabled }, e.selectProps, {
            onChange: e.handleChange,
          }),
          null,
          16,
          ["model-value", "options", "size", "disabled", "onChange"],
        ),
      ],
      2,
    )
  );
}
var xa = oe(Va, [["render", Pa]]),
  Ol = Z({
    name: "Pagination",
    props: {
      total: { type: Number, required: !0 },
      current: Number,
      defaultCurrent: { type: Number, default: 1 },
      pageSize: Number,
      defaultPageSize: { type: Number, default: 10 },
      disabled: { type: Boolean, default: !1 },
      hideOnSinglePage: { type: Boolean, default: !1 },
      simple: { type: Boolean, default: !1 },
      showTotal: { type: Boolean, default: !1 },
      showMore: { type: Boolean, default: !1 },
      showJumper: { type: Boolean, default: !1 },
      showPageSize: { type: Boolean, default: !1 },
      pageSizeOptions: { type: Array, default: () => [10, 20, 30, 40, 50] },
      pageSizeProps: { type: Object },
      size: { type: String },
      pageItemStyle: { type: Object },
      activePageItemStyle: { type: Object },
      baseSize: { type: Number, default: 6 },
      bufferSize: { type: Number, default: 2 },
      autoAdjust: { type: Boolean, default: !0 },
    },
    emits: { "update:current": (e) => !0, "update:pageSize": (e) => !0, change: (e) => !0, pageSizeChange: (e) => !0 },
    setup(e, { emit: l, slots: t }) {
      const n = J("pagination"),
        { t: u } = nl(),
        { disabled: o, pageItemStyle: a, activePageItemStyle: r, size: c } = de(e),
        { mergedSize: d } = Ee(c),
        v = z(e.defaultCurrent),
        w = z(e.defaultPageSize),
        h = s(() => {
          var i;
          return (i = e.current) != null ? i : v.value;
        }),
        S = s(() => {
          var i;
          return (i = e.pageSize) != null ? i : w.value;
        }),
        m = s(() => Math.ceil(e.total / S.value)),
        C = (i) => {
          i !== h.value && le(i) && !e.disabled && ((v.value = i), l("update:current", i), l("change", i));
        },
        k = (i) => {
          ((w.value = i), l("update:pageSize", i), l("pageSizeChange", i));
        },
        M = ke({ current: h, pages: m, disabled: o, style: a, activeStyle: r, onClick: C }),
        _ = (i, f = {}) =>
          i === "more"
            ? g(Ia, ne(f, M), { default: t["page-item-ellipsis"] })
            : i === "previous"
              ? g(Ql, ne({ type: "previous" }, f, M), { default: t["page-item-step"] })
              : i === "next"
                ? g(Ql, ne({ type: "next" }, f, M), { default: t["page-item-step"] })
                : g(Sa, ne(f, M), { default: t["page-item"] }),
        $ = s(() => {
          const i = [];
          if (m.value < e.baseSize + e.bufferSize * 2)
            for (let f = 1; f <= m.value; f++) i.push(_("page", { key: f, pageNumber: f }));
          else {
            let f = 1,
              P = m.value,
              j = !1,
              x = !1;
            (h.value > 2 + e.bufferSize &&
              ((j = !0), (f = Math.min(h.value - e.bufferSize, m.value - 2 * e.bufferSize))),
              h.value < m.value - (e.bufferSize + 1) &&
                ((x = !0), (P = Math.max(h.value + e.bufferSize, 2 * e.bufferSize + 1))),
              j &&
                (i.push(_("page", { key: 1, pageNumber: 1 })),
                i.push(_("more", { key: "left-ellipsis-pager", step: -(e.bufferSize * 2 + 1) }))));
            for (let B = f; B <= P; B++) i.push(_("page", { key: B, pageNumber: B }));
            x &&
              (i.push(_("more", { key: "right-ellipsis-pager", step: e.bufferSize * 2 + 1 })),
              i.push(_("page", { key: m.value, pageNumber: m.value })));
          }
          return i;
        }),
        b = () =>
          e.simple
            ? g("span", { class: `${n}-simple` }, [
                _("previous", { simple: !0 }),
                g(
                  et,
                  { disabled: e.disabled, current: h.value, size: d.value, pages: m.value, simple: !0, onChange: C },
                  null,
                ),
                _("next", { simple: !0 }),
              ])
            : g("ul", { class: `${n}-list` }, [
                _("previous", { simple: !0 }),
                $.value,
                e.showMore && _("more", { key: "more", step: e.bufferSize * 2 + 1 }),
                _("next", { simple: !0 }),
              ]);
      (ae(S, (i, f) => {
        if (e.autoAdjust && i !== f && h.value > 1) {
          const P = f * (h.value - 1) + 1,
            j = Math.ceil(P / i);
          j !== h.value && ((v.value = j), l("update:current", j), l("change", j));
        }
      }),
        ae(m, (i, f) => {
          if (e.autoAdjust && i !== f && h.value > 1 && h.value > i) {
            const P = Math.max(i, 1);
            ((v.value = P), l("update:current", P), l("change", P));
          }
        }));
      const V = s(() => [n, `${n}-size-${d.value}`, { [`${n}-simple`]: e.simple, [`${n}-disabled`]: e.disabled }]);
      return () => {
        var i, f;
        return e.hideOnSinglePage && m.value <= 1
          ? null
          : g("div", { class: V.value }, [
              e.showTotal &&
                g("span", { class: `${n}-total` }, [
                  (f = (i = t.total) == null ? void 0 : i.call(t, { total: e.total })) != null
                    ? f
                    : u("pagination.total", e.total),
                ]),
              b(),
              e.showPageSize &&
                g(
                  xa,
                  {
                    disabled: e.disabled,
                    sizeOptions: e.pageSizeOptions,
                    pageSize: S.value,
                    size: d.value,
                    onChange: k,
                    selectProps: e.pageSizeProps,
                  },
                  null,
                ),
              !e.simple &&
                e.showJumper &&
                g(
                  et,
                  { disabled: e.disabled, current: h.value, pages: m.value, size: d.value, onChange: C },
                  { "jumper-prepend": t["jumper-prepend"], "jumper-append": t["jumper-append"] },
                ),
            ]);
      };
    },
  });
const Na = Object.assign(Ol, {
    install: (e, l) => {
      Ce(e, l);
      const t = Se(l);
      e.component(t + Ol.name, Ol);
    },
  }),
  Ma = (e, { emit: l }) => {
    var t, n;
    const u = z(se(e.paginationProps) && (t = e.paginationProps.defaultCurrent) != null ? t : 1),
      o = z(se(e.paginationProps) && (n = e.paginationProps.defaultPageSize) != null ? n : 10),
      a = s(() => {
        var v;
        return se(e.paginationProps) && (v = e.paginationProps.current) != null ? v : u.value;
      }),
      r = s(() => {
        var v;
        return se(e.paginationProps) && (v = e.paginationProps.pageSize) != null ? v : o.value;
      });
    return {
      current: a,
      pageSize: r,
      handlePageChange: (v) => {
        ((u.value = v), l("pageChange", v));
      },
      handlePageSizeChange: (v) => {
        ((o.value = v), l("pageSizeChange", v));
      },
    };
  };
function lt(e) {
  return typeof e == "function" || (Object.prototype.toString.call(e) === "[object Object]" && !Ge(e));
}
var Vl = Z({
    name: "List",
    props: {
      data: { type: Array },
      size: { type: String, default: "medium" },
      bordered: { type: Boolean, default: !0 },
      split: { type: Boolean, default: !0 },
      loading: { type: Boolean, default: !1 },
      hoverable: { type: Boolean, default: !1 },
      paginationProps: { type: Object },
      gridProps: { type: Object },
      maxHeight: { type: [String, Number], default: 0 },
      bottomOffset: { type: Number, default: 0 },
      virtualListProps: { type: Object },
      scrollbar: { type: [Object, Boolean], default: !0 },
    },
    emits: { scroll: () => !0, reachBottom: () => !0, pageChange: (e) => !0, pageSizeChange: (e) => !0 },
    setup(e, { emit: l, slots: t }) {
      const { scrollbar: n } = de(e),
        u = J("list"),
        o = Me(jl, void 0),
        { componentRef: a, elementRef: r } = St("containerRef"),
        c = s(() => e.virtualListProps),
        { displayScrollbar: d, scrollbarProps: v } = kt(n);
      let w = 0;
      const h = (O) => {
        const { scrollTop: R, scrollHeight: T, offsetHeight: A } = O.target,
          F = Math.floor(T - (R + A));
        (R > w && F <= e.bottomOffset && l("reachBottom"), l("scroll"), (w = R));
      };
      we(() => {
        if (r.value) {
          const { scrollTop: O, scrollHeight: R, offsetHeight: T } = r.value;
          R <= O + T && l("reachBottom");
        }
      });
      const { current: S, pageSize: m, handlePageChange: C, handlePageSizeChange: k } = Ma(e, { emit: l }),
        M = (O) => {
          if (!e.paginationProps) return O;
          if (e.paginationProps && O.length > m.value) {
            const R = (S.value - 1) * m.value;
            return O.slice(R, R + m.value);
          }
          return O;
        },
        _ = (O) => {
          let R;
          if (!e.gridProps) return null;
          const T = M(O);
          if (e.gridProps.span) {
            const A = [],
              F = 24 / e.gridProps.span;
            for (let X = 0; X < T.length; X += F) {
              let ve;
              const y = X + F,
                H = Math.floor(X / F);
              A.push(
                g(
                  Ze.Row,
                  { key: H, class: `${u}-row`, gutter: e.gridProps.gutter },
                  lt(
                    (ve = T.slice(X, y).map((K, te) => {
                      var he;
                      return g(
                        Ze.Col,
                        { key: `${H}-${te}`, class: `${u}-col`, span: (he = e.gridProps) == null ? void 0 : he.span },
                        {
                          default: () => {
                            var ue;
                            return [Ge(K) ? K : (ue = t.item) == null ? void 0 : ue.call(t, { item: K, index: te })];
                          },
                        },
                      );
                    })),
                  )
                    ? ve
                    : { default: () => [ve] },
                ),
              );
            }
            return A;
          }
          return g(
            Ze.Row,
            { class: `${u}-row`, gutter: e.gridProps.gutter },
            lt(
              (R = T.map((A, F) =>
                g(Ze.Col, ne({ key: F, class: `${u}-col` }, Qe(e.gridProps, ["gutter"])), {
                  default: () => {
                    var X;
                    return [Ge(A) ? A : (X = t.item) == null ? void 0 : X.call(t, { item: A, index: F })];
                  },
                }),
              )),
            )
              ? R
              : { default: () => [R] },
          );
        },
        $ = (O) =>
          M(O).map((T, A) => {
            var F;
            return Ge(T) ? T : (F = t.item) == null ? void 0 : F.call(t, { item: T, index: A });
          }),
        b = () => {
          const O = t.default ? Ft(t.default()) : e.data;
          return O && O.length > 0 ? (e.gridProps ? _(O) : $(O)) : G();
        },
        V = () => {
          if (!e.paginationProps) return null;
          const O = Qe(e.paginationProps, ["current", "pageSize", "defaultCurrent", "defaultPageSize"]);
          return g(
            Na,
            ne({ class: `${u}-pagination` }, O, {
              current: S.value,
              pageSize: m.value,
              onChange: C,
              onPageSizeChange: k,
            }),
            null,
          );
        },
        i = s(() => [
          u,
          `${u}-${e.size}`,
          { [`${u}-bordered`]: e.bordered, [`${u}-split`]: e.split, [`${u}-hover`]: e.hoverable },
        ]),
        f = s(() => {
          if (e.maxHeight) return { maxHeight: le(e.maxHeight) ? `${e.maxHeight}px` : e.maxHeight, overflowY: "auto" };
        }),
        P = s(() => [`${u}-content`, { [`${u}-virtual`]: c.value }]),
        j = z(),
        x = () => {
          var O;
          const R = M((O = e.data) != null ? O : []);
          return R.length
            ? g(It, ne({ ref: j, class: P.value, data: R }, e.virtualListProps, { onScroll: h }), {
                item: ({ item: T, index: A }) => {
                  var F;
                  return (F = t.item) == null ? void 0 : F.call(t, { item: T, index: A });
                },
              })
            : G();
        },
        B = () =>
          t["scroll-loading"]
            ? g("div", { class: [`${u}-item`, `${u}-scroll-loading`] }, [t["scroll-loading"]()])
            : null,
        G = () => {
          var O, R, T, A, F;
          return t["scroll-loading"]
            ? null
            : (F =
                  (A = (O = t.empty) == null ? void 0 : O.call(t)) != null
                    ? A
                    : (T = o == null ? void 0 : (R = o.slots).empty) == null
                      ? void 0
                      : T.call(R, { component: "list" })) != null
              ? F
              : g($t, null, null);
        };
      return {
        virtualListRef: j,
        render: () => {
          const O = d.value ? Ct : "div";
          return g("div", { class: `${u}-wrapper` }, [
            g(
              rt,
              { class: `${u}-spin`, loading: e.loading },
              {
                default: () => [
                  g(O, ne({ ref: a, class: i.value, style: f.value }, v.value, { onScroll: h }), {
                    default: () => [
                      g("div", { class: `${u}-content-wrapper` }, [
                        t.header && g("div", { class: `${u}-header` }, [t.header()]),
                        c.value && !e.gridProps
                          ? g(Ae, null, [x(), B()])
                          : g("div", { role: "list", class: P.value }, [b(), B()]),
                        t.footer && g("div", { class: `${u}-footer` }, [t.footer()]),
                      ]),
                    ],
                  }),
                  V(),
                ],
              },
            ),
          ]);
        },
      };
    },
    methods: {
      scrollIntoView(e) {
        this.virtualListRef && this.virtualListRef.scrollTo(e);
      },
    },
    render() {
      return this.render();
    },
  }),
  Pl = Z({
    name: "ListItem",
    props: { actionLayout: { type: String, default: "horizontal" } },
    setup(e, { slots: l }) {
      const t = J("list-item"),
        n = () => {
          var u;
          const o = (u = l.actions) == null ? void 0 : u.call(l);
          return !o || !o.length
            ? null
            : g("ul", { class: `${t}-action` }, [o.map((a, r) => g("li", { key: `${t}-action-${r}` }, [a]))]);
        };
      return () => {
        var u, o;
        return g("div", { role: "listitem", class: t }, [
          g("div", { class: `${t}-main` }, [
            (u = l.meta) == null ? void 0 : u.call(l),
            g("div", { class: `${t}-content` }, [(o = l.default) == null ? void 0 : o.call(l)]),
            e.actionLayout === "vertical" && n(),
          ]),
          e.actionLayout === "horizontal" && n(),
          l.extra && g("div", { class: `${t}-extra` }, [l.extra()]),
        ]);
      };
    },
  });
const Ra = Z({
  name: "ListItemMeta",
  props: { title: String, description: String },
  setup(e, { slots: l }) {
    const t = J("list-item-meta"),
      n = !!(e.title || e.description || l.title || l.description);
    return { prefixCls: t, hasContent: n };
  },
});
function ja(e, l, t, n, u, o) {
  return (
    E(),
    Y(
      "div",
      { class: D(e.prefixCls) },
      [
        e.$slots.avatar
          ? (E(), Y("div", { key: 0, class: D(`${e.prefixCls}-avatar`) }, [ee(e.$slots, "avatar")], 2))
          : re("v-if", !0),
        e.hasContent
          ? (E(),
            Y(
              "div",
              { key: 1, class: D(`${e.prefixCls}-content`) },
              [
                e.$slots.title || e.title
                  ? (E(),
                    Y(
                      "div",
                      { key: 0, class: D(`${e.prefixCls}-title`) },
                      [ee(e.$slots, "title", {}, () => [Re(Ie(e.title), 1)])],
                      2,
                    ))
                  : re("v-if", !0),
                e.$slots.description || e.description
                  ? (E(),
                    Y(
                      "div",
                      { key: 1, class: D(`${e.prefixCls}-description`) },
                      [ee(e.$slots, "description", {}, () => [Re(Ie(e.description), 1)])],
                      2,
                    ))
                  : re("v-if", !0),
              ],
              2,
            ))
          : re("v-if", !0),
      ],
      2,
    )
  );
}
var xl = oe(Ra, [["render", ja]]);
const Fa = Object.assign(Vl, {
  Item: Object.assign(Pl, { Meta: xl }),
  install: (e, l) => {
    Ce(e, l);
    const t = Se(l);
    (e.component(t + Vl.name, Vl), e.component(t + Pl.name, Pl), e.component(t + xl.name, xl));
  },
});
export { $t as E, ua as I, Fa as L, An as T, Pl as a, Rl as i };
