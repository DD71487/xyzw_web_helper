import { Q as f, i as o, f as g } from "./index-7YDlkBnY.js";
const c = (l, t) => {
    if (!l || !t) return;
    t = t.replace(/\[(\w+)\]/g, ".$1");
    const r = t.split(".");
    if (r.length === 0) return;
    let n = l;
    for (let e = 0; e < r.length; e++) {
      if ((!f(n) && !o(n)) || !r[e]) return;
      if (e !== r.length - 1) n = n[r[e]];
      else return n[r[e]];
    }
  },
  a = (l, t, r, { addPath: n } = {}) => {
    if (!l || !t) return;
    t = t.replace(/\[(\w+)\]/g, ".$1");
    const e = t.split(".");
    if (e.length === 0) return;
    let s = l;
    for (let i = 0; i < e.length; i++) {
      if ((!f(s) && !o(s)) || !e[i]) return;
      i !== e.length - 1 ? (n && g(s[e[i]]) && (s[e[i]] = {}), (s = s[e[i]])) : (s[e[i]] = r);
    }
  };
export { c as g, a as s };
