import {
  k as I,
  x as y,
  s as h,
  r as k,
  z as F,
  e as c,
  w as l,
  u as e,
  aU as V,
  d as z,
  h as v,
  a as i,
  b as o,
  A as B,
  Q as g,
  i as b,
  N as T,
  aV as t,
  au as n,
  a6 as R,
  a7 as A,
} from "./index-UoU16364.js";
import { C as q } from "./CloudUpload-DBucip-_.js";
import { A as M } from "./AlertCircleOutline-BnovXsGQ.js";
import { _ as S } from "./_plugin-vue_export-helper-DlAUqK2U.js";
const $ = { class: "form-actions" },
  O = { class: "optional-fields" },
  Q = I({
    __name: "manual",
    emits: ["cancel", "ok"],
    setup(j, { emit: _ }) {
      const d = _,
        w = () => {
          d("cancel");
        },
        p = y(),
        f = h(),
        U = k(),
        u = k(!1),
        a = F({ name: "", base64Token: "", server: "", wsUrl: "" }),
        C = {
          name: [
            { required: !0, message: "请输入角色名称", trigger: "blur" },
            { min: 1, max: 50, message: "名称长度应在1到50个字符之间", trigger: "blur" },
          ],
          base64Token: [
            { required: !0, message: "请输入Token字符串", trigger: "blur" },
            { min: 20, message: "Token字符串长度应至少20个字符", trigger: "blur" },
          ],
        },
        N = () => {
          u.value = !0;
          try {
            (p.addToken({ name: a.name, token: a.base64Token, server: a.server, wsUrl: a.wsUrl }),
              f.success("Token添加成功"),
              (a.name = ""),
              (a.base64Token = ""),
              (a.server = ""),
              (a.wsUrl = ""),
              d("ok"));
          } catch (m) {
            f.error(`添加Token失败: ${m.message || m}`);
          } finally {
            u.value = !1;
          }
        };
      return (m, s) => {
        const x = z("n-popover");
        return (
          v(),
          c(
            e(V),
            {
              ref_key: "importFormRef",
              ref: U,
              model: a,
              rules: C,
              "label-placement": "top",
              size: "large",
              "show-label": !0,
            },
            {
              default: l(() => [
                i("div", $, [
                  o(
                    e(g),
                    { type: "primary", size: "large", block: "", loading: u.value, onClick: N },
                    {
                      icon: l(() => [o(e(T), null, { default: l(() => [o(e(q))]), _: 1 })]),
                      default: l(() => [s[4] || (s[4] = b(" 添加Token ", -1))]),
                      _: 1,
                    },
                    8,
                    ["loading"],
                  ),
                  e(p).hasTokens
                    ? (v(),
                      c(
                        e(g),
                        { key: 0, size: "large", block: "", onClick: w },
                        { default: l(() => [...(s[5] || (s[5] = [b(" 取消 ", -1)]))]), _: 1 },
                      ))
                    : B("", !0),
                ]),
                o(
                  e(t),
                  { label: "游戏角色名称", path: "name", "show-label": !0 },
                  {
                    default: l(() => [
                      o(
                        e(n),
                        {
                          value: a.name,
                          "onUpdate:value": s[0] || (s[0] = (r) => (a.name = r)),
                          placeholder: "例如：主号战士",
                          clearable: "",
                        },
                        null,
                        8,
                        ["value"],
                      ),
                    ]),
                    _: 1,
                  },
                ),
                o(
                  e(t),
                  { label: "Token字符串", path: "base64Token", "show-label": !0 },
                  {
                    default: l(() => [
                      o(
                        e(n),
                        {
                          value: a.base64Token,
                          "onUpdate:value": s[1] || (s[1] = (r) => (a.base64Token = r)),
                          type: "textarea",
                          rows: 3,
                          placeholder: "粘贴Token字符串...",
                          clearable: "",
                        },
                        {
                          suffix: l(() => [
                            o(
                              x,
                              { placement: "right", trigger: "hover" },
                              {
                                trigger: l(() => [o(e(T), { depth: 1 }, { default: l(() => [o(e(M))]), _: 1 })]),
                                default: l(() => [
                                  s[6] ||
                                    (s[6] = i(
                                      "div",
                                      { class: "large-text" },
                                      ' 输入格式为：{"roleToken":"****","sessId":***,"connId":***,"isRestore":***} ',
                                      -1,
                                    )),
                                ]),
                                _: 1,
                              },
                            ),
                          ]),
                          _: 1,
                        },
                        8,
                        ["value"],
                      ),
                    ]),
                    _: 1,
                  },
                ),
                o(e(R), null, {
                  default: l(() => [
                    o(
                      e(A),
                      { title: "角色详情 (可选)", name: "optional" },
                      {
                        default: l(() => [
                          i("div", O, [
                            o(
                              e(t),
                              { label: "服务器" },
                              {
                                default: l(() => [
                                  o(
                                    e(n),
                                    {
                                      value: a.server,
                                      "onUpdate:value": s[2] || (s[2] = (r) => (a.server = r)),
                                      placeholder: "服务器名称",
                                    },
                                    null,
                                    8,
                                    ["value"],
                                  ),
                                ]),
                                _: 1,
                              },
                            ),
                            o(
                              e(t),
                              { label: "自定义连接地址" },
                              {
                                default: l(() => [
                                  o(
                                    e(n),
                                    {
                                      value: a.wsUrl,
                                      "onUpdate:value": s[3] || (s[3] = (r) => (a.wsUrl = r)),
                                      placeholder: "留空使用默认连接",
                                    },
                                    null,
                                    8,
                                    ["value"],
                                  ),
                                ]),
                                _: 1,
                              },
                            ),
                          ]),
                        ]),
                        _: 1,
                      },
                    ),
                  ]),
                  _: 1,
                }),
              ]),
              _: 1,
            },
            8,
            ["model"],
          )
        );
      };
    },
  }),
  J = S(Q, [["__scopeId", "data-v-2a37aa51"]]);
export { J as default };
