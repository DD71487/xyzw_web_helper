import {
  s as L,
  v as J,
  r as y,
  z as K,
  o as Q,
  c as b,
  a,
  b as l,
  w as o,
  d as i,
  u as m,
  F as W,
  g as X,
  f as Y,
  h as p,
  i as _,
  E as Z,
  t as u,
  e as ee,
  A as se,
} from "./index-UoU16364.js";
import { u as te } from "./gameRoles-DtpzXQTv.js";
import { _ as le } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { A as ae } from "./Add-CN1YrD24.js";
import { E as oe } from "./EllipsisHorizontal-CLDjmchS.js";
import { P as ne } from "./PersonCircle-CkW3zhXQ.js";
import "./localTokenManager-BQJEcmfy.js";
const ie = { class: "game-roles-page" },
  re = { class: "container" },
  de = { class: "page-header" },
  ue = { class: "header-content" },
  ce = { class: "header-actions" },
  ve = { key: 0, class: "roles-grid" },
  me = ["onClick"],
  pe = { class: "card-header" },
  _e = { class: "role-avatar" },
  fe = ["src", "alt"],
  ge = { class: "role-actions" },
  be = { class: "card-body" },
  ye = { class: "role-name" },
  he = { class: "role-info" },
  ke = { class: "role-tags" },
  Re = { class: "card-footer" },
  we = { class: "role-stats" },
  xe = { class: "stat-item" },
  Ce = { class: "stat-value" },
  ze = { class: "stat-item" },
  Fe = { class: "stat-value" },
  Se = { key: 1, class: "empty-state" },
  Ae = { class: "modal-actions" },
  Ge = {
    __name: "GameRoles",
    setup(Ue) {
      Y();
      const c = L(),
        A = J(),
        r = te(),
        d = y(!1),
        h = y(!1),
        f = y(null),
        k = y(null),
        n = K({ name: "", server: "", profession: "", level: 1, account: "", note: "" }),
        G = {
          name: [{ required: !0, message: "请输入角色名称", trigger: "blur" }],
          server: [{ required: !0, message: "请选择服务器", trigger: "change" }],
          profession: [{ required: !0, message: "请选择职业", trigger: "change" }],
          level: [{ required: !0, type: "number", message: "请输入角色等级", trigger: "blur" }],
        },
        U = [
          { label: "风云服", value: "风云服" },
          { label: "神话服", value: "神话服" },
          { label: "传奇服", value: "传奇服" },
          { label: "梦幻服", value: "梦幻服" },
          { label: "英雄服", value: "英雄服" },
        ],
        $ = [
          { label: "战士", value: "战士" },
          { label: "法师", value: "法师" },
          { label: "道士", value: "道士" },
          { label: "刺客", value: "刺客" },
          { label: "弓手", value: "弓手" },
          { label: "牧师", value: "牧师" },
        ],
        E = [
          { label: "编辑", key: "edit" },
          { label: "设为主角色", key: "set-primary" },
          { label: "查看详情", key: "view-details" },
          { type: "divider" },
          { label: "删除", key: "delete" },
        ],
        x = (t) => {
          (r.selectRole(t), c.success(`已切换到角色：${t.name}`));
        },
        N = async (t, e) => {
          switch (t) {
            case "edit":
              O(e);
              break;
            case "set-primary":
              x(e);
              break;
            case "view-details":
              V();
              break;
            case "delete":
              q(e);
              break;
          }
        },
        O = (t) => {
          ((f.value = t), Object.assign(n, t), (d.value = !0));
        },
        V = (t) => {
          c.info("角色详情功能开发中...");
        },
        q = (t) => {
          A.warning({
            title: "删除角色",
            content: `确定要删除角色 "${t.name}" 吗？此操作无法恢复。`,
            positiveText: "确定删除",
            negativeText: "取消",
            onPositiveClick: async () => {
              const e = await r.deleteGameRole(t.id);
              e.success ? c.success(e.message) : c.error(e.message);
            },
          });
        },
        B = async () => {
          if (k.value)
            try {
              (await k.value.validate(), (h.value = !0));
              let t;
              (f.value ? (t = await r.updateGameRole(f.value.id, n)) : (t = await r.addGameRole(n)),
                t.success ? (c.success(t.message), (d.value = !1), M()) : c.error(t.message));
            } catch {
            } finally {
              h.value = !1;
            }
        },
        M = () => {
          (Object.keys(n).forEach((t) => {
            n[t] = t === "level" ? 1 : "";
          }),
            (f.value = null));
        },
        P = (t) => (t >= 1e8 ? (t / 1e8).toFixed(1) + "亿" : t >= 1e4 ? (t / 1e4).toFixed(1) + "万" : t.toString());
      return (
        Q(async () => {
          r.gameRoles.length === 0 && (await r.fetchGameRoles());
        }),
        (t, e) => {
          const R = i("n-icon"),
            g = i("n-button"),
            D = i("n-dropdown"),
            C = i("n-tag"),
            T = i("n-empty"),
            w = i("n-input"),
            v = i("n-form-item"),
            z = i("n-select"),
            j = i("n-input-number"),
            I = i("n-form"),
            H = i("n-modal");
          return (
            p(),
            b("div", ie, [
              a("div", re, [
                a("div", de, [
                  a("div", ue, [
                    e[11] ||
                      (e[11] = a(
                        "div",
                        { class: "header-left" },
                        [a("h1", null, "游戏角色"), a("p", null, "管理您的所有游戏角色")],
                        -1,
                      )),
                    a("div", ce, [
                      l(
                        g,
                        { type: "primary", size: "large", onClick: e[0] || (e[0] = (s) => (d.value = !0)) },
                        {
                          icon: o(() => [l(R, null, { default: o(() => [l(m(ae))]), _: 1 })]),
                          default: o(() => [e[10] || (e[10] = _(" 添加角色 ", -1))]),
                          _: 1,
                        },
                      ),
                    ]),
                  ]),
                ]),
                m(r).gameRoles.length
                  ? (p(),
                    b("div", ve, [
                      (p(!0),
                      b(
                        W,
                        null,
                        X(m(r).gameRoles, (s) => {
                          var F;
                          return (
                            p(),
                            b(
                              "div",
                              {
                                key: s.id,
                                class: Z([
                                  "role-card",
                                  { active: s.id === ((F = m(r).selectedRole) == null ? void 0 : F.id) },
                                ]),
                                onClick: (S) => x(s),
                              },
                              [
                                a("div", pe, [
                                  a("div", _e, [
                                    a("img", { src: s.avatar || "/icons/xiaoyugan.png", alt: s.name }, null, 8, fe),
                                  ]),
                                  a("div", ge, [
                                    l(
                                      D,
                                      { options: E, onSelect: (S) => N(S, s) },
                                      {
                                        default: o(() => [
                                          l(
                                            g,
                                            { text: "" },
                                            {
                                              icon: o(() => [l(R, null, { default: o(() => [l(m(oe))]), _: 1 })]),
                                              _: 1,
                                            },
                                          ),
                                        ]),
                                        _: 1,
                                      },
                                      8,
                                      ["onSelect"],
                                    ),
                                  ]),
                                ]),
                                a("div", be, [
                                  a("h3", ye, u(s.name), 1),
                                  a("p", he, u(s.server) + " | " + u(s.level) + "级", 1),
                                  a("div", ke, [
                                    l(
                                      C,
                                      { size: "small", type: s.isActive ? "success" : "default" },
                                      { default: o(() => [_(u(s.isActive ? "活跃" : "离线"), 1)]), _: 2 },
                                      1032,
                                      ["type"],
                                    ),
                                    s.vip
                                      ? (p(),
                                        ee(
                                          C,
                                          { key: 0, size: "small" },
                                          { default: o(() => [...(e[12] || (e[12] = [_(" VIP ", -1)]))]), _: 1 },
                                        ))
                                      : se("", !0),
                                  ]),
                                ]),
                                a("div", Re, [
                                  a("div", we, [
                                    a("div", xe, [
                                      e[13] || (e[13] = a("span", { class: "stat-label" }, "经验", -1)),
                                      a("span", Ce, u(s.exp || "0"), 1),
                                    ]),
                                    a("div", ze, [
                                      e[14] || (e[14] = a("span", { class: "stat-label" }, "金币", -1)),
                                      a("span", Fe, u(P(s.gold || 0)), 1),
                                    ]),
                                  ]),
                                ]),
                              ],
                              10,
                              me,
                            )
                          );
                        }),
                        128,
                      )),
                    ]))
                  : (p(),
                    b("div", Se, [
                      l(
                        T,
                        { description: "暂无游戏角色", size: "large" },
                        {
                          icon: o(() => [l(R, { size: "64" }, { default: o(() => [l(m(ne))]), _: 1 })]),
                          extra: o(() => [
                            l(
                              g,
                              { type: "primary", size: "large", onClick: e[1] || (e[1] = (s) => (d.value = !0)) },
                              { default: o(() => [...(e[15] || (e[15] = [_(" 添加第一个角色 ", -1)]))]), _: 1 },
                            ),
                          ]),
                          _: 1,
                        },
                      ),
                    ])),
                l(
                  H,
                  {
                    show: d.value,
                    "onUpdate:show": e[9] || (e[9] = (s) => (d.value = s)),
                    preset: "card",
                    title: "添加游戏角色",
                    style: { width: "500px" },
                  },
                  {
                    footer: o(() => [
                      a("div", Ae, [
                        l(
                          g,
                          { onClick: e[8] || (e[8] = (s) => (d.value = !1)) },
                          { default: o(() => [...(e[16] || (e[16] = [_(" 取消 ", -1)]))]), _: 1 },
                        ),
                        l(
                          g,
                          { type: "primary", loading: h.value, onClick: B },
                          { default: o(() => [_(u(f.value ? "保存" : "添加"), 1)]), _: 1 },
                          8,
                          ["loading"],
                        ),
                      ]),
                    ]),
                    default: o(() => [
                      l(
                        I,
                        {
                          ref_key: "roleFormRef",
                          ref: k,
                          model: n,
                          rules: G,
                          "label-placement": "left",
                          "label-width": "80px",
                        },
                        {
                          default: o(() => [
                            l(
                              v,
                              { label: "角色名称", path: "name" },
                              {
                                default: o(() => [
                                  l(
                                    w,
                                    {
                                      value: n.name,
                                      "onUpdate:value": e[2] || (e[2] = (s) => (n.name = s)),
                                      placeholder: "请输入角色名称",
                                    },
                                    null,
                                    8,
                                    ["value"],
                                  ),
                                ]),
                                _: 1,
                              },
                            ),
                            l(
                              v,
                              { label: "服务器", path: "server" },
                              {
                                default: o(() => [
                                  l(
                                    z,
                                    {
                                      value: n.server,
                                      "onUpdate:value": e[3] || (e[3] = (s) => (n.server = s)),
                                      options: U,
                                      placeholder: "请选择服务器",
                                    },
                                    null,
                                    8,
                                    ["value"],
                                  ),
                                ]),
                                _: 1,
                              },
                            ),
                            l(
                              v,
                              { label: "职业", path: "profession" },
                              {
                                default: o(() => [
                                  l(
                                    z,
                                    {
                                      value: n.profession,
                                      "onUpdate:value": e[4] || (e[4] = (s) => (n.profession = s)),
                                      options: $,
                                      placeholder: "请选择职业",
                                    },
                                    null,
                                    8,
                                    ["value"],
                                  ),
                                ]),
                                _: 1,
                              },
                            ),
                            l(
                              v,
                              { label: "等级", path: "level" },
                              {
                                default: o(() => [
                                  l(
                                    j,
                                    {
                                      value: n.level,
                                      "onUpdate:value": e[5] || (e[5] = (s) => (n.level = s)),
                                      min: 1,
                                      max: 200,
                                      placeholder: "角色等级",
                                    },
                                    null,
                                    8,
                                    ["value"],
                                  ),
                                ]),
                                _: 1,
                              },
                            ),
                            l(
                              v,
                              { label: "账号信息" },
                              {
                                default: o(() => [
                                  l(
                                    w,
                                    {
                                      value: n.account,
                                      "onUpdate:value": e[6] || (e[6] = (s) => (n.account = s)),
                                      placeholder: "游戏账号（可选）",
                                    },
                                    null,
                                    8,
                                    ["value"],
                                  ),
                                ]),
                                _: 1,
                              },
                            ),
                            l(
                              v,
                              { label: "备注" },
                              {
                                default: o(() => [
                                  l(
                                    w,
                                    {
                                      value: n.note,
                                      "onUpdate:value": e[7] || (e[7] = (s) => (n.note = s)),
                                      type: "textarea",
                                      placeholder: "角色备注信息（可选）",
                                      rows: 3,
                                    },
                                    null,
                                    8,
                                    ["value"],
                                  ),
                                ]),
                                _: 1,
                              },
                            ),
                          ]),
                          _: 1,
                        },
                        8,
                        ["model"],
                      ),
                    ]),
                    _: 1,
                  },
                  8,
                  ["show"],
                ),
              ]),
            ])
          );
        }
      );
    },
  },
  Me = le(Ge, [["__scopeId", "data-v-ad062ad7"]]);
export { Me as default };
