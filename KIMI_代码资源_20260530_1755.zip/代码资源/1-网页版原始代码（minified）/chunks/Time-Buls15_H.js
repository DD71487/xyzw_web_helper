import { k as e, c as o, h as t, a as n } from "./index-UoU16364.js";
const s = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  r = n(
    "path",
    {
      d: "M256 48C141.13 48 48 141.13 48 256s93.13 208 208 208s208-93.13 208-208S370.87 48 256 48zm96 240h-96a16 16 0 0 1-16-16V128a16 16 0 0 1 32 0v128h80a16 16 0 0 1 0 32z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  a = [r],
  m = e({
    name: "Time",
    render: function (i, l) {
      return (t(), o("svg", s, a));
    },
  });
export { m as T };
