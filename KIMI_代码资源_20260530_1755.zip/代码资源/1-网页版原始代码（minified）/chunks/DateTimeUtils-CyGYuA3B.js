import { aL as u, aM as c, aN as l } from "./index-UoU16364.js";
const g = (o) => {
  if (!o) return "";
  if (o instanceof Uint8Array) return `[BON:${o.length}b]`;
  if (Array.isArray(o)) return `[Array:${o.length}]`;
  if (typeof o == "object") {
    if (Object.keys(o).every((r) => !Number.isNaN(parseInt(r)))) return `[BON:Object:${Object.keys(o).length}]`;
    try {
      return JSON.stringify(o);
    } catch {
      return "[Object]";
    }
  }
  return String(o);
};
class f {
  constructor(e, r, t) {
    ((this.encoder = e), (this.enc = r), (this.hint = t), (this.commands = new Map()));
  }
  register(e, r = {}) {
    return (
      this.commands.set(e, (t = 0, s = 0, i = {}) => {
        var n, a;
        return {
          cmd: e,
          ack: t,
          seq: s,
          hint: this.hint,
          time: Date.now(),
          body:
            (a = (n = this.encoder) == null ? void 0 : n.bon) != null && a.encode
              ? this.encoder.bon.encode({ ...r, ...i })
              : { ...r, ...i },
        };
      }),
      this
    );
  }
  registerHeartbeat() {
    return (
      this.commands.set("heart_beat", (e, r) => ({
        cmd: "war_ping",
        ack: e,
        seq: r,
        hint: this.hint,
        time: Date.now(),
        body: { battlefieldId: this.hint },
      })),
      this
    );
  }
  encodePacket(e) {
    var r;
    return (r = this.encoder) != null && r.encode && this.enc ? this.encoder.encode(e, this.enc) : JSON.stringify(e);
  }
  build(e, r, t, s) {
    const i = this.commands.get(e);
    if (!i) throw new Error(`Unknown cmd: ${e}`);
    return i(r, t, s);
  }
}
function m(o) {
  return o.registerHeartbeat().register("war_getbattlefieldinfo").register("war_enterbattlefield");
}
class _ {
  constructor({ url: e, utils: r, hint: t, heartbeatMs: s = 5e3 }) {
    var i;
    ((this.url = e),
      (this.utils = r || u),
      (this.enc = (i = this.utils) != null && i.getEnc ? this.utils.getEnc("auto") : void 0),
      (this.socket = null),
      (this.ack = 0),
      (this.seq = 0),
      (this.hint = t),
      (this.sendQueue = []),
      (this.sendQueueTimer = null),
      (this.heartbeatTimer = null),
      (this.heartbeatInterval = s),
      (this.dialogStatus = !1),
      (this.messageListener = null),
      (this.showMsg = !1),
      (this.connected = !1),
      (this.isReconnecting = !1),
      (this.promises = Object.create(null)),
      (this.registry = m(new f(this.utils, this.enc, this.hint))),
      (this.onConnect = null),
      (this.onDisconnect = null),
      (this.onError = null));
  }
  init() {
    (c.info(`连接: ${this.url.split("?")[0]}`),
      (this.socket = new WebSocket(this.url)),
      (this.socket.onopen = () => {
        (c.info("连接成功"),
          (this.connected = !0),
          this._setupHeartbeat(),
          this._processQueueLoop(),
          this.onConnect && this.onConnect());
      }),
      (this.socket.onmessage = (e) => {
        var r;
        try {
          let t;
          if (typeof e.data == "string") t = JSON.parse(e.data);
          else if (e.data instanceof ArrayBuffer)
            t = (r = this.utils) != null && r.parse ? this.utils.parse(e.data, "auto", !0) : e.data;
          else if (e.data instanceof Blob) {
            e.data.arrayBuffer().then((s) => {
              var i;
              try {
                if (
                  ((t = (i = this.utils) != null && i.parse ? this.utils.parse(s, "auto", !0) : s),
                  t instanceof Object && t.rawData !== void 0)
                )
                  l.verbose("ProtoMsg Blob消息，使用rawData:", t.rawData);
                else if (t.body && this.shouldDecodeBody(t.body))
                  try {
                    if (this.utils && this.utils.bon && this.utils.bon.decode) {
                      const h = this.convertToUint8Array(t.body);
                      if (h) {
                        const d = this.utils.bon.decode(h);
                        (l.debug("BON Blob解码成功:", t.cmd, d), (t.decodedBody = d));
                      }
                    } else l.warn("BON解码器不可用 (Blob)");
                  } catch (h) {
                    l.error("BON Blob消息体解码失败:", h.message, t.cmd);
                  }
                const n = t._raw || t,
                  a =
                    typeof (n == null ? void 0 : n.seq) == "number"
                      ? n.seq
                      : typeof (t == null ? void 0 : t.seq) == "number"
                        ? t.seq
                        : void 0;
                (typeof a == "number" && a >= 0 && (this.ack = a),
                  this.showMsg,
                  this.messageListener && this.messageListener(t),
                  this._handlePromiseResponse(t));
              } catch (n) {
                l.error("Blob解析失败:", n.message);
              }
            });
            return;
          } else (l.warn("未知数据类型:", typeof e.data, e.data), (t = e.data));
          if ((this.showMsg && l.verbose("收到消息:", t), t instanceof Object && t.rawData !== void 0))
            l.verbose("ProtoMsg消息，使用rawData:", t.rawData);
          else {
            const s = t._raw || t,
              i = typeof s.seq == "number" ? s.seq : typeof t.seq == "number" ? t.seq : void 0;
            if ((typeof i == "number" && i >= 0 && (this.ack = i), s.body && this.shouldDecodeBody(s.body)))
              try {
                if (this.utils && this.utils.bon && this.utils.bon.decode) {
                  const n = this.convertToUint8Array(s.body);
                  if (n) {
                    const a = this.utils.bon.decode(n);
                    (l.debug("BON解码成功:", s.cmd || t.cmd, a),
                      (t.decodedBody = a),
                      t._raw && (t._raw.decodedBody = a));
                  }
                } else l.warn("BON解码器不可用");
              } catch (n) {
                l.error("BON消息体解码失败:", n.message, s.cmd || t.cmd);
              }
          }
          (this.messageListener && this.messageListener(t), this._handlePromiseResponse(t));
        } catch (t) {
          l.error("消息处理失败:", t.message);
        }
      }),
      (this.socket.onclose = (e) => {
        (c.info(`WebSocket 连接关闭: ${e.code} ${e.reason || ""}`),
          c.debug("关闭详情:", {
            code: e.code,
            reason: e.reason || "未提供原因",
            wasClean: e.wasClean,
            timestamp: new Date().toISOString(),
          }),
          (this.connected = !1),
          this._clearTimers(),
          this.onDisconnect && this.onDisconnect(e));
      }),
      (this.socket.onerror = (e) => {
        (c.error("WebSocket 错误:", e), (this.connected = !1), this._clearTimers(), this.onError && this.onError(e));
      }));
  }
  setMessageListener(e) {
    this.messageListener = e;
  }
  setShowMsg(e) {
    this.showMsg = !!e;
  }
  shouldDecodeBody(e) {
    if (!e) return !1;
    if (e instanceof Uint8Array || Array.isArray(e)) return !0;
    if (typeof e == "object" && e.constructor === Object) {
      const r = Object.keys(e);
      return r.length > 0 && r.every((t) => !isNaN(parseInt(t)));
    }
    return !1;
  }
  convertToUint8Array(e) {
    if (!e) return null;
    if (e instanceof Uint8Array) return e;
    if (Array.isArray(e)) return new Uint8Array(e);
    if (typeof e == "object" && e.constructor === Object) {
      const r = Object.keys(e)
        .map((t) => parseInt(t))
        .sort((t, s) => t - s);
      if (r.length > 0) {
        const t = Math.max(...r),
          s = new Array(t + 1).fill(0);
        for (const [i, n] of Object.entries(e)) {
          const a = parseInt(i);
          !isNaN(a) && typeof n == "number" && (s[a] = n);
        }
        return (l.debug("转换对象格式body为Uint8Array:", s.length, "bytes"), new Uint8Array(s));
      }
    }
    return null;
  }
  decodeBodyForLog(e) {
    var s, i;
    if (!e) return null;
    const r = (i = (s = this.utils) == null ? void 0 : s.bon) == null ? void 0 : i.decode;
    if (typeof r != "function") return null;
    let t = null;
    if (
      (e instanceof Uint8Array
        ? (t = e)
        : Array.isArray(e)
          ? (t = new Uint8Array(e))
          : this.shouldDecodeBody(e) && (t = this.convertToUint8Array(e)),
      !t)
    )
      return null;
    try {
      return r(t);
    } catch (n) {
      return (l.warn("日志解析BON失败:", n.message), null);
    }
  }
  reconnect() {
    if (this.isReconnecting) {
      c.debug("重连已在进行中，跳过此次重连请求");
      return;
    }
    ((this.isReconnecting = !0),
      c.info("开始WebSocket重连..."),
      this.disconnect(),
      setTimeout(() => {
        try {
          this.init();
        } finally {
          setTimeout(() => {
            this.isReconnecting = !1;
          }, 2e3);
        }
      }, 1e3));
  }
  disconnect() {
    (this.socket && (this.socket.close(), (this.socket = null)), (this.connected = !1), this._clearTimers());
  }
  send(e, r = {}, t = {}) {
    this.connected ||
      (c.warn(`WebSocket 未连接，消息已入队: ${e}`),
      !this.dialogStatus &&
        !this.isReconnecting &&
        ((this.dialogStatus = !0),
        c.info("自动触发重连..."),
        this.reconnect(),
        setTimeout(() => {
          this.dialogStatus = !1;
        }, 2e3)));
    const s = t.seq !== void 0 ? t.seq : e === "heart_beat" ? 0 : ++this.seq,
      i = {
        cmd: e,
        params: r,
        seq: s,
        hint: this.hint,
        respKey: t.respKey || e,
        sleep: t.sleep || 0,
        onSent: t.onSent,
      };
    return (this.sendQueue.push(i), i);
  }
  sendWithPromise(e, r = {}, t = 5e3) {
    return new Promise((s, i) => {
      if (!this.connected && !this.socket) return i(new Error("WebSocket 连接已关闭"));
      const n = ++this.seq;
      ((this.promises[n] = { resolve: s, reject: i, originalCmd: e }),
        setTimeout(() => {
          (delete this.promises[n], i(new Error(`请求超时: ${e} (${t}ms)`)));
        }, t),
        this.send(e, r, { seq: n, onSent: () => {} }));
    });
  }
  sendHeartbeat() {
    (c.verbose("发送心跳消息"), this.send("heart_beat", {}, { respKey: "war_ping" }));
  }
  _setupHeartbeat() {
    (setTimeout(() => {
      var e;
      this.connected &&
        ((e = this.socket) == null ? void 0 : e.readyState) === WebSocket.OPEN &&
        (c.debug("开始发送首次心跳"), this.sendHeartbeat());
    }, 3e3),
      (this.heartbeatTimer = setInterval(() => {
        var e;
        this.connected && ((e = this.socket) == null ? void 0 : e.readyState) === WebSocket.OPEN
          ? this.sendHeartbeat()
          : c.warn("心跳检查失败: 连接状态异常");
      }, this.heartbeatInterval)));
  }
  _processQueueLoop() {
    (this.sendQueueTimer && clearInterval(this.sendQueueTimer),
      (this.sendQueueTimer = setInterval(async () => {
        var r, t;
        if (
          !this.sendQueue.length ||
          !this.connected ||
          ((r = this.socket) == null ? void 0 : r.readyState) !== WebSocket.OPEN
        )
          return;
        const e = this.sendQueue.shift();
        if (e)
          try {
            const s = this.registry.build(e.cmd, this.ack, e.seq, e.params);
            if (s && s.cmd !== "war_ping") {
              const n = this.decodeBodyForLog(s.body);
              c.info("📤 发送报文", {
                cmd: s.cmd,
                hint: s.hint ?? 0,
                ack: s.ack ?? 0,
                seq: s.seq ?? 0,
                time: s.time,
                body: n ?? g(s.body),
              });
            }
            const i = this.registry.encodePacket(s);
            if (
              ((t = this.socket) == null || t.send(i),
              (this.showMsg || e.cmd === "heart_beat") &&
                (c.wsMessage("local", e.cmd, !1),
                this.showMsg &&
                  (c.verbose("原始数据:", s),
                  c.verbose("编码后数据:", i),
                  c.verbose("编码类型:", typeof i, i instanceof Uint8Array ? "Uint8Array (加密)" : "String (明文)"),
                  i instanceof Uint8Array &&
                    i.length > 0 &&
                    c.verbose(`加密验证: 前8字节 [${Array.from(i.slice(0, 8)).join(", ")}]`))),
              e.onSent)
            )
              try {
                const n = {
                  respKey: e.respKey,
                  cmd: e.cmd,
                  seq: (s == null ? void 0 : s.seq) ?? e.seq,
                  ack: (s == null ? void 0 : s.ack) ?? this.ack,
                  time: (s == null ? void 0 : s.time) ?? Date.now(),
                };
                e.onSent(n);
              } catch (n) {
                c.warn("发送回调执行失败:", n);
              }
            e.sleep && (await sleep(e.sleep));
          } catch (s) {
            c.error(`发送消息失败: ${e.cmd}`, s);
          }
      }, 50)));
  }
  _handlePromiseResponse(e) {
    if (e.resp !== void 0 && this.promises[e.resp]) {
      const n = this.promises[e.resp];
      delete this.promises[e.resp];
      const a = e.rawData !== void 0 ? e.rawData : e.decodedBody !== void 0 ? e.decodedBody : e.body;
      e.code === 0 || e.code === void 0
        ? n.resolve(a || e)
        : n.reject(new Error(`服务器错误: ${e.code} - ${e.hint || "未知错误"}`));
      return;
    }
    const r = e.cmd;
    if (!r) return;
    const t = typeof r == "string" ? r.toLowerCase() : r;
    let i = {
      fight_startpvpresp: "fight_startpvp",
      activity_getresp: "activity_get",
      collection_goodslistresp: "collection_goodslist",
      collection_claimfreerewardresp: "collection_claimfreereward",
      legion_getarearankresp: "legion_getarearank",
      legionwar_getgoldmonthwarrankresp: "legionwar_getgoldmonthwarrank",
      nightmare_getroleinforesp: "nightmare_getroleinfo",
      studyresp: "study_startgame",
      role_getroleinforesp: "role_getroleinfo",
      hero_recruitresp: "hero_recruit",
      friend_batchresp: "friend_batch",
      system_claimhanguprewardresp: "system_claimhangupreward",
      item_openboxresp: ["item_openbox", "item_batchclaimboxpointreward"],
      bottlehelper_claimresp: "bottlehelper_claim",
      bottlehelper_startresp: "bottlehelper_start",
      bottlehelper_stopresp: "bottlehelper_stop",
      legion_signinresp: "legion_signin",
      fight_startbossresp: "fight_startboss",
      fight_startlegionbossresp: "fight_startlegionboss",
      fight_startareaarenaresp: "fight_startareaarena",
      arena_startarearesp: "arena_startarea",
      arena_getareatargetresp: "arena_getareatarget",
      arena_getarearankresp: "arena_getarearank",
      presetteam_saveteamresp: "presetteam_saveteam",
      presetteam_getinforesp: "presetteam_getinfo",
      mail_claimallattachmentresp: "mail_claimallattachment",
      store_buyresp: "store_purchase",
      system_getdatabundleverresp: "system_getdatabundlever",
      tower_claimrewardresp: "tower_claimreward",
      fight_starttowerresp: "fight_starttower",
      evotowerinforesp: "evotower_getinfo",
      evotower_fightresp: "evotower_fight",
      item_openpackresp: "item_openpack",
      matchteam_getroleteaminforesp: "matchteam_getroleteaminfo",
      bosstower_getinforesp: "bosstower_getinfo",
      bosstower_startbossreso: "bosstower_startboss",
      bosstower_startboxresp: "bosstower_startbox",
      discount_getdiscountinforesp: "discount_getdiscountinfo",
      hero_heroupgradestarresp: "hero_heroupgradestar",
      book_upgraderesp: "book_upgrade",
      book_claimpointrewardresp: "book_claimpointreward",
      legion_getinforesp: "legion_getinfo",
      legion_getinforresp: "legion_getinfo",
      car_getrolecarresp: "car_getrolecar",
      car_refreshresp: "car_refresh",
      car_claimresp: "car_claim",
      car_sendresp: "car_send",
      car_getmemberhelpingcntresp: "car_getmemberhelpingcnt",
      role_gettargetteamresp: "role_gettargetteam",
      activity_warorderclaimresp: "activity_recyclewarorderrewardclaim",
      arena_getarearankresp: "arena_getarearank",
      bosstower_gethelprankresp: "bosstower_gethelprank",
      task_claimdailyrewardresp: "task_claimdailyreward",
      task_claimweekrewardresp: "task_claimweekreward",
      syncresp: ["system_mysharecallback", "task_claimdailypoint"],
      syncrewardresp: [
        "system_buygold",
        "discount_claimreward",
        "card_claimreward",
        "artifact_lottery",
        "genie_sweep",
        "genie_buysweep",
        "system_signinreward",
        "dungeon_selecthero",
      ],
    }[t];
    i ? typeof i == "string" && (i = [i]) : (i = [t]);
    for (const [n, a] of Object.entries(this.promises))
      if (i.includes(a.originalCmd)) {
        delete this.promises[n];
        const h = e.rawData !== void 0 ? e.rawData : e.decodedBody !== void 0 ? e.decodedBody : e.body;
        e.code === 0 || e.code === void 0
          ? a.resolve(h || e)
          : a.reject(new Error(`服务器错误: ${e.code} - ${e.hint || "未知错误"}`));
        break;
      }
  }
  _clearTimers() {
    (this.heartbeatTimer && (clearInterval(this.heartbeatTimer), (this.heartbeatTimer = null)),
      this.sendQueueTimer && (clearInterval(this.sendQueueTimer), (this.sendQueueTimer = null)));
  }
}
function y(o) {
  ((typeof o != "string" || o.trim() === "") && (o = "yyyy-MM-dd HH:mm:ss"), (o = o.trim()));
  const r = new Date(),
    t = r.getFullYear(),
    s = String(r.getMonth() + 1).padStart(2, "0"),
    i = String(r.getDate()).padStart(2, "0"),
    n = String(r.getHours()).padStart(2, "0"),
    a = String(r.getMinutes()).padStart(2, "0"),
    h = String(r.getSeconds()).padStart(2, "0");
  return o
    .replace(/yyyy/g, t)
    .replace(/MM/g, s)
    .replace(/dd/g, i)
    .replace(/HH/g, n)
    .replace(/mm/g, a)
    .replace(/ss/g, h);
}
export { _ as X, y as g };
