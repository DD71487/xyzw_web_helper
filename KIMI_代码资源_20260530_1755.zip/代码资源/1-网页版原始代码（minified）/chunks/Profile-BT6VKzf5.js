import {
  k as ie,
  c as U,
  h as T,
  a as c,
  _ as ue,
  B as ht,
  E as J,
  r as ge,
  n as Oe,
  p as V,
  z as re,
  al as et,
  X as gt,
  d as G,
  e as se,
  w as d,
  j as tt,
  ag as ye,
  A as ce,
  i as E,
  b as p,
  t as I,
  ah as Ee,
  o as Ve,
  aO as mt,
  aa as ot,
  g as nt,
  ad as Ie,
  F as st,
  aj as vt,
  $ as Ce,
  aP as bt,
  s as rt,
  v as lt,
  u as A,
  N as ee,
  T as Ne,
  G as yt,
  I as ne,
  f as kt,
} from "./index-UoU16364.js";
import { u as wt } from "./localTokenManager-BQJEcmfy.js";
import { u as jt } from "./gameRoles-DtpzXQTv.js";
import { _ as it } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { C as He, a as at, S as _t, T as Ct } from "./index-C7aQI1Ec.js";
import { E as Tt } from "./EllipsisHorizontal-CLDjmchS.js";
import { R as Be } from "./Refresh-DWYLAev-.js";
import { C as St } from "./CloudUpload-DBucip-_.js";
import { T as $t } from "./Time-Buls15_H.js";
import { u as Ot } from "./auth-BYvggjsB.js";
import {
  _ as me,
  g as ve,
  k as Et,
  O as Fe,
  l as Ge,
  i as xt,
  r as Mt,
  c as xe,
  R as Lt,
  m as Vt,
  P as Ke,
  s as Ft,
  a as Pt,
  B as Wt,
} from "./index-7YDlkBnY.js";
import { T as At } from "./index-BF2tcBOi.js";
import { g as Qe, s as Ze } from "./get-value-by-path-drwBAHM3.js";
import { C as zt, R as Ut, I as qt } from "./grid-col-GTGOUscx.js";
const Rt = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  It = c(
    "path",
    {
      d: "M256 48C141.31 48 48 141.31 48 256s93.31 208 208 208s208-93.31 208-208S370.69 48 256 48zm0 319.91a20 20 0 1 1 20-20a20 20 0 0 1-20 20zm21.72-201.15l-5.74 122a16 16 0 0 1-32 0l-5.74-121.94v-.05a21.74 21.74 0 1 1 43.44 0z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  Nt = [It],
  Ht = ie({
    name: "AlertCircle",
    render: function (t, n) {
      return (T(), U("svg", Rt, Nt));
    },
  }),
  Bt = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", viewBox: "0 0 512 512" },
  Gt = c(
    "rect",
    {
      x: "128",
      y: "128",
      width: "336",
      height: "336",
      rx: "57",
      ry: "57",
      fill: "none",
      stroke: "currentColor",
      "stroke-linejoin": "round",
      "stroke-width": "32",
    },
    null,
    -1,
  ),
  Kt = c(
    "path",
    {
      d: "M383.5 128l.5-24a56.16 56.16 0 0 0-56-56H112a64.19 64.19 0 0 0-64 64v216a56.16 56.16 0 0 0 56 56h24",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "32",
    },
    null,
    -1,
  ),
  Qt = [Gt, Kt],
  Zt = ie({
    name: "CopyOutline",
    render: function (t, n) {
      return (T(), U("svg", Bt, Qt));
    },
  }),
  Xt = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", viewBox: "0 0 512 512" },
  Yt = c(
    "path",
    {
      d: "M346.65 304.3a136 136 0 0 0-180.71 0a21 21 0 1 0 27.91 31.38a94 94 0 0 1 124.89 0a21 21 0 0 0 27.91-31.4z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  Dt = c(
    "path",
    {
      d: "M256.28 183.7a221.47 221.47 0 0 0-151.8 59.92a21 21 0 1 0 28.68 30.67a180.28 180.28 0 0 1 246.24 0a21 21 0 1 0 28.68-30.67a221.47 221.47 0 0 0-151.8-59.92z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  Jt = c(
    "path",
    {
      d: "M462 175.86a309 309 0 0 0-411.44 0a21 21 0 1 0 28 31.29a267 267 0 0 1 355.43 0a21 21 0 0 0 28-31.31z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  eo = c("circle", { cx: "256.28", cy: "393.41", r: "32", fill: "currentColor" }, null, -1),
  to = [Yt, Dt, Jt, eo],
  oo = ie({
    name: "Wifi",
    render: function (t, n) {
      return (T(), U("svg", Xt, to));
    },
  }),
  no = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", viewBox: "0 0 512 512" },
  so = c(
    "path",
    {
      d: "M332.41 310.59a115 115 0 0 0-152.8 0",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "32",
    },
    null,
    -1,
  ),
  ro = c(
    "path",
    {
      d: "M393.46 249.54a201.26 201.26 0 0 0-274.92 0",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "32",
    },
    null,
    -1,
  ),
  lo = c(
    "path",
    {
      d: "M447.72 182.11a288 288 0 0 0-383.44 0",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "32",
    },
    null,
    -1,
  ),
  io = c("path", { d: "M256 416a32 32 0 1 1 32-32a32 32 0 0 1-32 32z", fill: "currentColor" }, null, -1),
  ao = [so, ro, lo, io],
  uo = ie({
    name: "WifiOutline",
    render: function (t, n) {
      return (T(), U("svg", no, ao));
    },
  });
function Xe(e) {
  return typeof e == "object" && e != null && e.nodeType === 1;
}
function Ye(e, t) {
  return (!t || e !== "hidden") && e !== "visible" && e !== "clip";
}
function Te(e, t) {
  if (e.clientHeight < e.scrollHeight || e.clientWidth < e.scrollWidth) {
    var n = getComputedStyle(e, null);
    return (
      Ye(n.overflowY, t) ||
      Ye(n.overflowX, t) ||
      (function (o) {
        var s = (function (a) {
          if (!a.ownerDocument || !a.ownerDocument.defaultView) return null;
          try {
            return a.ownerDocument.defaultView.frameElement;
          } catch {
            return null;
          }
        })(o);
        return !!s && (s.clientHeight < o.scrollHeight || s.clientWidth < o.scrollWidth);
      })(e)
    );
  }
  return !1;
}
function be(e, t, n, o, s, a, f, h) {
  return (a < e && f > t) || (a > e && f < t)
    ? 0
    : (a <= e && h <= n) || (f >= t && h >= n)
      ? a - e - o
      : (f > t && h < n) || (a < e && h > n)
        ? f - t + s
        : 0;
}
var De = function (e, t) {
  var n = window,
    o = t.scrollMode,
    s = t.block,
    a = t.inline,
    f = t.boundary,
    h = t.skipOverflowHiddenElements,
    j =
      typeof f == "function"
        ? f
        : function (pt) {
            return pt !== f;
          };
  if (!Xe(e)) throw new TypeError("Invalid target");
  for (var x, N, X = document.scrollingElement || document.documentElement, _ = [], O = e; Xe(O) && j(O); ) {
    if ((O = (N = (x = O).parentElement) == null ? x.getRootNode().host || null : N) === X) {
      _.push(O);
      break;
    }
    (O != null && O === document.body && Te(O) && !Te(document.documentElement)) ||
      (O != null && Te(O, h) && _.push(O));
  }
  for (
    var q = n.visualViewport ? n.visualViewport.width : innerWidth,
      W = n.visualViewport ? n.visualViewport.height : innerHeight,
      F = window.scrollX || pageXOffset,
      m = window.scrollY || pageYOffset,
      l = e.getBoundingClientRect(),
      S = l.height,
      $ = l.width,
      H = l.top,
      Y = l.right,
      B = l.bottom,
      z = l.left,
      P = s === "start" || s === "nearest" ? H : s === "end" ? B : H + S / 2,
      M = a === "center" ? z + $ / 2 : a === "end" ? Y : z,
      K = [],
      u = 0;
    u < _.length;
    u++
  ) {
    var r = _[u],
      b = r.getBoundingClientRect(),
      w = b.height,
      C = b.width,
      Q = b.top,
      v = b.right,
      k = b.bottom,
      i = b.left;
    if (o === "if-needed" && H >= 0 && z >= 0 && B <= W && Y <= q && H >= Q && B <= k && z >= i && Y <= v) return K;
    var g = getComputedStyle(r),
      y = parseInt(g.borderLeftWidth, 10),
      L = parseInt(g.borderTopWidth, 10),
      D = parseInt(g.borderRightWidth, 10),
      Z = parseInt(g.borderBottomWidth, 10),
      R = 0,
      oe = 0,
      de = "offsetWidth" in r ? r.offsetWidth - r.clientWidth - y - D : 0,
      pe = "offsetHeight" in r ? r.offsetHeight - r.clientHeight - L - Z : 0,
      ze = "offsetWidth" in r ? (r.offsetWidth === 0 ? 0 : C / r.offsetWidth) : 0,
      Ue = "offsetHeight" in r ? (r.offsetHeight === 0 ? 0 : w / r.offsetHeight) : 0;
    if (X === r)
      ((R =
        s === "start"
          ? P
          : s === "end"
            ? P - W
            : s === "nearest"
              ? be(m, m + W, W, L, Z, m + P, m + P + S, S)
              : P - W / 2),
        (oe =
          a === "start"
            ? M
            : a === "center"
              ? M - q / 2
              : a === "end"
                ? M - q
                : be(F, F + q, q, y, D, F + M, F + M + $, $)),
        (R = Math.max(0, R + m)),
        (oe = Math.max(0, oe + F)));
    else {
      ((R =
        s === "start"
          ? P - Q - L
          : s === "end"
            ? P - k + Z + pe
            : s === "nearest"
              ? be(Q, k, w, L, Z + pe, P, P + S, S)
              : P - (Q + w / 2) + pe / 2),
        (oe =
          a === "start"
            ? M - i - y
            : a === "center"
              ? M - (i + C / 2) + de / 2
              : a === "end"
                ? M - v + D + de
                : be(i, v, C, y, D + de, M, M + $, $)));
      var qe = r.scrollLeft,
        Re = r.scrollTop;
      ((P += Re - (R = Math.max(0, Math.min(Re + R / Ue, r.scrollHeight - w / Ue + pe)))),
        (M += qe - (oe = Math.max(0, Math.min(qe + oe / ze, r.scrollWidth - C / ze + de)))));
    }
    K.push({ el: r, top: R, left: oe });
  }
  return K;
};
function ut(e) {
  return e === Object(e) && Object.keys(e).length !== 0;
}
function co(e, t) {
  t === void 0 && (t = "auto");
  var n = "scrollBehavior" in document.body.style;
  e.forEach(function (o) {
    var s = o.el,
      a = o.top,
      f = o.left;
    s.scroll && n ? s.scroll({ top: a, left: f, behavior: t }) : ((s.scrollTop = a), (s.scrollLeft = f));
  });
}
function fo(e) {
  return e === !1 ? { block: "end", inline: "nearest" } : ut(e) ? e : { block: "start", inline: "nearest" };
}
function po(e, t) {
  var n = e.isConnected || e.ownerDocument.documentElement.contains(e);
  if (ut(t) && typeof t.behavior == "function") return t.behavior(n ? De(e, t) : []);
  if (n) {
    var o = fo(t);
    return co(De(e, o), o.behavior);
  }
}
const Je = ["success", "warning", "error", "validating"],
  ho = (e) => {
    let t = "";
    for (const n of Object.keys(e)) {
      const o = e[n];
      o && (!t || Je.indexOf(o) > Je.indexOf(t)) && (t = e[n]);
    }
    return t;
  },
  go = (e) => {
    const t = [];
    for (const n of Object.keys(e)) {
      const o = e[n];
      o && t.push(o);
    }
    return t;
  },
  ct = (e, t) => {
    const n = t.replace(/[[.]/g, "_").replace(/\]/g, "");
    return e ? `${e}-${n}` : `${n}`;
  },
  mo = ie({
    name: "Form",
    props: {
      model: { type: Object, required: !0 },
      layout: { type: String, default: "horizontal" },
      size: { type: String },
      labelColProps: { type: Object, default: () => ({ span: 5, offset: 0 }) },
      wrapperColProps: { type: Object, default: () => ({ span: 19, offset: 0 }) },
      labelColStyle: Object,
      wrapperColStyle: Object,
      labelAlign: { type: String, default: "right" },
      disabled: { type: Boolean, default: void 0 },
      rules: { type: Object },
      autoLabelWidth: { type: Boolean, default: !1 },
      id: { type: String },
      scrollToFirstError: { type: Boolean, default: !1 },
    },
    emits: { submit: (e, t) => !0, submitSuccess: (e, t) => !0, submitFailed: (e, t) => !0 },
    setup(e, { emit: t }) {
      const n = ve("form"),
        o = ge(),
        {
          id: s,
          model: a,
          layout: f,
          disabled: h,
          labelAlign: j,
          labelColProps: x,
          wrapperColProps: N,
          labelColStyle: X,
          wrapperColStyle: _,
          size: O,
          rules: q,
        } = Oe(e),
        { mergedSize: W } = Et(O),
        F = V(() => e.layout === "horizontal" && e.autoLabelWidth),
        m = [],
        l = [],
        S = re({}),
        $ = V(() => Math.max(...Object.values(S))),
        H = (v) => {
          v && v.field && m.push(v);
        },
        Y = (v) => {
          v && v.field && m.splice(m.indexOf(v), 1);
        },
        B = (v) => {
          m.forEach((k) => {
            v[k.field] && k.setField(v[k.field]);
          });
        },
        z = (v, k) => {
          k && S[k] !== v && (S[k] = v);
        },
        P = (v) => {
          v && delete S[v];
        },
        M = (v) => {
          const k = v ? [].concat(v) : [];
          m.forEach((i) => {
            (k.length === 0 || k.includes(i.field)) && i.resetField();
          });
        },
        K = (v) => {
          const k = v ? [].concat(v) : [];
          m.forEach((i) => {
            (k.length === 0 || k.includes(i.field)) && i.clearValidate();
          });
        },
        u = (v, k) => {
          const g = (o.value || document.body).querySelector(`#${ct(e.id, v)}`);
          g && po(g, { behavior: "smooth", block: "nearest", scrollMode: "if-needed", ...k });
        },
        r = (v) => {
          const k = Mt(e.scrollToFirstError) ? void 0 : e.scrollToFirstError;
          u(v, k);
        },
        b = (v) => {
          const k = [];
          return (
            m.forEach((i) => {
              k.push(i.validate());
            }),
            Promise.all(k).then((i) => {
              const g = {};
              let y = !1;
              return (
                i.forEach((L) => {
                  L && ((y = !0), (g[L.field] = L));
                }),
                y && e.scrollToFirstError && r(Object.keys(g)[0]),
                Ge(v) && v(y ? g : void 0),
                y ? g : void 0
              );
            })
          );
        },
        w = (v, k) => {
          const i = [];
          for (const g of m) ((xt(v) && v.includes(g.field)) || v === g.field) && i.push(g.validate());
          return Promise.all(i).then((g) => {
            const y = {};
            let L = !1;
            return (
              g.forEach((D) => {
                D && ((L = !0), (y[D.field] = D));
              }),
              L && e.scrollToFirstError && r(Object.keys(y)[0]),
              Ge(k) && k(L ? y : void 0),
              L ? y : void 0
            );
          });
        },
        C = (v) => {
          const k = [];
          (m.forEach((i) => {
            k.push(i.validate());
          }),
            Promise.all(k).then((i) => {
              const g = {};
              let y = !1;
              (i.forEach((L) => {
                L && ((y = !0), (g[L.field] = L));
              }),
                y
                  ? (e.scrollToFirstError && r(Object.keys(g)[0]), t("submitFailed", { values: a.value, errors: g }, v))
                  : t("submitSuccess", a.value, v),
                t("submit", { values: a.value, errors: y ? g : void 0 }, v));
            }));
        };
      return (
        et(
          Fe,
          re({
            id: s,
            layout: f,
            disabled: h,
            labelAlign: j,
            labelColProps: x,
            wrapperColProps: N,
            labelColStyle: X,
            wrapperColStyle: _,
            model: a,
            size: W,
            rules: q,
            fields: m,
            touchedFields: l,
            addField: H,
            removeField: Y,
            validateField: w,
            setLabelWidth: z,
            removeLabelWidth: P,
            maxLabelWidth: $,
            autoLabelWidth: F,
          }),
        ),
        {
          cls: V(() => [
            n,
            `${n}-layout-${e.layout}`,
            `${n}-size-${W.value}`,
            { [`${n}-auto-label-width`]: e.autoLabelWidth },
          ]),
          formRef: o,
          handleSubmit: C,
          innerValidate: b,
          innerValidateField: w,
          innerResetFields: M,
          innerClearValidate: K,
          innerSetFields: B,
          innerScrollToField: u,
        }
      );
    },
    methods: {
      validate(e) {
        return this.innerValidate(e);
      },
      validateField(e, t) {
        return this.innerValidateField(e, t);
      },
      resetFields(e) {
        return this.innerResetFields(e);
      },
      clearValidate(e) {
        return this.innerClearValidate(e);
      },
      setFields(e) {
        return this.innerSetFields(e);
      },
      scrollToField(e) {
        return this.innerScrollToField(e);
      },
    },
  }),
  vo = ["id"];
function bo(e, t, n, o, s, a) {
  return (
    T(),
    U(
      "form",
      {
        id: e.id,
        ref: "formRef",
        class: J(e.cls),
        onSubmit: t[0] || (t[0] = ht((...f) => e.handleSubmit && e.handleSubmit(...f), ["prevent"])),
      },
      [ue(e.$slots, "default")],
      42,
      vo,
    )
  );
}
var Se = me(mo, [["render", bo]]),
  he = Object.prototype.toString;
function je(e) {
  return he.call(e) === "[object Array]";
}
function le(e) {
  return he.call(e) === "[object Object]";
}
function Me(e) {
  return he.call(e) === "[object String]";
}
function yo(e) {
  return he.call(e) === "[object Number]" && e === e;
}
function ko(e) {
  return he.call(e) === "[object Boolean]";
}
function Le(e) {
  return he.call(e) === "[object Function]";
}
function wo(e) {
  return le(e) && Object.keys(e).length === 0;
}
function fe(e) {
  return e == null || e === "";
}
function dt(e) {
  return je(e) && !e.length;
}
var Pe = function (e, t) {
    if (typeof e != "object" || typeof t != "object") return e === t;
    if (Le(e) && Le(t)) return e === t || e.toString() === t.toString();
    if (Object.keys(e).length !== Object.keys(t).length) return !1;
    for (var n in e) {
      var o = Pe(e[n], t[n]);
      if (!o) return !1;
    }
    return !0;
  },
  We = function (e, t) {
    var n = Object.assign({}, e);
    return (
      Object.keys(t || {}).forEach(function (o) {
        var s = n[o],
          a = t == null ? void 0 : t[o];
        n[o] = le(s) ? Object.assign(Object.assign({}, s), a) : a || s;
      }),
      n
    );
  },
  jo = function (e, t) {
    for (var n = t.split("."), o = e, s = 0; s < n.length; s++) if (((o = o && o[n[s]]), o === void 0)) return o;
    return o;
  },
  ae = "#{field} is not a #{type} type",
  _o = {
    required: "#{field} is required",
    type: { ip: ae, email: ae, url: ae, string: ae, number: ae, array: ae, object: ae, boolean: ae },
    number: {
      min: "`#{value}` is not greater than `#{min}`",
      max: "`#{value}` is not less than `#{max}`",
      equal: "`#{value}` is not equal to `#{equal}`",
      range: "`#{value}` is not in range `#{min} ~ #{max}`",
      positive: "`#{value}` is not a positive number",
      negative: "`#{value}` is not a negative number",
    },
    string: {
      maxLength: "#{field} cannot be longer than #{maxLength} characters",
      minLength: "#{field} must be at least #{minLength} characters",
      length: "#{field} must be exactly #{length} characters",
      match: "`#{value}` does not match pattern #{pattern}",
      uppercase: "`#{value}` must be all uppercase",
      lowercase: "`#{value}` must be all lowercased",
    },
    array: {
      length: "#{field} must be exactly #{length} in length",
      minLength: "#{field} cannot be less than #{minLength} in length",
      maxLength: "#{field} cannot be greater than #{maxLength} in length",
      includes: "#{field} is not includes #{includes}",
      deepEqual: "#{field} is not deep equal with #{deepEqual}",
      empty: "#{field} is not an empty array",
    },
    object: {
      deepEqual: "#{field} is not deep equal to expected value",
      hasKeys: "#{field} does not contain required fields",
      empty: "#{field} is not an empty object",
    },
    boolean: { true: "Expect true but got `#{value}`", false: "Expect false but got `#{value}`" },
  },
  te = function (t, n) {
    var o = this;
    ((this.getValidateMsg = function (s, a) {
      a === void 0 && (a = {});
      var f = Object.assign(Object.assign({}, a), { value: o.obj, field: o.field, type: o.type }),
        h = jo(o.validateMessages, s);
      return Le(h)
        ? h(f)
        : Me(h)
          ? h.replace(/\#\{.+?\}/g, function (j) {
              var x = j.slice(2, -1);
              if (x in f) {
                if (le(f[x]) || je(f[x]))
                  try {
                    return JSON.stringify(f[x]);
                  } catch {
                    return f[x];
                  }
                return String(f[x]);
              }
              return j;
            })
          : h;
    }),
      le(n) && Me(t) && n.trim
        ? (this.obj = t.trim())
        : le(n) && n.ignoreEmptyString && t === ""
          ? (this.obj = void 0)
          : (this.obj = t),
      (this.message = n.message),
      (this.type = n.type),
      (this.error = null),
      (this.field = n.field || n.type),
      (this.validateMessages = We(_o, n.validateMessages)));
  },
  _e = { not: { configurable: !0 }, isRequired: { configurable: !0 }, end: { configurable: !0 } };
_e.not.get = function () {
  return ((this._not = !this._not), this);
};
_e.isRequired.get = function () {
  if (fe(this.obj) || dt(this.obj)) {
    var e = this.getValidateMsg("required");
    this.error = {
      value: this.obj,
      type: this.type,
      requiredError: !0,
      message: this.message || (le(e) ? e : (this._not ? "[NOT MODE]:" : "") + e),
    };
  }
  return this;
};
_e.end.get = function () {
  return this.error;
};
te.prototype.addError = function (t) {
  !this.error &&
    t &&
    (this.error = {
      value: this.obj,
      type: this.type,
      message: this.message || (le(t) ? t : (this._not ? "[NOT MODE]:" : "") + t),
    });
};
te.prototype.validate = function (t, n) {
  var o = this._not ? t : !t;
  return (o && this.addError(n), this);
};
te.prototype.collect = function (t) {
  t && t(this.error);
};
Object.defineProperties(te.prototype, _e);
var Co = (function (e) {
    function t(o, s) {
      (e.call(this, o, Object.assign(Object.assign({}, s), { type: "string" })),
        this.validate(s && s.strict ? Me(this.obj) : !0, this.getValidateMsg("type.string")));
    }
    (e && (t.__proto__ = e), (t.prototype = Object.create(e && e.prototype)), (t.prototype.constructor = t));
    var n = { uppercase: { configurable: !0 }, lowercase: { configurable: !0 } };
    return (
      (t.prototype.maxLength = function (s) {
        return this.obj
          ? this.validate(this.obj.length <= s, this.getValidateMsg("string.maxLength", { maxLength: s }))
          : this;
      }),
      (t.prototype.minLength = function (s) {
        return this.obj
          ? this.validate(this.obj.length >= s, this.getValidateMsg("string.minLength", { minLength: s }))
          : this;
      }),
      (t.prototype.length = function (s) {
        return this.obj
          ? this.validate(this.obj.length === s, this.getValidateMsg("string.length", { length: s }))
          : this;
      }),
      (t.prototype.match = function (s) {
        var a = s instanceof RegExp;
        return (
          a && (s.lastIndex = 0),
          this.validate(
            this.obj === void 0 || (a && s.test(this.obj)),
            this.getValidateMsg("string.match", { pattern: s }),
          )
        );
      }),
      (n.uppercase.get = function () {
        return this.obj
          ? this.validate(this.obj.toUpperCase() === this.obj, this.getValidateMsg("string.uppercase"))
          : this;
      }),
      (n.lowercase.get = function () {
        return this.obj
          ? this.validate(this.obj.toLowerCase() === this.obj, this.getValidateMsg("string.lowercase"))
          : this;
      }),
      Object.defineProperties(t.prototype, n),
      t
    );
  })(te),
  To = (function (e) {
    function t(o, s) {
      (e.call(this, o, Object.assign(Object.assign({}, s), { type: "number" })),
        this.validate(s && s.strict ? yo(this.obj) : !0, this.getValidateMsg("type.number")));
    }
    (e && (t.__proto__ = e), (t.prototype = Object.create(e && e.prototype)), (t.prototype.constructor = t));
    var n = { positive: { configurable: !0 }, negative: { configurable: !0 } };
    return (
      (t.prototype.min = function (s) {
        return fe(this.obj) ? this : this.validate(this.obj >= s, this.getValidateMsg("number.min", { min: s }));
      }),
      (t.prototype.max = function (s) {
        return fe(this.obj) ? this : this.validate(this.obj <= s, this.getValidateMsg("number.max", { max: s }));
      }),
      (t.prototype.equal = function (s) {
        return fe(this.obj) ? this : this.validate(this.obj === s, this.getValidateMsg("number.equal", { equal: s }));
      }),
      (t.prototype.range = function (s, a) {
        return fe(this.obj)
          ? this
          : this.validate(this.obj >= s && this.obj <= a, this.getValidateMsg("number.range", { min: s, max: a }));
      }),
      (n.positive.get = function () {
        return fe(this.obj) ? this : this.validate(this.obj > 0, this.getValidateMsg("number.positive"));
      }),
      (n.negative.get = function () {
        return fe(this.obj) ? this : this.validate(this.obj < 0, this.getValidateMsg("number.negative"));
      }),
      Object.defineProperties(t.prototype, n),
      t
    );
  })(te),
  So = (function (e) {
    function t(o, s) {
      (e.call(this, o, Object.assign(Object.assign({}, s), { type: "array" })),
        this.validate(
          s && s.strict ? je(this.obj) : !0,
          this.getValidateMsg("type.array", { value: this.obj, type: this.type }),
        ));
    }
    (e && (t.__proto__ = e), (t.prototype = Object.create(e && e.prototype)), (t.prototype.constructor = t));
    var n = { empty: { configurable: !0 } };
    return (
      (t.prototype.length = function (s) {
        return this.obj
          ? this.validate(this.obj.length === s, this.getValidateMsg("array.length", { value: this.obj, length: s }))
          : this;
      }),
      (t.prototype.minLength = function (s) {
        return this.obj
          ? this.validate(
              this.obj.length >= s,
              this.getValidateMsg("array.minLength", { value: this.obj, minLength: s }),
            )
          : this;
      }),
      (t.prototype.maxLength = function (s) {
        return this.obj
          ? this.validate(
              this.obj.length <= s,
              this.getValidateMsg("array.maxLength", { value: this.obj, maxLength: s }),
            )
          : this;
      }),
      (t.prototype.includes = function (s) {
        var a = this;
        return this.obj
          ? this.validate(
              s.every(function (f) {
                return a.obj.indexOf(f) !== -1;
              }),
              this.getValidateMsg("array.includes", { value: this.obj, includes: s }),
            )
          : this;
      }),
      (t.prototype.deepEqual = function (s) {
        return this.obj
          ? this.validate(Pe(this.obj, s), this.getValidateMsg("array.deepEqual", { value: this.obj, deepEqual: s }))
          : this;
      }),
      (n.empty.get = function () {
        return this.validate(dt(this.obj), this.getValidateMsg("array.empty", { value: this.obj }));
      }),
      Object.defineProperties(t.prototype, n),
      t
    );
  })(te),
  $o = (function (e) {
    function t(o, s) {
      (e.call(this, o, Object.assign(Object.assign({}, s), { type: "object" })),
        this.validate(s && s.strict ? le(this.obj) : !0, this.getValidateMsg("type.object")));
    }
    (e && (t.__proto__ = e), (t.prototype = Object.create(e && e.prototype)), (t.prototype.constructor = t));
    var n = { empty: { configurable: !0 } };
    return (
      (t.prototype.deepEqual = function (s) {
        return this.obj
          ? this.validate(Pe(this.obj, s), this.getValidateMsg("object.deepEqual", { deepEqual: s }))
          : this;
      }),
      (t.prototype.hasKeys = function (s) {
        var a = this;
        return this.obj
          ? this.validate(
              s.every(function (f) {
                return a.obj[f];
              }),
              this.getValidateMsg("object.hasKeys", { keys: s }),
            )
          : this;
      }),
      (n.empty.get = function () {
        return this.validate(wo(this.obj), this.getValidateMsg("object.empty"));
      }),
      Object.defineProperties(t.prototype, n),
      t
    );
  })(te),
  Oo = (function (e) {
    function t(o, s) {
      (e.call(this, o, Object.assign(Object.assign({}, s), { type: "boolean" })),
        this.validate(s && s.strict ? ko(this.obj) : !0, this.getValidateMsg("type.boolean")));
    }
    (e && (t.__proto__ = e), (t.prototype = Object.create(e && e.prototype)), (t.prototype.constructor = t));
    var n = { true: { configurable: !0 }, false: { configurable: !0 } };
    return (
      (n.true.get = function () {
        return this.validate(this.obj === !0, this.getValidateMsg("boolean.true"));
      }),
      (n.false.get = function () {
        return this.validate(this.obj === !1, this.getValidateMsg("boolean.false"));
      }),
      Object.defineProperties(t.prototype, n),
      t
    );
  })(te),
  Eo =
    /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  xo = new RegExp(
    "^(?!mailto:)(?:(?:http|https|ftp)://)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-?)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$",
    "i",
  ),
  Mo = /^(2(5[0-5]{1}|[0-4]\d{1})|[0-1]?\d{1,2})(\.(2(5[0-5]{1}|[0-4]\d{1})|[0-1]?\d{1,2})){3}$/,
  Lo = (function (e) {
    function t(o, s) {
      e.call(this, o, Object.assign(Object.assign({}, s), { type: "type" }));
    }
    (e && (t.__proto__ = e), (t.prototype = Object.create(e && e.prototype)), (t.prototype.constructor = t));
    var n = { email: { configurable: !0 }, url: { configurable: !0 }, ip: { configurable: !0 } };
    return (
      (n.email.get = function () {
        return (
          (this.type = "email"),
          this.validate(this.obj === void 0 || Eo.test(this.obj), this.getValidateMsg("type.email"))
        );
      }),
      (n.url.get = function () {
        return (
          (this.type = "url"),
          this.validate(this.obj === void 0 || xo.test(this.obj), this.getValidateMsg("type.url"))
        );
      }),
      (n.ip.get = function () {
        return (
          (this.type = "ip"),
          this.validate(this.obj === void 0 || Mo.test(this.obj), this.getValidateMsg("type.ip"))
        );
      }),
      Object.defineProperties(t.prototype, n),
      t
    );
  })(te),
  Vo = (function (e) {
    function t(o, s) {
      e.call(this, o, Object.assign(Object.assign({}, s), { type: "custom" }));
    }
    (e && (t.__proto__ = e), (t.prototype = Object.create(e && e.prototype)), (t.prototype.constructor = t));
    var n = { validate: { configurable: !0 } };
    return (
      (n.validate.get = function () {
        var o = this;
        return function (s, a) {
          var f;
          if (s)
            return (
              (f = s(o.obj, o.addError.bind(o))),
              f && f.then
                ? (a &&
                    f.then(
                      function () {
                        a && a(o.error);
                      },
                      function (h) {
                        console.error(h);
                      },
                    ),
                  [f, o])
                : (a && a(o.error), o.error)
            );
        };
      }),
      Object.defineProperties(t.prototype, n),
      t
    );
  })(te),
  we = function (e, t) {
    return new ft(e, Object.assign({ field: "value" }, t));
  };
we.globalConfig = {};
we.setGlobalConfig = function (e) {
  we.globalConfig = e || {};
};
var ft = function (t, n) {
    var o = we.globalConfig,
      s = Object.assign(Object.assign(Object.assign({}, o), n), {
        validateMessages: We(o.validateMessages, n.validateMessages),
      });
    ((this.string = new Co(t, s)),
      (this.number = new To(t, s)),
      (this.array = new So(t, s)),
      (this.object = new $o(t, s)),
      (this.boolean = new Oo(t, s)),
      (this.type = new Lo(t, s)),
      (this.custom = new Vo(t, s)));
  },
  Ae = function (t, n) {
    (n === void 0 && (n = {}), (this.schema = t), (this.options = n));
  };
Ae.prototype.messages = function (t) {
  this.options = Object.assign(Object.assign({}, this.options), {
    validateMessages: We(this.options.validateMessages, t),
  });
};
Ae.prototype.validate = function (t, n) {
  var o = this;
  if (!le(t)) return;
  var s = [],
    a = null;
  function f(h, j) {
    (a || (a = {}), (!a[h] || j.requiredError) && (a[h] = j));
  }
  (this.schema &&
    Object.keys(this.schema).forEach(function (h) {
      if (je(o.schema[h]))
        for (
          var j = function (X) {
              var _ = o.schema[h][X],
                O = _.type,
                q = _.message;
              if (!O && !_.validator) throw "You must specify a type to field " + h + "!";
              var W = Object.assign(Object.assign({}, o.options), { message: q, field: h });
              (("ignoreEmptyString" in _) && (W.ignoreEmptyString = _.ignoreEmptyString),
                ("strict" in _) && (W.strict = _.strict));
              var F = new ft(t[h], W),
                m = F.type[O] || null;
              if (!m)
                if (_.validator) {
                  ((m = F.custom.validate(_.validator)),
                    Object.prototype.toString.call(m) === "[object Array]" && m[0].then
                      ? s.push({ function: m[0], _this: m[1], key: h })
                      : m && f(h, m));
                  return;
                } else m = F[O];
              if (
                (Object.keys(_).forEach(function (l) {
                  (_.required && (m = m.isRequired),
                    l !== "message" && m[l] && _[l] && typeof m[l] == "object" && (m = m[l]),
                    m[l] && _[l] !== void 0 && typeof m[l] == "function" && (m = m[l](_[l])));
                }),
                m.collect(function (l) {
                  l && f(h, l);
                }),
                a)
              )
                return "break";
            },
            x = 0;
          x < o.schema[h].length;
          x++
        ) {
          var N = j(x);
          if (N === "break") break;
        }
    }),
    s.length > 0
      ? Promise.all(
          s.map(function (h) {
            return h.function;
          }),
        ).then(function () {
          (s.forEach(function (h) {
            h._this.error && f(h.key, h._this.error);
          }),
            n && n(a));
        })
      : n && n(a));
};
const Fo = ie({
    name: "IconQuestionCircle",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = ve("icon"),
        o = V(() => [n, `${n}-question-circle`, { [`${n}-spin`]: e.spin }]),
        s = V(() => {
          const f = {};
          return (
            e.size && (f.fontSize = xe(e.size) ? `${e.size}px` : e.size),
            e.rotate && (f.transform = `rotate(${e.rotate}deg)`),
            f
          );
        });
      return {
        cls: o,
        innerStyle: s,
        onClick: (f) => {
          t("click", f);
        },
      };
    },
  }),
  Po = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Wo(e, t, n, o, s, a) {
  return (
    T(),
    U(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: J(e.cls),
        style: gt(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...f) => e.onClick && e.onClick(...f)),
      },
      t[1] ||
        (t[1] = [
          c("path", { d: "M42 24c0 9.941-8.059 18-18 18S6 33.941 6 24 14.059 6 24 6s18 8.059 18 18Z" }, null, -1),
          c(
            "path",
            {
              d: "M24.006 31v4.008m0-6.008L24 28c0-3 3-4 4.78-6.402C30.558 19.195 28.288 15 23.987 15c-4.014 0-5.382 2.548-5.388 4.514v.465",
            },
            null,
            -1,
          ),
        ]),
      14,
      Po,
    )
  );
}
var $e = me(Fo, [["render", Wo]]);
const Ao = Object.assign($e, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + $e.name, $e);
    },
  }),
  zo = ie({
    name: "FormItemLabel",
    components: { ResizeObserver: Lt, Tooltip: At, IconQuestionCircle: Ao },
    props: {
      required: { type: Boolean, default: !1 },
      showColon: { type: Boolean, default: !1 },
      component: { type: String, default: "label" },
      asteriskPosition: { type: String, default: "start" },
      tooltip: { type: String },
      attrs: Object,
    },
    setup() {
      const e = ve("form-item-label"),
        t = Ee(Fe, void 0),
        n = mt(),
        o = ge(),
        s = () => {
          o.value &&
            xe(o.value.offsetWidth) &&
            (t == null || t.setLabelWidth(o.value.offsetWidth, n == null ? void 0 : n.uid));
        };
      return (
        Ve(() => {
          o.value &&
            xe(o.value.offsetWidth) &&
            (t == null || t.setLabelWidth(o.value.offsetWidth, n == null ? void 0 : n.uid));
        }),
        ot(() => {
          t == null || t.removeLabelWidth(n == null ? void 0 : n.uid);
        }),
        { prefixCls: e, labelRef: o, handleResize: s }
      );
    },
  });
function Uo(e, t, n, o, s, a) {
  const f = G("icon-question-circle"),
    h = G("Tooltip"),
    j = G("ResizeObserver");
  return (
    T(),
    se(
      j,
      { onResize: e.handleResize },
      {
        default: d(() => [
          (T(),
          se(
            tt(e.component),
            ye({ ref: "labelRef", class: e.prefixCls }, e.attrs),
            {
              default: d(() => [
                e.required && e.asteriskPosition === "start"
                  ? (T(),
                    U(
                      "strong",
                      { key: 0, class: J(`${e.prefixCls}-required-symbol`) },
                      t[0] ||
                        (t[0] = [
                          c(
                            "svg",
                            { fill: "currentColor", viewBox: "0 0 1024 1024", width: "1em", height: "1em" },
                            [
                              c("path", {
                                d: "M583.338667 17.066667c18.773333 0 34.133333 15.36 34.133333 34.133333v349.013333l313.344-101.888a34.133333 34.133333 0 0 1 43.008 22.016l42.154667 129.706667a34.133333 34.133333 0 0 1-21.845334 43.178667l-315.733333 102.4 208.896 287.744a34.133333 34.133333 0 0 1-7.509333 47.786666l-110.421334 80.213334a34.133333 34.133333 0 0 1-47.786666-7.509334L505.685333 706.218667 288.426667 1005.226667a34.133333 34.133333 0 0 1-47.786667 7.509333l-110.421333-80.213333a34.133333 34.133333 0 0 1-7.509334-47.786667l214.186667-295.253333L29.013333 489.813333a34.133333 34.133333 0 0 1-22.016-43.008l42.154667-129.877333a34.133333 34.133333 0 0 1 43.008-22.016l320.512 104.106667L412.672 51.2c0-18.773333 15.36-34.133333 34.133333-34.133333h136.533334z",
                              }),
                            ],
                            -1,
                          ),
                        ]),
                      2,
                    ))
                  : ce("v-if", !0),
                ue(e.$slots, "default"),
                e.tooltip
                  ? (T(),
                    se(
                      h,
                      { key: 1, content: e.tooltip },
                      { default: d(() => [p(f, { class: J(`${e.prefixCls}-tooltip`) }, null, 8, ["class"])]), _: 1 },
                      8,
                      ["content"],
                    ))
                  : ce("v-if", !0),
                e.required && e.asteriskPosition === "end"
                  ? (T(),
                    U(
                      "strong",
                      { key: 2, class: J(`${e.prefixCls}-required-symbol`) },
                      t[1] ||
                        (t[1] = [
                          c(
                            "svg",
                            { fill: "currentColor", viewBox: "0 0 1024 1024", width: "1em", height: "1em" },
                            [
                              c("path", {
                                d: "M583.338667 17.066667c18.773333 0 34.133333 15.36 34.133333 34.133333v349.013333l313.344-101.888a34.133333 34.133333 0 0 1 43.008 22.016l42.154667 129.706667a34.133333 34.133333 0 0 1-21.845334 43.178667l-315.733333 102.4 208.896 287.744a34.133333 34.133333 0 0 1-7.509333 47.786666l-110.421334 80.213334a34.133333 34.133333 0 0 1-47.786666-7.509334L505.685333 706.218667 288.426667 1005.226667a34.133333 34.133333 0 0 1-47.786667 7.509333l-110.421333-80.213333a34.133333 34.133333 0 0 1-7.509334-47.786667l214.186667-295.253333L29.013333 489.813333a34.133333 34.133333 0 0 1-22.016-43.008l42.154667-129.877333a34.133333 34.133333 0 0 1 43.008-22.016l320.512 104.106667L412.672 51.2c0-18.773333 15.36-34.133333 34.133333-34.133333h136.533334z",
                              }),
                            ],
                            -1,
                          ),
                        ]),
                      2,
                    ))
                  : ce("v-if", !0),
                E(" " + I(e.showColon ? ":" : ""), 1),
              ]),
              _: 3,
            },
            16,
            ["class"],
          )),
        ]),
        _: 3,
      },
      8,
      ["onResize"],
    )
  );
}
var qo = me(zo, [["render", Uo]]);
const Ro = ie({
  name: "FormItemMessage",
  props: { error: { type: Array, default: () => [] }, help: String },
  setup() {
    return { prefixCls: ve("form-item-message") };
  },
});
function Io(e, t, n, o, s, a) {
  return e.error.length > 0
    ? (T(!0),
      U(
        st,
        { key: 0 },
        nt(
          e.error,
          (f) => (
            T(),
            se(
              Ie,
              { key: f, name: "form-blink", appear: "" },
              { default: d(() => [c("div", { role: "alert", class: J([e.prefixCls]) }, I(f), 3)]), _: 2 },
              1024,
            )
          ),
        ),
        128,
      ))
    : e.help || e.$slots.help
      ? (T(),
        se(
          Ie,
          { key: 1, name: "form-blink", appear: "" },
          {
            default: d(() => [
              c(
                "div",
                { class: J([e.prefixCls, `${e.prefixCls}-help`]) },
                [ue(e.$slots, "help", {}, () => [E(I(e.help), 1)])],
                2,
              ),
            ]),
            _: 3,
          },
        ))
      : ce("v-if", !0);
}
var No = me(Ro, [["render", Io]]);
const Ho = ie({
  name: "FormItem",
  components: { ArcoRow: Ut, ArcoCol: zt, FormItemLabel: qo, FormItemMessage: No },
  props: {
    field: { type: String, default: "" },
    label: String,
    tooltip: { type: String },
    showColon: { type: Boolean, default: !1 },
    noStyle: { type: Boolean, default: !1 },
    disabled: { type: Boolean, default: void 0 },
    help: String,
    extra: String,
    required: { type: Boolean, default: !1 },
    asteriskPosition: { type: String, default: "start" },
    rules: { type: [Object, Array] },
    validateStatus: { type: String },
    validateTrigger: { type: [String, Array], default: "change" },
    labelColProps: Object,
    wrapperColProps: Object,
    hideLabel: { type: Boolean, default: !1 },
    hideAsterisk: { type: Boolean, default: !1 },
    labelColStyle: Object,
    wrapperColStyle: Object,
    rowProps: Object,
    rowClass: [String, Array, Object],
    contentClass: [String, Array, Object],
    contentFlex: { type: Boolean, default: !0 },
    mergeProps: { type: [Boolean, Function], default: !0 },
    labelColFlex: { type: [Number, String] },
    feedback: { type: Boolean, default: !1 },
    labelComponent: { type: String, default: "label" },
    labelAttrs: Object,
  },
  setup(e) {
    const t = ve("form-item"),
      { field: n } = Oe(e),
      o = Ee(Fe, {}),
      { autoLabelWidth: s, layout: a } = Oe(o),
      { i18nMessage: f } = Vt(),
      h = V(() => {
        var i;
        const g = { ...((i = e.labelColProps) != null ? i : o.labelColProps) };
        return (e.labelColFlex ? (g.flex = e.labelColFlex) : o.autoLabelWidth && (g.flex = `${o.maxLabelWidth}px`), g);
      }),
      j = V(() => {
        var i;
        const g = { ...((i = e.wrapperColProps) != null ? i : o.wrapperColProps) };
        return (n.value && (g.id = ct(o.id, n.value)), (e.labelColFlex || o.autoLabelWidth) && (g.flex = "auto"), g);
      }),
      x = V(() => {
        var i;
        return (i = e.labelColStyle) != null ? i : o.labelColStyle;
      }),
      N = V(() => {
        var i;
        return (i = e.wrapperColStyle) != null ? i : o.wrapperColStyle;
      }),
      X = Qe(o.model, e.field),
      _ = re({}),
      O = re({}),
      q = V(() => ho(_)),
      W = V(() => go(O)),
      F = ge(!1),
      m = V(() => Qe(o.model, e.field)),
      l = V(() => {
        var i;
        return !!((i = e.disabled) != null ? i : o != null && o.disabled);
      }),
      S = V(() => {
        var i;
        return (i = e.validateStatus) != null ? i : q.value;
      }),
      $ = V(() => S.value === "error"),
      H = V(() => {
        var i, g, y;
        const L = [].concat(
            (y = (g = e.rules) != null ? g : (i = o == null ? void 0 : o.rules) == null ? void 0 : i[e.field]) != null
              ? y
              : [],
          ),
          D = L.some((Z) => Z.required);
        return e.required && !D ? [{ required: !0 }].concat(L) : L;
      }),
      Y = V(() => H.value.some((i) => i.required)),
      B = e.noStyle ? Ee(Ke, void 0) : void 0,
      z = (i, { status: g, message: y }) => {
        ((_[i] = g), (O[i] = y), e.noStyle && (B == null || B.updateValidateState(i, { status: g, message: y })));
      },
      P = V(() => (e.feedback && S.value ? S.value : void 0)),
      M = () => {
        var i;
        if (F.value) return Promise.resolve();
        const g = H.value;
        if (!n.value || g.length === 0) return (q.value && r(), Promise.resolve());
        const y = n.value,
          L = m.value;
        z(y, { status: "", message: "" });
        const D = new Ae(
          { [y]: g.map(({ ...Z }) => (!Z.type && !Z.validator && (Z.type = "string"), Z)) },
          { ignoreEmptyString: !0, validateMessages: (i = f.value.form) == null ? void 0 : i.validateMessages },
        );
        return new Promise((Z) => {
          D.validate({ [y]: L }, (R) => {
            var oe;
            const de = !!(R != null && R[y]);
            z(y, { status: de ? "error" : "", message: (oe = R == null ? void 0 : R[y].message) != null ? oe : "" });
            const pe = de
              ? {
                  label: e.label,
                  field: n.value,
                  value: R[y].value,
                  type: R[y].type,
                  isRequiredError: !!R[y].requiredError,
                  message: R[y].message,
                }
              : void 0;
            Z(pe);
          });
        });
      },
      K = V(() => [].concat(e.validateTrigger)),
      u = V(() =>
        K.value.reduce((i, g) => {
          switch (g) {
            case "change":
              return (
                (i.onChange = () => {
                  M();
                }),
                i
              );
            case "input":
              return (
                (i.onInput = () => {
                  Ce(() => {
                    M();
                  });
                }),
                i
              );
            case "focus":
              return (
                (i.onFocus = () => {
                  M();
                }),
                i
              );
            case "blur":
              return (
                (i.onBlur = () => {
                  M();
                }),
                i
              );
            default:
              return i;
          }
        }, {}),
      );
    et(
      Ke,
      re({ eventHandlers: u, size: o && bt(o, "size"), disabled: l, error: $, feedback: P, updateValidateState: z }),
    );
    const r = () => {
        n.value && z(n.value, { status: "", message: "" });
      },
      C = re({
        field: n,
        disabled: l,
        error: $,
        validate: M,
        clearValidate: r,
        resetField: () => {
          (r(),
            (F.value = !0),
            o != null && o.model && n.value && Ze(o.model, n.value, X),
            Ce(() => {
              F.value = !1;
            }));
        },
        setField: (i) => {
          var g, y;
          n.value &&
            ((F.value = !0),
            "value" in i && o != null && o.model && n.value && Ze(o.model, n.value, i.value),
            (i.status || i.message) &&
              z(n.value, { status: (g = i.status) != null ? g : "", message: (y = i.message) != null ? y : "" }),
            Ce(() => {
              F.value = !1;
            }));
        },
      });
    (Ve(() => {
      var i;
      C.field && ((i = o.addField) == null || i.call(o, C));
    }),
      ot(() => {
        var i;
        C.field && ((i = o.removeField) == null || i.call(o, C));
      }));
    const Q = V(() => [
        t,
        `${t}-layout-${o.layout}`,
        { [`${t}-error`]: $.value, [`${t}-status-${S.value}`]: !!S.value },
        e.rowClass,
      ]),
      v = V(() => [
        `${t}-label-col`,
        {
          [`${t}-label-col-left`]: o.labelAlign === "left",
          [`${t}-label-col-flex`]: o.autoLabelWidth || e.labelColFlex,
        },
      ]),
      k = V(() => [`${t}-wrapper-col`, { [`${t}-wrapper-col-flex`]: !j.value }]);
    return {
      prefixCls: t,
      cls: Q,
      isRequired: Y,
      isError: $,
      finalMessage: W,
      mergedLabelCol: h,
      mergedWrapperCol: j,
      labelColCls: v,
      autoLabelWidth: s,
      layout: a,
      mergedLabelStyle: x,
      wrapperColCls: k,
      mergedWrapperStyle: N,
    };
  },
});
function Bo(e, t, n, o, s, a) {
  var f;
  const h = G("FormItemLabel"),
    j = G("ArcoCol"),
    x = G("FormItemMessage"),
    N = G("ArcoRow");
  return e.noStyle
    ? ue(e.$slots, "default", { key: 0 })
    : (T(),
      se(
        N,
        ye(
          {
            key: 1,
            class: [e.cls, { [`${e.prefixCls}-has-help`]: !!((f = e.$slots.help) != null ? f : e.help) }],
            wrap: !(e.labelColFlex || e.autoLabelWidth),
            div: e.layout !== "horizontal" || e.hideLabel,
          },
          e.rowProps,
        ),
        {
          default: d(() => [
            e.hideLabel
              ? ce("v-if", !0)
              : (T(),
                se(
                  j,
                  ye({ key: 0, class: e.labelColCls, style: e.mergedLabelStyle }, e.mergedLabelCol),
                  {
                    default: d(() => [
                      p(
                        h,
                        {
                          required: e.hideAsterisk ? !1 : e.isRequired,
                          "show-colon": e.showColon,
                          "asterisk-position": e.asteriskPosition,
                          component: e.labelComponent,
                          attrs: e.labelAttrs,
                          tooltip: e.tooltip,
                        },
                        {
                          default: d(() => [
                            e.$slots.label || e.label
                              ? ue(e.$slots, "label", { key: 0 }, () => [E(I(e.label), 1)])
                              : ce("v-if", !0),
                          ]),
                          _: 3,
                        },
                        8,
                        ["required", "show-colon", "asterisk-position", "component", "attrs", "tooltip"],
                      ),
                    ]),
                    _: 3,
                  },
                  16,
                  ["class", "style"],
                )),
            p(
              j,
              ye({ class: e.wrapperColCls, style: e.mergedWrapperStyle }, e.mergedWrapperCol),
              {
                default: d(() => [
                  c(
                    "div",
                    { class: J(`${e.prefixCls}-content-wrapper`) },
                    [
                      c(
                        "div",
                        {
                          class: J([
                            `${e.prefixCls}-content`,
                            { [`${e.prefixCls}-content-flex`]: e.contentFlex },
                            e.contentClass,
                          ]),
                        },
                        [ue(e.$slots, "default")],
                        2,
                      ),
                    ],
                    2,
                  ),
                  e.isError || e.$slots.help || e.help
                    ? (T(),
                      se(
                        x,
                        { key: 0, error: e.finalMessage, help: e.help },
                        vt({ _: 2 }, [
                          e.$slots.help ? { name: "help", fn: d(() => [ue(e.$slots, "help")]), key: "0" } : void 0,
                        ]),
                        1032,
                        ["error", "help"],
                      ))
                    : ce("v-if", !0),
                  e.$slots.extra || e.extra
                    ? (T(),
                      U(
                        "div",
                        { key: 1, class: J(`${e.prefixCls}-extra`) },
                        [ue(e.$slots, "extra", {}, () => [E(I(e.extra), 1)])],
                        2,
                      ))
                    : ce("v-if", !0),
                ]),
                _: 3,
              },
              16,
              ["class", "style"],
            ),
          ]),
          _: 3,
        },
        16,
        ["class", "wrap", "div"],
      ));
}
var ke = me(Ho, [["render", Bo]]);
const Go = Object.assign(Se, {
    Item: ke,
    install: (e, t) => {
      Ft(e, t);
      const n = Pt(t);
      (e.component(n + Se.name, Se), e.component(n + ke.name, ke));
    },
  }),
  Ko = { class: "header-actions" },
  Qo = { class: "token-section" },
  Zo = { key: 0, class: "token-item" },
  Xo = { class: "token-info" },
  Yo = { class: "token-value" },
  Do = { key: 1, class: "empty-token" },
  Jo = { class: "token-section" },
  en = { class: "section-header" },
  tn = { class: "section-title" },
  on = { key: 0, class: "empty-state" },
  nn = { key: 1, class: "game-tokens-list" },
  sn = { class: "token-header" },
  rn = { class: "role-info" },
  ln = { class: "role-name-row" },
  an = { class: "role-name" },
  un = { class: "role-meta" },
  cn = { class: "last-used" },
  dn = { class: "token-actions" },
  fn = { class: "token-details" },
  pn = { class: "detail-item" },
  hn = { class: "detail-value" },
  gn = { class: "detail-item" },
  mn = { class: "detail-value" },
  vn = { class: "detail-item" },
  bn = { class: "detail-value" },
  yn = { class: "detail-item" },
  kn = {
    __name: "TokenManager",
    setup(e) {
      const t = rt(),
        n = lt(),
        o = wt(),
        s = jt(),
        a = ge(!1),
        f = (u) => {
          if (!u) return "";
          const r = u.length;
          return r <= 8 ? u : u.substring(0, 8) + "***" + u.substring(r - 8);
        },
        h = (u) => new Date(u).toLocaleString("zh-CN"),
        j = (u) => o.getWebSocketStatus(u),
        x = (u) => {
          switch (u) {
            case "connected":
              return "success";
            case "error":
              return "error";
            case "connecting":
              return "warning";
            default:
              return "default";
          }
        },
        N = (u) => {
          switch (u) {
            case "connected":
              return "已连接";
            case "error":
              return "连接错误";
            case "connecting":
              return "连接中";
            default:
              return "未连接";
          }
        },
        X = (u) => {
          switch (u) {
            case "connected":
              return oo;
            case "error":
              return Ht;
            case "connecting":
              return $t;
            default:
              return uo;
          }
        },
        _ = (u) => {
          switch (u) {
            case "url":
              return "URL导入";
            case "bin":
              return "Bin导入";
            case "wxQrcode":
              return "微信二维码";
            default:
              return "手动导入";
          }
        },
        O = () => {
          t.info("请使用页面顶部的Token导入功能添加新Token");
        },
        q = (u) => {
          const r = [
            { label: "编辑", key: "edit", icon: () => ne(ee, null, { default: () => ne(He) }) },
            { label: "复制Token", key: "copy", icon: () => ne(ee, null, { default: () => ne(Zt) }) },
          ];
          return (
            u.importMethod === "url" && u.sourceUrl
              ? r.unshift({
                  label: "从URL刷新",
                  key: "refresh-url",
                  icon: () => ne(ee, null, { default: () => ne(_t) }),
                })
              : r.unshift({ label: "刷新Token", key: "refresh", icon: () => ne(ee, null, { default: () => ne(Be) }) }),
            r.push(
              { type: "divider" },
              { label: "删除", key: "delete", icon: () => ne(ee, null, { default: () => ne(Ct) }) },
            ),
            r
          );
        },
        W = (u, r, b) => {
          switch (u) {
            case "edit":
              H();
              break;
            case "copy":
              Y(b.token);
              break;
            case "refresh":
              S(r);
              break;
            case "refresh-url":
              B(r, b);
              break;
            case "delete":
              $(r);
              break;
          }
        },
        F = () => {
          (o.initTokenManager(), t.success("Token数据已刷新"));
        },
        m = () => {
          n.warning({
            title: "清除用户Token",
            content: "确定要清除用户认证Token吗？这将会退出登录。",
            positiveText: "确定",
            negativeText: "取消",
            onPositiveClick: () => {
              (o.clearUserToken(), t.success("用户Token已清除"));
            },
          });
        },
        l = (u, r) => {
          if (j(u) === "connected") (o.closeWebSocketConnection(u), t.info("WebSocket连接已断开"));
          else
            try {
              (o.createWebSocketConnection(u, r.token, r.wsUrl), t.success("正在建立WebSocket连接..."));
            } catch {
              t.error("建立WebSocket连接失败");
            }
        },
        S = (u) => {
          const r = o.getGameToken(u);
          if (!r) {
            t.error("找不到对应的Token数据");
            return;
          }
          if (!r.sourceUrl) {
            t.warning("该Token没有配置源地址，无法重新生成。请手动重新导入Token。");
            return;
          }
          n.info({
            title: "重新获取Token",
            content: "确定要从源地址重新获取此角色的Token吗？",
            positiveText: "确定",
            negativeText: "取消",
            onPositiveClick: async () => {
              try {
                const b = t.loading("正在重新获取Token...", { duration: 0 });
                let w;
                const C = r.sourceUrl;
                if (
                  C.startsWith(window.location.origin) ||
                  C.startsWith("/") ||
                  C.startsWith("http://localhost") ||
                  C.startsWith("http://127.0.0.1")
                )
                  w = await fetch(C);
                else
                  try {
                    w = await fetch(C, { method: "GET", headers: { Accept: "application/json" }, mode: "cors" });
                  } catch (k) {
                    throw new Error(`跨域请求被阻止。请确保目标服务器支持CORS。错误详情: ${k.message}`);
                  }
                if (!w.ok) throw new Error(`请求失败: ${w.status} ${w.statusText}`);
                const v = await w.json();
                if (!v.token) throw new Error("返回数据中未找到token字段");
                (o.updateGameToken(u, {
                  token: v.token,
                  server: v.server || r.server,
                  regeneratedAt: new Date().toISOString(),
                  lastRefreshed: new Date().toISOString(),
                }),
                  o.getWebSocketStatus(u) === "connected" &&
                    (o.closeWebSocketConnection(u),
                    setTimeout(() => {
                      o.createWebSocketConnection(u, v.token, r.wsUrl);
                    }, 500)),
                  b.destroy(),
                  t.success("Token已成功重新获取"));
              } catch (b) {
                (console.error("重新获取Token失败:", b), t.error(b.message || "Token重新获取失败"));
              }
            },
          });
        },
        $ = (u) => {
          n.warning({
            title: "删除Token",
            content: "确定要删除此角色的游戏Token吗？这将断开相关的WebSocket连接。",
            positiveText: "确定删除",
            negativeText: "取消",
            onPositiveClick: () => {
              (o.removeGameToken(u), t.success("Token已删除"));
            },
          });
        },
        H = (u, r) => {
          t.info("编辑功能正在开发中");
        },
        Y = async (u) => {
          try {
            (await navigator.clipboard.writeText(u), t.success("Token已复制到剪贴板"));
          } catch {
            const b = document.createElement("textarea");
            ((b.value = u),
              document.body.appendChild(b),
              b.select(),
              document.execCommand("copy"),
              document.body.removeChild(b),
              t.success("Token已复制到剪贴板"));
          }
        },
        B = async (u, r) => {
          if (!r.sourceUrl) {
            t.warning("该Token没有配置源URL");
            return;
          }
          n.info({
            title: "从URL刷新Token",
            content: `确定要从源URL重新获取Token吗？
源地址：${r.sourceUrl}`,
            positiveText: "确定",
            negativeText: "取消",
            onPositiveClick: async () => {
              try {
                const b = t.loading("正在从URL获取新Token...", { duration: 0 });
                let w;
                if (
                  r.sourceUrl.startsWith(window.location.origin) ||
                  r.sourceUrl.startsWith("/") ||
                  r.sourceUrl.startsWith("http://localhost") ||
                  r.sourceUrl.startsWith("http://127.0.0.1")
                )
                  w = await fetch(r.sourceUrl);
                else {
                  const v = `/api/proxy?url=${encodeURIComponent(r.sourceUrl)}`;
                  w = await fetch(v);
                }
                if (!w.ok) throw new Error(`HTTP ${w.status}: ${w.statusText}`);
                const Q = await w.json();
                if (!Q.token) throw new Error("返回数据中未找到token字段");
                (o.updateGameToken(u, { token: Q.token, lastUsed: new Date().toISOString() }),
                  b.destroy(),
                  t.success("Token刷新成功"));
              } catch (b) {
                (console.error("URL刷新Token失败:", b), t.error("刷新失败: " + b.message));
              }
            },
          });
        },
        z = () => {
          try {
            const u = o.exportTokens(),
              r = JSON.stringify(u, null, 2),
              b = new Blob([r], { type: "application/json" }),
              w = document.createElement("a");
            ((w.href = URL.createObjectURL(b)),
              (w.download = `tokens_backup_${new Date().toISOString().split("T")[0]}.json`),
              w.click(),
              t.success("Token数据已导出"));
          } catch (u) {
            t.error("导出失败: " + u.message);
          }
        },
        P = ({ file: u }) => {
          const r = new FileReader();
          ((r.onload = (b) => {
            try {
              const w = JSON.parse(b.target.result),
                C = o.importTokens(w);
              C.success ? (t.success(C.message), s.fetchGameRoles()) : t.error(C.message);
            } catch {
              t.error("导入失败：文件格式错误");
            }
          }),
            r.readAsText(u.file));
        },
        M = () => {
          n.info({
            title: "清理过期Token",
            content: "确定要清理超过24小时未使用的Token吗？",
            positiveText: "确定",
            negativeText: "取消",
            onPositiveClick: () => {
              const u = o.cleanExpiredTokens();
              t.success(`已清理 ${u} 个过期Token`);
            },
          });
        },
        K = () => {
          n.error({
            title: "清除所有Token",
            content: "确定要清除所有游戏Token吗？这将断开所有WebSocket连接。此操作不可恢复！",
            positiveText: "确定清除",
            negativeText: "取消",
            onPositiveClick: () => {
              (o.clearAllGameTokens(), t.success("所有游戏Token已清除"));
            },
          });
        };
      return (u, r) => {
        const b = G("n-button"),
          w = G("n-upload"),
          C = G("n-tag"),
          Q = G("n-dropdown"),
          v = G("Menu"),
          k = at;
        return (
          T(),
          se(
            k,
            { class: "token-manager-card" },
            {
              extra: d(() => [
                c("div", Ko, [
                  p(
                    b,
                    { size: "small", onClick: F, disabled: a.value },
                    {
                      icon: d(() => [p(A(ee), null, { default: d(() => [p(A(Be))]), _: 1 })]),
                      default: d(() => [r[0] || (r[0] = c("span", { class: "btn-text" }, "刷新", -1))]),
                      _: 1,
                    },
                    8,
                    ["disabled"],
                  ),
                  p(
                    b,
                    { size: "small", type: "warning", onClick: z, disabled: a.value },
                    {
                      icon: d(() => [...(r[1] || (r[1] = [c("i", { class: "i-mdi:download" }, null, -1)]))]),
                      default: d(() => [r[2] || (r[2] = c("span", { class: "btn-text" }, "导出", -1))]),
                      _: 1,
                    },
                    8,
                    ["disabled"],
                  ),
                  p(
                    w,
                    { "show-file-list": !1, accept: ".json", onChange: P, disabled: a.value },
                    {
                      default: d(() => [
                        p(
                          b,
                          { size: "small", type: "info" },
                          {
                            icon: d(() => [p(A(ee), null, { default: d(() => [p(A(St))]), _: 1 })]),
                            default: d(() => [r[3] || (r[3] = c("span", { class: "btn-text" }, "导入", -1))]),
                            _: 1,
                          },
                        ),
                      ]),
                      _: 1,
                    },
                    8,
                    ["disabled"],
                  ),
                ]),
              ]),
              default: d(() => [
                c("div", Qo, [
                  r[6] || (r[6] = c("h4", { class: "section-title" }, "用户认证Token", -1)),
                  A(o).userToken
                    ? (T(),
                      U("div", Zo, [
                        c("div", Xo, [
                          r[4] || (r[4] = c("span", { class: "token-label" }, "Token:", -1)),
                          c("span", Yo, I(f(A(o).userToken)), 1),
                        ]),
                        p(
                          b,
                          { size: "tiny", type: "error", onClick: m, disabled: a.value },
                          { default: d(() => [...(r[5] || (r[5] = [E(" 清除 ", -1)]))]), _: 1 },
                          8,
                          ["disabled"],
                        ),
                      ]))
                    : (T(), U("div", Do, [p(A(Ne), { description: "未设置用户Token" })])),
                ]),
                c("div", Jo, [
                  c("div", en, [
                    c("h4", tn, [
                      r[7] || (r[7] = E(" 游戏角色Token ", -1)),
                      p(
                        C,
                        { size: "small", type: "info", class: "token-count-tag" },
                        { default: d(() => [E(I(Object.keys(A(o).gameTokens).length) + "个 ", 1)]), _: 1 },
                      ),
                    ]),
                    p(
                      b,
                      { size: "small", type: "primary", onClick: O, disabled: a.value },
                      {
                        icon: d(() => [p(A(ee), null, { default: d(() => [p(A(He))]), _: 1 })]),
                        default: d(() => [r[8] || (r[8] = E(" 添加Token ", -1))]),
                        _: 1,
                      },
                      8,
                      ["disabled"],
                    ),
                  ]),
                  Object.keys(A(o).gameTokens).length === 0
                    ? (T(), U("div", on, [p(A(Ne), { description: "暂无游戏Token" })]))
                    : (T(),
                      U("div", nn, [
                        (T(!0),
                        U(
                          st,
                          null,
                          nt(
                            A(o).gameTokens,
                            (i, g) => (
                              T(),
                              U(
                                "div",
                                { key: g, class: J(["game-token-item", { selected: A(yt) === g }]) },
                                [
                                  c("div", sn, [
                                    c("div", rn, [
                                      c("div", ln, [
                                        c("span", an, I(i.roleName), 1),
                                        p(
                                          C,
                                          { size: "small", type: "default", class: "server-tag" },
                                          { default: d(() => [E(I(i.server), 1)]), _: 2 },
                                          1024,
                                        ),
                                      ]),
                                      c("div", un, [
                                        c(
                                          "span",
                                          { class: J(["import-method-tag", `method-${i.importMethod}`]) },
                                          I(_(i.importMethod)),
                                          3,
                                        ),
                                        c("span", cn, " 最后使用: " + I(h(i.lastUsed)), 1),
                                      ]),
                                    ]),
                                    c("div", dn, [
                                      p(
                                        b,
                                        {
                                          size: "tiny",
                                          type: j(g) === "connected" ? "success" : "default",
                                          onClick: (y) => l(g, i),
                                          disabled: a.value,
                                        },
                                        {
                                          icon: d(() => [
                                            p(A(ee), null, { default: d(() => [(T(), se(tt(X(j(g)))))]), _: 2 }, 1024),
                                          ]),
                                          default: d(() => [E(" " + I(j(g) === "connected" ? "断开" : "连接"), 1)]),
                                          _: 2,
                                        },
                                        1032,
                                        ["type", "onClick", "disabled"],
                                      ),
                                      p(
                                        Q,
                                        { options: q(i), trigger: "click", onSelect: (y) => W(y, g, i) },
                                        {
                                          default: d(() => [
                                            p(
                                              b,
                                              { size: "tiny", type: "tertiary" },
                                              {
                                                icon: d(() => [p(A(ee), null, { default: d(() => [p(A(Tt))]), _: 1 })]),
                                                _: 1,
                                              },
                                            ),
                                          ]),
                                          _: 1,
                                        },
                                        8,
                                        ["options", "onSelect"],
                                      ),
                                    ]),
                                  ]),
                                  c("div", fn, [
                                    c("div", pn, [
                                      r[9] || (r[9] = c("span", { class: "detail-label" }, "Token:", -1)),
                                      c("span", hn, I(f(i.token)), 1),
                                    ]),
                                    c("div", gn, [
                                      r[10] || (r[10] = c("span", { class: "detail-label" }, "WebSocket URL:", -1)),
                                      c("span", mn, I(i.wsUrl || "默认"), 1),
                                    ]),
                                    c("div", vn, [
                                      r[11] || (r[11] = c("span", { class: "detail-label" }, "创建时间:", -1)),
                                      c("span", bn, I(h(i.createdAt)), 1),
                                    ]),
                                    c("div", yn, [
                                      r[12] || (r[12] = c("span", { class: "detail-label" }, "连接状态:", -1)),
                                      p(
                                        C,
                                        { size: "small", type: x(j(g)) },
                                        { default: d(() => [E(I(N(j(g))), 1)]), _: 2 },
                                        1032,
                                        ["type"],
                                      ),
                                    ]),
                                  ]),
                                ],
                                2,
                              )
                            ),
                          ),
                          128,
                        )),
                      ])),
                ]),
              ]),
              actions: d(() => [
                p(
                  Q,
                  { options: u.bulkOptions, onSelect: u.handleBulkAction },
                  {
                    default: d(() => [
                      p(
                        b,
                        { type: "primary" },
                        {
                          icon: d(() => [p(A(ee), null, { default: d(() => [p(v)]), _: 1 })]),
                          default: d(() => [r[13] || (r[13] = E(" 批量操作 ", -1))]),
                          _: 1,
                        },
                      ),
                    ]),
                    _: 1,
                  },
                  8,
                  ["options", "onSelect"],
                ),
                p(
                  b,
                  { type: "warning", onClick: M, disabled: a.value },
                  { default: d(() => [...(r[14] || (r[14] = [E(" 清理过期Token ", -1)]))]), _: 1 },
                  8,
                  ["disabled"],
                ),
                p(
                  b,
                  { type: "error", onClick: K, disabled: a.value },
                  { default: d(() => [...(r[15] || (r[15] = [E(" 清除所有Token ", -1)]))]), _: 1 },
                  8,
                  ["disabled"],
                ),
              ]),
              _: 1,
            },
          )
        );
      };
    },
  },
  wn = it(kn, [["__scopeId", "data-v-d3c7c1d5"]]),
  jn = { class: "profile-page" },
  _n = { class: "container" },
  Cn = { class: "security-items" },
  Tn = { class: "security-item" },
  Sn = { class: "security-item" },
  $n = { class: "security-item" },
  On = { class: "security-item danger" },
  En = {
    __name: "Profile",
    setup(e) {
      kt();
      const t = rt(),
        n = lt(),
        o = Ot(),
        s = ge(null),
        a = re({ username: "", email: "", nickname: "", phone: "", avatar: "" }),
        f = re({ currentPassword: "", newPassword: "", confirmPassword: "" }),
        h = re({ theme: "auto", language: "zh-CN", notifications: !0, autoExecute: !1 }),
        j = [
          { label: "跟随系统", value: "auto" },
          { label: "浅色主题", value: "light" },
          { label: "深色主题", value: "dark" },
        ],
        x = [
          { label: "简体中文", value: "zh-CN" },
          { label: "English", value: "en-US" },
        ],
        N = async () => {
          try {
            t.success("个人信息保存成功");
          } catch {
            t.error("保存失败，请稍后重试");
          }
        },
        X = async () => {
          if (s.value)
            try {
              (await s.value.validate(),
                t.success("密码修改成功"),
                Object.keys(f).forEach((m) => {
                  f[m] = "";
                }));
            } catch {}
        },
        _ = (m) => {
          ((h.theme = m),
            localStorage.setItem("theme", m),
            m === "dark"
              ? document.documentElement.setAttribute("data-theme", "dark")
              : m === "light"
                ? document.documentElement.removeAttribute("data-theme")
                : window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
                  ? document.documentElement.setAttribute("data-theme", "dark")
                  : document.documentElement.removeAttribute("data-theme"));
        },
        O = () => {
          t.info("两步验证设置功能开发中...");
        },
        q = () => {
          t.info("登录历史查看功能开发中...");
        },
        W = () => {
          t.info("数据导出功能开发中...");
        },
        F = () => {
          n.warning({
            title: "删除账户",
            content: "此操作将永久删除您的账户和所有数据，且无法恢复。确定要继续吗？",
            positiveText: "确定删除",
            negativeText: "取消",
            onPositiveClick: () => {
              t.error("账户删除功能暂未开放");
            },
          });
        };
      return (
        Ve(() => {
          o.userInfo && Object.assign(a, o.userInfo);
          const m = localStorage.getItem("userPreferences");
          if (m)
            try {
              Object.assign(h, JSON.parse(m));
            } catch (l) {
              console.error("解析用户偏好失败:", l);
            }
        }),
        (m, l) => {
          const S = qt,
            $ = ke,
            H = Go,
            Y = Wt,
            B = at,
            z = G("n-select"),
            P = G("n-switch"),
            M = wn,
            K = G("n-button");
          return (
            T(),
            U("div", jn, [
              c("div", _n, [
                l[25] ||
                  (l[25] = c(
                    "div",
                    { class: "page-header" },
                    [c("h1", null, "个人资料"), c("p", null, "管理您的账户信息和偏好设置")],
                    -1,
                  )),
                l[26] || (l[26] = c("h2", null, "基本信息", -1)),
                p(B, null, {
                  actions: d(() => [
                    p(
                      Y,
                      { type: "primary", onClick: N },
                      { default: d(() => [...(l[11] || (l[11] = [E(" 保存更改 ", -1)]))]), _: 1 },
                    ),
                  ]),
                  default: d(() => [
                    p(
                      H,
                      { model: a, "label-placement": "left", "label-width": "80px" },
                      {
                        default: d(() => [
                          p(
                            $,
                            { label: "用户名" },
                            {
                              default: d(() => [
                                p(
                                  S,
                                  {
                                    value: a.username,
                                    "onUpdate:value": l[0] || (l[0] = (u) => (a.username = u)),
                                    readonly: "",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          p(
                            $,
                            { label: "邮箱" },
                            {
                              default: d(() => [
                                p(
                                  S,
                                  { value: a.email, "onUpdate:value": l[1] || (l[1] = (u) => (a.email = u)) },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          p(
                            $,
                            { label: "昵称" },
                            {
                              default: d(() => [
                                p(
                                  S,
                                  {
                                    value: a.nickname,
                                    "onUpdate:value": l[2] || (l[2] = (u) => (a.nickname = u)),
                                    placeholder: "请输入昵称",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          p(
                            $,
                            { label: "手机" },
                            {
                              default: d(() => [
                                p(
                                  S,
                                  {
                                    value: a.phone,
                                    "onUpdate:value": l[3] || (l[3] = (u) => (a.phone = u)),
                                    placeholder: "请输入手机号",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                        ]),
                        _: 1,
                      },
                      8,
                      ["model"],
                    ),
                  ]),
                  _: 1,
                }),
                l[27] || (l[27] = c("h2", null, "密码修改", -1)),
                p(B, null, {
                  actions: d(() => [
                    p(
                      Y,
                      { type: "primary", onClick: X },
                      { default: d(() => [...(l[12] || (l[12] = [E(" 修改密码 ", -1)]))]), _: 1 },
                    ),
                  ]),
                  default: d(() => [
                    p(
                      H,
                      {
                        model: f,
                        ref_key: "passwordFormRef",
                        ref: s,
                        "label-placement": "left",
                        "label-width": "100px",
                      },
                      {
                        default: d(() => [
                          p(
                            $,
                            { label: "当前密码", prop: "currentPassword" },
                            {
                              default: d(() => [
                                p(
                                  S,
                                  {
                                    value: f.currentPassword,
                                    "onUpdate:value": l[4] || (l[4] = (u) => (f.currentPassword = u)),
                                    type: "password",
                                    placeholder: "请输入当前密码",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          p(
                            $,
                            { label: "新密码", prop: "newPassword" },
                            {
                              default: d(() => [
                                p(
                                  S,
                                  {
                                    value: f.newPassword,
                                    "onUpdate:value": l[5] || (l[5] = (u) => (f.newPassword = u)),
                                    type: "password",
                                    placeholder: "请输入新密码",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          p(
                            $,
                            { label: "确认新密码", prop: "confirmPassword" },
                            {
                              default: d(() => [
                                p(
                                  S,
                                  {
                                    value: f.confirmPassword,
                                    "onUpdate:value": l[6] || (l[6] = (u) => (f.confirmPassword = u)),
                                    type: "password",
                                    placeholder: "请再次输入新密码",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                        ]),
                        _: 1,
                      },
                      8,
                      ["model"],
                    ),
                  ]),
                  _: 1,
                }),
                l[28] || (l[28] = c("h2", null, "系统偏好", -1)),
                p(B, null, {
                  default: d(() => [
                    p(H, null, {
                      default: d(() => [
                        p(
                          $,
                          { label: "主题设置" },
                          {
                            extra: d(() => [...(l[13] || (l[13] = [E(" 选择您喜欢的界面主题 ", -1)]))]),
                            default: d(() => [
                              p(
                                z,
                                {
                                  value: h.theme,
                                  "onUpdate:value": [l[7] || (l[7] = (u) => (h.theme = u)), _],
                                  options: j,
                                },
                                null,
                                8,
                                ["value"],
                              ),
                            ]),
                            _: 1,
                          },
                        ),
                        p(
                          $,
                          { label: "语言设置" },
                          {
                            extra: d(() => [...(l[14] || (l[14] = [E(" 选择界面显示语言 ", -1)]))]),
                            default: d(() => [
                              p(
                                z,
                                {
                                  value: h.language,
                                  "onUpdate:value": l[8] || (l[8] = (u) => (h.language = u)),
                                  options: x,
                                },
                                null,
                                8,
                                ["value"],
                              ),
                            ]),
                            _: 1,
                          },
                        ),
                        p(
                          $,
                          { label: "通知设置" },
                          {
                            extra: d(() => [...(l[15] || (l[15] = [E(" 接收任务完成通知 ", -1)]))]),
                            default: d(() => [
                              p(
                                P,
                                {
                                  value: h.notifications,
                                  "onUpdate:value": l[9] || (l[9] = (u) => (h.notifications = u)),
                                },
                                null,
                                8,
                                ["value"],
                              ),
                            ]),
                            _: 1,
                          },
                        ),
                        p(
                          $,
                          { label: "自动执行" },
                          {
                            extra: d(() => [...(l[16] || (l[16] = [E(" 默认开启任务自动执行 ", -1)]))]),
                            default: d(() => [
                              p(
                                P,
                                {
                                  value: h.autoExecute,
                                  "onUpdate:value": l[10] || (l[10] = (u) => (h.autoExecute = u)),
                                },
                                null,
                                8,
                                ["value"],
                              ),
                            ]),
                            _: 1,
                          },
                        ),
                      ]),
                      _: 1,
                    }),
                  ]),
                  _: 1,
                }),
                l[29] || (l[29] = c("h2", null, "Token管理", -1)),
                p(M),
                l[30] || (l[30] = c("h2", null, "账户安全", -1)),
                p(B, null, {
                  default: d(() => [
                    c("div", Cn, [
                      c("div", Tn, [
                        l[18] ||
                          (l[18] = c(
                            "div",
                            { class: "security-info" },
                            [c("h3", null, "两步验证"), c("p", null, "为您的账户添加额外的安全保护")],
                            -1,
                          )),
                        p(K, { onClick: O }, { default: d(() => [...(l[17] || (l[17] = [E(" 设置 ", -1)]))]), _: 1 }),
                      ]),
                      c("div", Sn, [
                        l[20] ||
                          (l[20] = c(
                            "div",
                            { class: "security-info" },
                            [c("h3", null, "登录历史"), c("p", null, "查看最近的登录记录")],
                            -1,
                          )),
                        p(K, { onClick: q }, { default: d(() => [...(l[19] || (l[19] = [E(" 查看 ", -1)]))]), _: 1 }),
                      ]),
                      c("div", $n, [
                        l[22] ||
                          (l[22] = c(
                            "div",
                            { class: "security-info" },
                            [c("h3", null, "数据导出"), c("p", null, "导出您的所有数据")],
                            -1,
                          )),
                        p(K, { onClick: W }, { default: d(() => [...(l[21] || (l[21] = [E(" 导出 ", -1)]))]), _: 1 }),
                      ]),
                      c("div", On, [
                        l[24] ||
                          (l[24] = c(
                            "div",
                            { class: "security-info" },
                            [c("h3", null, "删除账户"), c("p", null, "永久删除您的账户和所有数据")],
                            -1,
                          )),
                        p(
                          K,
                          { type: "error", onClick: F },
                          { default: d(() => [...(l[23] || (l[23] = [E(" 删除 ", -1)]))]), _: 1 },
                        ),
                      ]),
                    ]),
                  ]),
                  _: 1,
                }),
              ]),
            ])
          );
        }
      );
    },
  },
  Hn = it(En, [["__scopeId", "data-v-67100bbd"]]);
export { Hn as default };
