import { aF as m, r as c } from "./index-UoU16364.js";
import { u as i } from "./localTokenManager-BQJEcmfy.js";
const G = m("gameRoles", () => {
  const a = c([]),
    o = c(!1),
    l = c(null),
    n = i();
  return {
    gameRoles: a,
    isLoading: o,
    selectedRole: l,
    fetchGameRoles: async () => {
      try {
        o.value = !0;
        const e = localStorage.getItem("gameRoles");
        if (e)
          try {
            a.value = JSON.parse(e);
          } catch (t) {
            (console.error("解析游戏角色数据失败:", t), (a.value = []));
          }
        else a.value = [];
        return { success: !0 };
      } catch (e) {
        return (console.error("获取游戏角色失败:", e), { success: !1, message: "本地数据读取失败" });
      } finally {
        o.value = !1;
      }
    },
    addGameRole: async (e) => {
      try {
        o.value = !0;
        const t = "role_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9),
          s = "game_token_" + Date.now() + "_" + Math.random().toString(36).substr(2, 16),
          r = {
            ...e,
            id: t,
            createdAt: new Date().toISOString(),
            isActive: !1,
            exp: 0,
            gold: 1e3,
            vip: !1,
            avatar: e.avatar || "/icons/xiaoyugan.png",
          };
        (a.value.push(r), localStorage.setItem("gameRoles", JSON.stringify(a.value)));
        const u = {
          token: s,
          roleId: t,
          roleName: r.name,
          server: r.server,
          wsUrl: null,
          createdAt: new Date().toISOString(),
          isActive: !0,
        };
        return (n.addGameToken(t, u), { success: !0, message: "添加角色成功，已生成游戏token" });
      } catch (t) {
        return (console.error("添加游戏角色失败:", t), { success: !1, message: "添加角色失败" });
      } finally {
        o.value = !1;
      }
    },
    updateGameRole: async (e, t) => {
      try {
        o.value = !0;
        const s = a.value.findIndex((r) => r.id === e);
        if (s !== -1) {
          ((a.value[s] = { ...a.value[s], ...t, updatedAt: new Date().toISOString() }),
            localStorage.setItem("gameRoles", JSON.stringify(a.value)));
          const r = n.getGameToken(e);
          return (
            r && n.updateGameToken(e, { roleName: t.name || r.roleName, server: t.server || r.server }),
            { success: !0, message: "更新角色成功" }
          );
        } else return { success: !1, message: "角色不存在" };
      } catch (s) {
        return (console.error("更新游戏角色失败:", s), { success: !1, message: "更新角色失败" });
      } finally {
        o.value = !1;
      }
    },
    deleteGameRole: async (e) => {
      try {
        return (
          (o.value = !0),
          (a.value = a.value.filter((t) => t.id !== e)),
          localStorage.setItem("gameRoles", JSON.stringify(a.value)),
          n.removeGameToken(e),
          l.value && l.value.id === e && ((l.value = null), localStorage.removeItem("selectedRole")),
          { success: !0, message: "删除角色成功，已清理相关token" }
        );
      } catch (t) {
        return (console.error("删除游戏角色失败:", t), { success: !1, message: "删除角色失败" });
      } finally {
        o.value = !1;
      }
    },
    selectRole: (e) => {
      ((l.value = e), localStorage.setItem("selectedRole", JSON.stringify(e)));
      const t = n.getGameToken(e.id);
      if (t && t.token)
        try {
          (n.createWebSocketConnection(e.id, t.token, t.wsUrl), console.log(`已为角色 ${e.name} 建立WebSocket连接`));
        } catch (s) {
          console.error(`建立WebSocket连接失败 [${e.name}]:`, s);
        }
    },
    initGameRoles: () => {
      const e = localStorage.getItem("gameRoles"),
        t = localStorage.getItem("selectedRole");
      if (e)
        try {
          a.value = JSON.parse(e);
        } catch (s) {
          console.error("解析缓存的游戏角色数据失败:", s);
        }
      if (t)
        try {
          l.value = JSON.parse(t);
        } catch (s) {
          console.error("解析缓存的选中角色数据失败:", s);
        }
    },
  };
});
export { G as u };
