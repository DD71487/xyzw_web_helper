import { U as h, _ as f, g as k, c as d } from "./index-7YDlkBnY.js";
import { k as m, c as p, h as y, a as g, X as w, E as C, p as s } from "./index-UoU16364.js";
const E = {
    ENTER: "Enter",
    ESC: "Escape",
    SPACE: " ",
    ARROW_UP: "ArrowUp",
    ARROW_DOWN: "ArrowDown",
    ARROW_LEFT: "ArrowLeft",
    ARROW_RIGHT: "ArrowRight",
  },
  u = (e) => JSON.stringify({ key: e.key, ctrl: !!e.ctrl, shift: !!e.shift, alt: !!e.alt, meta: !!e.meta }),
  N = (e) => {
    const n = {};
    return (
      e.forEach((t, o) => {
        const r = h(o) ? { key: o } : o;
        n[u(r)] = t;
      }),
      (t) => {
        const o = u({ key: t.key, ctrl: t.ctrlKey, shift: t.shiftKey, alt: t.altKey, meta: t.metaKey }),
          r = n[o];
        r && (t.stopPropagation(), r(t));
      }
    );
  },
  $ = m({
    name: "IconRight",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: n }) {
      const t = k("icon"),
        o = s(() => [t, `${t}-right`, { [`${t}-spin`]: e.spin }]),
        r = s(() => {
          const i = {};
          return (
            e.size && (i.fontSize = d(e.size) ? `${e.size}px` : e.size),
            e.rotate && (i.transform = `rotate(${e.rotate}deg)`),
            i
          );
        });
      return {
        cls: o,
        innerStyle: r,
        onClick: (i) => {
          n("click", i);
        },
      };
    },
  }),
  S = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function b(e, n, t, o, r, l) {
  return (
    y(),
    p(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: w(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: n[0] || (n[0] = (...i) => e.onClick && e.onClick(...i)),
      },
      n[1] || (n[1] = [g("path", { d: "m16 39.513 15.556-15.557L16 8.4" }, null, -1)]),
      14,
      S,
    )
  );
}
var a = f($, [["render", b]]);
const j = Object.assign(a, {
    install: (e, n) => {
      var t;
      const o = (t = n == null ? void 0 : n.iconPrefix) != null ? t : "";
      e.component(o + a.name, a);
    },
  }),
  R = m({
    name: "IconLeft",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: n }) {
      const t = k("icon"),
        o = s(() => [t, `${t}-left`, { [`${t}-spin`]: e.spin }]),
        r = s(() => {
          const i = {};
          return (
            e.size && (i.fontSize = d(e.size) ? `${e.size}px` : e.size),
            e.rotate && (i.transform = `rotate(${e.rotate}deg)`),
            i
          );
        });
      return {
        cls: o,
        innerStyle: r,
        onClick: (i) => {
          n("click", i);
        },
      };
    },
  }),
  v = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function z(e, n, t, o, r, l) {
  return (
    y(),
    p(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: w(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: n[0] || (n[0] = (...i) => e.onClick && e.onClick(...i)),
      },
      n[1] || (n[1] = [g("path", { d: "M32 8.4 16.444 23.956 32 39.513" }, null, -1)]),
      14,
      v,
    )
  );
}
var c = f(R, [["render", z]]);
const A = Object.assign(c, {
  install: (e, n) => {
    var t;
    const o = (t = n == null ? void 0 : n.iconPrefix) != null ? t : "";
    e.component(o + c.name, c);
  },
});
export { j as I, E as K, A as a, N as g };
