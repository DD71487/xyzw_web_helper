const __vite__mapDeps = (
  i,
  m = __vite__mapDeps,
  d = m.f ||
    (m.f = [
      "assets/wsAgent-W2DBAgyE.js",
      "assets/index-UoU16364.js",
      "assets/index-CM9NKNN3.css",
      "assets/gameCommands-Crdy2ccc.js",
    ]),
) => i.map((i) => d[i]);
import { aF as z, r as A, p as _, an as D } from "./index-UoU16364.js";
const F = "xyzw_token_db",
  H = 1,
  h = "kv",
  w = "gameTokens";
function J() {
  return new Promise((o, s) => {
    const n = indexedDB.open(F, H);
    ((n.onupgradeneeded = (k) => {
      const r = n.result;
      (r.objectStoreNames.contains(h) || r.createObjectStore(h, { keyPath: "key" }),
        r.objectStoreNames.contains(w) || r.createObjectStore(w, { keyPath: "roleId" }));
    }),
      (n.onsuccess = () => o(n.result)),
      (n.onerror = () => s(n.error)));
  });
}
async function T(o, s, n) {
  const k = await J();
  return new Promise((r, m) => {
    const a = k.transaction(o, s),
      S = a.objectStore(o),
      d = n(S);
    ((a.oncomplete = () => r(d)), (a.onerror = () => m(a.error)), (a.onabort = () => m(a.error)));
  });
}
async function N(o) {
  return T(
    h,
    "readonly",
    (s) =>
      new Promise((n, k) => {
        const r = s.get(o);
        ((r.onsuccess = () => n(r.result ? r.result.value : void 0)), (r.onerror = () => k(r.error)));
      }),
  );
}
async function Q(o, s) {
  return T(h, "readwrite", (n) => {
    n.put({ key: o, value: s });
  });
}
async function X(o) {
  return T(h, "readwrite", (s) => {
    s.delete(o);
  });
}
async function x() {
  return N("userToken");
}
async function W(o) {
  return Q("userToken", o);
}
async function Y() {
  return X("userToken");
}
async function P() {
  return T(
    w,
    "readonly",
    (o) =>
      new Promise((s, n) => {
        const k = o.getAll();
        ((k.onsuccess = () => {
          const r = k.result || [],
            m = {};
          (r.forEach((a) => {
            a && a.roleId && (m[a.roleId] = a);
          }),
            s(m));
        }),
          (k.onerror = () => n(k.error)));
      }),
  );
}
async function y(o, s) {
  return T(w, "readwrite", (n) => {
    n.put({ ...s, roleId: o });
  });
}
async function G(o) {
  return T(w, "readwrite", (s) => {
    s.delete(o);
  });
}
async function Z() {
  return T(w, "readwrite", (o) => {
    o.clear();
  });
}
async function I() {
  try {
    const o = await P(),
      s = o && Object.keys(o).length > 0,
      k = !!(await x());
    if (s || k) return { migrated: !1 };
    const r = localStorage.getItem("userToken"),
      m = localStorage.getItem("gameTokens");
    let a = {};
    try {
      a = m ? JSON.parse(m) : {};
    } catch {
      a = {};
    }
    if (!(r || (a && Object.keys(a).length > 0))) return { migrated: !1 };
    r && (await W(r));
    for (const [d, p] of Object.entries(a || {})) await y(d, p);
    return { migrated: !0 };
  } catch (o) {
    return (console.warn("Token DB migration skipped:", o), { migrated: !1, error: o == null ? void 0 : o.message });
  }
}
const oe = z("localToken", () => {
  const o = A(null),
    s = A({}),
    n = A({}),
    k = _(() => !!o.value),
    r = _(() => Object.keys(s.value).length > 0),
    m = (e) => {
      ((o.value = e), W(e).catch((t) => console.warn("保存用户Token失败:", t)));
    },
    a = () => {
      ((o.value = null), Y().catch((e) => console.warn("清除用户Token失败:", e)));
    },
    S = (e, t) => {
      const c = { ...t, roleId: e, createdAt: new Date().toISOString(), lastUsed: new Date().toISOString() };
      return ((s.value[e] = c), y(e, c).catch((u) => console.warn("保存游戏Token失败:", u)), c);
    },
    d = (e) => {
      const t = s.value[e];
      return (
        t && ((t.lastUsed = new Date().toISOString()), y(e, t).catch((c) => console.warn("更新游戏Token失败:", c))),
        t
      );
    },
    p = (e, t) => {
      s.value[e] &&
        ((s.value[e] = { ...s.value[e], ...t, updatedAt: new Date().toISOString() }),
        y(e, s.value[e]).catch((c) => console.warn("更新游戏Token失败:", c)));
    },
    $ = (e) => {
      (delete s.value[e], G(e).catch((t) => console.warn("删除游戏Token失败:", t)), n.value[e] && v(e));
    },
    j = () => {
      (Object.keys(n.value).forEach((e) => {
        v(e);
      }),
        (s.value = {}),
        Z().catch((e) => console.warn("清空游戏Token失败:", e)));
    },
    C = async (e, t, c = null) => {
      n.value[e] && v(e);
      try {
        const { WsAgent: u } = await D(
            async () => {
              const { WsAgent: g } = await import("./wsAgent-W2DBAgyE.js");
              return { WsAgent: g };
            },
            __vite__mapDeps([0, 1, 2]),
          ),
          { gameCommands: l } = await D(
            async () => {
              const { gameCommands: g } = await import("./gameCommands-Crdy2ccc.js");
              return { gameCommands: g };
            },
            __vite__mapDeps([3, 1, 2]),
          );
        let i = t;
        try {
          const g = t.replace(/^data:.*base64,/, "").trim(),
            b = atob(g);
          try {
            const U = JSON.parse(b);
            i = U.token || U.gameToken || b;
          } catch {
            i = b;
          }
        } catch (g) {
          (console.warn("Base64解析失败，使用原始token:", g.message), (i = t));
        }
        const f = new u({
          heartbeatInterval: 2e3,
          queueInterval: 50,
          channel: "x",
          autoReconnect: !0,
          maxReconnectAttempts: 5,
        });
        ((f.onOpen = () => {
          ((n.value[e].status = "connected"),
            (n.value[e].connectedAt = new Date().toISOString()),
            setTimeout(() => {
              (f.send(l.role_getroleinfo(0, 0, { roleId: e })), f.send(l.system_getdatabundlever()));
            }, 1e3));
        }),
          (f.onMessage = (g) => {
            g.cmd && R(e, g);
          }),
          (f.onError = (g) => {
            (console.error(`❌ WebSocket错误 [${e}]:`, g),
              n.value[e] && ((n.value[e].status = "error"), (n.value[e].lastError = g.message)));
          }),
          (f.onClose = (g) => {
            n.value[e] && (n.value[e].status = "disconnected");
          }),
          (f.onReconnect = (g) => {
            n.value[e] && ((n.value[e].status = "reconnecting"), (n.value[e].reconnectAttempt = g));
          }));
        const E = c || u.buildUrl("wss://xxz-xyzw.hortorgames.com/agent", { p: i, e: "x", lang: "chinese" });
        return (
          (n.value[e] = {
            agent: f,
            gameCommands: l,
            status: "connecting",
            roleId: e,
            wsUrl: E,
            actualToken: i,
            createdAt: new Date().toISOString(),
            lastError: null,
            reconnectAttempt: 0,
          }),
          await f.connect(E),
          f
        );
      } catch (u) {
        return (
          console.error(`创建WebSocket连接失败 [${e}]:`, u),
          n.value[e] && ((n.value[e].status = "error"), (n.value[e].lastError = u.message)),
          null
        );
      }
    },
    R = (e, t) => {
      const { cmd: c, body: u } = t;
    },
    v = (e) => {
      const t = n.value[e];
      t &&
        (t.agent && typeof t.agent.close == "function"
          ? t.agent.close()
          : t.connection && typeof t.connection.close == "function" && t.connection.close(),
        delete n.value[e]);
    },
    B = (e) => {
      var t;
      return ((t = n.value[e]) == null ? void 0 : t.status) || "disconnected";
    },
    V = (e, t, c = {}) => {
      const u = n.value[e];
      if (!u || !u.agent || u.status !== "connected") return !1;
      try {
        const { gameCommands: l } = u;
        if (typeof l[t] == "function") {
          const i = l[t](0, 0, c);
          return (u.agent.send(i), !0);
        } else return (console.error(`未知的游戏命令: ${t}`), !1);
      } catch (l) {
        return (console.error(`发送游戏命令失败 [${e}] ${t}:`, l), !1);
      }
    },
    M = async (e, t, c = {}, u = 8e3) => {
      const l = n.value[e];
      if (!l || !l.agent) throw new Error(`角色 ${e} 的WebSocket连接不存在`);
      if (l.status !== "connected") throw new Error(`角色 ${e} 的WebSocket未连接`);
      try {
        const { gameCommands: i } = l;
        if (typeof i[t] == "function") return await l.agent.sendWithPromise({ cmd: t, body: c, timeout: u });
        throw new Error(`未知的游戏命令: ${t}`);
      } catch (i) {
        throw (console.error(`发送游戏命令失败 [${e}] ${t}:`, i), i);
      }
    },
    K = (e) => {
      const t = n.value[e];
      return t
        ? {
            status: t.status,
            roleId: t.roleId,
            wsUrl: t.wsUrl,
            connectedAt: t.connectedAt,
            createdAt: t.createdAt,
            lastError: t.lastError,
            reconnectAttempt: t.reconnectAttempt,
            agentStatus: t.agent ? t.agent.getStatus() : null,
          }
        : { status: "disconnected", roleId: e, error: "连接不存在" };
    },
    q = () => ({ userToken: o.value, gameTokens: s.value, exportedAt: new Date().toISOString() }),
    L = (e) => {
      try {
        return (
          e.userToken && m(e.userToken),
          e.gameTokens &&
            ((s.value = e.gameTokens),
            Object.entries(s.value).forEach(([t, c]) => {
              y(t, { ...c, roleId: t }).catch(() => {});
            })),
          { success: !0, message: "Token导入成功" }
        );
      } catch (t) {
        return (console.error("Token导入失败:", t), { success: !1, message: "导入失败：数据格式错误" });
      }
    },
    O = () => {
      const e = new Date(),
        t = new Date(e.getTime() - 24 * 60 * 60 * 1e3),
        c = {};
      let u = 0;
      return (
        Object.entries(s.value).forEach(([l, i]) => {
          new Date(i.lastUsed || i.createdAt) > t ? (c[l] = i) : (u++, n.value[l] && v(l), G(l).catch(() => {}));
        }),
        (s.value = c),
        u
      );
    };
  return {
    userToken: o,
    gameTokens: s,
    wsConnections: n,
    isUserAuthenticated: k,
    hasGameTokens: r,
    setUserToken: m,
    clearUserToken: a,
    addGameToken: S,
    getGameToken: d,
    updateGameToken: p,
    removeGameToken: $,
    clearAllGameTokens: j,
    createWebSocketConnection: C,
    closeWebSocketConnection: v,
    getWebSocketStatus: B,
    getWebSocketDetails: K,
    sendGameCommand: V,
    sendGameCommandWithPromise: M,
    exportTokens: q,
    importTokens: L,
    cleanExpiredTokens: O,
    initTokenManager: async () => {
      try {
        await I();
        const [e, t] = await Promise.all([x(), P()]);
        (e && (o.value = e), (s.value = t || {}), O());
      } catch (e) {
        (console.warn("初始化Token管理器失败，回退为空:", e), (o.value = null), (s.value = {}));
      }
    },
  };
});
export { oe as u };
