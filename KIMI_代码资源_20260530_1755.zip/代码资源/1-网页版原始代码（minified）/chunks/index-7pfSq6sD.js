import {
  k as de,
  c as $,
  h as c,
  a as I,
  X,
  E as k,
  p as g,
  r as f,
  n as Ae,
  o as Ee,
  aa as Pe,
  y as pe,
  d as z,
  e as A,
  w as E,
  aI as Ie,
  ab as x,
  A as m,
  ag as ee,
  b as P,
  ad as ye,
  ac as oe,
  B as Ce,
  _ as le,
  i as ne,
  t as te,
  aJ as ke,
  $ as Le,
} from "./index-UoU16364.js";
import {
  _ as he,
  g as Be,
  c as ue,
  v as Ne,
  w as je,
  x as U,
  y as ce,
  z as Ve,
  A as Fe,
  C as He,
  I as Ke,
  h as We,
  B as Ge,
  D as Ye,
  m as Re,
  E as Xe,
  G as Ue,
  H as Ze,
  l as F,
  J as ge,
  r as be,
  K as Je,
  M as qe,
  s as _e,
  a as Qe,
  L as xe,
  N as ae,
  p as eo,
} from "./index-7YDlkBnY.js";
import { K as oo } from "./index-DMjs3mWk.js";
const lo = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  no = I(
    "path",
    {
      d: "M408 480H184a72 72 0 0 1-72-72V184a72 72 0 0 1 72-72h224a72 72 0 0 1 72 72v224a72 72 0 0 1-72 72z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  to = I(
    "path",
    {
      d: "M160 80h235.88A72.12 72.12 0 0 0 328 32H104a72 72 0 0 0-72 72v224a72.12 72.12 0 0 0 48 67.88V160a80 80 0 0 1 80-80z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  ao = [no, to],
  ko = de({
    name: "Copy",
    render: function (o, n) {
      return (c(), $("svg", lo, ao));
    },
  }),
  so = de({
    name: "IconInfoCircleFill",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: o }) {
      const n = Be("icon"),
        r = g(() => [n, `${n}-info-circle-fill`, { [`${n}-spin`]: e.spin }]),
        u = g(() => {
          const t = {};
          return (
            e.size && (t.fontSize = ue(e.size) ? `${e.size}px` : e.size),
            e.rotate && (t.transform = `rotate(${e.rotate}deg)`),
            t
          );
        });
      return {
        cls: r,
        innerStyle: u,
        onClick: (t) => {
          o("click", t);
        },
      };
    },
  }),
  io = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function ro(e, o, n, r, u, l) {
  return (
    c(),
    $(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: k(e.cls),
        style: X(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: o[0] || (o[0] = (...t) => e.onClick && e.onClick(...t)),
      },
      o[1] ||
        (o[1] = [
          I(
            "path",
            {
              "fill-rule": "evenodd",
              "clip-rule": "evenodd",
              d: "M24 44c11.046 0 20-8.954 20-20S35.046 4 24 4 4 12.954 4 24s8.954 20 20 20Zm2-30a1 1 0 0 0-1-1h-2a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1h2a1 1 0 0 0 1-1v-2Zm0 17h1a1 1 0 0 1 1 1v2a1 1 0 0 1-1 1h-6a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h1v-8a1 1 0 0 1-1-1v-2a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v11Z",
              fill: "currentColor",
              stroke: "none",
            },
            null,
            -1,
          ),
        ]),
      14,
      io,
    )
  );
}
var se = he(so, [["render", ro]]);
const uo = Object.assign(se, {
    install: (e, o) => {
      var n;
      const r = (n = o == null ? void 0 : o.iconPrefix) != null ? n : "";
      e.component(r + se.name, se);
    },
  }),
  co = (e) => {
    const o = f(!1),
      n = { overflow: "", width: "", boxSizing: "" };
    return {
      setOverflowHidden: () => {
        if (e.value) {
          const l = e.value;
          if (!o.value && l.style.overflow !== "hidden") {
            const t = Ne(l);
            (t > 0 || je(l)) &&
              ((n.overflow = l.style.overflow),
              (n.width = l.style.width),
              (n.boxSizing = l.style.boxSizing),
              (l.style.overflow = "hidden"),
              (l.style.width = `${l.offsetWidth - t}px`),
              (l.style.boxSizing = "border-box"),
              (o.value = !0));
          }
        }
      },
      resetOverflow: () => {
        if (e.value && o.value) {
          const l = e.value;
          ((l.style.overflow = n.overflow),
            (l.style.width = n.width),
            (l.style.boxSizing = n.boxSizing),
            (o.value = !1));
        }
      },
    };
  },
  fo = ({ modalRef: e, wrapperRef: o, draggable: n, alignCenter: r }) => {
    const u = f(!1),
      l = f([0, 0]),
      t = f([0, 0]),
      p = f(),
      y = f([0, 0]),
      a = f([0, 0]),
      d = () => {
        var i, O, T;
        if (o.value && e.value) {
          const { top: h, left: B } = o.value.getBoundingClientRect(),
            { clientWidth: H, clientHeight: K } = o.value,
            { top: L, left: W, width: N, height: j } = e.value.getBoundingClientRect(),
            M = r.value ? 0 : (i = e.value) == null ? void 0 : i.offsetTop,
            C = W - B,
            G = L - h - M;
          (C !== ((O = t.value) == null ? void 0 : O[0]) || G !== ((T = t.value) == null ? void 0 : T[1])) &&
            (t.value = [C, G]);
          const V = H > N ? H - N : 0,
            Y = K > j ? K - j - M : 0;
          ((V !== a.value[0] || Y !== a.value[1]) && (a.value = [V, Y]), M && (y.value = [0, 0 - M]));
        }
      },
      v = (i) => {
        n.value &&
          (i.preventDefault(),
          (u.value = !0),
          d(),
          (l.value = [i.x, i.y]),
          U(window, "mousemove", b),
          U(window, "mouseup", w),
          U(window, "contextmenu", w));
      },
      b = (i) => {
        if (u.value) {
          const O = i.x - l.value[0],
            T = i.y - l.value[1];
          let h = t.value[0] + O,
            B = t.value[1] + T;
          (h < y.value[0] && (h = y.value[0]),
            h > a.value[0] && (h = a.value[0]),
            B < y.value[1] && (B = y.value[1]),
            B > a.value[1] && (B = a.value[1]),
            (p.value = [h, B]));
        }
      },
      w = () => {
        ((u.value = !1), ce(window, "mousemove", b), ce(window, "mouseup", w));
      };
    return { position: p, handleMoveDown: v };
  };
var vo = de({
  name: "Modal",
  components: {
    ClientOnly: Ye,
    ArcoButton: Ge,
    IconHover: We,
    IconClose: Ke,
    IconInfoCircleFill: uo,
    IconCheckCircleFill: He,
    IconExclamationCircleFill: Fe,
    IconCloseCircleFill: Ve,
  },
  inheritAttrs: !1,
  props: {
    visible: { type: Boolean, default: void 0 },
    defaultVisible: { type: Boolean, default: !1 },
    width: { type: [Number, String] },
    top: { type: [Number, String] },
    mask: { type: Boolean, default: !0 },
    title: { type: String },
    titleAlign: { type: String, default: "center" },
    alignCenter: { type: Boolean, default: !0 },
    unmountOnClose: Boolean,
    maskClosable: { type: Boolean, default: !0 },
    hideCancel: { type: Boolean, default: !1 },
    simple: { type: Boolean, default: (e) => e.notice },
    closable: { type: Boolean, default: !0 },
    okText: String,
    cancelText: String,
    okLoading: { type: Boolean, default: !1 },
    okButtonProps: { type: Object },
    cancelButtonProps: { type: Object },
    footer: { type: Boolean, default: !0 },
    renderToBody: { type: Boolean, default: !0 },
    popupContainer: { type: [String, Object], default: "body" },
    maskStyle: { type: Object },
    modalClass: { type: [String, Array] },
    modalStyle: { type: Object },
    onBeforeOk: { type: Function },
    onBeforeCancel: { type: Function },
    escToClose: { type: Boolean, default: !0 },
    draggable: { type: Boolean, default: !1 },
    fullscreen: { type: Boolean, default: !1 },
    maskAnimationName: { type: String, default: (e) => (e.fullscreen ? "fade-in-standard" : "fade-modal") },
    modalAnimationName: { type: String, default: (e) => (e.fullscreen ? "zoom-in" : "zoom-modal") },
    bodyClass: { type: [String, Array] },
    bodyStyle: { type: [String, Object, Array] },
    messageType: { type: String },
    hideTitle: { type: Boolean, default: !1 },
  },
  emits: {
    "update:visible": (e) => !0,
    ok: (e) => !0,
    cancel: (e) => !0,
    open: () => !0,
    close: () => !0,
    beforeOpen: () => !0,
    beforeClose: () => !0,
  },
  setup(e, { emit: o }) {
    const { fullscreen: n, popupContainer: r, alignCenter: u } = Ae(e),
      l = Be("modal"),
      { t } = Re(),
      p = f(),
      y = f(),
      a = f(e.defaultVisible),
      d = g(() => {
        var s;
        return (s = e.visible) != null ? s : a.value;
      }),
      v = f(!1),
      b = g(() => e.okLoading || v.value),
      w = g(() => e.draggable && !e.fullscreen),
      { teleportContainer: i, containerRef: O } = Xe({ popupContainer: r, visible: d }),
      T = f(d.value),
      h = g(() => e.okText || t("modal.okText")),
      B = g(() => e.cancelText || t("modal.cancelText")),
      { zIndex: H, isLastDialog: K } = Ue("dialog", { visible: d });
    let L = !1;
    const W = (s) => {
        e.escToClose && s.key === oo.ESC && K() && J(s);
      },
      N = () => {
        e.escToClose && !L && ((L = !0), U(document.documentElement, "keydown", W));
      },
      j = () => {
        ((L = !1), ce(document.documentElement, "keydown", W));
      };
    let M = 0;
    const { position: C, handleMoveDown: G } = fo({ wrapperRef: p, modalRef: y, draggable: w, alignCenter: u }),
      V = () => {
        (M++, v.value && (v.value = !1), (a.value = !1), o("update:visible", !1));
      },
      Y = async (s) => {
        const S = M,
          R = await new Promise(async (_) => {
            var me;
            if (F(e.onBeforeOk)) {
              let D = e.onBeforeOk((Q = !0) => _(Q));
              if (((ge(D) || !be(D)) && (v.value = !0), ge(D)))
                try {
                  D = (me = await D) != null ? me : !0;
                } catch (Q) {
                  throw ((D = !1), Q);
                }
              be(D) && _(D);
            } else _(!0);
          });
        S === M && (R ? (o("ok", s), V()) : v.value && (v.value = !1));
      },
      J = (s) => {
        var S;
        let R = !0;
        (F(e.onBeforeCancel) && (R = (S = e.onBeforeCancel()) != null ? S : !1), R && (o("cancel", s), V()));
      },
      q = f(!1),
      Se = (s) => {
        s.target === p.value && (q.value = !0);
      },
      $e = (s) => {
        e.mask && e.maskClosable && q.value && J(s);
      },
      Oe = () => {
        d.value &&
          (!Je(p.value, document.activeElement) &&
            document.activeElement instanceof HTMLElement &&
            document.activeElement.blur(),
          o("open"));
      },
      Te = () => {
        d.value || (w.value && (C.value = void 0), (T.value = !1), ve(), o("close"));
      },
      { setOverflowHidden: fe, resetOverflow: ve } = co(O);
    (Ee(() => {
      ((O.value = Ze(e.popupContainer)), d.value && (fe(), e.escToClose && N()));
    }),
      Pe(() => {
        (ve(), j());
      }),
      pe(d, (s) => {
        (a.value !== s && (a.value = s),
          s ? (o("beforeOpen"), (T.value = !0), (q.value = !1), fe(), N()) : (o("beforeClose"), j()));
      }),
      pe(n, () => {
        C.value && (C.value = void 0);
      }));
    const Me = g(() => [
        `${l}-wrapper`,
        { [`${l}-wrapper-align-center`]: e.alignCenter && !e.fullscreen, [`${l}-wrapper-moved`]: !!C.value },
      ]),
      De = g(() => [
        `${l}`,
        e.modalClass,
        { [`${l}-simple`]: e.simple, [`${l}-draggable`]: w.value, [`${l}-fullscreen`]: e.fullscreen },
      ]),
      ze = g(() => {
        var s;
        const S = { ...((s = e.modalStyle) != null ? s : {}) };
        return (
          e.width && !e.fullscreen && (S.width = ue(e.width) ? `${e.width}px` : e.width),
          !e.alignCenter && e.top && (S.top = ue(e.top) ? `${e.top}px` : e.top),
          C.value && (S.transform = `translate(${C.value[0]}px, ${C.value[1]}px)`),
          S
        );
      });
    return {
      prefixCls: l,
      mounted: T,
      computedVisible: d,
      containerRef: O,
      wrapperRef: p,
      mergedModalStyle: ze,
      okDisplayText: h,
      cancelDisplayText: B,
      zIndex: H,
      handleOk: Y,
      handleCancel: J,
      handleMaskClick: $e,
      handleMaskMouseDown: Se,
      handleOpen: Oe,
      handleClose: Te,
      mergedOkLoading: b,
      modalRef: y,
      wrapperCls: Me,
      modalCls: De,
      teleportContainer: i,
      handleMoveDown: G,
    };
  },
});
function mo(e, o, n, r, u, l) {
  const t = z("icon-info-circle-fill"),
    p = z("icon-check-circle-fill"),
    y = z("icon-exclamation-circle-fill"),
    a = z("icon-close-circle-fill"),
    d = z("icon-close"),
    v = z("icon-hover"),
    b = z("arco-button"),
    w = z("client-only");
  return (
    c(),
    A(w, null, {
      default: E(() => [
        (c(),
        A(
          Ie,
          { to: e.teleportContainer, disabled: !e.renderToBody },
          [
            !e.unmountOnClose || e.computedVisible || e.mounted
              ? x(
                  (c(),
                  $(
                    "div",
                    ee({ key: 0, class: `${e.prefixCls}-container`, style: { zIndex: e.zIndex } }, e.$attrs),
                    [
                      P(
                        ye,
                        { name: e.maskAnimationName, appear: "" },
                        {
                          default: E(() => [
                            e.mask
                              ? x(
                                  (c(),
                                  $(
                                    "div",
                                    { key: 0, ref: "maskRef", class: k(`${e.prefixCls}-mask`), style: X(e.maskStyle) },
                                    null,
                                    6,
                                  )),
                                  [[oe, e.computedVisible]],
                                )
                              : m("v-if", !0),
                          ]),
                          _: 1,
                        },
                        8,
                        ["name"],
                      ),
                      I(
                        "div",
                        {
                          ref: "wrapperRef",
                          class: k(e.wrapperCls),
                          onClick:
                            o[2] || (o[2] = Ce((...i) => e.handleMaskClick && e.handleMaskClick(...i), ["self"])),
                          onMousedown:
                            o[3] ||
                            (o[3] = Ce((...i) => e.handleMaskMouseDown && e.handleMaskMouseDown(...i), ["self"])),
                        },
                        [
                          P(
                            ye,
                            {
                              name: e.modalAnimationName,
                              appear: "",
                              onAfterEnter: e.handleOpen,
                              onAfterLeave: e.handleClose,
                              persisted: "",
                            },
                            {
                              default: E(() => [
                                x(
                                  I(
                                    "div",
                                    { ref: "modalRef", class: k(e.modalCls), style: X(e.mergedModalStyle) },
                                    [
                                      !e.hideTitle && (e.$slots.title || e.title || e.closable)
                                        ? (c(),
                                          $(
                                            "div",
                                            {
                                              key: 0,
                                              class: k(`${e.prefixCls}-header`),
                                              onMousedown:
                                                o[1] || (o[1] = (...i) => e.handleMoveDown && e.handleMoveDown(...i)),
                                            },
                                            [
                                              e.$slots.title || e.title
                                                ? (c(),
                                                  $(
                                                    "div",
                                                    {
                                                      key: 0,
                                                      class: k([
                                                        `${e.prefixCls}-title`,
                                                        `${e.prefixCls}-title-align-${e.titleAlign}`,
                                                      ]),
                                                    },
                                                    [
                                                      e.messageType
                                                        ? (c(),
                                                          $(
                                                            "div",
                                                            { key: 0, class: k(`${e.prefixCls}-title-icon`) },
                                                            [
                                                              e.messageType === "info"
                                                                ? (c(), A(t, { key: 0 }))
                                                                : m("v-if", !0),
                                                              e.messageType === "success"
                                                                ? (c(), A(p, { key: 1 }))
                                                                : m("v-if", !0),
                                                              e.messageType === "warning"
                                                                ? (c(), A(y, { key: 2 }))
                                                                : m("v-if", !0),
                                                              e.messageType === "error"
                                                                ? (c(), A(a, { key: 3 }))
                                                                : m("v-if", !0),
                                                            ],
                                                            2,
                                                          ))
                                                        : m("v-if", !0),
                                                      le(e.$slots, "title", {}, () => [ne(te(e.title), 1)]),
                                                    ],
                                                    2,
                                                  ))
                                                : m("v-if", !0),
                                              !e.simple && e.closable
                                                ? (c(),
                                                  $(
                                                    "div",
                                                    {
                                                      key: 1,
                                                      tabindex: "-1",
                                                      role: "button",
                                                      "aria-label": "Close",
                                                      class: k(`${e.prefixCls}-close-btn`),
                                                      onClick:
                                                        o[0] ||
                                                        (o[0] = (...i) => e.handleCancel && e.handleCancel(...i)),
                                                    },
                                                    [P(v, null, { default: E(() => [P(d)]), _: 1 })],
                                                    2,
                                                  ))
                                                : m("v-if", !0),
                                            ],
                                            34,
                                          ))
                                        : m("v-if", !0),
                                      I(
                                        "div",
                                        { class: k([`${e.prefixCls}-body`, e.bodyClass]), style: X(e.bodyStyle) },
                                        [le(e.$slots, "default")],
                                        6,
                                      ),
                                      e.footer
                                        ? (c(),
                                          $(
                                            "div",
                                            { key: 1, class: k(`${e.prefixCls}-footer`) },
                                            [
                                              le(e.$slots, "footer", {}, () => [
                                                e.hideCancel
                                                  ? m("v-if", !0)
                                                  : (c(),
                                                    A(
                                                      b,
                                                      ee({ key: 0 }, e.cancelButtonProps, { onClick: e.handleCancel }),
                                                      { default: E(() => [ne(te(e.cancelDisplayText), 1)]), _: 1 },
                                                      16,
                                                      ["onClick"],
                                                    )),
                                                P(
                                                  b,
                                                  ee({ type: "primary" }, e.okButtonProps, {
                                                    loading: e.mergedOkLoading,
                                                    onClick: e.handleOk,
                                                  }),
                                                  { default: E(() => [ne(te(e.okDisplayText), 1)]), _: 1 },
                                                  16,
                                                  ["loading", "onClick"],
                                                ),
                                              ]),
                                            ],
                                            2,
                                          ))
                                        : m("v-if", !0),
                                    ],
                                    6,
                                  ),
                                  [[oe, e.computedVisible]],
                                ),
                              ]),
                              _: 3,
                            },
                            8,
                            ["name", "onAfterEnter", "onAfterLeave"],
                          ),
                        ],
                        34,
                      ),
                    ],
                    16,
                  )),
                  [[oe, e.computedVisible || e.mounted]],
                )
              : m("v-if", !0),
          ],
          8,
          ["to", "disabled"],
        )),
      ]),
      _: 3,
    })
  );
}
var Z = he(vo, [["render", mo]]);
const ie = (e, o) => {
    let n = xe("modal");
    const r = () => {
        (a.component && (a.component.props.visible = !1), F(e.onOk) && e.onOk());
      },
      u = () => {
        (a.component && (a.component.props.visible = !1), F(e.onCancel) && e.onCancel());
      },
      l = async () => {
        (await Le(), n && (ke(null, n), document.body.removeChild(n)), (n = null), F(e.onClose) && e.onClose());
      },
      t = () => {
        a.component && (a.component.props.visible = !1);
      },
      p = (d) => {
        a.component &&
          Object.entries(d).forEach(([v, b]) => {
            a.component.props[v] = b;
          });
      },
      a = P(
        Z,
        {
          ...{ visible: !0, renderToBody: !1, unmountOnClose: !0, onOk: r, onCancel: u, onClose: l },
          ...eo(e, ["content", "title", "footer", "visible", "unmountOnClose", "onOk", "onCancel", "onClose"]),
          footer: typeof e.footer == "boolean" ? e.footer : void 0,
        },
        { default: ae(e.content), title: ae(e.title), footer: typeof e.footer != "boolean" ? ae(e.footer) : void 0 },
      );
    return (
      (o ?? we._context) && (a.appContext = o ?? we._context),
      ke(a, n),
      document.body.appendChild(n),
      { close: t, update: p }
    );
  },
  re = {
    open: ie,
    confirm: (e, o) => {
      const n = { simple: !0, messageType: "warning", ...e };
      return ie(n, o);
    },
    ...qe.reduce(
      (e, o) => (
        (e[o] = (n, r) => {
          const u = { simple: !0, hideCancel: !0, messageType: o, ...n };
          return ie(u, r);
        }),
        e
      ),
      {},
    ),
  },
  we = Object.assign(Z, {
    ...re,
    install: (e, o) => {
      _e(e, o);
      const n = Qe(o);
      e.component(n + Z.name, Z);
      const r = {};
      for (const u of Object.keys(re)) r[u] = (l, t = e._context) => re[u](l, t);
      e.config.globalProperties.$modal = r;
    },
    _context: null,
  });
export { ko as C, we as M };
