import { k as t, c as o, h as n, a as e } from "./index-UoU16364.js";
const r = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  s = e(
    "path",
    {
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-miterlimit": "10",
      "stroke-width": "48",
      d: "M88 152h336",
    },
    null,
    -1,
  ),
  i = e(
    "path",
    {
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-miterlimit": "10",
      "stroke-width": "48",
      d: "M88 256h336",
    },
    null,
    -1,
  ),
  l = e(
    "path",
    {
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-miterlimit": "10",
      "stroke-width": "48",
      d: "M88 360h336",
    },
    null,
    -1,
  ),
  c = [s, i, l],
  m = t({
    name: "Menu",
    render: function (h, a) {
      return (n(), o("svg", r, c));
    },
  });
export { m as M };
