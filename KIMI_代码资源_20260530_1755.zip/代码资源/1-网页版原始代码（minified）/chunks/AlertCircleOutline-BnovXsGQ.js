import { k as t, c as o, h as n, a as e } from "./index-UoU16364.js";
const r = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  l = e(
    "path",
    {
      d: "M448 256c0-106-86-192-192-192S64 150 64 256s86 192 192 192s192-86 192-192z",
      fill: "none",
      stroke: "currentColor",
      "stroke-miterlimit": "10",
      "stroke-width": "32",
    },
    null,
    -1,
  ),
  s = e(
    "path",
    {
      d: "M250.26 166.05L256 288l5.73-121.95a5.74 5.74 0 0 0-5.79-6h0a5.74 5.74 0 0 0-5.68 6z",
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "32",
    },
    null,
    -1,
  ),
  i = e("path", { d: "M256 367.91a20 20 0 1 1 20-20a20 20 0 0 1-20 20z", fill: "currentColor" }, null, -1),
  c = [l, s, i],
  u = t({
    name: "AlertCircleOutline",
    render: function (d, h) {
      return (n(), o("svg", r, c));
    },
  });
export { u as A };
