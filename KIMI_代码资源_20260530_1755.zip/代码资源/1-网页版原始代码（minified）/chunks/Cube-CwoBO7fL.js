import { k as o, c as t, a as e, h as n } from "./index-UoU16364.js";
const a = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  l = e(
    "path",
    {
      d: "M440.9 136.3a4 4 0 0 0 0-6.91L288.16 40.65a64.14 64.14 0 0 0-64.33 0L71.12 129.39a4 4 0 0 0 0 6.91L254 243.88a4 4 0 0 0 4.06 0z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  r = e(
    "path",
    {
      d: "M54 163.51a4 4 0 0 0-6 3.49v173.89a48 48 0 0 0 23.84 41.39L234 479.51a4 4 0 0 0 6-3.46V274.3a4 4 0 0 0-2-3.46z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  s = e(
    "path",
    {
      d: "M272 275v201a4 4 0 0 0 6 3.46l162.15-97.23A48 48 0 0 0 464 340.89V167a4 4 0 0 0-6-3.45l-184 108a4 4 0 0 0-2 3.45z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  c = [l, r, s],
  u = o({
    name: "Cube",
    render: function (d, h) {
      return (n(), t("svg", a, c));
    },
  });
export { u as C };
