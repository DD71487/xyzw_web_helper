import {
  g as z,
  j as Xe,
  k as Ie,
  Q as P,
  p as Ye,
  a1 as ke,
  q as _e,
  l as Je,
  h as ge,
  I as et,
  F as tt,
  f as nt,
  $ as at,
  _ as O,
  c as R,
  B as lt,
  o as Le,
  n as it,
  s as je,
  a as Ne,
  Y as st,
  t as rt,
  U as xe,
} from "./index-7YDlkBnY.js";
import {
  r as L,
  k as S,
  n as ne,
  p as u,
  y as Ce,
  b as p,
  ag as ee,
  i as ot,
  $ as ut,
  c as A,
  h as B,
  a as H,
  X as q,
  E as T,
  F as me,
  d as Q,
  e as X,
  aj as ct,
  w as G,
  _ as E,
  A as Ee,
  B as Se,
  z as Re,
  ah as Oe,
  b0 as dt,
  o as ft,
  M as vt,
  al as pt,
} from "./index-UoU16364.js";
const mt = { key: "Enter" },
  Ht = { key: "Backspace" };
function yt(e) {
  const t = L();
  function n() {
    if (!e.value) return;
    const { selectionStart: r, selectionEnd: o, value: a } = e.value;
    if (r == null || o == null) return;
    const f = a.slice(0, Math.max(0, r)),
      s = a.slice(Math.max(0, o));
    t.value = { selectionStart: r, selectionEnd: o, value: a, beforeTxt: f, afterTxt: s };
  }
  function i() {
    if (!e.value || !t.value) return;
    const { value: r } = e.value,
      { beforeTxt: o, afterTxt: a, selectionStart: f } = t.value;
    if (!o || !a || !f) return;
    let s = r.length;
    if (r.endsWith(a)) s = r.length - a.length;
    else if (r.startsWith(o)) s = o.length;
    else {
      const v = o[f - 1],
        g = r.indexOf(v, f - 1);
      g !== -1 && (s = g + 1);
    }
    e.value.setSelectionRange(s, s);
  }
  return [n, i];
}
var W = S({
  name: "Input",
  inheritAttrs: !1,
  props: {
    modelValue: String,
    defaultValue: { type: String, default: "" },
    size: { type: String },
    allowClear: { type: Boolean, default: !1 },
    disabled: { type: Boolean, default: !1 },
    readonly: { type: Boolean, default: !1 },
    error: { type: Boolean, default: !1 },
    placeholder: String,
    maxLength: { type: [Number, Object], default: 0 },
    showWordLimit: { type: Boolean, default: !1 },
    wordLength: { type: Function },
    wordSlice: { type: Function },
    inputAttrs: { type: Object },
    type: { type: String, default: "text" },
    prepend: String,
    append: String,
  },
  emits: {
    "update:modelValue": (e) => !0,
    input: (e, t) => !0,
    change: (e, t) => !0,
    pressEnter: (e) => !0,
    clear: (e) => !0,
    focus: (e) => !0,
    blur: (e) => !0,
  },
  setup(e, { emit: t, slots: n, attrs: i }) {
    const { size: r, disabled: o, error: a, modelValue: f } = ne(e),
      s = z("input"),
      v = L(),
      {
        mergedSize: g,
        mergedDisabled: c,
        mergedError: h,
        feedback: b,
        eventHandlers: m,
      } = Xe({ size: r, disabled: o, error: a }),
      { mergedSize: k } = Ie(g),
      [j, K] = yt(v),
      V = L(e.defaultValue),
      x = u(() => {
        var l;
        return (l = e.modelValue) != null ? l : V.value;
      });
    let M = x.value;
    (Ce(f, (l) => {
      (nt(l) || at(l)) && (V.value = "");
    }),
      Ce(x, (l, d) => {
        M = d;
      }));
    const I = L(!1),
      D = u(() => e.allowClear && !e.readonly && !c.value && !!x.value),
      w = L(!1),
      $ = L(""),
      F = (l) => {
        var d;
        return Je(e.wordLength) ? e.wordLength(l) : (d = l.length) != null ? d : 0;
      },
      U = u(() => F(x.value)),
      he = u(() => h.value || !!(P(e.maxLength) && e.maxLength.errorOnly && U.value > C.value)),
      ae = u(() => P(e.maxLength) && !!e.maxLength.errorOnly),
      C = u(() => (P(e.maxLength) ? e.maxLength.length : e.maxLength)),
      Me = u(() => {
        const l = F("a");
        return Math.floor(C.value / l);
      }),
      le = (l) => {
        var d, y;
        (C.value &&
          !ae.value &&
          F(l) > C.value &&
          (l = (y = (d = e.wordSlice) == null ? void 0 : d.call(e, l, C.value)) != null ? y : l.slice(0, Me.value)),
          (V.value = l),
          t("update:modelValue", l));
      },
      Pe = (l) => {
        v.value && l.target !== v.value && (l.preventDefault(), v.value.focus());
      },
      ie = (l, d) => {
        var y, _;
        l !== M &&
          ((M = l), t("change", l, d), (_ = (y = m.value) == null ? void 0 : y.onChange) == null || _.call(y, d));
      },
      Ae = (l) => {
        var d, y;
        ((I.value = !0), t("focus", l), (y = (d = m.value) == null ? void 0 : d.onFocus) == null || y.call(d, l));
      },
      Te = (l) => {
        var d, y;
        ((I.value = !1),
          ie(x.value, l),
          t("blur", l),
          (y = (d = m.value) == null ? void 0 : d.onBlur) == null || y.call(d, l));
      },
      se = (l) => {
        var d, y, _;
        const { value: re, selectionStart: Ze, selectionEnd: Qe } = l.target;
        if (l.type === "compositionend") {
          if (
            ((w.value = !1), ($.value = ""), C.value && !ae.value && U.value >= C.value && F(re) > C.value && Ze === Qe)
          ) {
            Z();
            return;
          }
          (le(re), t("input", re, l), (y = (d = m.value) == null ? void 0 : d.onInput) == null || y.call(d, l), Z());
        } else ((w.value = !0), ($.value = x.value + ((_ = l.data) != null ? _ : "")));
      },
      Z = () => {
        (j(),
          ut(() => {
            v.value && x.value !== v.value.value && ((v.value.value = x.value), K());
          }));
      },
      Fe = (l) => {
        var d, y;
        const { value: _ } = l.target;
        if (!w.value) {
          if (C.value && !ae.value && U.value >= C.value && F(_) > C.value && l.inputType === "insertText") {
            Z();
            return;
          }
          (le(_), t("input", _, l), (y = (d = m.value) == null ? void 0 : d.onInput) == null || y.call(d, l), Z());
        }
      },
      Ge = (l) => {
        (le(""), ie("", l), t("clear", l));
      },
      We = (l) => {
        const d = l.key || l.code;
        !w.value && d === mt.key && (ie(x.value, l), t("pressEnter", l));
      },
      He = u(() => [
        `${s}-outer`,
        `${s}-outer-size-${k.value}`,
        { [`${s}-outer-has-suffix`]: !!n.suffix, [`${s}-outer-disabled`]: c.value },
      ]),
      qe = u(() => [`${s}-wrapper`, { [`${s}-error`]: he.value, [`${s}-disabled`]: c.value, [`${s}-focus`]: I.value }]),
      Ke = u(() => [s, `${s}-size-${k.value}`]),
      be = u(() => Ye(i, ke)),
      De = u(() => _e(i, ke)),
      Ue = u(() => {
        const l = { ...De.value, ...e.inputAttrs };
        return (he.value && (l["aria-invalid"] = !0), l);
      }),
      $e = (l) => {
        var d;
        return p("span", ee({ class: qe.value, onMousedown: Pe }, l ? void 0 : be.value), [
          n.prefix && p("span", { class: `${s}-prefix` }, [n.prefix()]),
          p(
            "input",
            ee(
              {
                ref: v,
                class: Ke.value,
                value: x.value,
                type: e.type,
                placeholder: e.placeholder,
                readonly: e.readonly,
                disabled: c.value,
                onInput: Fe,
                onKeydown: We,
                onFocus: Ae,
                onBlur: Te,
                onCompositionstart: se,
                onCompositionupdate: se,
                onCompositionend: se,
              },
              Ue.value,
            ),
            null,
          ),
          D.value && p(ge, { prefix: s, class: `${s}-clear-btn`, onClick: Ge }, { default: () => [p(et, null, null)] }),
          (n.suffix || (!!e.maxLength && e.showWordLimit) || !!b.value) &&
            p("span", { class: [`${s}-suffix`, { [`${s}-suffix-has-feedback`]: b.value }] }, [
              !!e.maxLength && e.showWordLimit && p("span", { class: `${s}-word-limit` }, [U.value, ot("/"), C.value]),
              (d = n.suffix) == null ? void 0 : d.call(n),
              !!b.value && p(tt, { type: b.value }, null),
            ]),
        ]);
      };
    return {
      inputRef: v,
      render: () =>
        n.prepend || n.append || e.prepend || e.append
          ? p("span", ee({ class: He.value }, be.value), [
              (n.prepend || e.prepend) && p("span", { class: `${s}-prepend` }, [n.prepend ? n.prepend() : e.prepend]),
              $e(!0),
              (n.append || e.append) && p("span", { class: `${s}-append` }, [n.append ? n.append() : e.append]),
            ])
          : $e(),
    };
  },
  methods: {
    focus() {
      var e;
      (e = this.inputRef) == null || e.focus();
    },
    blur() {
      var e;
      (e = this.inputRef) == null || e.blur();
    },
  },
  render() {
    return this.render();
  },
});
const gt = S({
    name: "IconSearch",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = z("icon"),
        i = u(() => [n, `${n}-search`, { [`${n}-spin`]: e.spin }]),
        r = u(() => {
          const a = {};
          return (
            e.size && (a.fontSize = R(e.size) ? `${e.size}px` : e.size),
            e.rotate && (a.transform = `rotate(${e.rotate}deg)`),
            a
          );
        });
      return {
        cls: i,
        innerStyle: r,
        onClick: (a) => {
          t("click", a);
        },
      };
    },
  }),
  ht = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function bt(e, t, n, i, r, o) {
  return (
    B(),
    A(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: T(e.cls),
        style: q(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...a) => e.onClick && e.onClick(...a)),
      },
      t[1] ||
        (t[1] = [
          H(
            "path",
            {
              d: "M33.072 33.071c6.248-6.248 6.248-16.379 0-22.627-6.249-6.249-16.38-6.249-22.628 0-6.248 6.248-6.248 16.379 0 22.627 6.248 6.248 16.38 6.248 22.628 0Zm0 0 8.485 8.485",
            },
            null,
            -1,
          ),
        ]),
      14,
      ht,
    )
  );
}
var oe = O(gt, [["render", bt]]);
const we = Object.assign(oe, {
  install: (e, t) => {
    var n;
    const i = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
    e.component(i + oe.name, oe);
  },
});
var ue = S({
  name: "InputSearch",
  props: {
    searchButton: { type: Boolean, default: !1 },
    loading: { type: Boolean, default: !1 },
    disabled: { type: Boolean, default: !1 },
    size: { type: String },
    buttonText: { type: String },
    buttonProps: { type: Object },
  },
  emits: { search: (e, t) => !0 },
  setup(e, { emit: t, slots: n }) {
    const { size: i } = ne(e),
      r = z("input-search"),
      { mergedSize: o } = Ie(i),
      a = L(),
      f = (c) => {
        a.value.inputRef && t("search", a.value.inputRef.value, c);
      },
      s = () => {
        var c;
        return p(me, null, [
          e.loading ? p(Le, null, null) : p(ge, { onClick: f }, { default: () => [p(we, null, null)] }),
          (c = n.suffix) == null ? void 0 : c.call(n),
        ]);
      },
      v = () => {
        var c;
        let h = {};
        return (
          e.buttonText || n["button-default"] || n["button-icon"]
            ? (h = {
                default: (c = n["button-default"]) != null ? c : e.buttonText ? () => e.buttonText : void 0,
                icon: n["button-icon"],
              })
            : (h = { icon: () => p(we, null, null) }),
          p(
            lt,
            ee(
              { type: "primary", class: `${r}-btn`, disabled: e.disabled, size: o.value, loading: e.loading },
              e.buttonProps,
              { onClick: f },
            ),
            h,
          )
        );
      };
    return {
      inputRef: a,
      render: () =>
        p(
          W,
          { ref: a, class: r, size: o.value, disabled: e.disabled },
          {
            prepend: n.prepend,
            prefix: n.prefix,
            suffix: e.searchButton ? n.suffix : s,
            append: e.searchButton ? v : n.append,
          },
        ),
    };
  },
  methods: {
    focus() {
      var e;
      (e = this.inputRef) == null || e.focus();
    },
    blur() {
      var e;
      (e = this.inputRef) == null || e.blur();
    },
  },
  render() {
    return this.render();
  },
});
const $t = S({
    name: "IconEye",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = z("icon"),
        i = u(() => [n, `${n}-eye`, { [`${n}-spin`]: e.spin }]),
        r = u(() => {
          const a = {};
          return (
            e.size && (a.fontSize = R(e.size) ? `${e.size}px` : e.size),
            e.rotate && (a.transform = `rotate(${e.rotate}deg)`),
            a
          );
        });
      return {
        cls: i,
        innerStyle: r,
        onClick: (a) => {
          t("click", a);
        },
      };
    },
  }),
  kt = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function xt(e, t, n, i, r, o) {
  return (
    B(),
    A(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: T(e.cls),
        style: q(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...a) => e.onClick && e.onClick(...a)),
      },
      t[1] ||
        (t[1] = [
          H(
            "path",
            {
              "clip-rule": "evenodd",
              d: "M24 37c6.627 0 12.627-4.333 18-13-5.373-8.667-11.373-13-18-13-6.627 0-12.627 4.333-18 13 5.373 8.667 11.373 13 18 13Z",
            },
            null,
            -1,
          ),
          H("path", { d: "M29 24a5 5 0 1 1-10 0 5 5 0 0 1 10 0Z" }, null, -1),
        ]),
      14,
      kt,
    )
  );
}
var ce = O($t, [["render", xt]]);
const Ct = Object.assign(ce, {
    install: (e, t) => {
      var n;
      const i = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(i + ce.name, ce);
    },
  }),
  St = S({
    name: "IconEyeInvisible",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = z("icon"),
        i = u(() => [n, `${n}-eye-invisible`, { [`${n}-spin`]: e.spin }]),
        r = u(() => {
          const a = {};
          return (
            e.size && (a.fontSize = R(e.size) ? `${e.size}px` : e.size),
            e.rotate && (a.transform = `rotate(${e.rotate}deg)`),
            a
          );
        });
      return {
        cls: i,
        innerStyle: r,
        onClick: (a) => {
          t("click", a);
        },
      };
    },
  }),
  wt = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Bt(e, t, n, i, r, o) {
  return (
    B(),
    A(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: T(e.cls),
        style: q(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...a) => e.onClick && e.onClick(...a)),
      },
      t[1] ||
        (t[1] = [
          H(
            "path",
            {
              d: "M14 14.5c-2.69 2-5.415 5.33-8 9.5 5.373 8.667 11.373 13 18 13 3.325 0 6.491-1.09 9.5-3.271M17.463 12.5C19 11 21.75 11 24 11c6.627 0 12.627 4.333 18 13-1.766 2.848-3.599 5.228-5.5 7.14",
            },
            null,
            -1,
          ),
          H("path", { d: "M29 24a5 5 0 1 1-10 0 5 5 0 0 1 10 0ZM6.852 7.103l34.294 34.294" }, null, -1),
        ]),
      14,
      wt,
    )
  );
}
var de = O(St, [["render", Bt]]);
const zt = Object.assign(de, {
    install: (e, t) => {
      var n;
      const i = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(i + de.name, de);
    },
  }),
  It = S({
    name: "InputPassword",
    components: { IconEye: Ct, IconEyeInvisible: zt, AIconHover: ge, AInput: W },
    props: {
      visibility: { type: Boolean, default: void 0 },
      defaultVisibility: { type: Boolean, default: !0 },
      invisibleButton: { type: Boolean, default: !0 },
    },
    emits: ["visibility-change", "update:visibility"],
    setup(e, { emit: t }) {
      const { visibility: n, defaultVisibility: i } = ne(e),
        r = L(),
        o = () => {
          s(!a.value);
        },
        [a, f] = it(i.value, Re({ value: n })),
        s = (v) => {
          v !== a.value && (t("visibility-change", v), t("update:visibility", v), f(v));
        };
      return { inputRef: r, mergedVisible: a, handleInvisible: o };
    },
    methods: {
      focus() {
        var e;
        (e = this.inputRef) == null || e.focus();
      },
      blur() {
        var e;
        (e = this.inputRef) == null || e.blur();
      },
    },
  });
function _t(e, t, n, i, r, o) {
  const a = Q("icon-eye"),
    f = Q("icon-eye-invisible"),
    s = Q("a-icon-hover"),
    v = Q("a-input");
  return (
    B(),
    X(
      v,
      { ref: "inputRef", type: e.mergedVisible ? "password" : "text" },
      ct({ _: 2 }, [
        e.$slots.prepend ? { name: "prepend", fn: G(() => [E(e.$slots, "prepend")]), key: "0" } : void 0,
        e.$slots.prefix ? { name: "prefix", fn: G(() => [E(e.$slots, "prefix")]), key: "1" } : void 0,
        e.invisibleButton || e.$slots.suffix
          ? {
              name: "suffix",
              fn: G(() => [
                e.invisibleButton
                  ? (B(),
                    X(
                      s,
                      {
                        key: 0,
                        onClick: e.handleInvisible,
                        onMousedown: t[0] || (t[0] = Se(() => {}, ["prevent"])),
                        onMouseup: t[1] || (t[1] = Se(() => {}, ["prevent"])),
                      },
                      { default: G(() => [e.mergedVisible ? (B(), X(f, { key: 1 })) : (B(), X(a, { key: 0 }))]), _: 1 },
                      8,
                      ["onClick"],
                    ))
                  : Ee("v-if", !0),
                E(e.$slots, "suffix"),
              ]),
              key: "2",
            }
          : void 0,
        e.$slots.append ? { name: "append", fn: G(() => [E(e.$slots, "append")]), key: "3" } : void 0,
      ]),
      1032,
      ["type"],
    )
  );
}
var fe = O(It, [["render", _t]]);
const Lt = S({
  name: "InputGroup",
  setup() {
    return { prefixCls: z("input-group") };
  },
});
function jt(e, t, n, i, r, o) {
  return (B(), A("div", { class: T(e.prefixCls) }, [E(e.$slots, "default")], 2));
}
var ve = O(Lt, [["render", jt]]);
const qt = Object.assign(W, {
    Search: ue,
    Password: fe,
    Group: ve,
    install: (e, t) => {
      je(e, t);
      const n = Ne(t);
      (e.component(n + W.name, W),
        e.component(n + ve.name, ve),
        e.component(n + ue.name, ue),
        e.component(n + fe.name, fe));
    },
  }),
  Nt = 5;
var Et = S({
    name: "DotLoading",
    props: { size: { type: Number } },
    setup(e) {
      const t = z("dot-loading");
      return () => {
        const n = e.size ? { width: `${e.size}px`, height: `${e.size}px` } : {};
        return p(
          "div",
          { class: t, style: { width: e.size ? `${e.size * 7}px` : void 0, height: e.size ? `${e.size}px` : void 0 } },
          [
            Array(Nt)
              .fill(1)
              .map((i, r) => p("div", { class: `${t}-item`, key: r, style: n }, null)),
          ],
        );
      };
    },
  }),
  pe = S({
    name: "Spin",
    props: {
      size: { type: Number },
      loading: Boolean,
      dot: Boolean,
      tip: String,
      hideIcon: { type: Boolean, default: !1 },
    },
    setup(e, { slots: t }) {
      const n = z("spin"),
        i = Oe(rt, void 0),
        r = u(() => [n, { [`${n}-loading`]: e.loading, [`${n}-with-tip`]: e.tip && !t.default }]),
        o = () => {
          if (t.icon) {
            const f = st(t.icon());
            if (f) return dt(f, { spin: !0 });
          }
          return t.element
            ? t.element()
            : e.dot
              ? p(Et, { size: e.size }, null)
              : i != null && i.slots.loading
                ? i.slots.loading()
                : p(Le, { spin: !0, size: e.size }, null);
        },
        a = () => {
          var f, s, v;
          const g = e.size ? { fontSize: `${e.size}px` } : void 0,
            c = !!((f = t.tip) != null ? f : e.tip);
          return p(me, null, [
            !e.hideIcon && p("div", { class: `${n}-icon`, style: g }, [o()]),
            c && p("div", { class: `${n}-tip` }, [(v = (s = t.tip) == null ? void 0 : s.call(t)) != null ? v : e.tip]),
          ]);
        };
      return () =>
        p("div", { class: r.value }, [
          t.default
            ? p(me, null, [
                t.default(),
                e.loading && p("div", { class: `${n}-mask` }, [p("div", { class: `${n}-mask-icon` }, [a()])]),
              ])
            : a(),
        ]);
    },
  });
const Kt = Object.assign(pe, {
    install: (e, t) => {
      je(e, t);
      const n = Ne(t);
      e.component(n + pe.name, pe);
    },
  }),
  te = ["xxl", "xl", "lg", "md", "sm", "xs"],
  Y = {
    xs: "(max-width: 575px)",
    sm: "(min-width: 576px)",
    md: "(min-width: 768px)",
    lg: "(min-width: 992px)",
    xl: "(min-width: 1200px)",
    xxl: "(min-width: 1600px)",
  };
let N = [],
  Rt = -1,
  J = {};
const Be = {
  matchHandlers: {},
  dispatch(e, t) {
    return (
      (J = e),
      N.length < 1
        ? !1
        : (N.forEach((n) => {
            n.func(J, t);
          }),
          !0)
    );
  },
  subscribe(e) {
    N.length === 0 && this.register();
    const t = (++Rt).toString();
    return (N.push({ token: t, func: e }), e(J, null), t);
  },
  unsubscribe(e) {
    ((N = N.filter((t) => t.token !== e)), N.length === 0 && this.unregister());
  },
  unregister() {
    Object.keys(Y).forEach((e) => {
      const t = Y[e];
      if (!t) return;
      const n = this.matchHandlers[t];
      n &&
        n.mql &&
        n.listener &&
        (n.mql.removeEventListener
          ? n.mql.removeEventListener("change", n.listener)
          : n.mql.removeListener(n.listener));
    });
  },
  register() {
    Object.keys(Y).forEach((e) => {
      const t = Y[e];
      if (!t) return;
      const n = ({ matches: r }) => {
          this.dispatch({ ...J, [e]: r }, e);
        },
        i = window.matchMedia(t);
      (i.addEventListener ? i.addEventListener("change", n) : i.addListener(n),
        (this.matchHandlers[t] = { mql: i, listener: n }),
        n(i));
    });
  },
};
function ze(e) {
  return P(e);
}
function ye(e, t, n = !1) {
  const i = L({ xs: !0, sm: !0, md: !0, lg: !0, xl: !0, xxl: !0 }),
    r = u(() => {
      let a = t;
      if (ze(e.value))
        for (let f = 0; f < te.length; f++) {
          const s = te[f];
          if ((i.value[s] || (s === "xs" && n)) && e.value[s] !== void 0) {
            a = e.value[s];
            break;
          }
        }
      else a = e.value;
      return a;
    });
  let o = "";
  return (
    ft(() => {
      o = Be.subscribe((a) => {
        ze(e.value) && (i.value = a);
      });
    }),
    vt(() => {
      o && Be.unsubscribe(o);
    }),
    r
  );
}
const Ve = Symbol("RowContextInjectionKey"),
  Dt = Symbol("GridContextInjectionKey"),
  Ut = Symbol("GridDataCollectorInjectionKey"),
  Ot = S({
    name: "Row",
    props: {
      gutter: { type: [Number, Object, Array], default: 0 },
      justify: { type: String, default: "start" },
      align: { type: String, default: "start" },
      div: { type: Boolean },
      wrap: { type: Boolean, default: !0 },
    },
    setup(e) {
      const { gutter: t, align: n, justify: i, div: r, wrap: o } = ne(e),
        a = z("row"),
        f = u(() => ({
          [`${a}`]: !r.value,
          [`${a}-nowrap`]: !o.value,
          [`${a}-align-${n.value}`]: n.value,
          [`${a}-justify-${i.value}`]: i.value,
        })),
        s = u(() => (Array.isArray(t.value) ? t.value[0] : t.value)),
        v = u(() => (Array.isArray(t.value) ? t.value[1] : 0)),
        g = ye(s, 0),
        c = ye(v, 0),
        h = u(() => {
          const m = {};
          if ((g.value || c.value) && !r.value) {
            const k = -g.value / 2,
              j = -c.value / 2;
            (k && ((m.marginLeft = `${k}px`), (m.marginRight = `${k}px`)),
              j && ((m.marginTop = `${j}px`), (m.marginBottom = `${j}px`)));
          }
          return m;
        }),
        b = u(() => [g.value, c.value]);
      return (pt(Ve, Re({ gutter: b, div: r })), { classNames: f, styles: h });
    },
  });
function Vt(e, t, n, i, r, o) {
  return (B(), A("div", { class: T(e.classNames), style: q(e.styles) }, [E(e.$slots, "default")], 6));
}
var Zt = O(Ot, [["render", Vt]]);
function Mt(e) {
  return u(() => {
    const { val: n, key: i, xs: r, sm: o, md: a, lg: f, xl: s, xxl: v } = e.value;
    if (!r && !o && !a && !f && !s && !v) return n;
    const g = {};
    return (
      te.forEach((c) => {
        const h = e.value[c];
        R(h) ? (g[c] = h) : P(h) && R(h[i]) && (g[c] = h[i]);
      }),
      g
    );
  });
}
function Pt(e) {
  if ((xe(e) && (["initial", "auto", "none"].includes(e) || /^\d+$/.test(e))) || R(e)) return e;
  if (xe(e) && /^\d+(px|em|rem|%)$/.test(e)) return `0 0 ${e}`;
}
const At = S({
  name: "Col",
  props: {
    span: { type: Number, default: 24 },
    offset: { type: Number },
    order: { type: Number },
    xs: { type: [Number, Object] },
    sm: { type: [Number, Object] },
    md: { type: [Number, Object] },
    lg: { type: [Number, Object] },
    xl: { type: [Number, Object] },
    xxl: { type: [Number, Object] },
    flex: { type: [Number, String] },
  },
  setup(e) {
    const t = z("col"),
      n = Oe(Ve, {}),
      i = u(() => Pt(e.flex)),
      r = u(() => {
        const { div: c } = n,
          { span: h, offset: b, order: m, xs: k, sm: j, md: K, lg: V, xl: x, xxl: M } = e,
          I = {
            [`${t}`]: !c,
            [`${t}-order-${m}`]: m,
            [`${t}-${h}`]: !c && !k && !j && !K && !V && !x && !M,
            [`${t}-offset-${b}`]: b && b > 0,
          },
          D = { xs: k, sm: j, md: K, lg: V, xl: x, xxl: M };
        return (
          Object.keys(D).forEach((w) => {
            const $ = D[w];
            $ && R($)
              ? (I[`${t}-${w}-${$}`] = !0)
              : $ &&
                P($) &&
                ((I[`${t}-${w}-${$.span}`] = $.span),
                (I[`${t}-${w}-offset-${$.offset}`] = $.offset),
                (I[`${t}-${w}-order-${$.order}`] = $.order));
          }),
          I
        );
      }),
      o = u(() => (i.value ? t : r.value)),
      a = u(() => {
        const { gutter: c, div: h } = n,
          b = {};
        if (Array.isArray(c) && !h) {
          const m = (c[0] && c[0] / 2) || 0,
            k = (c[1] && c[1] / 2) || 0;
          (m && ((b.paddingLeft = `${m}px`), (b.paddingRight = `${m}px`)),
            k && ((b.paddingTop = `${k}px`), (b.paddingBottom = `${k}px`)));
        }
        return b;
      }),
      f = u(() => (i.value ? { flex: i.value } : {})),
      s = u(() => _e(e, te)),
      v = Mt(u(() => ({ val: e.span, key: "span", ...s.value }))),
      g = ye(v, 24, !0);
    return { visible: u(() => !!g.value), classNames: o, styles: u(() => ({ ...a.value, ...f.value })) };
  },
});
function Tt(e, t, n, i, r, o) {
  return e.visible
    ? (B(), A("div", { key: 0, class: T(e.classNames), style: q(e.styles) }, [E(e.$slots, "default")], 6))
    : Ee("v-if", !0);
}
var Qt = O(At, [["render", Tt]]);
export { Ht as B, Qt as C, mt as E, Dt as G, qt as I, Zt as R, Kt as S, Ct as a, we as b, Ut as c, ye as u };
