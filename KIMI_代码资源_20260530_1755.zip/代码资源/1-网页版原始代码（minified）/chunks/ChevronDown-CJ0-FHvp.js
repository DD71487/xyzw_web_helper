import { k as e, c as o, h as n, a as t } from "./index-UoU16364.js";
const r = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  s = t(
    "path",
    {
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "48",
      d: "M112 184l144 144l144-144",
    },
    null,
    -1,
  ),
  l = [s],
  d = e({
    name: "ChevronDown",
    render: function (i, a) {
      return (n(), o("svg", r, l));
    },
  });
export { d as C };
