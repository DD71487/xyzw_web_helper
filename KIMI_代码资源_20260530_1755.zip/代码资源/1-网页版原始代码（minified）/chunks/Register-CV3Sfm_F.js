import {
  k as R,
  c as x,
  h as k,
  a as i,
  s as T,
  r as $,
  z,
  l as U,
  b as s,
  w as r,
  d as n,
  u as f,
  f as V,
  D as q,
  i as l,
} from "./index-UoU16364.js";
import { _ as B } from "./xiaoyugan-Dwisk7G8.js";
import { u as L } from "./auth-BYvggjsB.js";
import { _ as M } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { P as N } from "./PersonCircle-CkW3zhXQ.js";
import "./localTokenManager-BQJEcmfy.js";
const F = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  S = i(
    "path",
    {
      d: "M424 80H88a56.06 56.06 0 0 0-56 56v240a56.06 56.06 0 0 0 56 56h336a56.06 56.06 0 0 0 56-56V136a56.06 56.06 0 0 0-56-56zm-14.18 92.63l-144 112a16 16 0 0 1-19.64 0l-144-112a16 16 0 1 1 19.64-25.26L256 251.73l134.18-104.36a16 16 0 0 1 19.64 25.26z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  K = [S],
  W = R({
    name: "Mail",
    render: function (c, u) {
      return (k(), x("svg", F, K));
    },
  }),
  X = { class: "register-page" },
  Y = { class: "register-container" },
  Z = { class: "register-card glass" },
  A = { class: "card-body" },
  D = { class: "form-options" },
  E = { class: "login-prompt" },
  H = {
    __name: "Register",
    setup(y) {
      const c = V(),
        u = T(),
        _ = L(),
        v = $(null),
        t = z({ username: "", email: "", password: "", confirmPassword: "", agreeTerms: !1 }),
        h = {
          username: [
            { required: !0, message: "请输入用户名", trigger: ["input", "blur"] },
            { min: 3, max: 20, message: "用户名长度应在3-20个字符之间", trigger: ["input", "blur"] },
          ],
          email: [
            { required: !0, message: "请输入邮箱地址", trigger: ["input", "blur"] },
            { type: "email", message: "请输入正确的邮箱格式", trigger: ["input", "blur"] },
          ],
          password: [
            { required: !0, message: "请输入密码", trigger: ["input", "blur"] },
            { min: 6, message: "密码长度不能少于6位", trigger: ["input", "blur"] },
          ],
          confirmPassword: [
            { required: !0, message: "请确认密码", trigger: ["input", "blur"] },
            { validator: (a, e) => e === t.password, message: "两次输入的密码不一致", trigger: ["input", "blur"] },
          ],
        },
        w = async () => {
          if (v.value)
            try {
              if ((await v.value.validate(), !t.agreeTerms)) {
                u.warning("请先同意服务条款和隐私政策");
                return;
              }
              const a = await _.register({ username: t.username, email: t.email, password: t.password });
              a.success ? (u.success("注册成功，请登录"), c.push("/login")) : u.error(a.message);
            } catch (a) {
              console.error("Registration validation failed:", a);
            }
        };
      return (a, e) => {
        const d = n("n-icon"),
          p = n("n-input"),
          m = n("n-form-item"),
          b = n("Lock"),
          g = n("n-button"),
          C = n("n-checkbox"),
          P = n("n-form");
        return (
          k(),
          x("div", X, [
            i("div", Y, [
              i("div", Z, [
                e[15] ||
                  (e[15] = U(
                    '<div class="card-header" data-v-6933294e><div class="brand" data-v-6933294e><img src="' +
                      B +
                      '" alt="XYZW" class="brand-logo" data-v-6933294e><h1 class="brand-title" data-v-6933294e>注册 XYZW 账户</h1></div><p class="welcome-text" data-v-6933294e>加入我们，开始您的游戏管理之旅</p></div>',
                    1,
                  )),
                i("div", A, [
                  s(
                    P,
                    { ref_key: "registerFormRef", ref: v, model: t, rules: h, size: "large", "show-label": !1 },
                    {
                      default: r(() => [
                        s(
                          m,
                          { path: "username" },
                          {
                            default: r(() => [
                              s(
                                p,
                                {
                                  value: t.username,
                                  "onUpdate:value": e[0] || (e[0] = (o) => (t.username = o)),
                                  placeholder: "用户名",
                                  "input-props": { autocomplete: "username" },
                                },
                                { prefix: r(() => [s(d, null, { default: r(() => [s(f(N))]), _: 1 })]), _: 1 },
                                8,
                                ["value"],
                              ),
                            ]),
                            _: 1,
                          },
                        ),
                        s(
                          m,
                          { path: "email" },
                          {
                            default: r(() => [
                              s(
                                p,
                                {
                                  value: t.email,
                                  "onUpdate:value": e[1] || (e[1] = (o) => (t.email = o)),
                                  placeholder: "邮箱地址",
                                  "input-props": { autocomplete: "email" },
                                },
                                { prefix: r(() => [s(d, null, { default: r(() => [s(f(W))]), _: 1 })]), _: 1 },
                                8,
                                ["value"],
                              ),
                            ]),
                            _: 1,
                          },
                        ),
                        s(
                          m,
                          { path: "password" },
                          {
                            default: r(() => [
                              s(
                                p,
                                {
                                  value: t.password,
                                  "onUpdate:value": e[2] || (e[2] = (o) => (t.password = o)),
                                  type: "password",
                                  placeholder: "密码",
                                  "input-props": { autocomplete: "new-password" },
                                },
                                { prefix: r(() => [s(d, null, { default: r(() => [s(b)]), _: 1 })]), _: 1 },
                                8,
                                ["value"],
                              ),
                            ]),
                            _: 1,
                          },
                        ),
                        s(
                          m,
                          { path: "confirmPassword" },
                          {
                            default: r(() => [
                              s(
                                p,
                                {
                                  value: t.confirmPassword,
                                  "onUpdate:value": e[3] || (e[3] = (o) => (t.confirmPassword = o)),
                                  type: "password",
                                  placeholder: "确认密码",
                                  "input-props": { autocomplete: "new-password" },
                                  onKeydown: q(w, ["enter"]),
                                },
                                { prefix: r(() => [s(d, null, { default: r(() => [s(b)]), _: 1 })]), _: 1 },
                                8,
                                ["value"],
                              ),
                            ]),
                            _: 1,
                          },
                        ),
                        i("div", D, [
                          s(
                            C,
                            { checked: t.agreeTerms, "onUpdate:checked": e[6] || (e[6] = (o) => (t.agreeTerms = o)) },
                            {
                              default: r(() => [
                                e[10] || (e[10] = l(" 我已阅读并同意 ", -1)),
                                s(
                                  g,
                                  { text: "", type: "primary", onClick: e[4] || (e[4] = (o) => (a.showTerms = !0)) },
                                  { default: r(() => [...(e[8] || (e[8] = [l(" 服务条款 ", -1)]))]), _: 1 },
                                ),
                                e[11] || (e[11] = l(" 和 ", -1)),
                                s(
                                  g,
                                  { text: "", type: "primary", onClick: e[5] || (e[5] = (o) => (a.showPrivacy = !0)) },
                                  { default: r(() => [...(e[9] || (e[9] = [l(" 隐私政策 ", -1)]))]), _: 1 },
                                ),
                              ]),
                              _: 1,
                            },
                            8,
                            ["checked"],
                          ),
                        ]),
                        s(
                          g,
                          {
                            type: "primary",
                            size: "large",
                            block: "",
                            loading: f(_).isLoading,
                            disabled: !t.agreeTerms,
                            class: "register-button",
                            onClick: w,
                          },
                          { default: r(() => [...(e[12] || (e[12] = [l(" 注册账户 ", -1)]))]), _: 1 },
                          8,
                          ["loading", "disabled"],
                        ),
                      ]),
                      _: 1,
                    },
                    8,
                    ["model"],
                  ),
                  i("div", E, [
                    e[14] || (e[14] = i("span", null, "已有账户？", -1)),
                    s(
                      g,
                      { text: "", type: "primary", onClick: e[7] || (e[7] = (o) => f(c).push("/login")) },
                      { default: r(() => [...(e[13] || (e[13] = [l(" 立即登录 ", -1)]))]), _: 1 },
                    ),
                  ]),
                ]),
              ]),
            ]),
          ])
        );
      };
    },
  },
  ee = M(H, [["__scopeId", "data-v-6933294e"]]);
export { ee as default };
