import { k as e, c as o, h as t, a as n } from "./index-UoU16364.js";
const r = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  s = n(
    "path",
    {
      d: "M256 48C141.31 48 48 141.31 48 256s93.31 208 208 208s208-93.31 208-208S370.69 48 256 48zm108.25 138.29l-134.4 160a16 16 0 0 1-12 5.71h-.27a16 16 0 0 1-11.89-5.3l-57.6-64a16 16 0 1 1 23.78-21.4l45.29 50.32l122.59-145.91a16 16 0 0 1 24.5 20.58z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  a = [s],
  m = e({
    name: "CheckmarkCircle",
    render: function (l, i) {
      return (t(), o("svg", r, a));
    },
  });
export { m as C };
