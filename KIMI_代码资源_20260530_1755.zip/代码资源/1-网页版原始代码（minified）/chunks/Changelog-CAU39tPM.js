import {
  c as l,
  h as o,
  a as e,
  E as C,
  t as c,
  A as y,
  i as $,
  F as k,
  g as x,
  aF as w,
  r as T,
  p,
  o as D,
  b as F,
  w as j,
  aT as O,
  e as L,
} from "./index-UoU16364.js";
import { _ as V } from "./_plugin-vue_export-helper-DlAUqK2U.js";
const M = { class: "changelog-card" },
  R = { class: "changelog-header" },
  W = { class: "changelog-meta" },
  E = { class: "release-date" },
  z = { class: "changelog-content" },
  A = { key: 0, class: "changelog-title" },
  J = { key: 1, class: "change-section" },
  U = { class: "change-list" },
  q = { key: 2, class: "change-section" },
  G = { class: "change-list" },
  H = { key: 3, class: "change-section" },
  K = { class: "change-list" },
  P = { key: 4, class: "change-section breaking" },
  Q = { class: "change-list" },
  X = {
    __name: "ChangelogCard",
    props: { entry: { type: Object, required: !0, validator: (t) => t.version && t.date && t.type } },
    setup(t) {
      const h = (d) => {
          const r = new Date(d),
            i = new Date() - r,
            m = Math.floor(i / (1e3 * 60 * 60 * 24));
          return m === 0
            ? "今天"
            : m === 1
              ? "昨天"
              : m < 7
                ? `${m}天前`
                : m < 30
                  ? `${Math.floor(m / 7)}周前`
                  : r.toLocaleDateString("zh-CN", { year: "numeric", month: "long", day: "numeric" });
        },
        b = (d) => ({ major: "主要版本", minor: "次要版本", patch: "补丁版本", hotfix: "热修复" })[d] || d;
      return (d, r) => (
        o(),
        l("div", M, [
          e("div", R, [
            e("div", { class: C(["version-badge", `badge-${t.entry.type}`]) }, c(t.entry.version), 3),
            e("div", W, [
              e("span", E, c(h(t.entry.date)), 1),
              e("span", { class: C(["type-tag", `tag-${t.entry.type}`]) }, c(b(t.entry.type)), 3),
            ]),
          ]),
          e("div", z, [
            t.entry.title ? (o(), l("div", A, c(t.entry.title), 1)) : y("", !0),
            t.entry.features && t.entry.features.length
              ? (o(),
                l("div", J, [
                  r[0] ||
                    (r[0] = e(
                      "h4",
                      { class: "section-title" },
                      [e("i", { class: "icon-sparkles" }, "✨"), $(" 新功能 ")],
                      -1,
                    )),
                  e("ul", U, [
                    (o(!0),
                    l(
                      k,
                      null,
                      x(t.entry.features, (u, i) => (o(), l("li", { key: `feature-${i}` }, c(u), 1))),
                      128,
                    )),
                  ]),
                ]))
              : y("", !0),
            t.entry.improvements && t.entry.improvements.length
              ? (o(),
                l("div", q, [
                  r[1] ||
                    (r[1] = e(
                      "h4",
                      { class: "section-title" },
                      [e("i", { class: "icon-arrow-up" }, "⬆️"), $(" 改进优化 ")],
                      -1,
                    )),
                  e("ul", G, [
                    (o(!0),
                    l(
                      k,
                      null,
                      x(t.entry.improvements, (u, i) => (o(), l("li", { key: `improvement-${i}` }, c(u), 1))),
                      128,
                    )),
                  ]),
                ]))
              : y("", !0),
            t.entry.fixes && t.entry.fixes.length
              ? (o(),
                l("div", H, [
                  r[2] ||
                    (r[2] = e(
                      "h4",
                      { class: "section-title" },
                      [e("i", { class: "icon-bug" }, "🐛"), $(" 修复问题 ")],
                      -1,
                    )),
                  e("ul", K, [
                    (o(!0),
                    l(
                      k,
                      null,
                      x(t.entry.fixes, (u, i) => (o(), l("li", { key: `fix-${i}` }, c(u), 1))),
                      128,
                    )),
                  ]),
                ]))
              : y("", !0),
            t.entry.breaking && t.entry.breaking.length
              ? (o(),
                l("div", P, [
                  r[3] ||
                    (r[3] = e(
                      "h4",
                      { class: "section-title" },
                      [e("i", { class: "icon-warning" }, "⚠️"), $(" 重大变更 ")],
                      -1,
                    )),
                  e("ul", Q, [
                    (o(!0),
                    l(
                      k,
                      null,
                      x(t.entry.breaking, (u, i) => (o(), l("li", { key: `breaking-${i}` }, c(u), 1))),
                      128,
                    )),
                  ]),
                ]))
              : y("", !0),
          ]),
        ])
      );
    },
  },
  Y = V(X, [["__scopeId", "data-v-e42e0b51"]]),
  Z = w("changelog", () => {
    const t = T([
        {
          version: "v1.3.0",
          date: "2025-01-15",
          type: "minor",
          title: "俱乐部战绩与身份牌功能上线",
          features: [
            "新增俱乐部盐场战绩查询功能，支持内联和弹窗两种展示模式",
            "新增身份牌组件，展示玩家个人信息和游戏数据",
            "新增游戏状态页面的日常/俱乐部/活动分区切换",
            "新增战绩数据导出功能，支持Excel格式",
            "新增月度任务进度跟踪功能",
          ],
          improvements: [
            "优化俱乐部信息数据聚合逻辑，兼容多版本服务端",
            "优化响应式布局以适配新的界面结构",
            "改进Token持久化存储，使用IndexedDB替代localStorage",
            "优化游戏状态页面的数据加载性能",
          ],
          fixes: [
            "修复俱乐部战绩数据加载失败的问题",
            "修复身份牌在某些情况下显示异常的bug",
            "修复月度任务进度计算错误的问题",
          ],
        },
        {
          version: "v1.2.1",
          date: "2025-01-08",
          type: "patch",
          title: "WebSocket连接优化",
          improvements: [
            "改进WebSocket重连机制，提高连接稳定性",
            "优化消息队列管理，防止消息丢失",
            "增强心跳检测机制，及时发现连接异常",
          ],
          fixes: [
            "修复WebSocket连接在网络波动时断开的问题",
            "修复消息发送失败后未正确重试的bug",
            "修复心跳超时后未触发重连的问题",
          ],
        },
        {
          version: "v1.2.0",
          date: "2025-01-01",
          type: "minor",
          title: "Token管理系统重构",
          features: [
            "全新的Token管理界面，支持多账号管理",
            "新增Token导入功能，支持Base64格式解析",
            "新增Token状态监控，实时显示连接状态",
            "新增Token分组功能，方便管理多个账号",
          ],
          improvements: [
            "优化Token解析算法，支持更多格式",
            "改进Token存储机制，使用加密存储",
            "优化Token切换速度，提升用户体验",
            "改进路由守卫逻辑，基于Token状态进行访问控制",
          ],
          breaking: ["旧的用户认证系统已废弃，全面迁移到Token管理系统", "需要重新导入所有游戏账号Token"],
        },
        {
          version: "v1.1.5",
          date: "2024-12-20",
          type: "hotfix",
          title: "紧急修复BON协议解析问题",
          fixes: [
            "修复BON协议解析中的严重bug，导致部分消息无法正确解析",
            "修复加密消息解密失败的问题",
            "修复消息序列号错误导致的通信异常",
          ],
        },
        {
          version: "v1.1.0",
          date: "2024-12-15",
          type: "minor",
          title: "日常任务系统上线",
          features: ["新增日常任务管理页面", "新增任务进度跟踪功能", "新增任务自动完成功能", "新增任务奖励领取提醒"],
          improvements: ["优化任务数据加载速度", "改进任务状态更新机制", "优化任务列表渲染性能"],
        },
        {
          version: "v1.0.0",
          date: "2024-12-01",
          type: "major",
          title: "系统正式发布",
          features: [
            "基础Token管理功能",
            "WebSocket连接管理",
            "BON协议实现",
            "游戏角色管理",
            "基础UI框架",
            "响应式设计支持",
          ],
        },
      ]),
      h = p(() => (t.value.length > 0 ? t.value[0] : null)),
      b = p(
        () =>
          (n = 3) =>
            t.value.slice(0, n),
      ),
      d = p(() => (n) => t.value.filter((v) => v.type === n)),
      r = p(() => ({
        totalVersions: t.value.length,
        majorVersions: t.value.filter((n) => n.type === "major").length,
        minorVersions: t.value.filter((n) => n.type === "minor").length,
        patchVersions: t.value.filter((n) => n.type === "patch").length,
        hotfixVersions: t.value.filter((n) => n.type === "hotfix").length,
      })),
      u = (n) => {
        (t.value.unshift(n), g());
      },
      i = (n, v) => {
        const f = t.value.findIndex((_) => _.version === n);
        f !== -1 && ((t.value[f] = { ...t.value[f], ...v }), g());
      },
      m = (n) => {
        const v = t.value.findIndex((f) => f.version === n);
        v !== -1 && (t.value.splice(v, 1), g());
      },
      g = () => {
        try {
          localStorage.setItem("changelogs", JSON.stringify(t.value));
        } catch (n) {
          console.error("保存更新日志到本地存储失败:", n);
        }
      },
      s = () => {
        try {
          const n = localStorage.getItem("changelogs");
          n && (t.value = JSON.parse(n));
        } catch (n) {
          console.error("从本地存储加载更新日志失败:", n);
        }
      },
      a = (n, v) => {
        const f = t.value.findIndex((S) => S.version === n),
          _ = t.value.findIndex((S) => S.version === v);
        return f === -1 || _ === -1 ? [] : t.value.slice(Math.min(f, _), Math.max(f, _) + 1);
      },
      I = (n) => (h.value ? h.value.version !== n : !1),
      N = () => {
        try {
          const n = localStorage.getItem("last_read_changelog_version");
          if (!n) return t.value;
          const v = t.value.findIndex((f) => f.version === n);
          return v === -1 ? t.value : t.value.slice(0, v);
        } catch (n) {
          return (console.error("获取未读更新日志失败:", n), []);
        }
      },
      B = (n) => {
        try {
          localStorage.setItem("last_read_changelog_version", n);
        } catch (v) {
          console.error("标记更新日志为已读失败:", v);
        }
      };
    return (
      s(),
      {
        changelogs: t,
        latestVersion: h,
        getRecentChangelogs: b,
        getChangelogsByType: d,
        statistics: r,
        addChangelog: u,
        updateChangelog: i,
        deleteChangelog: m,
        saveToLocalStorage: g,
        loadFromLocalStorage: s,
        getVersionDiff: a,
        hasNewVersion: I,
        getUnreadChangelogs: N,
        markAsRead: B,
      }
    );
  }),
  ee = { class: "changelog-page" },
  te = { class: "changelog-container" },
  se = { class: "page-header" },
  ne = { class: "filter-section" },
  ae = { class: "filter-group" },
  oe = { class: "filter-buttons" },
  le = ["onClick"],
  re = { class: "stats-grid" },
  ie = { class: "stat-card" },
  ce = { class: "stat-content" },
  de = { class: "stat-value" },
  ue = { class: "stat-card" },
  ge = { class: "stat-content" },
  ve = { class: "stat-value" },
  he = { class: "stat-card" },
  fe = { class: "stat-content" },
  me = { class: "stat-value" },
  be = { class: "stat-card" },
  ye = { class: "stat-content" },
  ke = { class: "stat-value" },
  xe = { class: "changelog-list" },
  pe = { key: 0, class: "empty-state" },
  _e = { class: "subscribe-section" },
  $e = { class: "subscribe-card" },
  Se = {
    __name: "Changelog",
    setup(t) {
      const h = Z(),
        b = T("all"),
        d = T(!1),
        r = [
          { value: "all", label: "全部" },
          { value: "major", label: "主要版本" },
          { value: "minor", label: "次要版本" },
          { value: "patch", label: "补丁" },
          { value: "hotfix", label: "热修复" },
        ],
        u = p(() => (b.value === "all" ? h.changelogs : h.changelogs.filter((g) => g.type === b.value))),
        i = p(() => ({
          totalVersions: h.changelogs.length,
          totalFeatures: h.changelogs.reduce((g, s) => {
            var a;
            return g + (((a = s.features) == null ? void 0 : a.length) || 0);
          }, 0),
          totalFixes: h.changelogs.reduce((g, s) => {
            var a;
            return g + (((a = s.fixes) == null ? void 0 : a.length) || 0);
          }, 0),
          totalImprovements: h.changelogs.reduce((g, s) => {
            var a;
            return g + (((a = s.improvements) == null ? void 0 : a.length) || 0);
          }, 0),
        })),
        m = () => {
          ((d.value = !d.value),
            d.value
              ? (localStorage.setItem("changelog_subscribed", "true"), alert("已成功订阅更新通知！"))
              : (localStorage.removeItem("changelog_subscribed"), alert("已取消订阅")));
        };
      return (
        D(() => {
          d.value = localStorage.getItem("changelog_subscribed") === "true";
        }),
        (g, s) => (
          o(),
          l("div", ee, [
            e("div", te, [
              e("div", se, [
                s[2] ||
                  (s[2] = e(
                    "div",
                    { class: "header-content" },
                    [
                      e("h1", { class: "page-title" }, [e("i", { class: "icon-history" }, "📜"), $(" 更新日志 ")]),
                      e("p", { class: "page-description" }, "查看系统的最新更新和改进内容"),
                    ],
                    -1,
                  )),
                e("div", ne, [
                  e("div", ae, [
                    s[1] || (s[1] = e("label", null, "版本类型：", -1)),
                    e("div", oe, [
                      (o(),
                      l(
                        k,
                        null,
                        x(r, (a) =>
                          e(
                            "button",
                            {
                              key: a.value,
                              class: C(["filter-btn", { active: b.value === a.value }]),
                              onClick: (I) => (b.value = a.value),
                            },
                            c(a.label),
                            11,
                            le,
                          ),
                        ),
                        64,
                      )),
                    ]),
                  ]),
                ]),
              ]),
              e("div", re, [
                e("div", ie, [
                  s[4] || (s[4] = e("div", { class: "stat-icon" }, "🚀", -1)),
                  e("div", ce, [
                    e("div", de, c(i.value.totalVersions), 1),
                    s[3] || (s[3] = e("div", { class: "stat-label" }, "总版本数", -1)),
                  ]),
                ]),
                e("div", ue, [
                  s[6] || (s[6] = e("div", { class: "stat-icon" }, "✨", -1)),
                  e("div", ge, [
                    e("div", ve, c(i.value.totalFeatures), 1),
                    s[5] || (s[5] = e("div", { class: "stat-label" }, "新功能", -1)),
                  ]),
                ]),
                e("div", he, [
                  s[8] || (s[8] = e("div", { class: "stat-icon" }, "🐛", -1)),
                  e("div", fe, [
                    e("div", me, c(i.value.totalFixes), 1),
                    s[7] || (s[7] = e("div", { class: "stat-label" }, "修复问题", -1)),
                  ]),
                ]),
                e("div", be, [
                  s[10] || (s[10] = e("div", { class: "stat-icon" }, "⬆️", -1)),
                  e("div", ye, [
                    e("div", ke, c(i.value.totalImprovements), 1),
                    s[9] || (s[9] = e("div", { class: "stat-label" }, "优化改进", -1)),
                  ]),
                ]),
              ]),
              e("div", xe, [
                F(
                  O,
                  { name: "changelog-fade" },
                  {
                    default: j(() => [
                      (o(!0),
                      l(
                        k,
                        null,
                        x(u.value, (a) => (o(), L(Y, { key: a.version, entry: a }, null, 8, ["entry"]))),
                        128,
                      )),
                    ]),
                    _: 1,
                  },
                ),
                u.value.length === 0
                  ? (o(),
                    l("div", pe, [
                      s[11] || (s[11] = e("div", { class: "empty-icon" }, "📭", -1)),
                      s[12] || (s[12] = e("p", { class: "empty-text" }, "暂无该类型的更新日志", -1)),
                      e(
                        "button",
                        { class: "reset-filter-btn", onClick: s[0] || (s[0] = (a) => (b.value = "all")) },
                        " 重置筛选 ",
                      ),
                    ]))
                  : y("", !0),
              ]),
              e("div", _e, [
                e("div", $e, [
                  s[13] || (s[13] = e("div", { class: "subscribe-icon" }, "🔔", -1)),
                  s[14] ||
                    (s[14] = e(
                      "div",
                      { class: "subscribe-content" },
                      [
                        e("h3", { class: "subscribe-title" }, "订阅更新通知"),
                        e("p", { class: "subscribe-desc" }, "第一时间获取系统更新信息"),
                      ],
                      -1,
                    )),
                  e("button", { class: "subscribe-btn", onClick: m }, c(d.value ? "已订阅" : "立即订阅"), 1),
                ]),
              ]),
            ]),
          ])
        )
      );
    },
  },
  Ie = V(Se, [["__scopeId", "data-v-7cb59dc3"]]);
export { Ie as default };
