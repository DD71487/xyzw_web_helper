import { T as wt, H as Pe } from "./ThemeToggle-DtHNrC76.js";
import {
  k as ue,
  c as E,
  h as g,
  l as ht,
  a as u,
  n as bt,
  p as oe,
  b as s,
  C as _t,
  F as ge,
  q as xt,
  s as Ct,
  v as $t,
  x as St,
  r as R,
  y as Le,
  z as Mt,
  o as Ut,
  A as D,
  e as z,
  w as o,
  u as d,
  d as B,
  g as Oe,
  f as At,
  i as p,
  N as x,
  t as C,
  B as F,
  D as ie,
  E as Ne,
  G as ce,
  H as Rt,
  I as V,
} from "./index-UoU16364.js";
import { _ as Dt } from "./xiaoyugan-Dwisk7G8.js";
import zt from "./manual-BXqhRZtw.js";
import Bt from "./url-WN-sIDo1.js";
import Et from "./bin-BPBW-39X.js";
import It from "./singlebin-BBIEmkcK.js";
import Pt from "./wxqrcode-BCLthGDr.js";
import { _ as Lt } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { M as Ot, C as Nt } from "./index-7pfSq6sD.js";
import { E as Wt, T as jt } from "./index-CgWPhAzx.js";
import { A as We } from "./Add-CN1YrD24.js";
import { M as Ft } from "./Menu-BeijkhQo.js";
import { C as me, a as Vt, S as Qt, T as Kt } from "./index-C7aQI1Ec.js";
import { g as Qe, s as Ke, a as Ge, b as Gt, i as je, c as Ht, B as Jt } from "./index-7YDlkBnY.js";
import { R as pe } from "./Refresh-DWYLAev-.js";
import { E as Fe } from "./EllipsisHorizontal-CLDjmchS.js";
import "./CloudUpload-DBucip-_.js";
import "./AlertCircleOutline-BnovXsGQ.js";
import "./ServerRoleList-J82O2iip.js";
import "./legionWar-5YonzZw2.js";
import "./Search-D4B4lpJB.js";
import "./index-BdRnBi5N.js";
import "./index-BF2tcBOi.js";
import "./grid-col-GTGOUscx.js";
import "./index-DMjs3mWk.js";
import "./render-function-B77hMlED.js";
const qt = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  Xt = ht(
    '<path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M160 144h288"></path><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M160 256h288"></path><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="48" d="M160 368h288"></path><circle cx="80" cy="144" r="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle><circle cx="80" cy="256" r="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle><circle cx="80" cy="368" r="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="32"></circle>',
    6,
  ),
  Yt = [Xt],
  Zt = ue({
    name: "List",
    render: function (k, b) {
      return (g(), E("svg", qt, Yt));
    },
  }),
  en = { xmlns: "http://www.w3.org/2000/svg", "xmlns:xlink": "http://www.w3.org/1999/xlink", viewBox: "0 0 512 512" },
  tn = u(
    "path",
    {
      d: "M394 480a16 16 0 0 1-9.39-3L256 383.76L127.39 477a16 16 0 0 1-24.55-18.08L153 310.35L23 221.2a16 16 0 0 1 9-29.2h160.38l48.4-148.95a16 16 0 0 1 30.44 0l48.4 149H480a16 16 0 0 1 9.05 29.2L359 310.35l50.13 148.53A16 16 0 0 1 394 480z",
      fill: "currentColor",
    },
    null,
    -1,
  ),
  nn = [tn],
  Ve = ue({
    name: "Star",
    render: function (k, b) {
      return (g(), E("svg", en, nn));
    },
  }),
  sn = [
    "red",
    "orangered",
    "orange",
    "gold",
    "lime",
    "green",
    "cyan",
    "arcoblue",
    "purple",
    "pinkpurple",
    "magenta",
    "gray",
  ],
  on = ["normal", "processing", "success", "warning", "danger"];
var fe = ue({
  name: "Badge",
  props: {
    text: { type: String },
    dot: { type: Boolean },
    dotStyle: { type: Object },
    maxCount: { type: Number, default: 99 },
    offset: { type: Array, default: () => [] },
    color: { type: String },
    status: { type: String, validator: (m) => on.includes(m) },
    count: { type: Number },
  },
  setup(m, { slots: k }) {
    const { status: b, color: I, dotStyle: T, offset: L, text: l, dot: y, maxCount: a, count: f } = bt(m),
      _ = Qe("badge"),
      O = an(_, b == null ? void 0 : b.value, k == null ? void 0 : k.default),
      H = oe(() => {
        const $ = { ...((T == null ? void 0 : T.value) || {}) },
          [A, N] = (L == null ? void 0 : L.value) || [];
        (A && ($.marginRight = `${-A}px`), N && ($.marginTop = `${N}px`));
        const Q =
          !(I != null && I.value) || sn.includes(I == null ? void 0 : I.value) ? {} : { backgroundColor: I.value };
        return { mergedStyle: { ...Q, ...$ }, computedDotStyle: $, computedColorStyle: Q };
      }),
      J = () => {
        const $ = l == null ? void 0 : l.value,
          A = I == null ? void 0 : I.value,
          N = b == null ? void 0 : b.value,
          Q = y == null ? void 0 : y.value,
          P = Number(f == null ? void 0 : f.value),
          W = (f == null ? void 0 : f.value) != null,
          { computedDotStyle: K, mergedStyle: Y } = H.value;
        return k.content
          ? s("span", { class: `${_}-custom-dot`, style: K }, [k.content()])
          : $ && !A && !N
            ? s("span", { class: `${_}-text`, style: K }, [$])
            : N || (A && !W)
              ? s("span", { class: `${_}-status-wrapper` }, [
                  s(
                    "span",
                    { class: [`${_}-status-dot`, { [`${_}-status-${N}`]: N, [`${_}-color-${A}`]: A }], style: Y },
                    null,
                  ),
                  $ && s("span", { class: `${_}-status-text` }, [$]),
                ])
              : (Q || A) && P > 0
                ? s("span", { class: [`${_}-dot`, { [`${_}-color-${A}`]: A }], style: Y }, null)
                : P === 0
                  ? null
                  : s("span", { class: `${_}-number`, style: Y }, [
                      s("span", null, [a.value && P > a.value ? `${a.value}+` : P]),
                    ]);
      };
    return () => s("span", { class: O.value }, [k.default && k.default(), J()]);
  },
});
const an = (m, k, b) => oe(() => [m, { [`${m}-status`]: k, [`${m}-no-children`]: !b }]),
  rn = Object.assign(fe, {
    install: (m, k) => {
      Ke(m, k);
      const b = Ge(k);
      m.component(b + fe.name, fe);
    },
  });
var ve = ue({
  name: "Space",
  props: {
    align: { type: String },
    direction: { type: String, default: "horizontal" },
    size: { type: [Number, String, Array], default: "small" },
    wrap: { type: Boolean },
    fill: { type: Boolean },
  },
  setup(m, { slots: k }) {
    const b = Qe("space"),
      I = oe(() => {
        var y;
        return (y = m.align) != null ? y : m.direction === "horizontal" ? "center" : "";
      }),
      T = oe(() => [
        b,
        {
          [`${b}-${m.direction}`]: m.direction,
          [`${b}-align-${I.value}`]: I.value,
          [`${b}-wrap`]: m.wrap,
          [`${b}-fill`]: m.fill,
        },
      ]);
    function L(y) {
      if (Ht(y)) return y;
      switch (y) {
        case "mini":
          return 4;
        case "small":
          return 8;
        case "medium":
          return 16;
        case "large":
          return 24;
        default:
          return 8;
      }
    }
    const l = (y) => {
      const a = {},
        f = `${L(je(m.size) ? m.size[0] : m.size)}px`,
        _ = `${L(je(m.size) ? m.size[1] : m.size)}px`;
      return y
        ? m.wrap
          ? { marginBottom: _ }
          : {}
        : (m.direction === "horizontal" && (a.marginRight = f),
          (m.direction === "vertical" || m.wrap) && (a.marginBottom = _),
          a);
    };
    return () => {
      var y;
      const a = Gt((y = k.default) == null ? void 0 : y.call(k), !0).filter((f) => f.type !== _t);
      return s("div", { class: T.value }, [
        a.map((f, _) => {
          var O, H;
          const J = k.split && _ > 0;
          return s(ge, { key: (O = f.key) != null ? O : `item-${_}` }, [
            J && s("div", { class: `${b}-item-split`, style: l(!1) }, [(H = k.split) == null ? void 0 : H.call(k)]),
            s("div", { class: `${b}-item`, style: l(_ === a.length - 1) }, [f]),
          ]);
        }),
      ]);
    };
  },
});
const ln = Object.assign(ve, {
    install: (m, k) => {
      Ke(m, k);
      const b = Ge(k);
      m.component(b + ve.name, ve);
    },
  }),
  un = { class: "token-import-page" },
  dn = { class: "container" },
  cn = { class: "page-header" },
  mn = { class: "header-content" },
  pn = { class: "header-top" },
  fn = { class: "card-header" },
  vn = { class: "card-body" },
  gn = { key: 0, class: "tokens-section" },
  kn = { class: "section-header" },
  Tn = { class: "header-actions" },
  yn = { key: 0, class: "tokens-grid" },
  wn = { class: "token-display" },
  hn = { class: "token-value" },
  bn = ["onClick"],
  _n = { class: "remark-value" },
  xn = { class: "token-timestamps" },
  Cn = { class: "timestamp-item" },
  $n = { class: "timestamp-value" },
  Sn = { class: "timestamp-item" },
  Mn = { class: "timestamp-value" },
  Un = { class: "storage-info" },
  An = { class: "storage-item" },
  Rn = { key: 0, class: "storage-upgrade" },
  Dn = { key: 1, class: "tokens-list" },
  zn = { style: { "min-width": "65px" } },
  Bn = { style: { "min-width": "120px" } },
  En = { style: { "min-width": "100px" } },
  In = { style: { display: "flex", "align-items": "center", "flex-wrap": "wrap", gap: "2px" } },
  Pn = { style: { "font-weight": "bold", "font-size": "0.95em" } },
  Ln = ["onClick"],
  On = { class: "modal-actions" },
  Nn = {
    __name: "index",
    props: { token: String, name: String, server: String, wsUrl: String, api: String, auto: Boolean },
    setup(m) {
      const { getArrayBuffer: k, storeArrayBuffer: b, deleteArrayBuffer: I } = xt(),
        T = m,
        L = At(),
        l = Ct(),
        y = $t(),
        a = St(),
        f = R(!1),
        _ = R(!1),
        O = R(!1);
      (R(null), R(null));
      const H = R(null),
        J = R(null),
        $ = R("manual"),
        A = R(new Set()),
        N = R(new Set()),
        Q = R(localStorage.getItem("tokenViewMode") || "list"),
        P = R(null),
        W = R(null),
        K = R({});
      Le(Q, (t) => {
        localStorage.setItem("tokenViewMode", t);
      });
      const Y = localStorage.getItem("tokenSortConfig"),
        S = R(Y ? JSON.parse(Y) : { field: "createdAt", direction: "asc" }),
        de = oe(() =>
          S.value.field === "manual"
            ? a.gameTokens
            : [...a.gameTokens].sort((t, e) => {
                var w, h, M, v, j, G;
                let r, i;
                switch (S.value.field) {
                  case "name":
                    ((r = ((w = t.name) == null ? void 0 : w.toLowerCase()) || ""),
                      (i = ((h = e.name) == null ? void 0 : h.toLowerCase()) || ""));
                    break;
                  case "server":
                    ((r = ((M = t.server) == null ? void 0 : M.toLowerCase()) || ""),
                      (i = ((v = e.server) == null ? void 0 : v.toLowerCase()) || ""));
                    break;
                  case "createdAt":
                    ((r = new Date(t.createdAt || 0).getTime()), (i = new Date(e.createdAt || 0).getTime()));
                    break;
                  case "lastUsed":
                    ((r = new Date(t.lastUsed || 0).getTime()), (i = new Date(e.lastUsed || 0).getTime()));
                    break;
                  default:
                    ((r = ((j = t.name) == null ? void 0 : j.toLowerCase()) || ""),
                      (i = ((G = e.name) == null ? void 0 : G.toLowerCase()) || ""));
                }
                return r < i
                  ? S.value.direction === "asc"
                    ? -1
                    : 1
                  : r > i
                    ? S.value.direction === "asc"
                      ? 1
                      : -1
                    : 0;
              }),
        ),
        ae = (t) => {
          (S.value.field === t
            ? (S.value.direction = S.value.direction === "asc" ? "desc" : "asc")
            : ((S.value.field = t), (S.value.direction = "asc")),
            localStorage.setItem("tokenSortConfig", JSON.stringify(S.value)));
        },
        re = (t) => (S.value.field !== t ? null : S.value.direction === "asc" ? "↑" : "↓"),
        ke = (t, e) => {
          ((P.value = t), (e.dataTransfer.effectAllowed = "move"));
        },
        Te = (t) => {
          (t.preventDefault(), (t.dataTransfer.dropEffect = "move"));
        },
        ye = (t, e) => {
          if ((e.preventDefault(), P.value === null || P.value === t)) return;
          const r = [...de.value],
            i = r[P.value];
          (r.splice(P.value, 1),
            r.splice(t, 0, i),
            (a.gameTokens = r),
            (S.value.field = "manual"),
            localStorage.setItem("tokenSortConfig", JSON.stringify(S.value)),
            (P.value = null),
            l.success("Token 顺序已更新"));
        },
        U = Mt({ name: "", token: "", server: "", wsUrl: "", remark: "" }),
        He = {
          name: [{ required: !0, message: "请输入Token名称", trigger: "blur" }],
          token: [{ required: !0, message: "请输入Token字符串", trigger: "blur" }],
        },
        Je = [
          { label: "刷新所有Token", key: "refreshAll" },
          { label: "更新token信息", key: "updateInfo" },
          { label: "导出所有Token", key: "export" },
          { label: "导入Token文件", key: "import" },
          { label: "清理过期Token", key: "clean" },
          { label: "断开所有连接", key: "disconnect" },
          { label: "清除所有Token", key: "clear" },
        ],
        qe = () => {
          f.value = !0;
        },
        Z = async (t) => {
          (A.value.add(t.id), (a.tokenAutoRefreshStatus[t.id] = { lastRefresh: Date.now(), status: "pending" }));
          try {
            if (t.importMethod === "url") {
              let e;
              if (
                t.sourceUrl.startsWith(window.location.origin) ||
                t.sourceUrl.startsWith("/") ||
                t.sourceUrl.startsWith("http://localhost") ||
                t.sourceUrl.startsWith("http://127.0.0.1")
              )
                e = await fetch(t.sourceUrl);
              else
                try {
                  e = await fetch(t.sourceUrl, {
                    method: "GET",
                    headers: { Accept: "application/json" },
                    mode: "cors",
                  });
                } catch (h) {
                  throw new Error(`跨域请求被阻止。请确保目标服务器支持CORS。错误详情: ${h.message}`);
                }
              if (!e.ok) throw new Error(`请求失败: ${e.status} ${e.statusText}`);
              const i = await e.json();
              if (!i.token) throw new Error("返回数据中未找到token字段");
              (a.updateToken(t.id, { token: i.token, server: i.server || t.server, lastRefreshed: Date.now() }),
                (a.tokenAutoRefreshStatus[t.id] = { lastRefresh: Date.now(), status: "success" }),
                l.success("Token刷新成功"));
              const w = a.gameTokens.find((h) => h.id === t.id);
              w &&
                (a.getWebSocketStatus(t.id) === "connected" && a.closeWebSocketConnection(t.id),
                setTimeout(() => {
                  a.createWebSocketConnection(t.id, w.token, t.wsUrl);
                }, 500));
            } else if (t.importMethod === "wxQrcode" || t.importMethod === "bin") {
              let e = await k(t.id),
                r = !1;
              if ((e || ((e = await k(t.name)), (r = !0)), !e))
                throw new Error(`无法在本地存储中找到Token "${t.name}" 的原始数据，请重新导入Token`);
              const i = await Rt(e);
              (a.updateToken(t.id, { token: i, lastRefreshed: Date.now() }),
                r && (await b(t.id, e), await I(t.name), console.log("已迁移IndexedDB数据:", t.name, "->", t.id)),
                (a.tokenAutoRefreshStatus[t.id] = { lastRefresh: Date.now(), status: "success" }),
                l.success("Token刷新成功"));
              const w = a.gameTokens.find((h) => h.id === t.id);
              w &&
                (a.getWebSocketStatus(t.id) === "connected" && a.closeWebSocketConnection(t.id),
                setTimeout(() => {
                  a.createWebSocketConnection(t.id, w.token, t.wsUrl);
                }, 500));
            } else {
              (delete a.tokenAutoRefreshStatus[t.id],
                y.info({
                  title: "重新获取Token",
                  content: `Token "${t.name}" 是通过微信扫码登录导入的，没有配置自动刷新地址。

请选择以下操作：
1. 重新手动导入新的Token
2. 尝试重新连接现有Token`,
                  positiveText: "重新导入",
                  negativeText: "重新连接",
                  onPositiveClick: () => {
                    ((f.value = !0),
                      ($.value = "manual"),
                      (importForm.name = t.name),
                      (importForm.server = t.server),
                      (importForm.wsUrl = t.wsUrl));
                  },
                  onNegativeClick: () => {
                    (a.getWebSocketStatus(t.id) === "connected" && a.closeWebSocketConnection(t.id),
                      setTimeout(() => {
                        (a.createWebSocketConnection(t.id, t.token, t.wsUrl), l.info("正在尝试重新连接..."));
                      }, 500));
                  },
                }));
              return;
            }
          } catch (e) {
            (console.error("刷新Token失败:", e),
              (a.tokenAutoRefreshStatus[t.id] = {
                lastRefresh: Date.now(),
                status: "failed",
                error: e.message || "Token刷新失败",
              }),
              l.error(e.message || "Token刷新失败"));
          } finally {
            A.value.delete(t.id);
          }
        },
        we = (t) => {
          y.warning({
            title: "升级为长期有效",
            content: `确认要将Token "${t.name}" 升级为长期有效吗？升级后该Token将不会因24小时未使用而被自动清理。`,
            positiveText: "确认升级",
            negativeText: "取消",
            onPositiveClick: () => {
              a.upgradeTokenToPermanent(t.id)
                ? l.success(`Token "${t.name}" 已升级为长期有效！`)
                : l.error("升级失败，该Token可能已经是长期有效状态");
            },
          });
        },
        he = (t, e = !1) => {
          if (W.value) {
            Ue();
            return;
          }
          const r = ce.value === t.id,
            i = ee(t.id);
          if (r && i === "connected" && !e) {
            (a.closeWebSocketConnection(t.id), l.success(`已断开 ${t.name} 的连接`));
            return;
          }
          if (!r && i === "connected" && !e) {
            (a.closeWebSocketConnection(t.id), l.success(`已断开 ${t.name} 的连接`));
            return;
          }
          if (r && i === "connecting" && !e) {
            l.info(`${t.name} 正在连接中...`);
            return;
          }
          a.selectToken(t.id, e)
            ? e
              ? l.success(`强制重连：${t.name}`)
              : r
                ? l.success(`重新连接：${t.name}`)
                : l.success(`已选择：${t.name}`)
            : l.error(`选择Token失败：${t.name}`);
        },
        ee = (t) => a.getWebSocketStatus(t),
        be = (t) => {
          const e = ee(t);
          return (
            {
              connected: "已连接",
              connecting: "连接中...",
              disconnected: "已断开",
              error: "连接错误",
              disconnecting: "断开中...",
            }[e] || "未连接"
          );
        },
        _e = (t) => {
          const e = ee(t);
          return (
            {
              connected: "success",
              connecting: "warning",
              disconnected: "danger",
              error: "danger",
              disconnecting: "warning",
            }[e] || "danger"
          );
        },
        Xe = (t) => (ee(t) === "connected" ? "success" : "error"),
        Ye = (t) => (ee(t) === "connected" ? "green" : "red"),
        xe = (t) => {
          const e = a.tokenAutoRefreshStatus[t];
          return (e && { success: "success", failed: "error", pending: "warning" }[e.status]) || "default";
        },
        Ce = (t) => {
          const e = a.tokenAutoRefreshStatus[t];
          return (e && { success: "已自动刷新", failed: "自动刷新失败", pending: "刷新中..." }[e.status]) || "正常";
        },
        $e = (t) => {
          const e = [
            { label: "编辑", key: "edit", icon: () => V(x, null, { default: () => V(me) }) },
            { label: "复制Token", key: "copy", icon: () => V(x, null, { default: () => V(Nt) }) },
          ];
          return (
            t.importMethod === "url" && t.sourceUrl
              ? e.push({ label: "从URL刷新", key: "refresh-url", icon: () => V(x, null, { default: () => V(Qt) }) })
              : e.push({ label: "重新获取", key: "refresh", icon: () => V(x, null, { default: () => V(pe) }) }),
            e.push(
              { type: "divider" },
              {
                label: "删除",
                key: "delete",
                icon: () => V(x, null, { default: () => V(Kt) }),
                props: { style: { color: "#e74c3c" } },
              },
            ),
            e
          );
        },
        Se = async (t, e) => {
          switch (t) {
            case "edit":
              Ze(e);
              break;
            case "copy":
              tt(e);
              break;
            case "refresh":
              Z(e);
              break;
            case "refresh-url":
              Z(e);
              break;
            case "delete":
              nt(e);
              break;
          }
        },
        Ze = (t) => {
          ((J.value = t),
            Object.assign(U, {
              name: t.name,
              token: t.token,
              server: t.server || "",
              wsUrl: t.wsUrl || "",
              remark: t.remark || "",
            }),
            (O.value = !0));
        },
        et = async () => {
          if (!(!H.value || !J.value))
            try {
              (await H.value.validate(),
                a.updateToken(J.value.id, {
                  name: U.name,
                  token: U.token,
                  server: U.server,
                  wsUrl: U.wsUrl,
                  remark: U.remark,
                }),
                l.success("Token信息已更新"),
                (O.value = !1),
                (J.value = null));
            } catch {}
        },
        tt = async (t) => {
          try {
            (await navigator.clipboard.writeText(t.token), l.success("Token已复制到剪贴板"));
          } catch {
            l.error("复制失败");
          }
        },
        Me = (t) => {
          ((W.value = t.id), (K.value[t.id] = t.remark || ""));
        },
        Ue = () => {
          if (!W.value) return;
          const t = W.value,
            e = K.value[t] || "";
          (a.updateToken(t, { remark: e }), (W.value = null), l.success("备注已保存"));
        },
        le = (t) => {
          Ue();
        },
        Ae = () => {
          W.value = null;
        },
        nt = (t) => {
          y.warning({
            title: "删除Token",
            content: `确定要删除Token "${t.name}" 吗？此操作无法恢复。`,
            positiveText: "确定删除",
            negativeText: "取消",
            onPositiveClick: async () => {
              (await a.removeToken(t.id), l.success("Token已删除"));
            },
          });
        },
        st = async () => {
          if (!a.gameTokens.length) {
            l.warning("没有可刷新的Token");
            return;
          }
          const t = a.gameTokens.filter(
              (r) => r.importMethod === "url" || r.importMethod === "wxQrcode" || r.importMethod === "bin",
            ),
            e = a.gameTokens.filter((r) => r.importMethod === "manual");
          if (t.length === 0) {
            l.warning("没有支持自动刷新的Token");
            return;
          }
          y.warning({
            title: "批量刷新Token",
            content: `确定要刷新所有支持自动刷新的Token吗？

共 ${t.length} 个Token需要刷新`,
            positiveText: "开始刷新",
            negativeText: "取消",
            onPositiveClick: async () => {
              try {
                let r = 0,
                  i = 0;
                const w = [],
                  h = l.loading(`正在批量刷新Token (0/${t.length})`, { duration: 0 });
                for (let v = 0; v < t.length; v++) {
                  const j = t[v];
                  try {
                    ((h.content = `正在刷新Token (${v + 1}/${t.length}): ${j.name}`), await Z(j), r++);
                  } catch (q) {
                    (console.error(`刷新Token "${j.name}" 失败:`, q),
                      i++,
                      w.push({ name: j.name, error: q.message || "未知错误" }));
                  }
                  const G = j.importMethod === "url" ? 800 : 300;
                  v < t.length - 1 && (await new Promise((q) => setTimeout(q, G)));
                }
                h.destroy();
                let M = "";
                (i > 0 &&
                  (M = w.map((v) => `- ${v.name}: ${v.error}`).join(`
`)),
                  i === 0
                    ? l.success(`批量刷新完成！成功刷新 ${r} 个Token`)
                    : r === 0
                      ? y.error({
                          title: "批量刷新失败",
                          content: `所有Token刷新失败 (共 ${i} 个)

失败详情：
${M}`,
                          positiveText: "知道了",
                        })
                      : y.warning({
                          title: "批量刷新完成",
                          content: `成功 ${r} 个，失败 ${i} 个

失败详情：
${M}`,
                          positiveText: "知道了",
                        }),
                  e.length > 0 &&
                    setTimeout(() => {
                      l.info(`${e.length} 个手动导入的Token需要手动刷新`);
                    }, 1500));
              } catch (r) {
                l.error("批量刷新过程中发生错误: " + r.message);
              }
            },
          });
        },
        ot = (t) => {
          switch (t) {
            case "refreshAll":
              st();
              break;
            case "updateInfo":
              dt();
              break;
            case "export":
              at();
              break;
            case "import":
              rt();
              break;
            case "clean":
              lt();
              break;
            case "disconnect":
              it();
              break;
            case "clear":
              ut();
              break;
          }
        },
        at = () => {
          try {
            const t = a.exportTokens(),
              e = JSON.stringify(t, null, 2),
              r = new Blob([e], { type: "application/json" }),
              i = document.createElement("a");
            ((i.href = URL.createObjectURL(r)),
              (i.download = `tokens_backup_${new Date().toISOString().split("T")[0]}.json`),
              i.click(),
              l.success("Token数据已导出"));
          } catch {
            l.error("导出失败");
          }
        },
        rt = () => {
          const t = document.createElement("input");
          ((t.type = "file"),
            (t.accept = ".json"),
            (t.onchange = (e) => {
              const r = e.target.files[0];
              if (r) {
                const i = new FileReader();
                ((i.onload = (w) => {
                  try {
                    const h = JSON.parse(w.target.result),
                      M = a.importTokens(h);
                    M.success ? l.success(M.message) : l.error(M.message);
                  } catch {
                    l.error("文件格式错误");
                  }
                }),
                  i.readAsText(r));
              }
            }),
            t.click());
        },
        lt = async () => {
          const t = await a.cleanExpiredTokens();
          l.success(`已清理 ${t} 个过期Token`);
        },
        it = () => {
          (a.gameTokens.forEach((t) => {
            a.closeWebSocketConnection(t.id);
          }),
            l.success("所有连接已断开"));
        },
        ut = () => {
          y.error({
            title: "清除所有Token",
            content: "确定要清除所有Token吗？此操作无法恢复！",
            positiveText: "确定清除",
            negativeText: "取消",
            onPositiveClick: async () => {
              (await a.clearAllTokens(), l.success("所有Token已清除"));
            },
          });
        },
        dt = async () => {
          if (a.gameTokens.length === 0) {
            l.warning("没有可更新的Token");
            return;
          }
          y.warning({
            title: "更新所有Token信息",
            content: `此操作将逐个连接所有Token，获取最新的角色名称和服务器信息，完成后自动断开连接。

预计耗时：约3-5秒/个Token`,
            positiveText: "开始更新",
            negativeText: "取消",
            onPositiveClick: async () => {
              try {
                let t = 0,
                  e = 0;
                const r = a.gameTokens.length,
                  i = l.loading(`正在更新Token信息 (0/${r})`, { duration: 0 });
                for (let w = 0; w < a.gameTokens.length; w++) {
                  const h = a.gameTokens[w];
                  i.content = `正在更新Token信息 (${w + 1}/${r}): ${h.name}`;
                  try {
                    (await a.selectToken(h.id),
                      await new Promise((M) => setTimeout(M, 1e3)),
                      a.closeWebSocketConnection(h.id),
                      t++,
                      l.success(`Token "${h.name}" 信息更新成功`));
                  } catch (M) {
                    (console.error(`更新Token "${h.name}" 失败:`, M), e++, l.error(`Token "${h.name}" 信息更新失败`));
                  }
                  w < a.gameTokens.length - 1 && (await new Promise((M) => setTimeout(M, 500)));
                }
                (i.destroy(),
                  e === 0
                    ? l.success(`所有Token信息更新完成！成功更新 ${t} 个Token`)
                    : l.warning(`Token信息更新完成，成功 ${t} 个，失败 ${e} 个`));
              } catch (t) {
                l.error("更新过程中发生错误: " + t.message);
              }
            },
          });
        },
        ct = (t) => {
          if (!t) return "";
          const e = t.length;
          return e <= 8 ? t : t.substring(0, 4) + "***" + t.substring(e - 4);
        },
        Re = (t) => new Date(t).toLocaleString("zh-CN"),
        mt = () => {
          L.push("/admin/batch-daily-tasks");
        },
        De = (t) => {
          (a.selectToken(t.id),
            l.success(`正在进入 ${t.name} 的游戏功能页面`),
            setTimeout(() => {
              L.push("/admin/game-features");
            }, 300));
        },
        ze = async () => {
          if (T.token || T.api)
            try {
              _.value = !0;
              let t = null;
              if (T.api) {
                l.info("正在从API获取token...");
                const e = await fetch(T.api, { method: "GET", headers: { Accept: "application/json" }, mode: "cors" });
                if (!e.ok) throw new Error(`API请求失败: ${e.status} ${e.statusText}`);
                const r = await e.json();
                if (!r.token) throw new Error("API返回数据中未找到token字段");
                t = a.importBase64Token(T.name || r.name || "通过API导入的Token", r.token, {
                  server: T.server || r.server,
                  wsUrl: T.wsUrl,
                  sourceUrl: T.api,
                  importMethod: "url",
                });
              } else
                T.token &&
                  (l.info("正在导入token..."),
                  (t = a.importBase64Token(T.name || "通过URL导入的Token", T.token, {
                    server: T.server,
                    wsUrl: T.wsUrl,
                    importMethod: "url",
                  })));
              if (t && t.success)
                (l.success(`Token "${t.tokenName}" 导入成功！`),
                  T.auto && t.token
                    ? (a.selectToken(t.token.id),
                      l.success("正在跳转到控制台..."),
                      setTimeout(() => {
                        L.push("/admin/dashboard");
                      }, 1500))
                    : L.replace("/tokens"));
              else throw new Error((t == null ? void 0 : t.message) || "Token导入失败");
            } catch (t) {
              (console.error("URL参数处理失败:", t), l.error(`导入失败: ${t.message}`), L.replace("/tokens"));
            } finally {
              _.value = !1;
            }
        };
      return (
        Le(() => [T.token, T.api], ze, { immediate: !1 }),
        Ut(async () => {
          (a.initTokenStore(), await ze(), !a.hasTokens && !T.token && !T.api && (f.value = !0));
        }),
        (t, e) => {
          const r = wt,
            i = B("n-radio-button"),
            w = B("n-radio-group"),
            h = Ot,
            M = B("n-divider"),
            v = B("n-button"),
            j = B("n-button-group"),
            G = B("n-space"),
            q = B("n-dropdown"),
            Be = B("n-avatar"),
            pt = jt,
            Ee = rn,
            te = B("n-tag"),
            ft = ln,
            X = B("n-input"),
            Ie = Jt,
            vt = Vt,
            gt = B("n-card"),
            kt = Wt,
            ne = B("n-form-item"),
            Tt = B("n-form"),
            yt = B("n-modal");
          return (
            g(),
            E("div", un, [
              u("div", dn, [
                u("div", cn, [
                  u("div", mn, [
                    u("div", pn, [
                      e[32] || (e[32] = u("img", { src: Dt, alt: "XYZW", class: "brand-logo" }, null, -1)),
                      s(r),
                    ]),
                    e[33] || (e[33] = u("h1", null, "游戏Token管理", -1)),
                  ]),
                ]),
                s(
                  h,
                  {
                    class: "token-import-modal",
                    visible: f.value,
                    "onUpdate:visible": e[11] || (e[11] = (n) => (f.value = n)),
                    width: "40rem",
                    footer: !1,
                    "default-visible": !d(a).hasTokens,
                  },
                  {
                    title: o(() => [
                      u("h2", null, [
                        s(d(x), null, { default: o(() => [s(d(We))]), _: 1 }),
                        e[34] || (e[34] = p(" 添加游戏Token ", -1)),
                      ]),
                    ]),
                    default: o(() => [
                      u("div", fn, [
                        s(
                          w,
                          {
                            value: $.value,
                            "onUpdate:value": e[0] || (e[0] = (n) => ($.value = n)),
                            class: "import-method-tabs",
                            size: "small",
                          },
                          {
                            default: o(() => [
                              s(
                                i,
                                { value: "manual" },
                                { default: o(() => [...(e[35] || (e[35] = [p(" 手动输入 ", -1)]))]), _: 1 },
                              ),
                              s(
                                i,
                                { value: "url" },
                                { default: o(() => [...(e[36] || (e[36] = [p(" URL获取 ", -1)]))]), _: 1 },
                              ),
                              s(
                                i,
                                { value: "wxQrcode" },
                                { default: o(() => [...(e[37] || (e[37] = [p(" 微信扫码获取 ", -1)]))]), _: 1 },
                              ),
                              s(
                                i,
                                { value: "bin" },
                                { default: o(() => [...(e[38] || (e[38] = [p(" BIN多角色获取 ", -1)]))]), _: 1 },
                              ),
                              s(
                                i,
                                { value: "singlebin" },
                                { default: o(() => [...(e[39] || (e[39] = [p(" BIN单角色获取 ", -1)]))]), _: 1 },
                              ),
                            ]),
                            _: 1,
                          },
                          8,
                          ["value"],
                        ),
                      ]),
                      u("div", vn, [
                        $.value === "manual"
                          ? (g(),
                            z(zt, {
                              key: 0,
                              onCancel: e[1] || (e[1] = () => (f.value = !1)),
                              onOk: e[2] || (e[2] = () => (f.value = !1)),
                            }))
                          : D("", !0),
                        $.value === "url"
                          ? (g(),
                            z(Bt, {
                              key: 1,
                              onCancel: e[3] || (e[3] = () => (f.value = !1)),
                              onOk: e[4] || (e[4] = () => (f.value = !1)),
                            }))
                          : D("", !0),
                        $.value === "wxQrcode"
                          ? (g(),
                            z(Pt, {
                              key: 2,
                              onCancel: e[5] || (e[5] = () => (f.value = !1)),
                              onOk: e[6] || (e[6] = () => (f.value = !1)),
                            }))
                          : D("", !0),
                        $.value === "bin"
                          ? (g(),
                            z(Et, {
                              key: 3,
                              onCancel: e[7] || (e[7] = () => (f.value = !1)),
                              onOk: e[8] || (e[8] = () => (f.value = !1)),
                            }))
                          : D("", !0),
                        $.value === "singlebin"
                          ? (g(),
                            z(It, {
                              key: 4,
                              onCancel: e[9] || (e[9] = () => (f.value = !1)),
                              onOk: e[10] || (e[10] = () => (f.value = !1)),
                            }))
                          : D("", !0),
                      ]),
                    ]),
                    _: 1,
                  },
                  8,
                  ["visible", "default-visible"],
                ),
                d(a).hasTokens
                  ? (g(),
                    E("div", gn, [
                      u("div", kn, [
                        s(
                          G,
                          { align: "center" },
                          {
                            default: o(() => [
                              u("h2", null, "我的Token列表 (" + C(d(a).gameTokens.length) + "个)", 1),
                              s(
                                w,
                                {
                                  value: Q.value,
                                  "onUpdate:value": e[12] || (e[12] = (n) => (Q.value = n)),
                                  size: "small",
                                },
                                {
                                  default: o(() => [
                                    s(
                                      i,
                                      { value: "list" },
                                      { default: o(() => [...(e[40] || (e[40] = [p("列表", -1)]))]), _: 1 },
                                    ),
                                    s(
                                      i,
                                      { value: "card" },
                                      { default: o(() => [...(e[41] || (e[41] = [p("卡片", -1)]))]), _: 1 },
                                    ),
                                  ]),
                                  _: 1,
                                },
                                8,
                                ["value"],
                              ),
                              s(M, { vertical: "", style: { height: "24px" } }),
                              s(
                                j,
                                { size: "small" },
                                {
                                  default: o(() => [
                                    s(
                                      v,
                                      {
                                        onClick: e[13] || (e[13] = (n) => ae("name")),
                                        type: S.value.field === "name" ? "primary" : "default",
                                      },
                                      { default: o(() => [p(" 名称 " + C(re("name")), 1)]), _: 1 },
                                      8,
                                      ["type"],
                                    ),
                                    s(
                                      v,
                                      {
                                        onClick: e[14] || (e[14] = (n) => ae("server")),
                                        type: S.value.field === "server" ? "primary" : "default",
                                      },
                                      { default: o(() => [p(" 服务器 " + C(re("server")), 1)]), _: 1 },
                                      8,
                                      ["type"],
                                    ),
                                    s(
                                      v,
                                      {
                                        onClick: e[15] || (e[15] = (n) => ae("createdAt")),
                                        type: S.value.field === "createdAt" ? "primary" : "default",
                                      },
                                      { default: o(() => [p(" 创建时间 " + C(re("createdAt")), 1)]), _: 1 },
                                      8,
                                      ["type"],
                                    ),
                                    s(
                                      v,
                                      {
                                        onClick: e[16] || (e[16] = (n) => ae("lastUsed")),
                                        type: S.value.field === "lastUsed" ? "primary" : "default",
                                      },
                                      { default: o(() => [p(" 最后使用 " + C(re("lastUsed")), 1)]), _: 1 },
                                      8,
                                      ["type"],
                                    ),
                                  ]),
                                  _: 1,
                                },
                              ),
                            ]),
                            _: 1,
                          },
                        ),
                        u("div", Tn, [
                          s(
                            v,
                            { type: "success", onClick: mt },
                            {
                              icon: o(() => [s(d(x), null, { default: o(() => [s(d(Zt))]), _: 1 })]),
                              default: o(() => [e[42] || (e[42] = p(" 批量功能 ", -1))]),
                              _: 1,
                            },
                          ),
                          f.value
                            ? D("", !0)
                            : (g(),
                              z(
                                v,
                                { key: 0, type: "primary", onClick: e[17] || (e[17] = (n) => (f.value = !0)) },
                                {
                                  icon: o(() => [s(d(x), null, { default: o(() => [s(d(We))]), _: 1 })]),
                                  default: o(() => [e[43] || (e[43] = p(" 添加Token ", -1))]),
                                  _: 1,
                                },
                              )),
                          s(
                            q,
                            { options: Je, onSelect: ot },
                            {
                              default: o(() => [
                                s(v, null, {
                                  icon: o(() => [s(d(x), null, { default: o(() => [s(d(Ft))]), _: 1 })]),
                                  default: o(() => [e[44] || (e[44] = p(" 批量操作 ", -1))]),
                                  _: 1,
                                }),
                              ]),
                              _: 1,
                            },
                          ),
                        ]),
                      ]),
                      Q.value === "card"
                        ? (g(),
                          E("div", yn, [
                            (g(!0),
                            E(
                              ge,
                              null,
                              Oe(
                                d(de),
                                (n, se) => (
                                  g(),
                                  z(
                                    vt,
                                    {
                                      key: n.id,
                                      draggable: "true",
                                      onDragstart: (c) => ke(se, c),
                                      onDragover: e[20] || (e[20] = (c) => Te(c)),
                                      onDrop: (c) => ye(se, c),
                                      class: Ne({ "token-card": !0, active: d(ce) === n.id }),
                                      onClick: (c) => he(n),
                                    },
                                    {
                                      title: o(() => [
                                        s(
                                          ft,
                                          { class: "token-name", align: "center" },
                                          {
                                            default: o(() => [
                                              n.avatar
                                                ? (g(),
                                                  z(
                                                    Be,
                                                    {
                                                      key: 0,
                                                      src: n.avatar,
                                                      round: "",
                                                      size: "small",
                                                      "fallback-src": "/icons/xiaoyugan.png",
                                                    },
                                                    null,
                                                    8,
                                                    ["src"],
                                                  ))
                                                : D("", !0),
                                              p(" " + C(n.name) + " ", 1),
                                              n.server
                                                ? (g(),
                                                  z(
                                                    pt,
                                                    { key: 1, color: Ye(n.id) },
                                                    { default: o(() => [p(C(n.server), 1)]), _: 2 },
                                                    1032,
                                                    ["color"],
                                                  ))
                                                : D("", !0),
                                              s(Ee, { status: _e(n.id), text: be(n.id) }, null, 8, ["status", "text"]),
                                              s(
                                                te,
                                                { type: xe(n.id), size: "small", style: { "margin-left": "8px" } },
                                                { default: o(() => [p(C(Ce(n.id)), 1)]), _: 2 },
                                                1032,
                                                ["type"],
                                              ),
                                            ]),
                                            _: 2,
                                          },
                                          1024,
                                        ),
                                      ]),
                                      extra: o(() => [
                                        s(
                                          q,
                                          { options: $e(n), onSelect: (c) => Se(c, n) },
                                          {
                                            default: o(() => [
                                              s(
                                                v,
                                                { text: "" },
                                                {
                                                  icon: o(() => [
                                                    s(d(x), null, { default: o(() => [s(d(Fe))]), _: 1 }),
                                                  ]),
                                                  _: 1,
                                                },
                                              ),
                                            ]),
                                            _: 1,
                                          },
                                          8,
                                          ["options", "onSelect"],
                                        ),
                                      ]),
                                      default: o(() => [
                                        u("div", wn, [
                                          e[45] || (e[45] = u("span", { class: "token-label" }, "Token:", -1)),
                                          u("code", hn, C(ct(n.token)), 1),
                                        ]),
                                        W.value === n.id
                                          ? (g(),
                                            E(
                                              "div",
                                              {
                                                key: 0,
                                                class: "token-remark token-remark-edit",
                                                onClick: e[19] || (e[19] = F(() => {}, ["stop"])),
                                              },
                                              [
                                                e[46] || (e[46] = u("span", { class: "remark-label" }, "备注：", -1)),
                                                s(
                                                  X,
                                                  {
                                                    value: K.value[n.id],
                                                    "onUpdate:value": (c) => (K.value[n.id] = c),
                                                    type: "textarea",
                                                    rows: 2,
                                                    placeholder: "添加备注信息...",
                                                    onBlur: (c) => le(n),
                                                    onKeyup: [
                                                      ie((c) => le(n), ["enter"]),
                                                      e[18] || (e[18] = ie((c) => Ae(), ["esc"])),
                                                    ],
                                                    autofocus: "",
                                                  },
                                                  null,
                                                  8,
                                                  ["value", "onUpdate:value", "onBlur", "onKeyup"],
                                                ),
                                              ],
                                            ))
                                          : (g(),
                                            E(
                                              "div",
                                              { key: 1, class: "token-remark", onClick: F((c) => Me(n), ["stop"]) },
                                              [
                                                e[47] || (e[47] = u("span", { class: "remark-label" }, "备注：", -1)),
                                                u("span", _n, C(n.remark || "点击添加备注"), 1),
                                                s(
                                                  d(x),
                                                  { style: { "margin-left": "4px", color: "var(--text-tertiary)" } },
                                                  { default: o(() => [s(d(me))]), _: 1 },
                                                ),
                                              ],
                                              8,
                                              bn,
                                            )),
                                        s(
                                          Ie,
                                          { loading: A.value.has(n.id), onClick: F((c) => Z(n), ["stop"]) },
                                          {
                                            icon: o(() => [s(d(x), null, { default: o(() => [s(d(pe))]), _: 1 })]),
                                            default: o(() => [p(" " + C(n.sourceUrl ? "刷新" : "重新获取"), 1)]),
                                            _: 2,
                                          },
                                          1032,
                                          ["loading", "onClick"],
                                        ),
                                        u("div", xn, [
                                          u("div", Cn, [
                                            e[48] || (e[48] = u("span", { class: "timestamp-label" }, "创建：", -1)),
                                            u("span", $n, C(Re(n.createdAt)), 1),
                                          ]),
                                          u("div", Sn, [
                                            e[49] || (e[49] = u("span", { class: "timestamp-label" }, "使用：", -1)),
                                            u("span", Mn, C(Re(n.lastUsed)), 1),
                                          ]),
                                        ]),
                                        u("div", Un, [
                                          u("div", An, [
                                            e[50] || (e[50] = u("span", { class: "storage-label" }, "存储类型：", -1)),
                                            s(
                                              te,
                                              {
                                                size: "small",
                                                type:
                                                  n.importMethod === "url" ||
                                                  n.importMethod === "bin" ||
                                                  n.importMethod === "wxQrcode" ||
                                                  n.upgradedToPermanent
                                                    ? "success"
                                                    : "warning",
                                              },
                                              {
                                                default: o(() => [
                                                  p(
                                                    C(
                                                      n.importMethod === "url" ||
                                                        n.importMethod === "bin" ||
                                                        n.importMethod === "wxQrcode" ||
                                                        n.upgradedToPermanent
                                                        ? "长期有效"
                                                        : "临时存储",
                                                    ),
                                                    1,
                                                  ),
                                                ]),
                                                _: 2,
                                              },
                                              1032,
                                              ["type"],
                                            ),
                                          ]),
                                          n.importMethod === "url" ||
                                          n.importMethod === "bin" ||
                                          n.importMethod === "wxQrcode" ||
                                          n.upgradedToPermanent
                                            ? D("", !0)
                                            : (g(),
                                              E("div", Rn, [
                                                s(
                                                  v,
                                                  {
                                                    size: "tiny",
                                                    type: "success",
                                                    ghost: "",
                                                    onClick: F((c) => we(n), ["stop"]),
                                                  },
                                                  {
                                                    icon: o(() => [
                                                      s(d(x), null, { default: o(() => [s(d(Ve))]), _: 1 }),
                                                    ]),
                                                    default: o(() => [e[51] || (e[51] = p(" 升级为长期有效 ", -1))]),
                                                    _: 1,
                                                  },
                                                  8,
                                                  ["onClick"],
                                                ),
                                              ])),
                                        ]),
                                      ]),
                                      actions: o(() => [
                                        s(
                                          v,
                                          {
                                            type: "primary",
                                            size: "large",
                                            block: "",
                                            loading: N.value.has(n.id),
                                            onClick: (c) => De(n),
                                          },
                                          {
                                            icon: o(() => [s(d(x), null, { default: o(() => [s(d(Pe))]), _: 1 })]),
                                            default: o(() => [e[52] || (e[52] = p(" 进入控制台 ", -1))]),
                                            _: 1,
                                          },
                                          8,
                                          ["loading", "onClick"],
                                        ),
                                      ]),
                                      _: 2,
                                    },
                                    1032,
                                    ["onDragstart", "onDrop", "class", "onClick"],
                                  )
                                ),
                              ),
                              128,
                            )),
                          ]))
                        : (g(),
                          E("div", Dn, [
                            (g(!0),
                            E(
                              ge,
                              null,
                              Oe(
                                d(de),
                                (n, se) => (
                                  g(),
                                  z(
                                    gt,
                                    {
                                      key: n.id,
                                      draggable: "true",
                                      onDragstart: (c) => ke(se, c),
                                      onDragover: e[24] || (e[24] = (c) => Te(c)),
                                      onDrop: (c) => ye(se, c),
                                      size: "small",
                                      style: { "margin-bottom": "8px" },
                                      hoverable: "",
                                      onClick: (c) => he(n),
                                      class: Ne({ active: d(ce) === n.id }),
                                    },
                                    {
                                      default: o(() => [
                                        s(
                                          G,
                                          { justify: "space-between", align: "center" },
                                          {
                                            default: o(() => [
                                              s(
                                                G,
                                                { align: "center", size: 6 },
                                                {
                                                  default: o(() => [
                                                    u("div", zn, [
                                                      s(Ee, { status: _e(n.id), text: be(n.id) }, null, 8, [
                                                        "status",
                                                        "text",
                                                      ]),
                                                    ]),
                                                    u("div", Bn, [
                                                      s(
                                                        te,
                                                        { type: xe(n.id), size: "small" },
                                                        { default: o(() => [p(C(Ce(n.id)), 1)]), _: 2 },
                                                        1032,
                                                        ["type"],
                                                      ),
                                                    ]),
                                                    n.avatar
                                                      ? (g(),
                                                        z(
                                                          Be,
                                                          {
                                                            key: 0,
                                                            src: n.avatar,
                                                            round: "",
                                                            size: "small",
                                                            "fallback-src": "/icons/xiaoyugan.png",
                                                          },
                                                          null,
                                                          8,
                                                          ["src"],
                                                        ))
                                                      : D("", !0),
                                                    u("div", En, [
                                                      u("div", In, [
                                                        u("span", Pn, C(n.name), 1),
                                                        n.server
                                                          ? (g(),
                                                            z(
                                                              te,
                                                              { key: 0, size: "small", type: Xe(n.id) },
                                                              { default: o(() => [p(C(n.server), 1)]), _: 2 },
                                                              1032,
                                                              ["type"],
                                                            ))
                                                          : D("", !0),
                                                        W.value === n.id
                                                          ? (g(),
                                                            E(
                                                              "div",
                                                              {
                                                                key: 1,
                                                                style: {
                                                                  "font-size": "0.75em",
                                                                  display: "flex",
                                                                  "align-items": "center",
                                                                  gap: "4px",
                                                                },
                                                                onClick: e[22] || (e[22] = F(() => {}, ["stop"])),
                                                              },
                                                              [
                                                                e[53] ||
                                                                  (e[53] = u(
                                                                    "i",
                                                                    {
                                                                      class: "i-mdi:note-outline",
                                                                      style: { "margin-right": "1px" },
                                                                    },
                                                                    null,
                                                                    -1,
                                                                  )),
                                                                s(
                                                                  X,
                                                                  {
                                                                    value: K.value[n.id],
                                                                    "onUpdate:value": (c) => (K.value[n.id] = c),
                                                                    size: "small",
                                                                    placeholder: "添加备注...",
                                                                    onBlur: (c) => le(n),
                                                                    onKeyup: [
                                                                      ie((c) => le(n), ["enter"]),
                                                                      e[21] || (e[21] = ie((c) => Ae(), ["esc"])),
                                                                    ],
                                                                    autofocus: "",
                                                                    style: { width: "150px" },
                                                                  },
                                                                  null,
                                                                  8,
                                                                  ["value", "onUpdate:value", "onBlur", "onKeyup"],
                                                                ),
                                                              ],
                                                            ))
                                                          : (g(),
                                                            E(
                                                              "div",
                                                              {
                                                                key: 2,
                                                                style: {
                                                                  "font-size": "0.75em",
                                                                  color: "var(--text-secondary)",
                                                                  "white-space": "nowrap",
                                                                  overflow: "hidden",
                                                                  "text-overflow": "ellipsis",
                                                                  cursor: "pointer",
                                                                  display: "flex",
                                                                  "align-items": "center",
                                                                  gap: "4px",
                                                                },
                                                                onClick: F((c) => Me(n), ["stop"]),
                                                              },
                                                              [
                                                                e[54] ||
                                                                  (e[54] = u(
                                                                    "i",
                                                                    {
                                                                      class: "i-mdi:note-outline",
                                                                      style: { "margin-right": "1px" },
                                                                    },
                                                                    null,
                                                                    -1,
                                                                  )),
                                                                p(" " + C(n.remark || "点击添加备注") + " ", 1),
                                                                s(
                                                                  d(x),
                                                                  {
                                                                    style: {
                                                                      "font-size": "0.8em",
                                                                      color: "var(--text-tertiary)",
                                                                    },
                                                                  },
                                                                  { default: o(() => [s(d(me))]), _: 1 },
                                                                ),
                                                              ],
                                                              8,
                                                              Ln,
                                                            )),
                                                      ]),
                                                    ]),
                                                  ]),
                                                  _: 2,
                                                },
                                                1024,
                                              ),
                                              s(
                                                G,
                                                null,
                                                {
                                                  default: o(() => [
                                                    s(
                                                      te,
                                                      {
                                                        size: "small",
                                                        type:
                                                          n.importMethod === "url" ||
                                                          n.importMethod === "bin" ||
                                                          n.importMethod === "wxQrcode" ||
                                                          n.upgradedToPermanent
                                                            ? "success"
                                                            : "warning",
                                                      },
                                                      {
                                                        default: o(() => [
                                                          p(
                                                            C(
                                                              n.importMethod === "url" ||
                                                                n.importMethod === "bin" ||
                                                                n.importMethod === "wxQrcode" ||
                                                                n.upgradedToPermanent
                                                                ? "长期"
                                                                : "临时",
                                                            ),
                                                            1,
                                                          ),
                                                        ]),
                                                        _: 2,
                                                      },
                                                      1032,
                                                      ["type"],
                                                    ),
                                                    n.importMethod === "url" ||
                                                    n.importMethod === "bin" ||
                                                    n.importMethod === "wxQrcode" ||
                                                    n.upgradedToPermanent
                                                      ? D("", !0)
                                                      : (g(),
                                                        z(
                                                          v,
                                                          {
                                                            key: 0,
                                                            size: "small",
                                                            type: "success",
                                                            ghost: "",
                                                            onClick: F((c) => we(n), ["stop"]),
                                                          },
                                                          {
                                                            icon: o(() => [
                                                              s(d(x), null, { default: o(() => [s(d(Ve))]), _: 1 }),
                                                            ]),
                                                            default: o(() => [e[55] || (e[55] = p(" 升级 ", -1))]),
                                                            _: 1,
                                                          },
                                                          8,
                                                          ["onClick"],
                                                        )),
                                                    s(
                                                      v,
                                                      {
                                                        size: "small",
                                                        type: "primary",
                                                        loading: N.value.has(n.id),
                                                        onClick: F((c) => De(n), ["stop"]),
                                                      },
                                                      {
                                                        icon: o(() => [
                                                          s(d(x), null, { default: o(() => [s(d(Pe))]), _: 1 }),
                                                        ]),
                                                        default: o(() => [e[56] || (e[56] = p(" 控制台 ", -1))]),
                                                        _: 1,
                                                      },
                                                      8,
                                                      ["loading", "onClick"],
                                                    ),
                                                    s(
                                                      v,
                                                      {
                                                        size: "small",
                                                        onClick: F((c) => Z(n), ["stop"]),
                                                        loading: A.value.has(n.id),
                                                      },
                                                      {
                                                        icon: o(() => [
                                                          s(d(x), null, { default: o(() => [s(d(pe))]), _: 1 }),
                                                        ]),
                                                        default: o(() => [e[57] || (e[57] = p(" 刷新 ", -1))]),
                                                        _: 1,
                                                      },
                                                      8,
                                                      ["onClick", "loading"],
                                                    ),
                                                    s(
                                                      q,
                                                      { options: $e(n), onSelect: (c) => Se(c, n) },
                                                      {
                                                        default: o(() => [
                                                          s(
                                                            v,
                                                            {
                                                              size: "small",
                                                              circle: "",
                                                              onClick: e[23] || (e[23] = F(() => {}, ["stop"])),
                                                            },
                                                            {
                                                              icon: o(() => [
                                                                s(d(x), null, { default: o(() => [s(d(Fe))]), _: 1 }),
                                                              ]),
                                                              _: 1,
                                                            },
                                                          ),
                                                        ]),
                                                        _: 1,
                                                      },
                                                      8,
                                                      ["options", "onSelect"],
                                                    ),
                                                  ]),
                                                  _: 2,
                                                },
                                                1024,
                                              ),
                                            ]),
                                            _: 2,
                                          },
                                          1024,
                                        ),
                                      ]),
                                      _: 2,
                                    },
                                    1032,
                                    ["onDragstart", "onDrop", "onClick", "class"],
                                  )
                                ),
                              ),
                              128,
                            )),
                          ])),
                    ]))
                  : D("", !0),
                !d(a).hasTokens && !f.value
                  ? (g(),
                    z(
                      kt,
                      { key: 1 },
                      {
                        image: o(() => [...(e[58] || (e[58] = [u("i", { class: "mdi:bed-empty" }, null, -1)]))]),
                        default: o(() => [
                          e[60] || (e[60] = p(" 还没有导入任何Token ", -1)),
                          s(
                            Ie,
                            { type: "link", onClick: qe },
                            { default: o(() => [...(e[59] || (e[59] = [p("打开Token管理", -1)]))]), _: 1 },
                          ),
                        ]),
                        _: 1,
                      },
                    ))
                  : D("", !0),
              ]),
              s(
                yt,
                {
                  show: O.value,
                  "onUpdate:show": e[31] || (e[31] = (n) => (O.value = n)),
                  preset: "card",
                  title: "编辑Token",
                  style: { width: "500px" },
                },
                {
                  footer: o(() => [
                    u("div", On, [
                      s(
                        v,
                        { onClick: e[30] || (e[30] = (n) => (O.value = !1)) },
                        { default: o(() => [...(e[61] || (e[61] = [p(" 取消 ", -1)]))]), _: 1 },
                      ),
                      s(
                        v,
                        { type: "primary", onClick: et },
                        { default: o(() => [...(e[62] || (e[62] = [p(" 保存 ", -1)]))]), _: 1 },
                      ),
                    ]),
                  ]),
                  default: o(() => [
                    s(
                      Tt,
                      {
                        ref_key: "editFormRef",
                        ref: H,
                        model: U,
                        rules: He,
                        "label-placement": "left",
                        "label-width": "80px",
                      },
                      {
                        default: o(() => [
                          s(
                            ne,
                            { label: "名称", path: "name" },
                            {
                              default: o(() => [
                                s(
                                  X,
                                  { value: U.name, "onUpdate:value": e[25] || (e[25] = (n) => (U.name = n)) },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          s(
                            ne,
                            { label: "Token字符串", path: "token" },
                            {
                              default: o(() => [
                                s(
                                  X,
                                  {
                                    value: U.token,
                                    "onUpdate:value": e[26] || (e[26] = (n) => (U.token = n)),
                                    type: "textarea",
                                    rows: 3,
                                    placeholder: "粘贴Token字符串...",
                                    clearable: "",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          s(
                            ne,
                            { label: "服务器" },
                            {
                              default: o(() => [
                                s(
                                  X,
                                  { value: U.server, "onUpdate:value": e[27] || (e[27] = (n) => (U.server = n)) },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          s(
                            ne,
                            { label: "WebSocket地址" },
                            {
                              default: o(() => [
                                s(
                                  X,
                                  { value: U.wsUrl, "onUpdate:value": e[28] || (e[28] = (n) => (U.wsUrl = n)) },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                          s(
                            ne,
                            { label: "备注" },
                            {
                              default: o(() => [
                                s(
                                  X,
                                  {
                                    value: U.remark,
                                    "onUpdate:value": e[29] || (e[29] = (n) => (U.remark = n)),
                                    type: "textarea",
                                    rows: 2,
                                    placeholder: "添加备注信息...",
                                  },
                                  null,
                                  8,
                                  ["value"],
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                        ]),
                        _: 1,
                      },
                      8,
                      ["model"],
                    ),
                  ]),
                  _: 1,
                },
                8,
                ["show"],
              ),
            ])
          );
        }
      );
    },
  },
  fs = Lt(Nn, [["__scopeId", "data-v-82d82eb8"]]);
export { fs as default };
