import {
  k as de,
  c as g,
  h as m,
  a as s,
  s as Z,
  r as $,
  y as ee,
  d as _,
  A as b,
  b as n,
  t as p,
  E as P,
  w as l,
  u as R,
  i as x,
  F as K,
  g as H,
  e as Q,
  v as ue,
  x as me,
  p as J,
  o as ve,
  f as ge,
} from "./index-UoU16364.js";
import { _ as te } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { S as Y } from "./Settings-BMY43FOw.js";
import { T as fe } from "./Time-Buls15_H.js";
import { u as pe } from "./gameRoles-DtpzXQTv.js";
import { u as ke } from "./localTokenManager-BQJEcmfy.js";
import { u as _e } from "./auth-BYvggjsB.js";
import { R as he } from "./Refresh-DWYLAev-.js";
import { C as we } from "./ChevronDown-CJ0-FHvp.js";
import { S as ye } from "./Search-D4B4lpJB.js";
import { C as xe } from "./Cube-CwoBO7fL.js";
const be = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  Se = s(
    "path",
    {
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "32",
      d: "M416 128L192 384l-96-96",
    },
    null,
    -1,
  ),
  $e = [Se],
  Te = de({
    name: "Checkmark",
    render: function (z, d) {
      return (m(), g("svg", be, $e));
    },
  }),
  Ce = { class: "card-header" },
  De = { class: "header-left" },
  Ee = ["src", "alt"],
  Re = { class: "title-container" },
  Oe = { class: "title" },
  Ae = { key: 0, class: "subtitle" },
  Le = { class: "header-right" },
  Ue = { key: 0, class: "progress-container" },
  Ie = { class: "info-container" },
  Ne = { class: "info-item" },
  We = { class: "info-value" },
  Pe = { key: 0, class: "info-item" },
  ze = { class: "info-value" },
  Be = { key: 1, class: "info-item" },
  Me = { class: "info-value" },
  Fe = { key: 1, class: "actions-container" },
  Ve = { class: "modal-header" },
  Ge = { class: "settings-content" },
  Je = { class: "settings-grid" },
  je = { class: "setting-item" },
  qe = { class: "setting-item" },
  Ke = { class: "setting-item" },
  He = { key: 0, class: "task-details" },
  Qe = { class: "task-list" },
  Xe = { class: "task-item-left" },
  Ye = { class: "task-name" },
  Ze = { key: 1, class: "execution-log" },
  et = { class: "log-container" },
  tt = { class: "log-time" },
  st = {
    __name: "DailyTaskCard",
    props: { task: { type: Object, required: !0 } },
    emits: ["update:task", "execute", "toggle-status"],
    setup(i, { emit: z }) {
      var B, M, I;
      const d = i,
        O = z,
        y = Z(),
        f = $(!1),
        S = $(!1),
        h = $({
          autoExecute: ((B = d.task.settings) == null ? void 0 : B.autoExecute) || !1,
          delay: ((M = d.task.settings) == null ? void 0 : M.delay) || 0,
          notification: ((I = d.task.settings) == null ? void 0 : I.notification) || !0,
        }),
        U = () => (S.value ? "执行中..." : d.task.canExecute ? "立即执行" : "不可执行"),
        N = () => {
          O("toggle-status", d.task.id);
        },
        v = async () => {
          if (!(S.value || !d.task.canExecute))
            try {
              ((S.value = !0),
                await O("execute", d.task.id),
                h.value.notification && y.success(`任务 "${d.task.title}" 执行成功`));
            } catch (k) {
              y.error(`任务执行失败: ${k.message}`);
            } finally {
              S.value = !1;
            }
        },
        T = (k, a) => {
          ((h.value[k] = a), O("update:task", { ...d.task, settings: { ...h.value } }));
        },
        A = (k) =>
          new Date(k).toLocaleString("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }),
        c = (k) => new Date(k).toLocaleTimeString("zh-CN", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      return (
        ee(
          () => d.task.settings,
          (k) => {
            k && (h.value = { ...h.value, ...k });
          },
          { immediate: !0 },
        ),
        (k, a) => {
          const W = _("n-icon"),
            C = _("n-button"),
            F = _("n-checkbox"),
            V = _("n-input-number"),
            j = _("n-modal");
          return (
            m(),
            g(
              "div",
              { class: P(["daily-task-card", { completed: i.task.completed }]) },
              [
                s("div", Ce, [
                  s("div", De, [
                    s(
                      "img",
                      { src: i.task.icon || "/icons/ta.png", alt: i.task.title, class: "task-icon" },
                      null,
                      8,
                      Ee,
                    ),
                    s("div", Re, [
                      s("h3", Oe, p(i.task.title), 1),
                      i.task.subtitle ? (m(), g("p", Ae, p(i.task.subtitle), 1)) : b("", !0),
                    ]),
                  ]),
                  s("div", Le, [
                    s(
                      "div",
                      { class: P(["status-indicator", { completed: i.task.completed }]), onClick: N },
                      [
                        s("span", { class: P(["status-dot", { completed: i.task.completed }]) }, null, 2),
                        s("span", null, p(i.task.completed ? "已完成" : "待完成"), 1),
                      ],
                      2,
                    ),
                    n(
                      C,
                      { text: "", class: "settings-button", onClick: a[0] || (a[0] = (r) => (f.value = !0)) },
                      {
                        icon: l(() => [n(W, { class: "settings-icon" }, { default: l(() => [n(R(Y))]), _: 1 })]),
                        _: 1,
                      },
                    ),
                  ]),
                ]),
                i.task.progress
                  ? (m(),
                    g("div", Ue, [
                      s("div", Ie, [
                        s("div", Ne, [
                          a[8] || (a[8] = s("span", { class: "info-label" }, "当前进度", -1)),
                          s("span", We, p(i.task.progress.current) + "/" + p(i.task.progress.total), 1),
                        ]),
                        i.task.reward
                          ? (m(),
                            g("div", Pe, [
                              a[9] || (a[9] = s("span", { class: "info-label" }, "奖励", -1)),
                              s("span", ze, p(i.task.reward), 1),
                            ]))
                          : b("", !0),
                        i.task.nextReset
                          ? (m(),
                            g("div", Be, [
                              a[10] || (a[10] = s("span", { class: "info-label" }, "重置时间", -1)),
                              s("span", Me, p(A(i.task.nextReset)), 1),
                            ]))
                          : b("", !0),
                      ]),
                    ]))
                  : b("", !0),
                i.task.completed
                  ? b("", !0)
                  : (m(),
                    g("div", Fe, [
                      n(
                        C,
                        {
                          type: "primary",
                          block: "",
                          loading: S.value,
                          disabled: !i.task.canExecute,
                          class: "complete-button",
                          onClick: v,
                        },
                        { default: l(() => [x(p(U()), 1)]), _: 1 },
                        8,
                        ["loading", "disabled"],
                      ),
                    ])),
                n(
                  j,
                  {
                    show: f.value,
                    "onUpdate:show": a[7] || (a[7] = (r) => (f.value = r)),
                    preset: "card",
                    title: "任务设置",
                    style: { width: "480px" },
                  },
                  {
                    header: l(() => [
                      s("div", Ve, [
                        n(W, { class: "modal-icon" }, { default: l(() => [n(R(Y))]), _: 1 }),
                        s("span", null, p(i.task.title) + " - 设置", 1),
                      ]),
                    ]),
                    default: l(() => [
                      s("div", Ge, [
                        s("div", Je, [
                          s("div", je, [
                            n(
                              F,
                              {
                                checked: h.value.autoExecute,
                                "onUpdate:checked": [
                                  a[1] || (a[1] = (r) => (h.value.autoExecute = r)),
                                  a[2] || (a[2] = (r) => T("autoExecute", r)),
                                ],
                              },
                              { default: l(() => [...(a[11] || (a[11] = [x(" 自动执行 ", -1)]))]), _: 1 },
                              8,
                              ["checked"],
                            ),
                          ]),
                          s("div", qe, [
                            a[12] || (a[12] = s("label", { class: "setting-label" }, "执行延迟 (秒)", -1)),
                            n(
                              V,
                              {
                                value: h.value.delay,
                                "onUpdate:value": [
                                  a[3] || (a[3] = (r) => (h.value.delay = r)),
                                  a[4] || (a[4] = (r) => T("delay", r)),
                                ],
                                min: 0,
                                max: 300,
                              },
                              null,
                              8,
                              ["value"],
                            ),
                          ]),
                          s("div", Ke, [
                            n(
                              F,
                              {
                                checked: h.value.notification,
                                "onUpdate:checked": [
                                  a[5] || (a[5] = (r) => (h.value.notification = r)),
                                  a[6] || (a[6] = (r) => T("notification", r)),
                                ],
                              },
                              { default: l(() => [...(a[13] || (a[13] = [x(" 完成通知 ", -1)]))]), _: 1 },
                              8,
                              ["checked"],
                            ),
                          ]),
                        ]),
                        i.task.details
                          ? (m(),
                            g("div", He, [
                              a[14] || (a[14] = s("h4", null, "任务详情", -1)),
                              s("div", Qe, [
                                (m(!0),
                                g(
                                  K,
                                  null,
                                  H(
                                    i.task.details,
                                    (r) => (
                                      m(),
                                      g("div", { key: r.id, class: "task-item" }, [
                                        s("div", Xe, [
                                          n(
                                            W,
                                            { class: P(["task-status-icon", { completed: r.completed }]) },
                                            {
                                              default: l(() => [
                                                r.completed ? (m(), Q(R(Te), { key: 0 })) : (m(), Q(R(fe), { key: 1 })),
                                              ]),
                                              _: 2,
                                            },
                                            1032,
                                            ["class"],
                                          ),
                                          s("span", Ye, p(r.name), 1),
                                        ]),
                                      ])
                                    ),
                                  ),
                                  128,
                                )),
                              ]),
                            ]))
                          : b("", !0),
                        i.task.logs && i.task.logs.length
                          ? (m(),
                            g("div", Ze, [
                              a[15] || (a[15] = s("h4", null, "执行日志", -1)),
                              s("div", et, [
                                (m(!0),
                                g(
                                  K,
                                  null,
                                  H(
                                    i.task.logs.slice(-5),
                                    (r) => (
                                      m(),
                                      g("div", { key: r.id, class: "log-item" }, [
                                        s("span", tt, p(c(r.timestamp)), 1),
                                        s(
                                          "span",
                                          {
                                            class: P([
                                              "log-message",
                                              { error: r.type === "error", success: r.type === "success" },
                                            ]),
                                          },
                                          p(r.message),
                                          3,
                                        ),
                                      ])
                                    ),
                                  ),
                                  128,
                                )),
                              ]),
                            ]))
                          : b("", !0),
                      ]),
                    ]),
                    _: 1,
                  },
                  8,
                  ["show"],
                ),
              ],
              2,
            )
          );
        }
      );
    },
  },
  at = te(st, [["__scopeId", "data-v-b4b158a9"]]),
  ot = { class: "daily-tasks-page" },
  nt = { class: "page-header" },
  lt = { class: "container" },
  it = { class: "header-content" },
  ct = { class: "header-actions" },
  rt = { class: "role-selector-section" },
  dt = { class: "container" },
  ut = { class: "role-selector" },
  mt = { key: 0, class: "role-stats" },
  vt = { class: "stat-item" },
  gt = { class: "stat-value" },
  ft = { class: "stat-item" },
  pt = { class: "stat-value" },
  kt = { class: "stat-item" },
  _t = { class: "stat-value" },
  ht = { class: "filter-section" },
  wt = { class: "container" },
  yt = { class: "filter-bar" },
  xt = { class: "search-box" },
  bt = { class: "tasks-section" },
  St = { class: "container" },
  $t = { key: 0, class: "tasks-grid" },
  Tt = { key: 1, class: "empty-state" },
  Ct = { key: 2, class: "loading-state" },
  Dt = {
    __name: "DailyTasks",
    setup(i) {
      const z = ge(),
        d = Z(),
        O = ue(),
        y = me(),
        f = pe(),
        S = ke(),
        h = _e(),
        U = $(!1),
        N = $(!1),
        v = $(null),
        T = $("all"),
        A = $(""),
        c = $([]),
        B = J(() => f.gameRoles.find((t) => t.id === v.value)),
        M = J(() => f.gameRoles.map((t) => ({ label: `${t.name} (${t.server})`, value: t.id }))),
        I = J(() => {
          const t = c.value.length,
            e = c.value.filter((u) => u.completed).length,
            o = t > 0 ? Math.round((e / t) * 100) : 0;
          return { total: t, completed: e, percentage: o };
        }),
        k = J(() => {
          let t = c.value;
          switch (T.value) {
            case "pending":
              t = t.filter((e) => !e.completed);
              break;
            case "completed":
              t = t.filter((e) => e.completed);
              break;
            case "auto":
              t = t.filter((e) => {
                var o;
                return (o = e.settings) == null ? void 0 : o.autoExecute;
              });
              break;
          }
          if (A.value) {
            const e = A.value.toLowerCase();
            t = t.filter((o) => {
              var u;
              return (
                o.title.toLowerCase().includes(e) || ((u = o.subtitle) == null ? void 0 : u.toLowerCase().includes(e))
              );
            });
          }
          return t;
        }),
        a = [
          { label: "执行所有待完成任务", key: "execute-all-pending" },
          { label: "标记所有为已完成", key: "mark-all-completed" },
          { label: "重置所有任务状态", key: "reset-all-tasks" },
        ],
        W = async (t, e = 3, o = 2e3) => {
          for (let u = 1; u <= e; u++)
            try {
              if (y.getWebSocketStatus(t) !== "connected") {
                const w = y.gameTokens.find((G) => G.id === t);
                if (w && w.token) {
                  if (
                    (y.createWebSocketConnection(t, w.token, w.wsUrl),
                    await new Promise((q) => setTimeout(q, o)),
                    y.getWebSocketStatus(t) !== "connected")
                  ) {
                    if (u < e) continue;
                    throw new Error("WebSocket连接超时");
                  }
                } else throw new Error("未找到有效的Token数据或WebSocket URL");
              }
              const L = await y.sendMessageWithPromise(t, "presetteam_getinfo", {}, 8e3);
              if (L)
                return (
                  y.$patch((w) => {
                    w.gameData = { ...(w.gameData ?? {}), presetTeam: L };
                  }),
                  d.success("阵容数据已更新"),
                  L
                );
            } catch (D) {
              if ((console.error(`第${u}次尝试失败:`, D), u < e)) await new Promise((L) => setTimeout(L, o));
              else
                return (
                  console.error("所有重试均失败，阵容数据加载失败"),
                  d.warning(`阵容数据加载失败: ${D.message || "未知错误"}`),
                  null
                );
            }
        },
        C = async () => {
          if (!v.value) {
            d.warning("请先选择游戏角色");
            return;
          }
          try {
            ((N.value = !0), (U.value = !0));
            const t = F(v.value);
            ((c.value = t),
              localStorage.setItem(`dailyTasks_${v.value}`, JSON.stringify(t)),
              d.success("任务数据刷新成功"));
          } catch (t) {
            (console.error("刷新任务失败:", t), d.error("本地数据生成失败"));
          } finally {
            ((N.value = !1), (U.value = !1));
          }
        },
        F = (t) => {
          const e = f.gameRoles.find((o) => o.id === t);
          return (
            e != null && e.name,
            [
              {
                id: `task_${t}_daily_signin`,
                title: "每日签到",
                subtitle: "登录游戏获取签到奖励",
                icon: "/icons/ta.png",
                completed: !1,
                canExecute: !0,
                progress: { current: 0, total: 1 },
                reward: "金币 x100, 经验 x50",
                nextReset: new Date(Date.now() + 24 * 60 * 60 * 1e3).toISOString(),
                settings: { autoExecute: !1, delay: 0, notification: !0 },
                details: [
                  { id: 1, name: "打开游戏客户端", completed: !1 },
                  { id: 2, name: "点击签到按钮", completed: !1 },
                ],
                logs: [],
              },
              {
                id: `task_${t}_black_market_purchase`,
                title: "黑市购买",
                subtitle: "在黑市购买1次物品，如未购买到则兜底购买青铜宝箱",
                icon: "/icons/ta.png",
                completed: !1,
                canExecute: !0,
                progress: { current: 0, total: 1 },
                reward: "随机物品或青铜宝箱",
                nextReset: new Date(Date.now() + 24 * 60 * 60 * 1e3).toISOString(),
                settings: { autoExecute: !0, delay: 0, notification: !0 },
                details: [
                  { id: 1, name: "尝试黑市购买1次物品", completed: !1 },
                  { id: 2, name: "检查购买结果", completed: !1 },
                  { id: 3, name: "如未购买到物品，购买青铜宝箱（兜底）", completed: !1 },
                ],
                logs: [],
              },
              {
                id: `task_${t}_daily_quest`,
                title: "完成日常任务",
                subtitle: "完成5个日常任务获得奖励",
                icon: "/icons/ta.png",
                completed: !1,
                canExecute: !0,
                progress: { current: 2, total: 5 },
                reward: "金币 x500, 装备碎片 x10",
                nextReset: new Date(Date.now() + 24 * 60 * 60 * 1e3).toISOString(),
                settings: { autoExecute: !0, delay: 5, notification: !0 },
                details: [
                  { id: 1, name: "击败10只怪物", completed: !0 },
                  { id: 2, name: "收集20个材料", completed: !0 },
                  { id: 3, name: "完成一次副本", completed: !1 },
                  { id: 4, name: "参与公会活动", completed: !1 },
                  { id: 5, name: "强化装备", completed: !1 },
                ],
                logs: [
                  { id: 1, timestamp: Date.now() - 30 * 60 * 1e3, type: "success", message: "已完成击败怪物任务" },
                  { id: 2, timestamp: Date.now() - 60 * 60 * 1e3, type: "success", message: "已完成材料收集任务" },
                ],
              },
              {
                id: `task_${t}_guild_contribution`,
                title: "公会贡献",
                subtitle: "为公会贡献资源获得贡献点",
                icon: "/icons/ta.png",
                completed: !0,
                canExecute: !1,
                progress: { current: 1, total: 1 },
                reward: "公会贡献点 x100",
                nextReset: new Date(Date.now() + 24 * 60 * 60 * 1e3).toISOString(),
                settings: { autoExecute: !0, delay: 0, notification: !0 },
                details: [{ id: 1, name: "捐献金币", completed: !0 }],
                logs: [
                  { id: 1, timestamp: Date.now() - 2 * 60 * 60 * 1e3, type: "success", message: "已完成公会贡献" },
                ],
              },
            ]
          );
        },
        V = (t) => {
          ((v.value = t), f.selectRole(f.gameRoles.find((e) => e.id === t)), t && C());
        },
        j = (t) => {
          T.value = t;
        },
        r = (t) => {
          A.value = t;
        },
        X = async (t) => {
          if (!v.value) {
            d.error("请先选择游戏角色");
            return;
          }
          try {
            if (S.getWebSocketStatus(v.value) !== "connected") {
              const u = S.getGameToken(v.value);
              if (u)
                (S.createWebSocketConnection(v.value, u.token, u.wsUrl), await new Promise((D) => setTimeout(D, 1e3)));
              else throw new Error("未找到游戏token，请重新添加角色");
            }
            const o = c.value.findIndex((u) => u.id === t);
            (o !== -1 &&
              ((c.value[o] = { ...c.value[o], completed: !0, completedAt: new Date().toISOString() }),
              c.value[o].logs || (c.value[o].logs = []),
              c.value[o].logs.push({
                id: Date.now(),
                timestamp: Date.now(),
                type: "success",
                message: `任务 "${c.value[o].title}" 执行成功`,
              }),
              localStorage.setItem(`dailyTasks_${v.value}`, JSON.stringify(c.value))),
              d.success("任务执行成功"));
          } catch (e) {
            console.error("执行任务失败:", e);
            const o = c.value.findIndex((u) => u.id === t);
            throw (
              o !== -1 &&
                (c.value[o].logs || (c.value[o].logs = []),
                c.value[o].logs.push({
                  id: Date.now(),
                  timestamp: Date.now(),
                  type: "error",
                  message: `任务执行失败: ${e.message}`,
                })),
              e
            );
          }
        },
        se = (t) => {
          const e = c.value.findIndex((o) => o.id === t);
          e !== -1 && ((c.value[e].completed = !c.value[e].completed), d.info("任务状态已更新"));
        },
        ae = (t) => {
          const e = c.value.findIndex((o) => o.id === t.id);
          e !== -1 && (c.value[e] = t);
        },
        oe = (t) => {
          switch (t) {
            case "execute-all-pending":
              ne();
              break;
            case "mark-all-completed":
              le();
              break;
            case "reset-all-tasks":
              ie();
              break;
          }
        },
        ne = async () => {
          const t = c.value.filter((e) => !e.completed && e.canExecute);
          if (t.length === 0) {
            d.info("没有可执行的待完成任务");
            return;
          }
          O.confirm({
            title: "批量执行任务",
            content: `确定要执行 ${t.length} 个待完成任务吗？`,
            positiveText: "确定",
            negativeText: "取消",
            onPositiveClick: async () => {
              let e = 0,
                o = 0;
              for (const u of t)
                try {
                  (await X(u.id), e++);
                } catch {
                  o++;
                }
              d.info(`批量执行完成：成功 ${e} 个，失败 ${o} 个`);
            },
          });
        },
        le = () => {
          const t = c.value.filter((e) => !e.completed);
          if (t.length === 0) {
            d.info("所有任务都已完成");
            return;
          }
          O.confirm({
            title: "标记所有任务为已完成",
            content: `确定要将 ${t.length} 个待完成任务标记为已完成吗？`,
            positiveText: "确定",
            negativeText: "取消",
            onPositiveClick: () => {
              (t.forEach((e) => {
                ((e.completed = !0), (e.completedAt = new Date().toISOString()));
              }),
                d.success("所有任务已标记为完成"));
            },
          });
        },
        ie = () => {
          O.confirm({
            title: "重置所有任务状态",
            content: "确定要重置所有任务状态吗？此操作将清除所有完成记录。",
            positiveText: "确定",
            negativeText: "取消",
            onPositiveClick: () => {
              (c.value.forEach((t) => {
                ((t.completed = !1), (t.completedAt = null));
              }),
                d.success("所有任务状态已重置"));
            },
          });
        };
      return (
        ve(async () => {
          if (!h.isAuthenticated) {
            z.push("/login");
            return;
          }
          if (
            (f.gameRoles.length === 0 && (await f.fetchGameRoles()),
            y.selectedToken && (await W(y.selectedToken.id)),
            f.selectedRole)
          ) {
            v.value = f.selectedRole.id;
            const t = localStorage.getItem(`dailyTasks_${v.value}`);
            if (t)
              try {
                c.value = JSON.parse(t);
              } catch (e) {
                (console.error("解析任务数据失败:", e), C());
              }
            else C();
          } else f.gameRoles.length > 0 && ((v.value = f.gameRoles[0].id), V(v.value));
        }),
        ee(
          () => f.selectedRole,
          (t) => {
            t && t.id !== v.value && (v.value = t.id);
          },
        ),
        (t, e) => {
          const o = _("n-icon"),
            u = _("n-button"),
            D = _("n-dropdown"),
            L = _("n-select"),
            w = _("n-radio-button"),
            G = _("n-radio-group"),
            q = _("n-input"),
            ce = _("n-empty"),
            re = _("n-spin");
          return (
            m(),
            g("div", ot, [
              s("div", nt, [
                s("div", lt, [
                  s("div", it, [
                    e[5] ||
                      (e[5] = s(
                        "div",
                        { class: "header-left" },
                        [
                          s("h1", { class: "page-title" }, "日常任务"),
                          s("p", { class: "page-subtitle" }, "管理和执行您的日常游戏任务"),
                        ],
                        -1,
                      )),
                    s("div", ct, [
                      n(
                        u,
                        { type: "primary", size: "large", loading: N.value, onClick: C },
                        {
                          icon: l(() => [n(o, null, { default: l(() => [n(R(he))]), _: 1 })]),
                          default: l(() => [e[3] || (e[3] = x(" 刷新任务 ", -1))]),
                          _: 1,
                        },
                        8,
                        ["loading"],
                      ),
                      n(
                        D,
                        { options: a, onSelect: oe },
                        {
                          default: l(() => [
                            n(
                              u,
                              { size: "large" },
                              {
                                icon: l(() => [n(o, null, { default: l(() => [n(R(we))]), _: 1 })]),
                                default: l(() => [e[4] || (e[4] = x(" 批量操作 ", -1))]),
                                _: 1,
                              },
                            ),
                          ]),
                          _: 1,
                        },
                      ),
                    ]),
                  ]),
                ]),
              ]),
              s("div", rt, [
                s("div", dt, [
                  s("div", ut, [
                    e[9] || (e[9] = s("span", { class: "selector-label" }, "选择角色：", -1)),
                    n(
                      L,
                      {
                        value: v.value,
                        "onUpdate:value": [e[0] || (e[0] = (E) => (v.value = E)), V],
                        options: M.value,
                        placeholder: "请选择游戏角色",
                        style: { "min-width": "200px" },
                      },
                      null,
                      8,
                      ["value", "options"],
                    ),
                    B.value
                      ? (m(),
                        g("div", mt, [
                          s("div", vt, [
                            e[6] || (e[6] = s("span", { class: "stat-label" }, "总任务：", -1)),
                            s("span", gt, p(I.value.total), 1),
                          ]),
                          s("div", ft, [
                            e[7] || (e[7] = s("span", { class: "stat-label" }, "已完成：", -1)),
                            s("span", pt, p(I.value.completed), 1),
                          ]),
                          s("div", kt, [
                            e[8] || (e[8] = s("span", { class: "stat-label" }, "进度：", -1)),
                            s("span", _t, p(I.value.percentage) + "%", 1),
                          ]),
                        ]))
                      : b("", !0),
                  ]),
                ]),
              ]),
              s("div", ht, [
                s("div", wt, [
                  s("div", yt, [
                    n(
                      G,
                      { value: T.value, "onUpdate:value": [e[1] || (e[1] = (E) => (T.value = E)), j] },
                      {
                        default: l(() => [
                          n(
                            w,
                            { value: "all" },
                            { default: l(() => [...(e[10] || (e[10] = [x(" 全部任务 ", -1)]))]), _: 1 },
                          ),
                          n(
                            w,
                            { value: "pending" },
                            { default: l(() => [...(e[11] || (e[11] = [x(" 待完成 ", -1)]))]), _: 1 },
                          ),
                          n(
                            w,
                            { value: "completed" },
                            { default: l(() => [...(e[12] || (e[12] = [x(" 已完成 ", -1)]))]), _: 1 },
                          ),
                          n(
                            w,
                            { value: "auto" },
                            { default: l(() => [...(e[13] || (e[13] = [x(" 自动执行 ", -1)]))]), _: 1 },
                          ),
                        ]),
                        _: 1,
                      },
                      8,
                      ["value"],
                    ),
                    s("div", xt, [
                      n(
                        q,
                        {
                          value: A.value,
                          "onUpdate:value": [e[2] || (e[2] = (E) => (A.value = E)), r],
                          placeholder: "搜索任务...",
                          clearable: "",
                        },
                        { prefix: l(() => [n(o, null, { default: l(() => [n(R(ye))]), _: 1 })]), _: 1 },
                        8,
                        ["value"],
                      ),
                    ]),
                  ]),
                ]),
              ]),
              s("div", bt, [
                s("div", St, [
                  k.value.length
                    ? (m(),
                      g("div", $t, [
                        (m(!0),
                        g(
                          K,
                          null,
                          H(
                            k.value,
                            (E) => (
                              m(),
                              Q(
                                at,
                                { key: E.id, task: E, onExecute: X, onToggleStatus: se, "onUpdate:task": ae },
                                null,
                                8,
                                ["task"],
                              )
                            ),
                          ),
                          128,
                        )),
                      ]))
                    : U.value
                      ? b("", !0)
                      : (m(),
                        g("div", Tt, [
                          n(
                            ce,
                            { description: "暂无任务数据", size: "large" },
                            {
                              icon: l(() => [n(o, null, { default: l(() => [n(R(xe))]), _: 1 })]),
                              extra: l(() => [
                                n(
                                  u,
                                  { type: "primary", onClick: C },
                                  { default: l(() => [...(e[14] || (e[14] = [x(" 刷新任务 ", -1)]))]), _: 1 },
                                ),
                              ]),
                              _: 1,
                            },
                          ),
                        ])),
                  U.value
                    ? (m(),
                      g("div", Ct, [
                        n(
                          re,
                          { size: "large" },
                          { description: l(() => [...(e[15] || (e[15] = [x(" 正在加载任务数据... ", -1)]))]), _: 1 },
                        ),
                      ]))
                    : b("", !0),
                ]),
              ]),
            ])
          );
        }
      );
    },
  },
  Bt = te(Dt, [["__scopeId", "data-v-90043dfd"]]);
export { Bt as default };
