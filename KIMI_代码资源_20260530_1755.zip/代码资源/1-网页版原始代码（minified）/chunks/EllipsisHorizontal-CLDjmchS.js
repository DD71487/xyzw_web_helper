import { k as e, c as l, a as o, h as c } from "./index-UoU16364.js";
const r = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  n = o("circle", { cx: "256", cy: "256", r: "48", fill: "currentColor" }, null, -1),
  t = o("circle", { cx: "416", cy: "256", r: "48", fill: "currentColor" }, null, -1),
  s = o("circle", { cx: "96", cy: "256", r: "48", fill: "currentColor" }, null, -1),
  i = [n, t, s],
  h = e({
    name: "EllipsisHorizontal",
    render: function (_, x) {
      return (c(), l("svg", r, i));
    },
  });
export { h as E };
