import {
  _ as M,
  g as j,
  c as X,
  x as We,
  y as Me,
  S as cn,
  U as dn,
  I as fn,
  o as vn,
  m as Ze,
  n as Pt,
  G as mn,
  V as pn,
  i as Vt,
  f as Se,
  A as It,
  Q as zt,
  k as hn,
  s as Qt,
  a as Zt,
  W as Je,
  l as we,
  B as kn,
  J as gn,
  h as yn,
  j as wn,
  r as bn,
} from "./index-7YDlkBnY.js";
import { i as He, I as Tt } from "./index-CgWPhAzx.js";
import {
  k as _,
  c as P,
  h as w,
  l as $n,
  X as O,
  E as C,
  p as m,
  d as ie,
  a as L,
  b as f,
  ag as be,
  aY as Cn,
  n as ge,
  _ as ve,
  F as ze,
  g as Lt,
  e as ue,
  w as ke,
  r as ne,
  am as Ht,
  y as Ge,
  $ as Gt,
  z as de,
  aa as Sn,
  I as Pe,
  A as Y,
  ab as Pn,
  ac as In,
  ad as Nt,
  t as Ke,
  ai as Ae,
  B as zn,
  aI as Ln,
  al as Kt,
  aj as Fe,
  i as _t,
  ak as et,
  ah as Bt,
  aT as _n,
  ae as Bn,
} from "./index-UoU16364.js";
import { T as Oe } from "./index-BF2tcBOi.js";
import { a as jn } from "./grid-col-GTGOUscx.js";
import { I as Tn, a as Nn, K as Ie } from "./index-DMjs3mWk.js";
import { R as On } from "./render-function-B77hMlED.js";
const En = _({
    name: "IconImageClose",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-image-close`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  Wn = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Mn(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          $n(
            '<path d="M41 26V9a2 2 0 0 0-2-2H9a2 2 0 0 0-2 2v30a2 2 0 0 0 2 2h17"></path><path d="m24 33 9-8.5V27s-2 1-3.5 2.5C27.841 31.159 27 33 27 33h-3Zm0 0-3.5-4.5L17 33h7Z"></path><path d="M20.5 28.5 17 33h7l-3.5-4.5ZM33 24.5 24 33h3s.841-1.841 2.5-3.5C31 28 33 27 33 27v-2.5Z" fill="currentColor" stroke="none"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M46 38a8 8 0 1 1-16 0 8 8 0 0 1 16 0Zm-4.95-4.782 1.74 1.74-3.045 3.046 3.046 3.046-1.74 1.74-3.047-3.045-3.046 3.046-1.74-1.74 3.046-3.047-3.046-3.046 1.74-1.74 3.046 3.046 3.046-3.046Z" fill="currentColor" stroke="none"></path><path d="M17 15h-2v2h2v-2Z"></path>',
            5,
          ),
        ]),
      14,
      Wn,
    )
  );
}
var tt = M(En, [["render", Mn]]);
const An = Object.assign(tt, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + tt.name, tt);
    },
  }),
  Fn = _({
    name: "ImagePreviewArrow",
    components: { IconLeft: Nn, IconRight: Tn },
    props: { onPrev: { type: Function }, onNext: { type: Function } },
    setup() {
      return { prefixCls: j("image-preview-arrow") };
    },
  });
function Rn(e, t, n, o, i, s) {
  const r = ie("icon-left"),
    a = ie("icon-right");
  return (
    w(),
    P(
      "div",
      { class: C(e.prefixCls) },
      [
        L(
          "div",
          {
            class: C([`${e.prefixCls}-left`, { [`${e.prefixCls}-disabled`]: !e.onPrev }]),
            onClick:
              t[0] ||
              (t[0] = (l) => {
                (l.preventDefault(), e.onPrev && e.onPrev());
              }),
          },
          [f(r)],
          2,
        ),
        L(
          "div",
          {
            class: C([`${e.prefixCls}-right`, { [`${e.prefixCls}-disabled`]: !e.onNext }]),
            onClick:
              t[1] ||
              (t[1] = (l) => {
                (l.preventDefault(), e.onNext && e.onNext());
              }),
          },
          [f(a)],
          2,
        ),
      ],
      2,
    )
  );
}
var Un = M(Fn, [["render", Rn]]);
function Dn(e) {
  return typeof e == "function" || (Object.prototype.toString.call(e) === "[object Object]" && !Cn(e));
}
var qn = _({
    name: "ImagePreviewAction",
    components: { Tooltip: Oe },
    inheritAttrs: !1,
    props: { name: { type: String }, disabled: { type: Boolean } },
    setup(e, { slots: t, attrs: n }) {
      const o = j("image-preview-toolbar-action");
      return () => {
        var i;
        const { name: s, disabled: r } = e,
          a = (i = t.default) == null ? void 0 : i.call(t);
        if (!a || !a.length) return null;
        const l = f(
          "div",
          be(
            {
              class: [`${o}`, { [`${o}-disabled`]: r }],
              onMousedown: (c) => {
                c.preventDefault();
              },
            },
            n,
          ),
          [f("span", { class: `${o}-content` }, [a])],
        );
        return s ? f(Oe, { class: `${o}-tooltip`, content: s }, Dn(l) ? l : { default: () => [l] }) : l;
      };
    },
  }),
  xn = _({
    name: "ImagePreviewToolbar",
    components: { RenderFunction: On, PreviewAction: qn },
    props: { actions: { type: Array, default: () => [] }, actionsLayout: { type: Array, default: () => [] } },
    setup(e) {
      const { actions: t, actionsLayout: n } = ge(e),
        o = j("image-preview-toolbar"),
        i = m(() => {
          const s = new Set(n.value),
            r = (l) => s.has(l.key);
          return t.value.filter(r).sort((l, c) => {
            const d = n.value.indexOf(l.key),
              u = n.value.indexOf(c.key);
            return d > u ? 1 : -1;
          });
        });
      return { prefixCls: o, resultActions: i };
    },
  });
function Vn(e, t, n, o, i, s) {
  const r = ie("RenderFunction"),
    a = ie("PreviewAction");
  return (
    w(),
    P(
      "div",
      { class: C(e.prefixCls) },
      [
        (w(!0),
        P(
          ze,
          null,
          Lt(
            e.resultActions,
            (l) => (
              w(),
              ue(
                a,
                { key: l.key, name: l.name, disabled: l.disabled, onClick: l.onClick },
                { default: ke(() => [f(r, { "render-func": l.content }, null, 8, ["render-func"])]), _: 2 },
                1032,
                ["name", "disabled", "onClick"],
              )
            ),
          ),
          128,
        )),
        ve(e.$slots, "default"),
      ],
      2,
    )
  );
}
var Qn = M(xn, [["render", Vn]]);
function Zn(e) {
  const t = ne("beforeLoad"),
    n = m(() => t.value === "beforeLoad"),
    o = m(() => t.value === "loading"),
    i = m(() => t.value === "error"),
    s = m(() => t.value === "loaded");
  return {
    status: t,
    isBeforeLoad: n,
    isLoading: o,
    isError: i,
    isLoaded: s,
    setLoadStatus: (r) => {
      t.value = r;
    },
  };
}
function Hn(e, t, n, o, i) {
  let s = n,
    r = o;
  return (
    n &&
      (e.width > t.width
        ? (s = 0)
        : (t.left > e.left && (s -= Math.abs(e.left - t.left) / i),
          t.right < e.right && (s += Math.abs(e.right - t.right) / i))),
    o &&
      (e.height > t.height
        ? (r = 0)
        : (t.top > e.top && (r -= Math.abs(e.top - t.top) / i),
          t.bottom < e.bottom && (r += Math.abs(e.bottom - t.bottom) / i))),
    [s, r]
  );
}
function Gn(e) {
  const { wrapperEl: t, imageEl: n, scale: o } = ge(e),
    i = ne([0, 0]),
    s = ne(!1);
  let r = 0,
    a = 0,
    l = [0, 0];
  const c = () => {
      if (!t.value || !n.value) return;
      const p = t.value.getBoundingClientRect(),
        T = n.value.getBoundingClientRect(),
        [v, g] = Hn(p, T, i.value[0], i.value[1], o.value);
      (v !== i.value[0] || g !== i.value[1]) && (i.value = [v, g]);
    },
    d = (p) => {
      p.preventDefault && p.preventDefault();
      const T = l[0] + (p.pageX - r) / o.value,
        v = l[1] + (p.pageY - a) / o.value;
      i.value = [T, v];
    },
    u = (p) => {
      (p.preventDefault && p.preventDefault(), (s.value = !1), c(), y());
    },
    $ = (p) => {
      p.target === p.currentTarget &&
        (p.preventDefault && p.preventDefault(),
        (s.value = !0),
        (r = p.pageX),
        (a = p.pageY),
        (l = [...i.value]),
        We(window, "mousemove", d, !1),
        We(window, "mouseup", u, !1));
    };
  function y() {
    (Me(window, "mousemove", d, !1), Me(window, "mouseup", u, !1));
  }
  return (
    Ht((p) => {
      (n.value && We(n.value, "mousedown", $),
        p(() => {
          (n.value && Me(n.value, "mousedown", $), y());
        }));
    }),
    Ge([o], () => {
      Gt(() => c());
    }),
    {
      translate: i,
      moving: s,
      resetTranslate() {
        i.value = [0, 0];
      },
    }
  );
}
const Kn = _({
    name: "IconZoomOut",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-zoom-out`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  Yn = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Xn(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            {
              d: "M32.607 32.607A14.953 14.953 0 0 0 37 22c0-8.284-6.716-15-15-15-8.284 0-15 6.716-15 15 0 8.284 6.716 15 15 15 4.142 0 7.892-1.679 10.607-4.393Zm0 0L41.5 41.5M29 22H15",
            },
            null,
            -1,
          ),
        ]),
      14,
      Yn,
    )
  );
}
var nt = M(Kn, [["render", Xn]]);
const Jn = Object.assign(nt, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + nt.name, nt);
    },
  }),
  ei = _({
    name: "IconZoomIn",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-zoom-in`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  ti = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function ni(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            {
              d: "M32.607 32.607A14.953 14.953 0 0 0 37 22c0-8.284-6.716-15-15-15-8.284 0-15 6.716-15 15 0 8.284 6.716 15 15 15 4.142 0 7.892-1.679 10.607-4.393Zm0 0L41.5 41.5M29 22H15m7 7V15",
            },
            null,
            -1,
          ),
        ]),
      14,
      ti,
    )
  );
}
var it = M(ei, [["render", ni]]);
const ii = Object.assign(it, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + it.name, it);
    },
  }),
  oi = _({
    name: "IconFullscreen",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-fullscreen`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  ri = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function li(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            { d: "M42 17V9a1 1 0 0 0-1-1h-8M6 17V9a1 1 0 0 1 1-1h8m27 23v8a1 1 0 0 1-1 1h-8M6 31v8a1 1 0 0 0 1 1h8" },
            null,
            -1,
          ),
        ]),
      14,
      ri,
    )
  );
}
var ot = M(oi, [["render", li]]);
const si = Object.assign(ot, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + ot.name, ot);
    },
  }),
  ai = _({
    name: "IconRotateLeft",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-rotate-left`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  ui = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function ci(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            {
              d: "M10 22a1 1 0 0 1 1-1h20a1 1 0 0 1 1 1v16a1 1 0 0 1-1 1H11a1 1 0 0 1-1-1V22ZM23 11h11a6 6 0 0 1 6 6v6M22.5 12.893 19.587 11 22.5 9.107v3.786Z",
            },
            null,
            -1,
          ),
        ]),
      14,
      ui,
    )
  );
}
var rt = M(ai, [["render", ci]]);
const di = Object.assign(rt, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + rt.name, rt);
    },
  }),
  fi = _({
    name: "IconRotateRight",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-rotate-right`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  vi = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function mi(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            {
              d: "M38 22a1 1 0 0 0-1-1H17a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h20a1 1 0 0 0 1-1V22ZM25 11H14a6 6 0 0 0-6 6v6M25.5 12.893 28.413 11 25.5 9.107v3.786Z",
            },
            null,
            -1,
          ),
        ]),
      14,
      vi,
    )
  );
}
var lt = M(fi, [["render", mi]]);
const pi = Object.assign(lt, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + lt.name, lt);
    },
  }),
  hi = _({
    name: "IconOriginalSize",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-original-size`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  ki = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function gi(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L("path", { d: "m5.5 11.5 5-2.5h1v32M34 11.5 39 9h1v32" }, null, -1),
          L("path", { d: "M24 17h1v1h-1v-1ZM24 30h1v1h-1v-1Z", fill: "currentColor", stroke: "none" }, null, -1),
          L("path", { d: "M24 17h1v1h-1v-1ZM24 30h1v1h-1v-1Z" }, null, -1),
        ]),
      14,
      ki,
    )
  );
}
var st = M(hi, [["render", gi]]);
const yi = Object.assign(st, {
  install: (e, t) => {
    var n;
    const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
    e.component(o + st.name, st);
  },
});
function wi(e) {
  const { container: t, hidden: n } = ge(e);
  let o = !1,
    i = {};
  const s = (l) =>
      l.tagName === "BODY"
        ? window.innerWidth - (document.body.clientWidth || document.documentElement.clientWidth)
        : l.offsetWidth - l.clientWidth,
    r = () => {
      if (t.value && t.value.style.overflow !== "hidden") {
        const l = t.value.style;
        o = !0;
        const c = s(t.value);
        (c && ((i.width = l.width), (t.value.style.width = `calc(${t.value.style.width || "100%"} - ${c}px)`)),
          (i.overflow = l.overflow),
          (t.value.style.overflow = "hidden"));
      }
    },
    a = () => {
      if (t.value && o) {
        const l = i;
        Object.keys(l).forEach((c) => {
          t.value.style[c] = l[c];
        });
      }
      ((o = !1), (i = {}));
    };
  return (
    Ht((l) => {
      (n.value ? r() : a(),
        l(() => {
          a();
        }));
    }),
    [a, r]
  );
}
function bi(e, t) {
  const { popupContainer: n } = ge(t);
  return m(() => (dn(n.value) ? cn(n.value) : n.value) || e);
}
const fe = [25, 33, 50, 67, 75, 80, 90, 100, 110, 125, 150, 175, 200, 250, 300, 400, 500].map(
    (e) => +(e / 100).toFixed(2),
  ),
  Yt = fe[0],
  Xt = fe[fe.length - 1];
function $i(e = 1, t = "zoomIn") {
  let n = fe.indexOf(e);
  return (n === -1 && (n = Si(e)), t === "zoomIn" ? (n === fe.length - 1 ? e : fe[n + 1]) : n === 0 ? e : fe[n - 1]);
}
function Ci(e, t = 1.1, n = "zoomIn") {
  const o = n === "zoomIn" ? t : 1 / t,
    i = Number.parseFloat((e * o).toFixed(3));
  return Math.min(Xt, Math.max(Yt, i));
}
function Si(e) {
  let t = fe.length - 1;
  for (let n = 0; n < fe.length; n++) {
    const o = fe[n];
    if (e === o) {
      t = n;
      break;
    }
    if (e < o) {
      const i = fe[n - 1];
      t = i === void 0 || Math.abs(i - e) <= Math.abs(o - e) ? n - 1 : n;
      break;
    }
  }
  return t;
}
const at = 90;
var Pi = _({
  name: "ImagePreview",
  components: { PreviewArrow: Un, PreviewToolbar: Qn, IconLoading: vn, IconClose: fn },
  props: {
    renderToBody: { type: Boolean, default: !0 },
    src: { type: String },
    visible: { type: Boolean, default: void 0 },
    defaultVisible: { type: Boolean, default: !1 },
    maskClosable: { type: Boolean, default: !0 },
    closable: { type: Boolean, default: !0 },
    actionsLayout: {
      type: Array,
      default: () => ["fullScreen", "rotateRight", "rotateLeft", "zoomIn", "zoomOut", "originalSize"],
    },
    popupContainer: { type: [Object, String] },
    inGroup: { type: Boolean, default: !1 },
    groupArrowProps: { type: Object, default: () => ({}) },
    escToClose: { type: Boolean, default: !0 },
    wheelZoom: { type: Boolean, default: !0 },
    keyboard: { type: Boolean, default: !0 },
    defaultScale: { type: Number, default: 1 },
    zoomRate: { type: Number, default: 1.1 },
  },
  emits: ["close", "update:visible"],
  setup(e, { emit: t }) {
    const { t: n } = Ze(),
      {
        src: o,
        popupContainer: i,
        visible: s,
        defaultVisible: r,
        maskClosable: a,
        actionsLayout: l,
        defaultScale: c,
        zoomRate: d,
      } = ge(e),
      u = ne(),
      $ = ne(),
      y = j("image-preview"),
      [p, T] = Pt(r.value, de({ value: s })),
      v = m(() => [y, { [`${y}-hide`]: !p.value }]),
      g = bi(document.body, de({ popupContainer: i })),
      I = m(() => g.value === document.body),
      { zIndex: b } = mn("dialog", { visible: p }),
      Z = m(() => ({
        ...(I.value ? { zIndex: b.value, position: "fixed" } : { zIndex: "inherit", position: "absolute" }),
      })),
      { isLoading: F, isLoaded: E, setLoadStatus: K } = Zn(),
      H = ne(0),
      q = ne(c.value),
      { translate: z, moving: U, resetTranslate: J } = Gn(de({ wrapperEl: u, imageEl: $, visible: p, scale: q })),
      A = ne(!1);
    let V = null;
    const R = () => {
      (!A.value && (A.value = !0),
        V && clearTimeout(V),
        (V = setTimeout(() => {
          A.value = !1;
        }, 1e3)));
    };
    wi(de({ container: g, hidden: p }));
    function ee() {
      ((H.value = 0), (q.value = c.value), J());
    }
    const te = (B) => l.value.includes(B),
      oe = (B) => {
        switch ((B.stopPropagation(), B.preventDefault(), B.key)) {
          case Ie.ESC:
            e.escToClose && Ee();
            break;
          case Ie.ARROW_LEFT:
            e.groupArrowProps.onPrev && e.groupArrowProps.onPrev();
            break;
          case Ie.ARROW_RIGHT:
            e.groupArrowProps.onNext && e.groupArrowProps.onNext();
            break;
          case Ie.ARROW_UP:
            te("zoomIn") && re("zoomIn");
            break;
          case Ie.ARROW_DOWN:
            te("zoomOut") && re("zoomOut");
            break;
          case Ie.SPACE:
            te("originalSize") && S(1);
            break;
        }
      },
      Le = pn((B) => {
        if ((B.preventDefault(), B.stopPropagation(), !e.wheelZoom)) return;
        const N = (B.deltaY || B.deltaX) > 0 ? "zoomOut" : "zoomIn",
          le = Ci(q.value, d.value, N);
        S(le);
      });
    let $e = !1;
    const Xe = () => {
        (Gt(() => {
          var B;
          (B = u == null ? void 0 : u.value) == null || B.focus();
        }),
          e.keyboard && !$e && (($e = !0), We(g.value, "keydown", oe)));
      },
      Ce = () => {
        $e && (($e = !1), Me(g.value, "keydown", oe));
      };
    Ge([o, p], () => {
      p.value ? (ee(), K("loading"), Xe()) : Ce();
    });
    function Ee() {
      p.value && (t("close"), t("update:visible", !1), T(!1));
    }
    function k(B) {
      var Q;
      ((Q = u == null ? void 0 : u.value) == null || Q.focus(), a.value && B.target === B.currentTarget && Ee());
    }
    function S(B) {
      q.value !== B && ((q.value = B), R());
    }
    function W() {
      const B = u.value.getBoundingClientRect(),
        Q = $.value.getBoundingClientRect(),
        N = B.height / (Q.height / q.value),
        le = B.width / (Q.width / q.value),
        un = Math.max(N, le);
      S(un);
    }
    function G(B) {
      const N = B === "clockwise" ? (H.value + at) % 360 : H.value === 0 ? 360 - at : H.value - at;
      H.value = N;
    }
    function re(B) {
      const Q = $i(q.value, B);
      S(Q);
    }
    return (
      Sn(() => {
        Ce();
      }),
      {
        prefixCls: y,
        classNames: v,
        container: g,
        wrapperStyles: Z,
        scale: q,
        translate: z,
        rotate: H,
        moving: U,
        mergedVisible: p,
        isLoading: F,
        isLoaded: E,
        scaleValueVisible: A,
        refWrapper: u,
        refImage: $,
        onWheel: Le,
        onMaskClick: k,
        onCloseClick: Ee,
        onImgLoad() {
          K("loaded");
        },
        onImgError() {
          K("error");
        },
        actions: m(() => [
          { key: "fullScreen", name: n("imagePreview.fullScreen"), content: () => Pe(si), onClick: () => W() },
          {
            key: "rotateRight",
            name: n("imagePreview.rotateRight"),
            content: () => Pe(pi),
            onClick: () => G("clockwise"),
          },
          {
            key: "rotateLeft",
            name: n("imagePreview.rotateLeft"),
            content: () => Pe(di),
            onClick: () => G("counterclockwise"),
          },
          {
            key: "zoomIn",
            name: n("imagePreview.zoomIn"),
            content: () => Pe(ii),
            onClick: () => re("zoomIn"),
            disabled: q.value === Xt,
          },
          {
            key: "zoomOut",
            name: n("imagePreview.zoomOut"),
            content: () => Pe(Jn),
            onClick: () => re("zoomOut"),
            disabled: q.value === Yt,
          },
          { key: "originalSize", name: n("imagePreview.originalSize"), content: () => Pe(yi), onClick: () => S(1) },
        ]),
      }
    );
  },
});
const Ii = ["src"];
function zi(e, t, n, o, i, s) {
  const r = ie("IconLoading"),
    a = ie("PreviewToolbar"),
    l = ie("IconClose"),
    c = ie("PreviewArrow");
  return (
    w(),
    ue(
      Ln,
      { to: e.container, disabled: !e.renderToBody },
      [
        L(
          "div",
          { class: C(e.classNames), style: O(e.wrapperStyles) },
          [
            f(
              Nt,
              {
                name: "image-fade",
                onBeforeEnter: t[0] || (t[0] = (d) => d.parentElement && (d.parentElement.style.display = "block")),
                onAfterLeave: t[1] || (t[1] = (d) => d.parentElement && (d.parentElement.style.display = "")),
                persisted: "",
              },
              {
                default: ke(() => [
                  Pn(L("div", { class: C(`${e.prefixCls}-mask`) }, null, 2), [[In, e.mergedVisible]]),
                ]),
                _: 1,
              },
            ),
            e.mergedVisible
              ? (w(),
                P(
                  "div",
                  {
                    key: 0,
                    ref: "refWrapper",
                    tabindex: "0",
                    class: C(`${e.prefixCls}-wrapper`),
                    onClick: t[6] || (t[6] = (...d) => e.onMaskClick && e.onMaskClick(...d)),
                    onWheel: t[7] || (t[7] = zn((...d) => e.onWheel && e.onWheel(...d), ["prevent", "stop"])),
                  },
                  [
                    Y(" img "),
                    L(
                      "div",
                      {
                        class: C(`${e.prefixCls}-img-container`),
                        style: O({ transform: `scale(${e.scale}, ${e.scale})` }),
                        onClick: t[4] || (t[4] = (...d) => e.onMaskClick && e.onMaskClick(...d)),
                      },
                      [
                        (w(),
                        P(
                          "img",
                          {
                            ref: "refImage",
                            key: e.src,
                            src: e.src,
                            class: C([`${e.prefixCls}-img`, { [`${e.prefixCls}-img-moving`]: e.moving }]),
                            style: O({
                              transform: `translate(${e.translate[0]}px, ${e.translate[1]}px) rotate(${e.rotate}deg)`,
                            }),
                            onLoad: t[2] || (t[2] = (...d) => e.onImgLoad && e.onImgLoad(...d)),
                            onError: t[3] || (t[3] = (...d) => e.onImgError && e.onImgError(...d)),
                          },
                          null,
                          46,
                          Ii,
                        )),
                      ],
                      6,
                    ),
                    Y(" loading "),
                    e.isLoading
                      ? (w(), P("div", { key: 0, class: C(`${e.prefixCls}-loading`) }, [f(r)], 2))
                      : Y("v-if", !0),
                    Y(" scale value "),
                    f(
                      Nt,
                      { name: "image-fade" },
                      {
                        default: ke(() => [
                          e.scaleValueVisible
                            ? (w(),
                              P(
                                "div",
                                { key: 0, class: C(`${e.prefixCls}-scale-value`) },
                                Ke((e.scale * 100).toFixed(0)) + "% ",
                                3,
                              ))
                            : Y("v-if", !0),
                        ]),
                        _: 1,
                      },
                    ),
                    Y(" toolbar "),
                    e.isLoaded && e.actionsLayout.length
                      ? (w(),
                        ue(
                          a,
                          { key: 1, actions: e.actions, "actions-layout": e.actionsLayout },
                          { default: ke(() => [ve(e.$slots, "actions")]), _: 3 },
                          8,
                          ["actions", "actions-layout"],
                        ))
                      : Y("v-if", !0),
                    Y(" close btn "),
                    e.closable
                      ? (w(),
                        P(
                          "div",
                          {
                            key: 2,
                            class: C(`${e.prefixCls}-close-btn`),
                            onClick: t[5] || (t[5] = (...d) => e.onCloseClick && e.onCloseClick(...d)),
                          },
                          [f(l)],
                          2,
                        ))
                      : Y("v-if", !0),
                    Y(" group arrow "),
                    e.inGroup ? (w(), ue(c, Ae(be({ key: 3 }, e.groupArrowProps)), null, 16)) : Y("v-if", !0),
                  ],
                  34,
                ))
              : Y("v-if", !0),
          ],
          6,
        ),
      ],
      8,
      ["to", "disabled"],
    )
  );
}
var Li = M(Pi, [["render", zi]]);
const _i = Symbol("PreviewGroupInjectionKey");
var Bi = _({
  name: "ImagePreviewGroup",
  components: { ImagePreview: Li },
  inheritAttrs: !1,
  props: {
    renderToBody: { type: Boolean, default: !0 },
    srcList: { type: Array },
    current: { type: Number },
    defaultCurrent: { type: Number, default: 0 },
    infinite: { type: Boolean, default: !1 },
    visible: { type: Boolean, default: void 0 },
    defaultVisible: { type: Boolean, default: !1 },
    maskClosable: { type: Boolean, default: !0 },
    closable: { type: Boolean, default: !0 },
    actionsLayout: {
      type: Array,
      default: () => ["fullScreen", "rotateRight", "rotateLeft", "zoomIn", "zoomOut", "originalSize"],
    },
    popupContainer: { type: [String, Object] },
  },
  emits: ["change", "update:current", "visible-change", "update:visible"],
  setup(e, { emit: t }) {
    const { srcList: n, visible: o, defaultVisible: i, current: s, defaultCurrent: r, infinite: a } = ge(e),
      [l, c] = Pt(i.value, de({ value: o })),
      d = (z) => {
        z !== l.value && (t("visible-change", z), t("update:visible", z), c(z));
      },
      u = m(
        () =>
          new Map(
            Vt(n == null ? void 0 : n.value)
              ? n == null
                ? void 0
                : n.value.map((z, U) => [U, { url: z, canPreview: !0 }])
              : [],
          ),
      ),
      $ = ne(new Map(u.value || [])),
      y = m(() => Array.from($.value.keys())),
      p = m(() => y.value.length);
    function T(z, U, J) {
      return (
        u.value.has(z) || $.value.set(z, { url: U, canPreview: J }),
        function () {
          u.value.has(z) || $.value.delete(z);
        }
      );
    }
    Ge(u, () => {
      $.value = new Map(u.value || []);
    });
    const [v, g] = Pt(r.value, de({ value: s })),
      I = (z) => {
        z !== v.value && (t("change", z), t("update:current", z), g(z));
      },
      b = m(() => y.value[v.value]),
      Z = (z) => {
        const U = y.value.indexOf(z);
        U !== v.value && I(U);
      },
      F = m(() => {
        var z;
        return (z = $.value.get(b.value)) == null ? void 0 : z.url;
      });
    Kt(
      _i,
      de({
        registerImageUrl: T,
        preview: (z) => {
          (d(!0), Z(z));
        },
      }),
    );
    const E = m(() => {
        const z = (J, A) => {
            var V;
            for (let R = J; R <= A; R++) {
              const ee = y.value[R];
              if ((V = $.value.get(ee)) != null && V.canPreview) return R;
            }
          },
          U = z(v.value + 1, p.value - 1);
        return Se(U) && a.value ? z(0, v.value - 1) : U;
      }),
      K = m(() => {
        const z = (J, A) => {
            var V;
            for (let R = J; R >= A; R--) {
              const ee = y.value[R];
              if ((V = $.value.get(ee)) != null && V.canPreview) return R;
            }
          },
          U = z(v.value - 1, 0);
        return Se(U) && a.value ? z(p.value - 1, v.value + 1) : U;
      }),
      H = m(() =>
        Se(K.value)
          ? void 0
          : () => {
              !Se(K.value) && I(K.value);
            },
      ),
      q = m(() =>
        Se(E.value)
          ? void 0
          : () => {
              !Se(E.value) && I(E.value);
            },
      );
    return {
      mergedVisible: l,
      currentUrl: F,
      prevIndex: K,
      nextIndex: E,
      onClose() {
        d(!1);
      },
      groupArrowProps: de({ onPrev: H, onNext: q }),
    };
  },
});
function ji(e, t, n, o, i, s) {
  const r = ie("ImagePreview");
  return (
    w(),
    P(
      ze,
      null,
      [
        ve(e.$slots, "default"),
        f(
          r,
          be(
            { ...e.$attrs, groupArrowProps: e.groupArrowProps },
            {
              "in-group": "",
              src: e.currentUrl,
              visible: e.mergedVisible,
              "mask-closable": e.maskClosable,
              closable: e.closable,
              "actions-layout": e.actionsLayout,
              "popup-container": e.popupContainer,
              "render-to-body": e.renderToBody,
              onClose: e.onClose,
            },
          ),
          Fe({ _: 2 }, [
            e.$slots.actions
              ? { name: "actions", fn: ke(() => [ve(e.$slots, "actions", { url: e.currentUrl })]), key: "0" }
              : void 0,
          ]),
          1040,
          [
            "src",
            "visible",
            "mask-closable",
            "closable",
            "actions-layout",
            "popup-container",
            "render-to-body",
            "onClose",
          ],
        ),
      ],
      64,
    )
  );
}
var Ti = M(Bi, [["render", ji]]);
const Ni = { small: 3, medium: 4, large: 8 },
  Oi = (e) => {
    if (e)
      return zt(e)
        ? {
            backgroundImage: `linear-gradient(to right, ${Object.keys(e)
              .map((n) => `${e[n]} ${n}`)
              .join(",")})`,
          }
        : { backgroundColor: e };
  },
  Ei = _({
    name: "ProgressLine",
    components: { IconExclamationCircleFill: It },
    props: {
      percent: { type: Number, default: 0 },
      animation: { type: Boolean, default: !1 },
      size: { type: String, default: "medium" },
      strokeWidth: { type: Number, default: 4 },
      width: { type: [Number, String], default: "100%" },
      color: { type: [String, Object], default: void 0 },
      trackColor: String,
      formatText: { type: Function, default: void 0 },
      status: { type: String },
      showText: Boolean,
    },
    setup(e) {
      const t = j("progress-line"),
        n = m(() => (e.strokeWidth !== 4 ? e.strokeWidth : Ni[e.size])),
        o = m(() => `${He.times(e.percent, 100)}%`),
        i = m(() => ({ width: e.width, height: `${n.value}px`, backgroundColor: e.trackColor })),
        s = m(() => ({ width: `${e.percent * 100}%`, ...Oi(e.color) }));
      return { prefixCls: t, style: i, barStyle: s, text: o };
    },
  }),
  Wi = ["aria-valuenow"];
function Mi(e, t, n, o, i, s) {
  const r = ie("icon-exclamation-circle-fill");
  return (
    w(),
    P(
      "div",
      {
        role: "progressbar",
        "aria-valuemin": "0",
        "aria-valuemax": "100",
        "aria-valuenow": e.percent,
        class: C(`${e.prefixCls}-wrapper`),
      },
      [
        L(
          "div",
          { class: C(e.prefixCls), style: O(e.style) },
          [
            L("div", { class: C(`${e.prefixCls}-bar-buffer`) }, null, 2),
            L("div", { class: C([`${e.prefixCls}-bar`]), style: O(e.barStyle) }, null, 6),
          ],
          6,
        ),
        e.showText
          ? (w(),
            P(
              "div",
              { key: 0, class: C(`${e.prefixCls}-text`) },
              [
                ve(e.$slots, "text", { percent: e.percent }, () => [
                  _t(Ke(e.text) + " ", 1),
                  e.status === "danger" ? (w(), ue(r, { key: 0 })) : Y("v-if", !0),
                ]),
              ],
              2,
            ))
          : Y("v-if", !0),
      ],
      10,
      Wi,
    )
  );
}
var Ai = M(Ei, [["render", Mi]]);
const Fi = _({
    name: "IconExclamation",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-exclamation`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  Ri = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Ui(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L("path", { d: "M23 9h2v21h-2z" }, null, -1),
          L("path", { fill: "currentColor", stroke: "none", d: "M23 9h2v21h-2z" }, null, -1),
          L("path", { d: "M23 37h2v2h-2z" }, null, -1),
          L("path", { fill: "currentColor", stroke: "none", d: "M23 37h2v2h-2z" }, null, -1),
        ]),
      14,
      Ri,
    )
  );
}
var ut = M(Fi, [["render", Ui]]);
const Di = Object.assign(ut, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + ut.name, ut);
    },
  }),
  qi = _({
    name: "IconCheck",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-check`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  xi = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Vi(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] || (t[1] = [L("path", { d: "M41.678 11.05 19.05 33.678 6.322 20.95" }, null, -1)]),
      14,
      xi,
    )
  );
}
var ct = M(qi, [["render", Vi]]);
const Jt = Object.assign(ct, {
  install: (e, t) => {
    var n;
    const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
    e.component(o + ct.name, ct);
  },
});
let Ot = 0;
const Qi = { mini: 16, small: 48, medium: 64, large: 80 },
  Zi = { mini: 4, small: 3, medium: 4, large: 4 },
  Hi = _({
    name: "ProgressCircle",
    components: { IconExclamation: Di, IconCheck: Jt },
    props: {
      percent: { type: Number, default: 0 },
      type: { type: String },
      size: { type: String, default: "medium" },
      strokeWidth: { type: Number },
      width: { type: Number, default: void 0 },
      color: { type: [String, Object], default: void 0 },
      trackColor: String,
      status: { type: String, default: void 0 },
      showText: { type: Boolean, default: !0 },
      pathStrokeWidth: { type: Number },
    },
    setup(e) {
      const t = j("progress-circle"),
        n = zt(e.color),
        o = m(() => {
          var u;
          return (u = e.width) != null ? u : Qi[e.size];
        }),
        i = m(() => {
          var u;
          return (u = e.strokeWidth) != null ? u : e.size === "mini" ? o.value / 2 : Zi[e.size];
        }),
        s = m(() => {
          var u;
          return (u = e.pathStrokeWidth) != null ? u : e.size === "mini" ? i.value : Math.max(2, i.value - 2);
        }),
        r = m(() => (o.value - i.value) / 2),
        a = m(() => Math.PI * 2 * r.value),
        l = m(() => o.value / 2),
        c = m(() => ((Ot += 1), `${t}-linear-gradient-${Ot}`)),
        d = m(() => `${He.times(e.percent, 100)}%`);
      return {
        prefixCls: t,
        isLinearGradient: n,
        radius: r,
        text: d,
        perimeter: a,
        center: l,
        mergedWidth: o,
        mergedStrokeWidth: i,
        mergedPathStrokeWidth: s,
        linearGradientId: c,
      };
    },
  }),
  Gi = ["aria-valuenow"],
  Ki = ["viewBox"],
  Yi = { key: 0 },
  Xi = ["id"],
  Ji = ["offset", "stop-color"],
  eo = ["cx", "cy", "r", "stroke-width"],
  to = ["cx", "cy", "r", "stroke-width"];
function no(e, t, n, o, i, s) {
  const r = ie("icon-check"),
    a = ie("icon-exclamation");
  return (
    w(),
    P(
      "div",
      {
        role: "progressbar",
        "aria-valuemin": "0",
        "aria-valuemax": "100",
        "aria-valuenow": e.percent,
        class: C(`${e.prefixCls}-wrapper`),
        style: O({ width: `${e.mergedWidth}px`, height: `${e.mergedWidth}px` }),
      },
      [
        e.type === "circle" && e.size === "mini" && e.status === "success"
          ? (w(), ue(r, { key: 0, style: O({ fontSize: e.mergedWidth - 2, color: e.color }) }, null, 8, ["style"]))
          : (w(),
            P(
              "svg",
              { key: 1, viewBox: `0 0 ${e.mergedWidth} ${e.mergedWidth}`, class: C(`${e.prefixCls}-svg`) },
              [
                e.isLinearGradient
                  ? (w(),
                    P("defs", Yi, [
                      L(
                        "linearGradient",
                        { id: e.linearGradientId, x1: "0", y1: "1", x2: "0", y2: "0" },
                        [
                          (w(!0),
                          P(
                            ze,
                            null,
                            Lt(
                              Object.keys(e.color),
                              (l) => (w(), P("stop", { key: l, offset: l, "stop-color": e.color[l] }, null, 8, Ji)),
                            ),
                            128,
                          )),
                        ],
                        8,
                        Xi,
                      ),
                    ]))
                  : Y("v-if", !0),
                L(
                  "circle",
                  {
                    class: C(`${e.prefixCls}-bg`),
                    fill: "none",
                    cx: e.center,
                    cy: e.center,
                    r: e.radius,
                    "stroke-width": e.mergedPathStrokeWidth,
                    style: O({ stroke: e.trackColor }),
                  },
                  null,
                  14,
                  eo,
                ),
                L(
                  "circle",
                  {
                    class: C(`${e.prefixCls}-bar`),
                    fill: "none",
                    cx: e.center,
                    cy: e.center,
                    r: e.radius,
                    "stroke-width": e.mergedStrokeWidth,
                    style: O({
                      stroke: e.isLinearGradient ? `url(#${e.linearGradientId})` : e.color,
                      strokeDasharray: e.perimeter,
                      strokeDashoffset: (e.percent >= 1 ? 0 : 1 - e.percent) * e.perimeter,
                    }),
                  },
                  null,
                  14,
                  to,
                ),
              ],
              10,
              Ki,
            )),
        e.showText && e.size !== "mini"
          ? (w(),
            P(
              "div",
              { key: 2, class: C(`${e.prefixCls}-text`) },
              [
                ve(e.$slots, "text", { percent: e.percent }, () => [
                  e.status === "danger"
                    ? (w(), ue(a, { key: 0 }))
                    : e.status === "success"
                      ? (w(), ue(r, { key: 1 }))
                      : (w(), P(ze, { key: 2 }, [_t(Ke(e.text), 1)], 64)),
                ]),
              ],
              2,
            ))
          : Y("v-if", !0),
      ],
      14,
      Gi,
    )
  );
}
var io = M(Hi, [["render", no]]);
const oo = _({
    name: "ProgressSteps",
    components: { IconExclamationCircleFill: It },
    props: {
      steps: { type: Number, default: 0 },
      percent: { type: Number, default: 0 },
      size: { type: String },
      color: { type: [String, Object], default: void 0 },
      trackColor: String,
      strokeWidth: { type: Number },
      status: { type: String, default: void 0 },
      showText: { type: Boolean, default: !0 },
    },
    setup(e) {
      const t = j("progress-steps"),
        n = m(() => {
          var s;
          return ((s = e.strokeWidth) != null ? s : e.size === "small") ? 8 : 4;
        }),
        o = m(() => [...Array(e.steps)].map((s, r) => e.percent > 0 && e.percent > (1 / e.steps) * r)),
        i = m(() => `${He.times(e.percent, 100)}%`);
      return { prefixCls: t, stepList: o, mergedStrokeWidth: n, text: i };
    },
  }),
  ro = ["aria-valuenow"];
function lo(e, t, n, o, i, s) {
  const r = ie("icon-exclamation-circle-fill");
  return (
    w(),
    P(
      "div",
      {
        role: "progressbar",
        "aria-valuemin": "0",
        "aria-valuemax": "100",
        "aria-valuenow": e.percent,
        class: C(`${e.prefixCls}-wrapper`),
      },
      [
        L(
          "div",
          { class: C(e.prefixCls), style: O({ height: `${e.mergedStrokeWidth}px` }) },
          [
            (w(!0),
            P(
              ze,
              null,
              Lt(
                e.stepList,
                (a, l) => (
                  w(),
                  P(
                    "div",
                    {
                      key: l,
                      class: C([`${e.prefixCls}-item`, { [`${e.prefixCls}-item-active`]: a }]),
                      style: O({ backgroundColor: a ? e.color : e.trackColor }),
                    },
                    null,
                    6,
                  )
                ),
              ),
              128,
            )),
          ],
          6,
        ),
        e.showText
          ? (w(),
            P(
              "div",
              { key: 0, class: C(`${e.prefixCls}-text`) },
              [
                ve(e.$slots, "text", { percent: e.percent }, () => [
                  _t(Ke(e.text) + " ", 1),
                  e.status === "danger" ? (w(), ue(r, { key: 0 })) : Y("v-if", !0),
                ]),
              ],
              2,
            ))
          : Y("v-if", !0),
      ],
      10,
      ro,
    )
  );
}
var so = M(oo, [["render", lo]]);
const ao = _({
  name: "Progress",
  components: { ProgressLine: Ai, ProgressCircle: io, ProgressSteps: so },
  props: {
    type: { type: String, default: "line" },
    size: { type: String },
    percent: { type: Number, default: 0 },
    steps: { type: Number, default: 0 },
    animation: { type: Boolean, default: !1 },
    strokeWidth: { type: Number },
    width: { type: [Number, String] },
    color: { type: [String, Object] },
    trackColor: String,
    bufferColor: { type: [String, Object] },
    showText: { type: Boolean, default: !0 },
    status: { type: String },
  },
  setup(e) {
    const t = j("progress"),
      { size: n } = ge(e),
      o = m(() => (e.steps > 0 ? "steps" : e.type)),
      i = m(() => e.status || (e.percent >= 1 ? "success" : "normal")),
      { mergedSize: s } = hn(n);
    return {
      cls: m(() => [t, `${t}-type-${o.value}`, `${t}-size-${s.value}`, `${t}-status-${i.value}`]),
      computedStatus: i,
      mergedSize: s,
    };
  },
});
function uo(e, t, n, o, i, s) {
  const r = ie("progress-steps"),
    a = ie("progress-line"),
    l = ie("progress-circle");
  return (
    w(),
    P(
      "div",
      { class: C(e.cls) },
      [
        e.steps > 0
          ? (w(),
            ue(
              r,
              {
                key: 0,
                "stroke-width": e.strokeWidth,
                percent: e.percent,
                color: e.color,
                "track-color": e.trackColor,
                width: e.width,
                steps: e.steps,
                size: e.mergedSize,
                "show-text": e.showText,
              },
              Fe({ _: 2 }, [
                e.$slots.text ? { name: "text", fn: ke((c) => [ve(e.$slots, "text", Ae(et(c)))]), key: "0" } : void 0,
              ]),
              1032,
              ["stroke-width", "percent", "color", "track-color", "width", "steps", "size", "show-text"],
            ))
          : e.type === "line" && e.mergedSize !== "mini"
            ? (w(),
              ue(
                a,
                {
                  key: 1,
                  "stroke-width": e.strokeWidth,
                  animation: e.animation,
                  percent: e.percent,
                  color: e.color,
                  "track-color": e.trackColor,
                  size: e.mergedSize,
                  "buffer-color": e.bufferColor,
                  width: e.width,
                  "show-text": e.showText,
                  status: e.computedStatus,
                },
                Fe({ _: 2 }, [
                  e.$slots.text ? { name: "text", fn: ke((c) => [ve(e.$slots, "text", Ae(et(c)))]), key: "0" } : void 0,
                ]),
                1032,
                [
                  "stroke-width",
                  "animation",
                  "percent",
                  "color",
                  "track-color",
                  "size",
                  "buffer-color",
                  "width",
                  "show-text",
                  "status",
                ],
              ))
            : (w(),
              ue(
                l,
                {
                  key: 2,
                  type: e.type,
                  "stroke-width": e.type === "line" ? e.strokeWidth || 4 : e.strokeWidth,
                  "path-stroke-width": e.type === "line" ? e.strokeWidth || 4 : e.strokeWidth,
                  width: e.width,
                  percent: e.percent,
                  color: e.color,
                  "track-color": e.trackColor,
                  size: e.mergedSize,
                  "show-text": e.showText,
                  status: e.computedStatus,
                },
                Fe({ _: 2 }, [
                  e.$slots.text ? { name: "text", fn: ke((c) => [ve(e.$slots, "text", Ae(et(c)))]), key: "0" } : void 0,
                ]),
                1032,
                [
                  "type",
                  "stroke-width",
                  "path-stroke-width",
                  "width",
                  "percent",
                  "color",
                  "track-color",
                  "size",
                  "show-text",
                  "status",
                ],
              )),
      ],
      2,
    )
  );
}
var dt = M(ao, [["render", uo]]);
const co = Object.assign(dt, {
    install: (e, t) => {
      Qt(e, t);
      const n = Zt(t);
      e.component(n + dt.name, dt);
    },
  }),
  fo = _({
    name: "IconDelete",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-delete`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  vo = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function mo(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            {
              d: "M5 11h5.5m0 0v29a1 1 0 0 0 1 1h25a1 1 0 0 0 1-1V11m-27 0H16m21.5 0H43m-5.5 0H32m-16 0V7h16v4m-16 0h16M20 18v15m8-15v15",
            },
            null,
            -1,
          ),
        ]),
      14,
      vo,
    )
  );
}
var ft = M(fo, [["render", mo]]);
const en = Object.assign(ft, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + ft.name, ft);
    },
  }),
  po = _({
    name: "IconFile",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-file`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  ho = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function ko(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            { d: "M16 21h16m-16 8h10m11 13H11a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h21l7 7v27a2 2 0 0 1-2 2Z" },
            null,
            -1,
          ),
        ]),
      14,
      ho,
    )
  );
}
var vt = M(po, [["render", ko]]);
const go = Object.assign(vt, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + vt.name, vt);
    },
  }),
  Et = (e) => {
    const t = e.responseText || e.response;
    if (!t) return;
    const n = e.getResponseHeader("Content-Type");
    if (n && n.includes("json"))
      try {
        return JSON.parse(t);
      } catch {
        return t;
      }
    return t;
  },
  yo = (e) => {
    switch (e) {
      case "done":
        return "success";
      case "error":
        return "danger";
      default:
        return "normal";
    }
  },
  Wt = (e, t) => (we(e) ? e(t) : e),
  wo = ({
    fileItem: e,
    action: t,
    name: n,
    data: o,
    headers: i = {},
    withCredentials: s = !1,
    onProgress: r = Je,
    onSuccess: a = Je,
    onError: l = Je,
  }) => {
    const c = Wt(n, e) || "file",
      d = Wt(o, e),
      u = new XMLHttpRequest();
    (s && (u.withCredentials = !0),
      (u.upload.onprogress = (y) => {
        const p = y.total > 0 ? He.round(y.loaded / y.total, 2) : 0;
        r(p, y);
      }),
      (u.onerror = function (p) {
        l(p);
      }),
      (u.onload = () => {
        if (u.status < 200 || u.status >= 300) {
          l(Et(u));
          return;
        }
        a(Et(u));
      }));
    const $ = new FormData();
    if (d) for (const y of Object.keys(d)) $.append(y, d[y]);
    (e.file && $.append(c, e.file), u.open("post", t ?? "", !0));
    for (const y of Object.keys(i)) u.setRequestHeader(y, i[y]);
    return (
      u.send($),
      {
        abort() {
          u.abort();
        },
      }
    );
  },
  tn = (e, t) => {
    if (t && e) {
      const n = Vt(t)
          ? t
          : t
              .split(",")
              .map((i) => i.trim())
              .filter((i) => i),
        o = (e.name.indexOf(".") > -1 ? `.${e.name.split(".").pop()}` : "").toLowerCase();
      return n.some((i) => {
        const s = i && i.toLowerCase(),
          r = (e.type || "").toLowerCase(),
          a = r.split("/")[0];
        if (s === r || `${a}${o.replace(".", "/")}` === s || /^\*(\/\*)?$/.test(s)) return !0;
        if (/\/\*/.test(s)) return r.replace(/\/.*$/, "") === s.replace(/\/.*$/, "");
        if (/\..*/.test(s)) {
          let l = [s];
          return ((s === ".jpg" || s === ".jpeg") && (l = [".jpg", ".jpeg"]), l.indexOf(o) > -1);
        }
        return !1;
      });
    }
    return !!e;
  },
  bo = (e, t, n) => {
    const o = [];
    let i = 0;
    const s = () => {
        !i && n(o);
      },
      r = (a) => {
        if (((i += 1), a != null && a.isFile)) {
          a.file((l) => {
            ((i -= 1),
              tn(l, t) &&
                (Object.defineProperty(l, "webkitRelativePath", { value: a.fullPath.replace(/^\//, "") }), o.push(l)),
              s());
          });
          return;
        }
        if (a != null && a.isDirectory) {
          const l = a.createReader();
          let c = !1;
          const d = () => {
            l.readEntries((u) => {
              (c || ((i -= 1), (c = !0)), u.length === 0 ? s() : (d(), u.forEach(r)));
            });
          };
          d();
          return;
        }
        ((i -= 1), s());
      };
    [].slice.call(e).forEach((a) => a.webkitGetAsEntry && r(a.webkitGetAsEntry()));
  },
  $o = (e) => {
    var t;
    return (t = e.type) == null ? void 0 : t.includes("image");
  },
  mt = (e, t) => {
    if (!e) return [];
    const n = Array.from(e);
    return t ? n.filter((o) => tn(o, t)) : n;
  },
  Co = _({
    name: "IconUpload",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-upload`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  So = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Po(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] || (t[1] = [L("path", { d: "M14.93 17.071 24.001 8l9.071 9.071m-9.07 16.071v-25M40 35v6H8v-6" }, null, -1)]),
      14,
      So,
    )
  );
}
var pt = M(Co, [["render", Po]]);
const jt = Object.assign(pt, {
  install: (e, t) => {
    var n;
    const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
    e.component(o + pt.name, pt);
  },
});
var Io = _({
  name: "UploadButton",
  props: {
    disabled: { type: Boolean, default: !1 },
    directory: { type: Boolean, default: !1 },
    accept: String,
    listType: { type: String },
    tip: String,
    draggable: { type: Boolean, default: !1 },
    multiple: { type: Boolean, default: !1 },
    uploadFiles: { type: Function, required: !0 },
    hide: Boolean,
    onButtonClick: { type: Function },
  },
  setup(e, { slots: t }) {
    const n = j("upload"),
      { t: o } = Ze(),
      i = ne(!1),
      s = ne(null),
      r = ne(null),
      a = ne(0),
      l = (v) => {
        v === "subtract" ? (a.value -= 1) : v === "add" ? (a.value += 1) : v === "reset" && (a.value = 0);
      },
      c = (v) => {
        if (!e.disabled) {
          if (we(e.onButtonClick)) {
            const g = e.onButtonClick(v);
            if (gn(g)) {
              g.then((I) => {
                e.uploadFiles(mt(I));
              });
              return;
            }
          }
          s.value && s.value.click();
        }
      },
      d = (v) => {
        const g = v.target;
        (g.files && e.uploadFiles(mt(g.files)), (g.value = ""));
      },
      u = (v) => {
        var g, I;
        if ((v.preventDefault(), (i.value = !1), l("reset"), !e.disabled))
          if (e.directory && (g = v.dataTransfer) != null && g.items)
            bo(v.dataTransfer.items, e.accept, (b) => {
              e.uploadFiles(b);
            });
          else {
            const b = mt((I = v.dataTransfer) == null ? void 0 : I.files, e.accept);
            e.uploadFiles(e.multiple ? b : b.slice(0, 1));
          }
      },
      $ = (v) => {
        (v.preventDefault(), l("subtract"), a.value === 0 && ((i.value = !1), l("reset")));
      },
      y = (v) => {
        (v.preventDefault(), !e.disabled && !i.value && (i.value = !0));
      },
      p = () =>
        t.default
          ? f("span", null, [t.default()])
          : e.listType === "picture-card"
            ? f("div", { class: `${n}-picture-card` }, [
                f("div", { class: `${n}-picture-card-text` }, [f(Tt, null, null)]),
                e.tip && f("div", { class: `${n}-tip` }, [e.tip]),
              ])
            : e.draggable
              ? f("div", { class: [`${n}-drag`, { [`${n}-drag-active`]: i.value }] }, [
                  f("div", null, [f(Tt, null, null)]),
                  f("div", { class: `${n}-drag-text` }, [i.value ? o("upload.dragHover") : o("upload.drag")]),
                  e.tip && f("div", { class: `${n}-tip` }, [e.tip]),
                ])
              : f(
                  kn,
                  { type: "primary", disabled: e.disabled },
                  { default: () => [o("upload.buttonText")], icon: () => f(jt, null, null) },
                ),
      T = m(() => [
        n,
        {
          [`${n}-type-picture-card`]: e.listType === "picture-card",
          [`${n}-draggable`]: e.draggable,
          [`${n}-disabled`]: e.disabled,
          [`${n}-hide`]: e.hide,
        },
      ]);
    return () =>
      f(
        "span",
        {
          ref: r,
          class: T.value,
          onClick: c,
          onDragenter: () => {
            l("add");
          },
          onDrop: u,
          onDragover: y,
          onDragleave: $,
        },
        [
          f(
            "input",
            be(
              {
                ref: s,
                type: "file",
                style: { display: "none" },
                disabled: e.disabled,
                accept: e.accept,
                multiple: e.multiple,
              },
              e.directory ? { webkitdirectory: "webkitdirectory" } : {},
              { onChange: d },
            ),
            null,
          ),
          p(),
        ],
      );
  },
});
const zo = _({
    name: "IconPause",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-pause`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  Lo = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function _o(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L("path", { d: "M14 12h4v24h-4zM30 12h4v24h-4z" }, null, -1),
          L("path", { fill: "currentColor", stroke: "none", d: "M14 12h4v24h-4zM30 12h4v24h-4z" }, null, -1),
        ]),
      14,
      Lo,
    )
  );
}
var ht = M(zo, [["render", _o]]);
const Bo = Object.assign(ht, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + ht.name, ht);
    },
  }),
  jo = _({
    name: "IconPlayArrowFill",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-play-arrow-fill`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  To = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function No(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            {
              d: "M17.533 10.974a1 1 0 0 0-1.537.844v24.356a1 1 0 0 0 1.537.844L36.67 24.84a1 1 0 0 0 0-1.688L17.533 10.974Z",
              fill: "currentColor",
              stroke: "none",
            },
            null,
            -1,
          ),
        ]),
      14,
      To,
    )
  );
}
var kt = M(jo, [["render", No]]);
const Oo = Object.assign(kt, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + kt.name, kt);
    },
  }),
  Ye = Symbol("ArcoUpload");
var nn = _({
  name: "UploadProgress",
  props: { file: { type: Object, required: !0 }, listType: { type: String, required: !0 } },
  setup(e) {
    const t = j("upload-progress"),
      { t: n } = Ze(),
      o = Bt(Ye, void 0),
      i = () => {
        var r, a, l, c, d, u, $, y, p, T, v;
        return e.file.status === "error"
          ? f(
              "span",
              {
                class: [o == null ? void 0 : o.iconCls, `${o == null ? void 0 : o.iconCls}-upload`],
                onClick: () => (o == null ? void 0 : o.onUpload(e.file)),
              },
              [
                (o != null &&
                  o.showRetryButton &&
                  ((d = (a = o == null ? void 0 : (r = o.slots)["retry-icon"]) == null ? void 0 : a.call(r)) != null
                    ? d
                    : (c = (l = o == null ? void 0 : o.customIcon) == null ? void 0 : l.retryIcon) != null &&
                      c.call(l))) ||
                e.listType === "picture-card"
                  ? f(jt, null, null)
                  : n("upload.retry"),
              ],
            )
          : e.file.status === "done"
            ? f("span", { class: [o == null ? void 0 : o.iconCls, `${o == null ? void 0 : o.iconCls}-success`] }, [
                (v =
                  (T = ($ = o == null ? void 0 : (u = o.slots)["success-icon"]) == null ? void 0 : $.call(u)) != null
                    ? T
                    : (p = (y = o == null ? void 0 : o.customIcon) == null ? void 0 : y.successIcon) == null
                      ? void 0
                      : p.call(y)) != null
                  ? v
                  : f(Jt, null, null),
              ])
            : e.file.status === "init"
              ? f(
                  Oe,
                  { content: n("upload.start") },
                  {
                    default: () => {
                      var g, I, b, Z, F, E;
                      return [
                        f(
                          "span",
                          {
                            class: [o == null ? void 0 : o.iconCls, `${o == null ? void 0 : o.iconCls}-start`],
                            onClick: () => (o == null ? void 0 : o.onUpload(e.file)),
                          },
                          [
                            (E =
                              (F =
                                (I = o == null ? void 0 : (g = o.slots)["start-icon"]) == null ? void 0 : I.call(g)) !=
                              null
                                ? F
                                : (Z = (b = o == null ? void 0 : o.customIcon) == null ? void 0 : b.startIcon) == null
                                  ? void 0
                                  : Z.call(b)) != null
                              ? E
                              : f(Oo, null, null),
                          ],
                        ),
                      ];
                    },
                  },
                )
              : (o == null ? void 0 : o.showCancelButton) &&
                f(
                  Oe,
                  { content: n("upload.cancel") },
                  {
                    default: () => {
                      var g, I, b, Z, F, E;
                      return [
                        f(
                          "span",
                          {
                            class: [o == null ? void 0 : o.iconCls, `${o == null ? void 0 : o.iconCls}-cancel`],
                            onClick: () => (o == null ? void 0 : o.onAbort(e.file)),
                          },
                          [
                            (E =
                              (F =
                                (I = o == null ? void 0 : (g = o.slots)["cancel-icon"]) == null ? void 0 : I.call(g)) !=
                              null
                                ? F
                                : (Z = (b = o == null ? void 0 : o.customIcon) == null ? void 0 : b.cancelIcon) == null
                                  ? void 0
                                  : Z.call(b)) != null
                              ? E
                              : f(Bo, null, null),
                          ],
                        ),
                      ];
                    },
                  },
                );
      },
      s = () => {
        var r;
        if (["init", "uploading"].includes((r = e.file.status) != null ? r : "")) {
          const a = yo(e.file.status);
          return f(co, { type: "circle", size: "mini", showText: !1, status: a, percent: e.file.percent }, null);
        }
        return null;
      };
    return () => f("span", { class: t }, [s(), i()]);
  },
});
const Eo = _({
    name: "IconFilePdf",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-file-pdf`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  Wo = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Mo(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            {
              d: "M11 42h26a2 2 0 0 0 2-2V13.828a2 2 0 0 0-.586-1.414l-5.828-5.828A2 2 0 0 0 31.172 6H11a2 2 0 0 0-2 2v32a2 2 0 0 0 2 2Z",
            },
            null,
            -1,
          ),
          L(
            "path",
            {
              d: "M22.305 21.028c.874 1.939 3.506 6.265 4.903 8.055 1.747 2.237 3.494 2.685 4.368 2.237.873-.447 1.21-4.548-7.425-2.685-7.523 1.623-7.424 3.58-6.988 4.476.728 1.193 2.522 2.627 5.678-6.266C25.699 18.79 24.489 17 23.277 17c-1.409 0-2.538.805-.972 4.028Z",
            },
            null,
            -1,
          ),
        ]),
      14,
      Wo,
    )
  );
}
var gt = M(Eo, [["render", Mo]]);
const Ao = Object.assign(gt, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + gt.name, gt);
    },
  }),
  Fo = _({
    name: "IconFileImage",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-file-image`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  Ro = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Uo(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L(
            "path",
            {
              d: "m26 33 5-6v6h-5Zm0 0-3-4-4 4h7Zm11 9H11a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h21l7 7v27a2 2 0 0 1-2 2ZM17 19h1v1h-1v-1Z",
            },
            null,
            -1,
          ),
        ]),
      14,
      Ro,
    )
  );
}
var yt = M(Fo, [["render", Uo]]);
const Do = Object.assign(yt, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + yt.name, yt);
    },
  }),
  qo = _({
    name: "IconFileVideo",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-file-video`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  xo = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Vo(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L("path", { d: "M37 42H11a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h21l7 7v27a2 2 0 0 1-2 2Z" }, null, -1),
          L("path", { d: "M22 27.796v-6l5 3-5 3Z" }, null, -1),
        ]),
      14,
      xo,
    )
  );
}
var wt = M(qo, [["render", Vo]]);
const Qo = Object.assign(wt, {
    install: (e, t) => {
      var n;
      const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
      e.component(o + wt.name, wt);
    },
  }),
  Zo = _({
    name: "IconFileAudio",
    props: {
      size: { type: [Number, String] },
      strokeWidth: { type: Number, default: 4 },
      strokeLinecap: { type: String, default: "butt", validator: (e) => ["butt", "round", "square"].includes(e) },
      strokeLinejoin: {
        type: String,
        default: "miter",
        validator: (e) => ["arcs", "bevel", "miter", "miter-clip", "round"].includes(e),
      },
      rotate: Number,
      spin: Boolean,
    },
    emits: { click: (e) => !0 },
    setup(e, { emit: t }) {
      const n = j("icon"),
        o = m(() => [n, `${n}-file-audio`, { [`${n}-spin`]: e.spin }]),
        i = m(() => {
          const r = {};
          return (
            e.size && (r.fontSize = X(e.size) ? `${e.size}px` : e.size),
            e.rotate && (r.transform = `rotate(${e.rotate}deg)`),
            r
          );
        });
      return {
        cls: o,
        innerStyle: i,
        onClick: (r) => {
          t("click", r);
        },
      };
    },
  }),
  Ho = ["stroke-width", "stroke-linecap", "stroke-linejoin"];
function Go(e, t, n, o, i, s) {
  return (
    w(),
    P(
      "svg",
      {
        viewBox: "0 0 48 48",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        stroke: "currentColor",
        class: C(e.cls),
        style: O(e.innerStyle),
        "stroke-width": e.strokeWidth,
        "stroke-linecap": e.strokeLinecap,
        "stroke-linejoin": e.strokeLinejoin,
        onClick: t[0] || (t[0] = (...r) => e.onClick && e.onClick(...r)),
      },
      t[1] ||
        (t[1] = [
          L("path", { d: "M37 42H11a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h21l7 7v27a2 2 0 0 1-2 2Z" }, null, -1),
          L("path", { d: "M25 30a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z", fill: "currentColor", stroke: "none" }, null, -1),
          L("path", { d: "M25 30a3 3 0 1 1-6 0 3 3 0 0 1 6 0Zm0 0-.951-12.363a.5.5 0 0 1 .58-.532L30 18" }, null, -1),
        ]),
      14,
      Ho,
    )
  );
}
var bt = M(Zo, [["render", Go]]);
const Ko = Object.assign(bt, {
  install: (e, t) => {
    var n;
    const o = (n = t == null ? void 0 : t.iconPrefix) != null ? n : "";
    e.component(o + bt.name, bt);
  },
});
var Mt = _({
    name: "UploadListItem",
    props: { file: { type: Object, required: !0 }, listType: { type: String, required: !0 } },
    setup(e) {
      const n = `${j("upload-list")}-item`,
        { t: o } = Ze(),
        i = Bt(Ye, void 0),
        s = () => {
          var r, a;
          let l = "";
          if (e.file.file && e.file.file.type) l = e.file.file.type;
          else {
            const c = (a = (r = e.file.name) == null ? void 0 : r.split(".")[1]) != null ? a : "";
            ["png", "jpg", "jpeg", "bmp", "gif", "webp"].includes(c)
              ? (l = "image")
              : ["mp4", "m2v", "mkv", "m4v", "mov"].includes(c)
                ? (l = "video")
                : ["mp3", "wav", "wmv", "m4a", "acc", "flac"].includes(c) && (l = "audio");
          }
          return l.includes("image")
            ? f(Do, null, null)
            : l.includes("pdf")
              ? f(Ao, null, null)
              : l.includes("audio")
                ? f(Ko, null, null)
                : l.includes("video")
                  ? f(Qo, null, null)
                  : f(go, null, null);
        };
      return () => {
        var r, a, l, c, d, u, $, y, p, T, v, g, I, b, Z, F, E, K, H, q, z, U, J;
        return f("div", { class: [n, `${n}-${e.file.status}`] }, [
          f("div", { class: `${n}-content` }, [
            (i == null ? void 0 : i.listType) === "picture" &&
              f("span", { class: `${n}-thumbnail` }, [
                (l =
                  (a = i == null ? void 0 : (r = i.slots).image) == null ? void 0 : a.call(r, { fileItem: e.file })) !=
                null
                  ? l
                  : f(
                      "img",
                      be(
                        { src: e.file.url, alt: e.file.name },
                        i != null && i.imageLoading ? { loading: i.imageLoading } : void 0,
                      ),
                      null,
                    ),
              ]),
            f("div", { class: `${n}-name` }, [
              (i == null ? void 0 : i.listType) === "text" &&
                f("span", { class: `${n}-file-icon` }, [
                  (p =
                    (y =
                      (d = i == null ? void 0 : (c = i.slots)["file-icon"]) == null
                        ? void 0
                        : d.call(c, { fileItem: e.file })) != null
                      ? y
                      : ($ = (u = i == null ? void 0 : i.customIcon) == null ? void 0 : u.fileIcon) == null
                        ? void 0
                        : $.call(u, e.file)) != null
                    ? p
                    : s(),
                ]),
              i != null && i.showLink && e.file.url
                ? f(
                    "a",
                    be(
                      { class: `${n}-name-link`, target: "_blank", href: e.file.url },
                      i != null && i.download ? { download: e.file.name } : void 0,
                    ),
                    [
                      (Z =
                        (b =
                          (v = i == null ? void 0 : (T = i.slots)["file-name"]) == null
                            ? void 0
                            : v.call(T, { fileItem: e.file })) != null
                          ? b
                          : (I = (g = i == null ? void 0 : i.customIcon) == null ? void 0 : g.fileName) == null
                            ? void 0
                            : I.call(g, e.file)) != null
                        ? Z
                        : e.file.name,
                    ],
                  )
                : f("span", { class: `${n}-name-text`, onClick: () => (i == null ? void 0 : i.onPreview(e.file)) }, [
                    (z =
                      (q =
                        (E = i == null ? void 0 : (F = i.slots)["file-name"]) == null
                          ? void 0
                          : E.call(F, { fileItem: e.file })) != null
                        ? q
                        : (H = (K = i == null ? void 0 : i.customIcon) == null ? void 0 : K.fileName) == null
                          ? void 0
                          : H.call(K, e.file)) != null
                      ? z
                      : e.file.name,
                  ]),
              e.file.status === "error" &&
                f(
                  Oe,
                  { content: o("upload.error") },
                  {
                    default: () => {
                      var A, V, R, ee, te, oe;
                      return [
                        f(
                          "span",
                          { class: [i == null ? void 0 : i.iconCls, `${i == null ? void 0 : i.iconCls}-error`] },
                          [
                            (oe =
                              (te =
                                (V = i == null ? void 0 : (A = i.slots)["error-icon"]) == null ? void 0 : V.call(A)) !=
                              null
                                ? te
                                : (ee = (R = i == null ? void 0 : i.customIcon) == null ? void 0 : R.errorIcon) == null
                                  ? void 0
                                  : ee.call(R)) != null
                              ? oe
                              : f(It, null, null),
                          ],
                        ),
                      ];
                    },
                  },
                ),
            ]),
            f(nn, { file: e.file, listType: e.listType }, null),
          ]),
          (i == null ? void 0 : i.showRemoveButton) &&
            f("span", { class: `${n}-operation` }, [
              f(
                yn,
                {
                  onClick: () => {
                    var A;
                    return (A = i == null ? void 0 : i.onRemove) == null ? void 0 : A.call(i, e.file);
                  },
                },
                {
                  default: () => {
                    var A, V, R, ee, te, oe;
                    return [
                      f(
                        "span",
                        { class: [i == null ? void 0 : i.iconCls, `${i == null ? void 0 : i.iconCls}-remove`] },
                        [
                          (oe =
                            (te =
                              (V = i == null ? void 0 : (A = i.slots)["remove-icon"]) == null ? void 0 : V.call(A)) !=
                            null
                              ? te
                              : (ee = (R = i == null ? void 0 : i.customIcon) == null ? void 0 : R.removeIcon) == null
                                ? void 0
                                : ee.call(R)) != null
                            ? oe
                            : f(en, null, null),
                        ],
                      ),
                    ];
                  },
                },
              ),
            ]),
          (J = i == null ? void 0 : (U = i.slots)["extra-button"]) == null ? void 0 : J.call(U, { fileItem: e.file }),
        ]);
      };
    },
  }),
  At = _({
    name: "UploadPictureItem",
    props: { file: { type: Object, required: !0 }, disabled: { type: Boolean, default: !1 } },
    setup(e) {
      const n = `${j("upload-list")}-picture`,
        o = m(() => [n, { [`${n}-status-error`]: e.file.status === "error" }]),
        i = Bt(Ye, void 0),
        s = () => {
          var r, a, l, c, d, u, $, y, p, T, v, g, I, b, Z, F, E, K, H, q, z, U, J, A, V, R, ee, te, oe;
          return e.file.status === "uploading"
            ? f(nn, { file: e.file, listType: "picture-card" }, null)
            : f(ze, null, [
                (l =
                  (a = i == null ? void 0 : (r = i.slots).image) == null ? void 0 : a.call(r, { fileItem: e.file })) !=
                null
                  ? l
                  : f(
                      "img",
                      be(
                        { src: e.file.url, alt: e.file.name },
                        i != null && i.imageLoading ? { loading: i.imageLoading } : void 0,
                      ),
                      null,
                    ),
                f("div", { class: `${n}-mask` }, [
                  e.file.status === "error" &&
                    (i == null ? void 0 : i.showCancelButton) &&
                    f("div", { class: `${n}-error-tip` }, [
                      f(
                        "span",
                        { class: [i == null ? void 0 : i.iconCls, `${i == null ? void 0 : i.iconCls}-error`] },
                        [
                          (p =
                            (y = (d = i == null ? void 0 : (c = i.slots)["error-icon"]) == null ? void 0 : d.call(c)) !=
                            null
                              ? y
                              : ($ = (u = i == null ? void 0 : i.customIcon) == null ? void 0 : u.errorIcon) == null
                                ? void 0
                                : $.call(u)) != null
                            ? p
                            : f(An, null, null),
                        ],
                      ),
                    ]),
                  f("div", { class: `${n}-operation` }, [
                    e.file.status !== "error" &&
                      (i == null ? void 0 : i.showPreviewButton) &&
                      f(
                        "span",
                        {
                          class: [i == null ? void 0 : i.iconCls, `${i == null ? void 0 : i.iconCls}-preview`],
                          onClick: () => (i == null ? void 0 : i.onPreview(e.file)),
                        },
                        [
                          (Z =
                            (b =
                              (v = i == null ? void 0 : (T = i.slots)["preview-icon"]) == null ? void 0 : v.call(T)) !=
                            null
                              ? b
                              : (I = (g = i == null ? void 0 : i.customIcon) == null ? void 0 : g.previewIcon) == null
                                ? void 0
                                : I.call(g)) != null
                            ? Z
                            : f(jn, null, null),
                        ],
                      ),
                    ["init", "error"].includes(e.file.status) &&
                      (i == null ? void 0 : i.showRetryButton) &&
                      f(
                        "span",
                        {
                          class: [i == null ? void 0 : i.iconCls, `${i == null ? void 0 : i.iconCls}-upload`],
                          onClick: () => (i == null ? void 0 : i.onUpload(e.file)),
                        },
                        [
                          (z =
                            (q = (E = i == null ? void 0 : (F = i.slots)["retry-icon"]) == null ? void 0 : E.call(F)) !=
                            null
                              ? q
                              : (H = (K = i == null ? void 0 : i.customIcon) == null ? void 0 : K.retryIcon) == null
                                ? void 0
                                : H.call(K)) != null
                            ? z
                            : f(jt, null, null),
                        ],
                      ),
                    !(i != null && i.disabled) &&
                      (i == null ? void 0 : i.showRemoveButton) &&
                      f(
                        "span",
                        {
                          class: [i == null ? void 0 : i.iconCls, `${i == null ? void 0 : i.iconCls}-remove`],
                          onClick: () => (i == null ? void 0 : i.onRemove(e.file)),
                        },
                        [
                          (ee =
                            (R =
                              (J = i == null ? void 0 : (U = i.slots)["remove-icon"]) == null ? void 0 : J.call(U)) !=
                            null
                              ? R
                              : (V = (A = i == null ? void 0 : i.customIcon) == null ? void 0 : A.removeIcon) == null
                                ? void 0
                                : V.call(A)) != null
                            ? ee
                            : f(en, null, null),
                        ],
                      ),
                    (oe = i == null ? void 0 : (te = i.slots)["extra-button"]) == null ? void 0 : oe.call(te, e.file),
                  ]),
                ]),
              ]);
        };
      return () => f("span", { class: o.value }, [s()]);
    },
  }),
  Yo = _({
    name: "UploadList",
    components: { UploadListItem: Mt, UploadPictureItem: At },
    props: { fileList: { type: Array, required: !0 }, listType: { type: String, required: !0 } },
    setup(e, { slots: t }) {
      const n = j("upload"),
        o = m(() => [`${n}-list`, `${n}-list-type-${e.listType}`]),
        i = (s, r) =>
          we(t["upload-item"])
            ? t["upload-item"]({ fileItem: s, index: r })
            : e.listType === "picture-card"
              ? f(At, { file: s, key: `item-${r}` }, null)
              : f(Mt, { file: s, listType: e.listType, key: `item-${r}` }, null);
      return () =>
        f(
          _n,
          { tag: "div", class: o.value },
          {
            default: () => {
              var s;
              return [
                ...e.fileList.map((r, a) => i(r, a)),
                e.listType === "picture-card" && ((s = t["upload-button"]) == null ? void 0 : s.call(t)),
              ];
            },
          },
        );
    },
  }),
  $t = _({
    name: "Upload",
    props: {
      fileList: { type: Array, default: void 0 },
      defaultFileList: { type: Array, default: () => [] },
      accept: String,
      action: String,
      disabled: { type: Boolean, default: !1 },
      multiple: { type: Boolean, default: !1 },
      directory: { type: Boolean, default: !1 },
      draggable: { type: Boolean, default: !1 },
      tip: String,
      headers: { type: Object },
      data: { type: [Object, Function] },
      name: { type: [String, Function] },
      withCredentials: { type: Boolean, default: !1 },
      customRequest: { type: Function },
      limit: { type: Number, default: 0 },
      autoUpload: { type: Boolean, default: !0 },
      showFileList: { type: Boolean, default: !0 },
      showRemoveButton: { type: Boolean, default: !0 },
      showRetryButton: { type: Boolean, default: !0 },
      showCancelButton: { type: Boolean, default: !0 },
      showUploadButton: { type: [Boolean, Object], default: !0 },
      showPreviewButton: { type: Boolean, default: !0 },
      download: { type: Boolean, default: !1 },
      showLink: { type: Boolean, default: !0 },
      imageLoading: { type: String },
      listType: { type: String, default: "text" },
      responseUrlKey: { type: [String, Function] },
      customIcon: { type: Object },
      imagePreview: { type: Boolean, default: !1 },
      onBeforeUpload: { type: Function },
      onBeforeRemove: { type: Function },
      onButtonClick: { type: Function },
    },
    emits: {
      "update:fileList": (e) => !0,
      exceedLimit: (e, t) => !0,
      change: (e, t) => !0,
      progress: (e, t) => !0,
      preview: (e) => !0,
      success: (e) => !0,
      error: (e) => !0,
    },
    setup(e, { emit: t, slots: n }) {
      const {
          fileList: o,
          disabled: i,
          listType: s,
          customIcon: r,
          showRetryButton: a,
          showCancelButton: l,
          showRemoveButton: c,
          showPreviewButton: d,
          imageLoading: u,
          download: $,
          showLink: y,
        } = ge(e),
        p = j("upload"),
        { mergedDisabled: T, eventHandlers: v } = wn({ disabled: i }),
        g = ne([]),
        I = new Map(),
        b = new Map(),
        Z = m(() => e.limit > 0 && g.value.length >= e.limit),
        F = (k) => {
          I.clear();
          const S =
            k == null
              ? void 0
              : k.map((W, G) => {
                  var re, B, Q;
                  const N = (re = W.status) != null ? re : "done",
                    le = de({
                      ...W,
                      uid: (B = W.uid) != null ? B : `${Date.now()}${G}`,
                      status: N,
                      percent: (Q = W.percent) != null ? Q : ["error", "init"].indexOf(N) > -1 ? 0 : 1,
                    });
                  return (I.set(le.uid, le), le);
                });
          g.value = S ?? [];
        };
      (F(e.defaultFileList),
        Ge(
          o,
          (k) => {
            k && F(k);
          },
          { immediate: !0, deep: !0 },
        ));
      const E = (k) => {
          var S, W;
          (t("update:fileList", g.value),
            t("change", g.value, k),
            (W = (S = v.value) == null ? void 0 : S.onChange) == null || W.call(S));
        },
        K = (k, S) => {
          for (const W of g.value)
            if (W.uid === k) {
              ((W.file = S), E(W));
              break;
            }
        },
        H = (k) => {
          const S = (Q, N) => {
              const le = I.get(k.uid);
              le && ((le.status = "uploading"), (le.percent = Q), t("progress", le, N), E(le));
            },
            W = (Q) => {
              const N = I.get(k.uid);
              N &&
                ((N.status = "done"),
                (N.percent = 1),
                (N.response = Q),
                e.responseUrlKey &&
                  (we(e.responseUrlKey)
                    ? (N.url = e.responseUrlKey(N))
                    : Q[e.responseUrlKey] && (N.url = Q[e.responseUrlKey])),
                b.delete(N.uid),
                t("success", N),
                E(N));
            },
            G = (Q) => {
              const N = I.get(k.uid);
              N && ((N.status = "error"), (N.percent = 0), (N.response = Q), b.delete(N.uid), t("error", N), E(N));
            },
            re = {
              fileItem: k,
              action: e.action,
              name: e.name,
              data: e.data,
              headers: e.headers,
              withCredentials: e.withCredentials,
              onProgress: S,
              onSuccess: W,
              onError: G,
            };
          ((k.status = "uploading"), (k.percent = 0));
          const B = we(e.customRequest) ? e.customRequest(re) : wo(re);
          (b.set(k.uid, B), E(k));
        },
        q = (k) => {
          var S;
          const W = b.get(k.uid);
          if (W) {
            ((S = W.abort) == null || S.call(W), b.delete(k.uid));
            const G = I.get(k.uid);
            G && ((G.status = "error"), (G.percent = 0), E(G));
          }
        },
        z = (k) => {
          if (k) {
            const S = I.get(k.uid);
            S && H(S);
          } else for (const S of g.value) S.status === "init" && H(S);
        },
        U = async (k, S) => {
          const W = `${Date.now()}-${S}`,
            G = $o(k) ? URL.createObjectURL(k) : void 0,
            re = de({ uid: W, file: k, url: G, name: k.name, status: "init", percent: 0 });
          (I.set(W, re), (g.value = [...g.value, re]), E(re), e.autoUpload && H(re));
        },
        J = (k) => {
          if (e.limit > 0 && g.value.length + k.length > e.limit) {
            t("exceedLimit", g.value, k);
            return;
          }
          for (let S = 0; S < k.length; S++) {
            const W = k[S];
            we(e.onBeforeUpload)
              ? Promise.resolve(e.onBeforeUpload(W))
                  .then((G) => {
                    G && U(bn(G) ? W : G, S);
                  })
                  .catch((G) => {
                    console.error(G);
                  })
              : U(W, S);
          }
        },
        A = (k) => {
          ((g.value = g.value.filter((S) => S.uid !== k.uid)), E(k));
        },
        V = (k) => {
          we(e.onBeforeRemove)
            ? Promise.resolve(e.onBeforeRemove(k))
                .then((S) => {
                  S && A(k);
                })
                .catch((S) => {
                  console.error(S);
                })
            : A(k);
        },
        R = (k) => {
          if (e.imagePreview && k.url) {
            const S = Ce.value.indexOf(k.url);
            S > -1 && ((Le.value = S), (oe.value = !0));
          }
          t("preview", k);
        };
      Kt(
        Ye,
        de({
          disabled: T,
          listType: s,
          iconCls: `${p}-icon`,
          showRemoveButton: c,
          showRetryButton: a,
          showCancelButton: l,
          showPreviewButton: d,
          showLink: y,
          imageLoading: u,
          download: $,
          customIcon: r,
          slots: n,
          onUpload: H,
          onAbort: q,
          onRemove: V,
          onPreview: R,
        }),
      );
      const ee = m(() => {
          if (e.accept) return e.accept;
          if (e.listType === "picture" || e.listType === "picture-card") return "image/*";
        }),
        te = () => {
          const k = f(
            Io,
            {
              key: "arco-upload-button",
              disabled: T.value,
              draggable: e.draggable,
              listType: e.listType,
              uploadFiles: J,
              multiple: e.multiple,
              directory: e.directory,
              tip: e.tip,
              hide:
                !e.showUploadButton || (Z.value && !(zt(e.showUploadButton) && e.showUploadButton.showOnExceedLimit)),
              accept: ee.value,
              onButtonClick: e.onButtonClick,
            },
            { default: n["upload-button"] },
          );
          return e.tip && e.listType !== "picture-card" && !e.draggable
            ? f("span", null, [k, f("div", { class: `${p}-tip` }, [e.tip])])
            : k;
        },
        oe = ne(!1),
        Le = ne(0),
        $e = (k) => {
          Le.value = k;
        },
        Xe = (k) => {
          oe.value = k;
        },
        Ce = m(() => g.value.filter((k) => !!k.url).map((k) => k.url));
      return {
        prefixCls: p,
        render: () =>
          e.showFileList
            ? f("div", { class: [`${p}-wrapper`, `${p}-wrapper-type-${e.listType}`] }, [
                e.imagePreview &&
                  Ce.value.length > 0 &&
                  f(
                    Ti,
                    { srcList: Ce.value, visible: oe.value, current: Le.value, onChange: $e, onVisibleChange: Xe },
                    null,
                  ),
                e.listType !== "picture-card" && e.showUploadButton && te(),
                f(
                  Yo,
                  { fileList: g.value, listType: e.listType },
                  { "upload-button": te, "upload-item": n["upload-item"] },
                ),
              ])
            : e.showUploadButton && te(),
        innerSubmit: z,
        innerAbort: q,
        innerUpdateFile: K,
        innerUpload: J,
      };
    },
    methods: {
      submit(e) {
        return this.innerSubmit(e);
      },
      abort(e) {
        return this.innerAbort(e);
      },
      updateFile(e, t) {
        return this.innerUpdateFile(e, t);
      },
      upload(e) {
        return this.innerUpload(e);
      },
    },
    render() {
      return this.render();
    },
  });
const dr = Object.assign($t, {
  install: (e, t) => {
    Qt(e, t);
    const n = Zt(t);
    e.component(n + $t.name, $t);
  },
});
var on = { exports: {} };
(function (e) {
  var t = Object.prototype.hasOwnProperty,
    n = "~";
  function o() {}
  Object.create && ((o.prototype = Object.create(null)), new o().__proto__ || (n = !1));
  function i(l, c, d) {
    ((this.fn = l), (this.context = c), (this.once = d || !1));
  }
  function s(l, c, d, u, $) {
    if (typeof d != "function") throw new TypeError("The listener must be a function");
    var y = new i(d, u || l, $),
      p = n ? n + c : c;
    return (
      l._events[p]
        ? l._events[p].fn
          ? (l._events[p] = [l._events[p], y])
          : l._events[p].push(y)
        : ((l._events[p] = y), l._eventsCount++),
      l
    );
  }
  function r(l, c) {
    --l._eventsCount === 0 ? (l._events = new o()) : delete l._events[c];
  }
  function a() {
    ((this._events = new o()), (this._eventsCount = 0));
  }
  ((a.prototype.eventNames = function () {
    var c = [],
      d,
      u;
    if (this._eventsCount === 0) return c;
    for (u in (d = this._events)) t.call(d, u) && c.push(n ? u.slice(1) : u);
    return Object.getOwnPropertySymbols ? c.concat(Object.getOwnPropertySymbols(d)) : c;
  }),
    (a.prototype.listeners = function (c) {
      var d = n ? n + c : c,
        u = this._events[d];
      if (!u) return [];
      if (u.fn) return [u.fn];
      for (var $ = 0, y = u.length, p = new Array(y); $ < y; $++) p[$] = u[$].fn;
      return p;
    }),
    (a.prototype.listenerCount = function (c) {
      var d = n ? n + c : c,
        u = this._events[d];
      return u ? (u.fn ? 1 : u.length) : 0;
    }),
    (a.prototype.emit = function (c, d, u, $, y, p) {
      var T = n ? n + c : c;
      if (!this._events[T]) return !1;
      var v = this._events[T],
        g = arguments.length,
        I,
        b;
      if (v.fn) {
        switch ((v.once && this.removeListener(c, v.fn, void 0, !0), g)) {
          case 1:
            return (v.fn.call(v.context), !0);
          case 2:
            return (v.fn.call(v.context, d), !0);
          case 3:
            return (v.fn.call(v.context, d, u), !0);
          case 4:
            return (v.fn.call(v.context, d, u, $), !0);
          case 5:
            return (v.fn.call(v.context, d, u, $, y), !0);
          case 6:
            return (v.fn.call(v.context, d, u, $, y, p), !0);
        }
        for (b = 1, I = new Array(g - 1); b < g; b++) I[b - 1] = arguments[b];
        v.fn.apply(v.context, I);
      } else {
        var Z = v.length,
          F;
        for (b = 0; b < Z; b++)
          switch ((v[b].once && this.removeListener(c, v[b].fn, void 0, !0), g)) {
            case 1:
              v[b].fn.call(v[b].context);
              break;
            case 2:
              v[b].fn.call(v[b].context, d);
              break;
            case 3:
              v[b].fn.call(v[b].context, d, u);
              break;
            case 4:
              v[b].fn.call(v[b].context, d, u, $);
              break;
            default:
              if (!I) for (F = 1, I = new Array(g - 1); F < g; F++) I[F - 1] = arguments[F];
              v[b].fn.apply(v[b].context, I);
          }
      }
      return !0;
    }),
    (a.prototype.on = function (c, d, u) {
      return s(this, c, d, u, !1);
    }),
    (a.prototype.once = function (c, d, u) {
      return s(this, c, d, u, !0);
    }),
    (a.prototype.removeListener = function (c, d, u, $) {
      var y = n ? n + c : c;
      if (!this._events[y]) return this;
      if (!d) return (r(this, y), this);
      var p = this._events[y];
      if (p.fn) p.fn === d && (!$ || p.once) && (!u || p.context === u) && r(this, y);
      else {
        for (var T = 0, v = [], g = p.length; T < g; T++)
          (p[T].fn !== d || ($ && !p[T].once) || (u && p[T].context !== u)) && v.push(p[T]);
        v.length ? (this._events[y] = v.length === 1 ? v[0] : v) : r(this, y);
      }
      return this;
    }),
    (a.prototype.removeAllListeners = function (c) {
      var d;
      return (
        c ? ((d = n ? n + c : c), this._events[d] && r(this, d)) : ((this._events = new o()), (this._eventsCount = 0)),
        this
      );
    }),
    (a.prototype.off = a.prototype.removeListener),
    (a.prototype.addListener = a.prototype.on),
    (a.prefixed = n),
    (a.EventEmitter = a),
    (e.exports = a));
})(on);
var Xo = on.exports;
const Jo = Bn(Xo);
class rn extends Error {
  constructor(t) {
    (super(t), (this.name = "TimeoutError"));
  }
}
let er = class extends Error {
  constructor(t) {
    (super(), (this.name = "AbortError"), (this.message = t));
  }
};
const Ft = (e) => (globalThis.DOMException === void 0 ? new er(e) : new DOMException(e)),
  Rt = (e) => {
    const t = e.reason === void 0 ? Ft("This operation was aborted.") : e.reason;
    return t instanceof Error ? t : Ft(t);
  };
function tr(e, t, n, o) {
  let i;
  const s = new Promise((r, a) => {
    if (typeof t != "number" || Math.sign(t) !== 1)
      throw new TypeError(`Expected \`milliseconds\` to be a positive number, got \`${t}\``);
    if (t === Number.POSITIVE_INFINITY) {
      r(e);
      return;
    }
    if (((o = { customTimers: { setTimeout, clearTimeout }, ...o }), o.signal)) {
      const { signal: l } = o;
      (l.aborted && a(Rt(l)),
        l.addEventListener("abort", () => {
          a(Rt(l));
        }));
    }
    ((i = o.customTimers.setTimeout.call(
      void 0,
      () => {
        const l = `Promise timed out after ${t} milliseconds`,
          c = n instanceof Error ? n : new rn(l);
        (typeof e.cancel == "function" && e.cancel(), a(c));
      },
      t,
    )),
      (async () => {
        try {
          r(await e);
        } catch (l) {
          a(l);
        } finally {
          o.customTimers.clearTimeout.call(void 0, i);
        }
      })());
  });
  return (
    (s.clear = () => {
      (clearTimeout(i), (i = void 0));
    }),
    s
  );
}
function nr(e, t, n) {
  let o = 0,
    i = e.length;
  for (; i > 0; ) {
    const s = Math.trunc(i / 2);
    let r = o + s;
    n(e[r], t) <= 0 ? ((o = ++r), (i -= s + 1)) : (i = s);
  }
  return o;
}
var ye = function (e, t, n, o) {
    if (n === "a" && !o) throw new TypeError("Private accessor was defined without a getter");
    if (typeof t == "function" ? e !== t || !o : !t.has(e))
      throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return n === "m" ? o : n === "a" ? o.call(e) : o ? o.value : t.get(e);
  },
  me;
class ir {
  constructor() {
    me.set(this, []);
  }
  enqueue(t, n) {
    n = { priority: 0, ...n };
    const o = { priority: n.priority, run: t };
    if (this.size && ye(this, me, "f")[this.size - 1].priority >= n.priority) {
      ye(this, me, "f").push(o);
      return;
    }
    const i = nr(ye(this, me, "f"), o, (s, r) => r.priority - s.priority);
    ye(this, me, "f").splice(i, 0, o);
  }
  dequeue() {
    const t = ye(this, me, "f").shift();
    return t == null ? void 0 : t.run;
  }
  filter(t) {
    return ye(this, me, "f")
      .filter((n) => n.priority === t.priority)
      .map((n) => n.run);
  }
  get size() {
    return ye(this, me, "f").length;
  }
}
me = new WeakMap();
var D = function (e, t, n, o, i) {
    if (o === "m") throw new TypeError("Private method is not writable");
    if (o === "a" && !i) throw new TypeError("Private accessor was defined without a setter");
    if (typeof t == "function" ? e !== t || !i : !t.has(e))
      throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (o === "a" ? i.call(e, n) : i ? (i.value = n) : t.set(e, n), n);
  },
  h = function (e, t, n, o) {
    if (n === "a" && !o) throw new TypeError("Private accessor was defined without a getter");
    if (typeof t == "function" ? e !== t || !o : !t.has(e))
      throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return n === "m" ? o : n === "a" ? o.call(e) : o ? o.value : t.get(e);
  },
  x,
  Be,
  je,
  he,
  Ve,
  Te,
  Re,
  ce,
  _e,
  se,
  Ue,
  ae,
  Ne,
  pe,
  De,
  Ut,
  Dt,
  ln,
  qt,
  xt,
  qe,
  Ct,
  St,
  Qe,
  sn,
  xe;
class an extends Error {}
class vr extends Jo {
  constructor(t) {
    var n, o, i, s;
    if (
      (super(),
      x.add(this),
      Be.set(this, void 0),
      je.set(this, void 0),
      he.set(this, 0),
      Ve.set(this, void 0),
      Te.set(this, void 0),
      Re.set(this, 0),
      ce.set(this, void 0),
      _e.set(this, void 0),
      se.set(this, void 0),
      Ue.set(this, void 0),
      ae.set(this, 0),
      Ne.set(this, void 0),
      pe.set(this, void 0),
      De.set(this, void 0),
      Object.defineProperty(this, "timeout", { enumerable: !0, configurable: !0, writable: !0, value: void 0 }),
      (t = {
        carryoverConcurrencyCount: !1,
        intervalCap: Number.POSITIVE_INFINITY,
        interval: 0,
        concurrency: Number.POSITIVE_INFINITY,
        autoStart: !0,
        queueClass: ir,
        ...t,
      }),
      !(typeof t.intervalCap == "number" && t.intervalCap >= 1))
    )
      throw new TypeError(
        `Expected \`intervalCap\` to be a number from 1 and up, got \`${(o = (n = t.intervalCap) === null || n === void 0 ? void 0 : n.toString()) !== null && o !== void 0 ? o : ""}\` (${typeof t.intervalCap})`,
      );
    if (t.interval === void 0 || !(Number.isFinite(t.interval) && t.interval >= 0))
      throw new TypeError(
        `Expected \`interval\` to be a finite number >= 0, got \`${(s = (i = t.interval) === null || i === void 0 ? void 0 : i.toString()) !== null && s !== void 0 ? s : ""}\` (${typeof t.interval})`,
      );
    (D(this, Be, t.carryoverConcurrencyCount, "f"),
      D(this, je, t.intervalCap === Number.POSITIVE_INFINITY || t.interval === 0, "f"),
      D(this, Ve, t.intervalCap, "f"),
      D(this, Te, t.interval, "f"),
      D(this, se, new t.queueClass(), "f"),
      D(this, Ue, t.queueClass, "f"),
      (this.concurrency = t.concurrency),
      (this.timeout = t.timeout),
      D(this, De, t.throwOnTimeout === !0, "f"),
      D(this, pe, t.autoStart === !1, "f"));
  }
  get concurrency() {
    return h(this, Ne, "f");
  }
  set concurrency(t) {
    if (!(typeof t == "number" && t >= 1))
      throw new TypeError(`Expected \`concurrency\` to be a number from 1 and up, got \`${t}\` (${typeof t})`);
    (D(this, Ne, t, "f"), h(this, x, "m", Qe).call(this));
  }
  async add(t, n = {}) {
    return (
      (n = { timeout: this.timeout, throwOnTimeout: h(this, De, "f"), ...n }),
      new Promise((o, i) => {
        (h(this, se, "f").enqueue(async () => {
          var s, r, a;
          (D(this, ae, ((r = h(this, ae, "f")), r++, r), "f"), D(this, he, ((a = h(this, he, "f")), a++, a), "f"));
          try {
            if (!((s = n.signal) === null || s === void 0) && s.aborted) throw new an("The task was aborted.");
            let l = t({ signal: n.signal });
            (n.timeout && (l = tr(Promise.resolve(l), n.timeout)),
              n.signal && (l = Promise.race([l, h(this, x, "m", sn).call(this, n.signal)])));
            const c = await l;
            (o(c), this.emit("completed", c));
          } catch (l) {
            if (l instanceof rn && !n.throwOnTimeout) {
              o();
              return;
            }
            (i(l), this.emit("error", l));
          } finally {
            h(this, x, "m", ln).call(this);
          }
        }, n),
          this.emit("add"),
          h(this, x, "m", qe).call(this));
      })
    );
  }
  async addAll(t, n) {
    return Promise.all(t.map(async (o) => this.add(o, n)));
  }
  start() {
    return h(this, pe, "f") ? (D(this, pe, !1, "f"), h(this, x, "m", Qe).call(this), this) : this;
  }
  pause() {
    D(this, pe, !0, "f");
  }
  clear() {
    D(this, se, new (h(this, Ue, "f"))(), "f");
  }
  async onEmpty() {
    h(this, se, "f").size !== 0 && (await h(this, x, "m", xe).call(this, "empty"));
  }
  async onSizeLessThan(t) {
    h(this, se, "f").size < t || (await h(this, x, "m", xe).call(this, "next", () => h(this, se, "f").size < t));
  }
  async onIdle() {
    (h(this, ae, "f") === 0 && h(this, se, "f").size === 0) || (await h(this, x, "m", xe).call(this, "idle"));
  }
  get size() {
    return h(this, se, "f").size;
  }
  sizeBy(t) {
    return h(this, se, "f").filter(t).length;
  }
  get pending() {
    return h(this, ae, "f");
  }
  get isPaused() {
    return h(this, pe, "f");
  }
}
((Be = new WeakMap()),
  (je = new WeakMap()),
  (he = new WeakMap()),
  (Ve = new WeakMap()),
  (Te = new WeakMap()),
  (Re = new WeakMap()),
  (ce = new WeakMap()),
  (_e = new WeakMap()),
  (se = new WeakMap()),
  (Ue = new WeakMap()),
  (ae = new WeakMap()),
  (Ne = new WeakMap()),
  (pe = new WeakMap()),
  (De = new WeakMap()),
  (x = new WeakSet()),
  (Ut = function () {
    return h(this, je, "f") || h(this, he, "f") < h(this, Ve, "f");
  }),
  (Dt = function () {
    return h(this, ae, "f") < h(this, Ne, "f");
  }),
  (ln = function () {
    var t;
    (D(this, ae, ((t = h(this, ae, "f")), t--, t), "f"), h(this, x, "m", qe).call(this), this.emit("next"));
  }),
  (qt = function () {
    (h(this, x, "m", St).call(this), h(this, x, "m", Ct).call(this), D(this, _e, void 0, "f"));
  }),
  (xt = function () {
    const t = Date.now();
    if (h(this, ce, "f") === void 0) {
      const n = h(this, Re, "f") - t;
      if (n < 0) D(this, he, h(this, Be, "f") ? h(this, ae, "f") : 0, "f");
      else
        return (
          h(this, _e, "f") === void 0 &&
            D(
              this,
              _e,
              setTimeout(() => {
                h(this, x, "m", qt).call(this);
              }, n),
              "f",
            ),
          !0
        );
    }
    return !1;
  }),
  (qe = function () {
    if (h(this, se, "f").size === 0)
      return (
        h(this, ce, "f") && clearInterval(h(this, ce, "f")),
        D(this, ce, void 0, "f"),
        this.emit("empty"),
        h(this, ae, "f") === 0 && this.emit("idle"),
        !1
      );
    if (!h(this, pe, "f")) {
      const t = !h(this, x, "a", xt);
      if (h(this, x, "a", Ut) && h(this, x, "a", Dt)) {
        const n = h(this, se, "f").dequeue();
        return n ? (this.emit("active"), n(), t && h(this, x, "m", Ct).call(this), !0) : !1;
      }
    }
    return !1;
  }),
  (Ct = function () {
    h(this, je, "f") ||
      h(this, ce, "f") !== void 0 ||
      (D(
        this,
        ce,
        setInterval(
          () => {
            h(this, x, "m", St).call(this);
          },
          h(this, Te, "f"),
        ),
        "f",
      ),
      D(this, Re, Date.now() + h(this, Te, "f"), "f"));
  }),
  (St = function () {
    (h(this, he, "f") === 0 &&
      h(this, ae, "f") === 0 &&
      h(this, ce, "f") &&
      (clearInterval(h(this, ce, "f")), D(this, ce, void 0, "f")),
      D(this, he, h(this, Be, "f") ? h(this, ae, "f") : 0, "f"),
      h(this, x, "m", Qe).call(this));
  }),
  (Qe = function () {
    for (; h(this, x, "m", qe).call(this); );
  }),
  (sn = async function (t) {
    return new Promise((n, o) => {
      t.addEventListener(
        "abort",
        () => {
          o(new an("The task was aborted."));
        },
        { once: !0 },
      );
    });
  }),
  (xe = async function (t, n) {
    return new Promise((o) => {
      const i = () => {
        (n && !n()) || (this.off(t, i), o());
      };
      this.on(t, i);
    });
  }));
export { vr as P, dr as U };
