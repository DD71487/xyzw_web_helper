var x = Object.defineProperty;
var L = (o, n, i) => (n in o ? x(o, n, { enumerable: !0, configurable: !0, writable: !0, value: i }) : (o[n] = i));
var a = (o, n, i) => L(o, typeof n != "symbol" ? n + "" : n, i);
const H = [
    { id: "20_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "22_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "23_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "23_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_13", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "25_13", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "27_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "30_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "30_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "33_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "34_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "34_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "35_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "37_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "37_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "38_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "36_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "35_13", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "36_12", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "37_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "36_10", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "35_9", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "34_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "34_12", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "33_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "33_9", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_11", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_9", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "30_8", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_8", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_10", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_10", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_9", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_9", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "23_9", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_9", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_8", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_6", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_4", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_3", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_3", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_4", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "27_23", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "18_6", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "22_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "18_12", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_13", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_13", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_7", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "22_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "25_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "25_21", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_23", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_24", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_25", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_26", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "27_25", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "30_26", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_26", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_28", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_29", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_28", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_28", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_28", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "27_29", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "27_30", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "25_30", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_30", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "25_28", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "25_27", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_28", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_26", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "25_25", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "22_28", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "23_28", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "23_27", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_29", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_30", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_29", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_30", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_27", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_27", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_25", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_24", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "18_23", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "22_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_21", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "17_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "17_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "18_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "18_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "15_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_21", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "13_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "10_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "10_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "5_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "10_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_13", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_10", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_9", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_8", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "13_8", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_10", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "13_10", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "10_8", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_5", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "15_13", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "15_12", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_24", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_25", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "10_26", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_25", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_21", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_23", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_23", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_24", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_25", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_25", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "17_24", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_25", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_23", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_24", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "33_23", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_21", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "33_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "33_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "34_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_16", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "30_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_21", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "30_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_23", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_13", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_12", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_10", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_8", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "10_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_5", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_6", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "13_4", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "13_3", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "15_3", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_4", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "15_5", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "15_6", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_6", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "17_5", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "17_6", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_8", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "15_8", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_12", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_11", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "2_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "3_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "3_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "3_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "4_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "4_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "4_24", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "5_20", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "5_24", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "6_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "6_18", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "6_17", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "6_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "6_23", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "7_10", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "7_14", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "7_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "7_19", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "7_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "7_22", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "7_24", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_5", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_6", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_7", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_7", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "10_5", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "13_5", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_5", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_21", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_7", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_7", type: 3, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_9", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_12", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_14", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_15", type: 9, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "7_16", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "6_19", type: 3, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "4_17", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "3_19", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "5_21", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "6_24", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "8_23", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_25", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_12", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_14", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_16", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "11_24", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_10", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "7_4", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "6_10", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "5_14", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "1_18", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "3_23", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "13_23", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "12_19", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_3", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_12", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_5", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_28", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_31", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "33_29", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "34_23", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "35_19", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "39_16", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "37_10", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "27_10", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_15", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_22", type: 4, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_9", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_14", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "14_20", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "15_16", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "15_25", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "16_18", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "17_14", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "17_20", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "18_24", type: 5, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_5", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_3", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_8", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "22_10", type: 5, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_11", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "18_13", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_13", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_17", type: 6, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_18", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "9_20", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_23", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "22_21", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "19_20", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_26", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "20_31", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "21_28", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_27", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_29", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_25", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "28_24", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_26", type: 3, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_24", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_27", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "30_29", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "27_28", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_22", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_19", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "32_20", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "33_17", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "34_15", type: 3, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_13", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_15", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_17", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_14", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "23_13", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "24_16", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "26_20", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "25_17", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "23_19", type: 2, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "36_17", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "36_15", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "35_12", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "34_10", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "31_8", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "29_9", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
    { id: "25_8", type: 1, belongsLegionId: -1, hP: 0, maxHP: 0, point: 0 },
  ],
  p = class p {
    constructor() {
      a(this, "nodes", {});
      a(this, "evenQDirs", [
        { q: -1, r: 0 },
        { q: -1, r: -1 },
        { q: 0, r: 1 },
        { q: 0, r: -1 },
        { q: 1, r: 0 },
        { q: 1, r: -1 },
      ]);
      a(this, "oddQDirs", [
        { q: -1, r: 0 },
        { q: -1, r: 1 },
        { q: 0, r: 1 },
        { q: 0, r: -1 },
        { q: 1, r: 0 },
        { q: 1, r: 1 },
      ]);
      a(this, "getAllNodes", function () {
        return Object.values(this.nodes);
      });
      if (p.instance) throw new Error("请使用HexGraph.getInstance()获取单例");
      (this.loadStaticNodes(), (p.instance = this));
    }
    static getInstance() {
      return p.instance ? p.instance : new p();
    }
    loadStaticNodes() {
      H.forEach((n) => {
        this.addNode(n);
      });
    }
    removeAllNode() {
      ((this.nodes = {}), this.loadStaticNodes());
    }
    addNode(n) {
      var d;
      const i = n.id;
      this.nodes[i] ||
        ((this.nodes[i] = {
          id: n.id,
          type: n.type,
          belongsLegionId: n.belongsLegionId,
          hP: n.hP,
          maxHP: n.maxHP,
          point: n.point,
          colorBg: ((d = n == null ? void 0 : n.belongsLegionInfo) == null ? void 0 : d.color) || r(n.type),
          typeName: c(n.type),
          position: { x: (n.id + "").split("_")[0], y: (n.id + "").split("_")[1] },
          neighbors: [],
        }),
        this.buildAdjacency(this.nodes[i]));
    }
    addNodeList(n) {
      n.forEach((i) => {
        this.addNode(i);
      });
    }
    buildAdjacency(n) {
      const { x: i, y: d } = n.position;
      (i % 2 === 0 ? this.evenQDirs : this.oddQDirs).forEach(({ q: e, r: s }) => {
        const g = `${parseInt(i) + e}_${parseInt(d) + s}`,
          t = this.nodes[g];
        t && (n.neighbors.includes(t) || n.neighbors.push(t), t.neighbors.includes(n) || t.neighbors.push(n));
      });
    }
    getNodeByCoords(n) {
      return this.nodes[n];
    }
    findShortestPath(n, i, d) {
      if (!n.includes("_") || !n.includes("_") || n === i) return !1;
      let P = this.getNodeByCoords(n),
        e = this.getNodeByCoords(i);
      if (!P || !e) return !1;
      const s = [P],
        g = new Map();
      g.set(P.id, null);
      let t = !1;
      for (; s.length > 0 && !t; ) {
        const h = s.shift();
        if (!(h.type != 9 && h.belongsLegionId != d)) {
          for (const b of h.neighbors)
            if (!g.has(b.id) && (g.set(b.id, h), s.push(b), b.id === e.id)) {
              t = !0;
              break;
            }
        }
      }
      if (!t) return !1;
      const I = [];
      let l = e;
      for (; l; ) (I.push(l), (l = g.get(l.id)));
      return (I.reverse(), I);
    }
  };
a(p, "instance");
let y = p;
const _ = [
    "#ff000033",
    "#00ff0033",
    "#0000ff33",
    "#FFFF0033",
    "#FF00FF33",
    "#00ffff33",
    "#66666633",
    "#cdcdcd",
    "#f77aff",
    "#c9a0ff",
    "#a0c6ff",
    "#a0fffb",
    "#a0ffb0",
    "#cdffa0",
    "#fffca0",
    "#ffdda0",
    "#ffbfa0",
    "#f16f5a",
    "#fb9494",
    "#dcdd9a",
  ],
  f = (o) => {
    const n = o;
    if (!n || !n.battlefield) return !1;
    let i = n.battlefield.buildingData,
      d = Object.fromEntries(
        Object.values(n.battlefield.legions).map((e, s) => [
          e.id,
          {
            blessingCount: e.blessingIdList.length,
            blessingScore: e.blessingScore,
            buildings: e.buildings,
            redCount: e.custom["red:quench"] || 0,
            killCnt: e.killCnt,
            level: e.level,
            name: e.name,
            color: _[e.color],
            id: e.id,
            memberCount: Object.keys(e.membersV2).length,
            point: e.point,
            position: e.position,
            strongholdId: e.strongholdId,
            score:
              Object.keys((e == null ? void 0 : e.buildings) || {})
                .map((g) => {
                  var t;
                  return ((t = i[g]) == null ? void 0 : t.point) ?? 0;
                })
                .reduce((g, t) => g + t, 0) + e.blessingScore,
            power: e.power,
            OnlineCount: 0,
            participantsCount: 0,
            danCount: 0,
            reviveCount: 0,
            serverId: e.serverId,
          },
        ]),
      ),
      P = Object.values(n.battlefield.roles).map(
        (e) => (
          d[e.legionID + ""].participantsCount++,
          e.isOnline && d[e.legionID + ""].OnlineCount++,
          (d[e.legionID].reviveCount += e.revive),
          (d[e.legionID].danCount += e.d - 6 > 0 ? e.d - 6 : 0),
          {
            name: e.name,
            legionName: d[e.legionID].name,
            legionId: e.legionID,
            lastState: m(e.state),
            digGround: e.aB,
            kill: e.killCnt,
            revive: e.revive,
            die: e.d,
            dan: e.d - 6 > 0 ? e.d - 6 : 0,
            score: e.point,
          }
        ),
      );
    return { buildingData: i, memberInfo: P, legionInfo: d };
  },
  m = (o) => {
    switch (o) {
      case "idle":
        return "空闲";
      case "march":
        return "行进";
      case "watching":
        return "观看";
      case "over":
        return "死亡";
      default:
        return "未知";
    }
  },
  r = (o) => {
    switch (o) {
      case 1:
        return "orange";
      case 2:
        return "yellow";
      case 3:
        return "gray";
      case 4:
        return "red";
      case 5:
        return "green";
      case 6:
        return "#1bd7d7";
      case 9:
        return "#2452f7";
      default:
        return "未知";
    }
  },
  c = (o) => {
    switch (o) {
      case 1:
        return "30分据点";
      case 2:
        return "50分据点";
      case 3:
        return "80分据点";
      case 4:
        return "大本营";
      case 5:
        return "100分据点";
      case 6:
        return "核心";
      case 9:
        return "道路";
      default:
        return "未知";
    }
  },
  v = (o) =>
    o ? (o >= 1e8 ? (o / 1e8).toFixed(2) + "亿" : o >= 1e4 ? (o / 1e4).toFixed(2) + "万" : o.toString()) : "0";
export { y as H, f as e, v as f, H as r, r as t };
