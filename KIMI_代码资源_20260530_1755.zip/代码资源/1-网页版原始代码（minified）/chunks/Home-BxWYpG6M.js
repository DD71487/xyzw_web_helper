import { _ as S } from "./xiaoyugan-Dwisk7G8.js";
import {
  r as _,
  m as f,
  o as B,
  c as d,
  a as s,
  b as o,
  w as n,
  d as k,
  e as w,
  u as i,
  F as g,
  f as R,
  g as x,
  h as l,
  i as u,
  t as p,
  j as A,
} from "./index-UoU16364.js";
import { u as V } from "./auth-BYvggjsB.js";
import { _ as F } from "./_plugin-vue_export-helper-DlAUqK2U.js";
import { P as $ } from "./PersonCircle-CkW3zhXQ.js";
import { C as h } from "./Cube-CwoBO7fL.js";
import { R as y } from "./Ribbon-CequGJWg.js";
import { S as z } from "./Settings-BMY43FOw.js";
import { M as N } from "./Menu-BeijkhQo.js";
import "./localTokenManager-BQJEcmfy.js";
const T = { class: "home-page" },
  D = { class: "navbar glass" },
  H = { class: "container" },
  I = { class: "nav-content" },
  K = { class: "mobile-menu-button" },
  P = { class: "nav-actions" },
  j = { class: "drawer-menu" },
  E = { class: "drawer-actions" },
  L = { class: "main-content" },
  O = { class: "hero-section" },
  U = { class: "container" },
  q = { class: "hero-content" },
  G = { class: "hero-text" },
  J = { class: "hero-actions" },
  Q = { class: "hero-visual" },
  tt = { class: "feature-cards" },
  st = { class: "card-icon" },
  et = { class: "card-content" },
  ot = { class: "container" },
  nt = { class: "features-grid" },
  it = { class: "feature-icon" },
  lt = { class: "feature-title" },
  rt = { class: "feature-description" },
  at = { class: "stats-section" },
  dt = { class: "container" },
  ut = { class: "stats-grid" },
  ft = { class: "stat-number" },
  pt = { class: "stat-label" },
  mt = { class: "footer" },
  vt = { class: "container" },
  ct = { class: "footer-content" },
  _t = { class: "footer-links" },
  bt = {
    __name: "Home",
    setup(kt) {
      const m = R(),
        b = V(),
        C = _(null),
        r = _(!1),
        M = _([
          { id: 1, icon: f($), title: "角色管理", description: "统一管理游戏角色" },
          { id: 2, icon: f(h), title: "任务系统", description: "自动化日常任务" },
          { id: 3, icon: f(y), title: "数据统计", description: "全面的数据分析" },
        ]),
        W = _([
          {
            id: 1,
            icon: f($),
            title: "角色管理",
            description: "轻松管理多个游戏角色，统一查看角色信息、等级进度和装备状态",
          },
          {
            id: 2,
            icon: f(h),
            title: "任务自动化",
            description: "智能日常任务系统，自动完成重复性任务，节省您的宝贵时间",
          },
          { id: 3, icon: f(y), title: "数据分析", description: "详细的数据统计和分析报告，帮助您更好地了解游戏进度" },
          { id: 4, icon: f(z), title: "个性化设置", description: "灵活的配置选项，根据您的需求定制最适合的管理方案" },
        ]),
        X = _([
          { id: 1, number: "1000+", label: "活跃用户" },
          { id: 2, number: "50K+", label: "管理角色" },
          { id: 3, number: "100K+", label: "完成任务" },
          { id: 4, number: "99.9%", label: "系统稳定性" },
        ]),
        Y = () => {
          C.value && C.value.scrollIntoView({ behavior: "smooth" });
        };
      return (
        B(() => {
          b.initAuth();
        }),
        (gt, t) => {
          const v = k("n-icon"),
            a = k("n-button"),
            c = k("router-link"),
            Z = k("n-drawer");
          return (
            l(),
            d("div", T, [
              s("nav", D, [
                s("div", H, [
                  s("div", I, [
                    t[16] ||
                      (t[16] = s(
                        "div",
                        { class: "nav-brand" },
                        [
                          s("img", { src: S, alt: "XYZW", class: "brand-logo" }),
                          s("span", { class: "brand-text" }, "XYZW 游戏管理系统"),
                        ],
                        -1,
                      )),
                    s("div", K, [
                      o(
                        a,
                        { text: "", onClick: t[0] || (t[0] = (e) => (r.value = !0)) },
                        { default: n(() => [o(v, null, { default: n(() => [o(i(N))]), _: 1 })]), _: 1 },
                      ),
                    ]),
                    s("div", P, [
                      i(b).isAuthenticated
                        ? (l(),
                          w(
                            a,
                            {
                              key: 1,
                              type: "primary",
                              size: "large",
                              onClick: t[3] || (t[3] = (e) => i(m).push("/admin/dashboard")),
                            },
                            { default: n(() => [...(t[15] || (t[15] = [u(" 进入控制台 ", -1)]))]), _: 1 },
                          ))
                        : (l(),
                          d(
                            g,
                            { key: 0 },
                            [
                              o(
                                a,
                                {
                                  text: "",
                                  type: "primary",
                                  size: "large",
                                  onClick: t[1] || (t[1] = (e) => i(m).push("/login")),
                                },
                                { default: n(() => [...(t[13] || (t[13] = [u(" 登录 ", -1)]))]), _: 1 },
                              ),
                              o(
                                a,
                                {
                                  type: "primary",
                                  size: "large",
                                  onClick: t[2] || (t[2] = (e) => i(m).push("/register")),
                                },
                                { default: n(() => [...(t[14] || (t[14] = [u(" 注册 ", -1)]))]), _: 1 },
                              ),
                            ],
                            64,
                          )),
                    ]),
                  ]),
                ]),
              ]),
              o(
                Z,
                {
                  show: r.value,
                  "onUpdate:show": t[11] || (t[11] = (e) => (r.value = e)),
                  placement: "left",
                  style: { width: "260px" },
                },
                {
                  default: n(() => [
                    s("div", j, [
                      o(
                        c,
                        { to: "/", class: "drawer-item", onClick: t[4] || (t[4] = (e) => (r.value = !1)) },
                        {
                          default: n(() => [
                            o(v, null, { default: n(() => [o(i(y))]), _: 1 }),
                            t[17] || (t[17] = s("span", null, "首页", -1)),
                          ]),
                          _: 1,
                        },
                      ),
                      o(
                        c,
                        {
                          to: "/admin/dashboard",
                          class: "drawer-item",
                          onClick: t[5] || (t[5] = (e) => (r.value = !1)),
                        },
                        {
                          default: n(() => [
                            o(v, null, { default: n(() => [o(i(z))]), _: 1 }),
                            t[18] || (t[18] = s("span", null, "控制台", -1)),
                          ]),
                          _: 1,
                        },
                      ),
                      o(
                        c,
                        {
                          to: "/admin/game-features",
                          class: "drawer-item",
                          onClick: t[6] || (t[6] = (e) => (r.value = !1)),
                        },
                        {
                          default: n(() => [
                            o(v, null, { default: n(() => [o(i(h))]), _: 1 }),
                            t[19] || (t[19] = s("span", null, "游戏功能", -1)),
                          ]),
                          _: 1,
                        },
                      ),
                      o(
                        c,
                        { to: "/tokens", class: "drawer-item", onClick: t[7] || (t[7] = (e) => (r.value = !1)) },
                        {
                          default: n(() => [
                            o(v, null, { default: n(() => [o(i($))]), _: 1 }),
                            t[20] || (t[20] = s("span", null, "Token管理", -1)),
                          ]),
                          _: 1,
                        },
                      ),
                      o(
                        c,
                        { to: "/changelog", class: "drawer-item", onClick: t[8] || (t[8] = (e) => (r.value = !1)) },
                        {
                          default: n(() => [
                            o(v, null, { default: n(() => [o(i(y))]), _: 1 }),
                            t[21] || (t[21] = s("span", null, "更新日志", -1)),
                          ]),
                          _: 1,
                        },
                      ),
                      s("div", E, [
                        o(
                          a,
                          {
                            type: "primary",
                            block: "",
                            onClick:
                              t[9] ||
                              (t[9] = (e) => {
                                (i(m).push("/login"), (r.value = !1));
                              }),
                          },
                          { default: n(() => [...(t[22] || (t[22] = [u("登录", -1)]))]), _: 1 },
                        ),
                        o(
                          a,
                          {
                            type: "primary",
                            block: "",
                            onClick:
                              t[10] ||
                              (t[10] = (e) => {
                                (i(m).push("/register"), (r.value = !1));
                              }),
                          },
                          { default: n(() => [...(t[23] || (t[23] = [u("注册", -1)]))]), _: 1 },
                        ),
                      ]),
                    ]),
                  ]),
                  _: 1,
                },
                8,
                ["show"],
              ),
              s("main", L, [
                s("section", O, [
                  s("div", U, [
                    s("div", q, [
                      s("div", G, [
                        t[25] || (t[25] = s("h1", { class: "hero-title" }, "专业的游戏管理平台", -1)),
                        t[26] || (t[26] = s("p", { class: "hero-subtitle" }, "让游戏变得更简单，让管理变得更高效", -1)),
                        s("div", J, [
                          o(
                            a,
                            {
                              type: "primary",
                              size: "large",
                              class: "hero-button",
                              onClick:
                                t[12] ||
                                (t[12] = (e) => i(m).push(i(b).isAuthenticated ? "/admin/dashboard" : "/register")),
                            },
                            { default: n(() => [u(p(i(b).isAuthenticated ? "进入控制台" : "立即开始"), 1)]), _: 1 },
                          ),
                          o(
                            a,
                            { text: "", type: "primary", size: "large", class: "hero-button", onClick: Y },
                            { default: n(() => [...(t[24] || (t[24] = [u(" 了解更多 ", -1)]))]), _: 1 },
                          ),
                        ]),
                      ]),
                      s("div", Q, [
                        s("div", tt, [
                          (l(!0),
                          d(
                            g,
                            null,
                            x(
                              M.value,
                              (e) => (
                                l(),
                                d("div", { key: e.id, class: "feature-card" }, [
                                  s("div", st, [(l(), w(A(e.icon)))]),
                                  s("div", et, [s("h3", null, p(e.title), 1), s("p", null, p(e.description), 1)]),
                                ])
                              ),
                            ),
                            128,
                          )),
                        ]),
                      ]),
                    ]),
                  ]),
                ]),
                s(
                  "section",
                  { ref_key: "featuresSection", ref: C, class: "features-section" },
                  [
                    s("div", ot, [
                      t[27] ||
                        (t[27] = s(
                          "div",
                          { class: "section-header" },
                          [
                            s("h2", { class: "section-title" }, "核心功能"),
                            s("p", { class: "section-subtitle" }, "为您提供全方位的游戏管理解决方案"),
                          ],
                          -1,
                        )),
                      s("div", nt, [
                        (l(!0),
                        d(
                          g,
                          null,
                          x(
                            W.value,
                            (e) => (
                              l(),
                              d("div", { key: e.id, class: "feature-item" }, [
                                s("div", it, [(l(), w(A(e.icon)))]),
                                s("h3", lt, p(e.title), 1),
                                s("p", rt, p(e.description), 1),
                              ])
                            ),
                          ),
                          128,
                        )),
                      ]),
                    ]),
                  ],
                  512,
                ),
                s("section", at, [
                  s("div", dt, [
                    s("div", ut, [
                      (l(!0),
                      d(
                        g,
                        null,
                        x(
                          X.value,
                          (e) => (
                            l(),
                            d("div", { key: e.id, class: "stat-item" }, [
                              s("div", ft, p(e.number), 1),
                              s("div", pt, p(e.label), 1),
                            ])
                          ),
                        ),
                        128,
                      )),
                    ]),
                  ]),
                ]),
              ]),
              s("footer", mt, [
                s("div", vt, [
                  s("div", ct, [
                    t[33] ||
                      (t[33] = s(
                        "div",
                        { class: "footer-brand" },
                        [
                          s("img", { src: S, alt: "XYZW", class: "footer-logo" }),
                          s("span", { class: "footer-text" }, "XYZW 游戏管理系统"),
                        ],
                        -1,
                      )),
                    s("div", _t, [
                      o(
                        c,
                        { to: "/changelog", class: "footer-link" },
                        { default: n(() => [...(t[28] || (t[28] = [u(" 更新日志 ", -1)]))]), _: 1 },
                      ),
                      t[29] || (t[29] = s("a", { href: "#", class: "footer-link" }, "关于我们", -1)),
                      t[30] || (t[30] = s("a", { href: "#", class: "footer-link" }, "隐私政策", -1)),
                      t[31] || (t[31] = s("a", { href: "#", class: "footer-link" }, "服务条款", -1)),
                      t[32] || (t[32] = s("a", { href: "#", class: "footer-link" }, "联系我们", -1)),
                    ]),
                  ]),
                  t[34] ||
                    (t[34] = s(
                      "div",
                      { class: "footer-bottom" },
                      [s("p", null, "© 2024 XYZW. All rights reserved.")],
                      -1,
                    )),
                ]),
              ]),
            ])
          );
        }
      );
    },
  },
  Wt = F(bt, [["__scopeId", "data-v-f4a62037"]]);
export { Wt as default };
