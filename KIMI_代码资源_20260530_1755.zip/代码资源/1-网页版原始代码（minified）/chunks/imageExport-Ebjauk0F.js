import "./index-UoU16364.js";
const M = { FREE: 3, PAID: 1 },
  _ = {
    DIAMOND: { id: 2005, name: "钻石宝箱" },
    WOODEN: { id: 2001, name: "木质宝箱" },
    BRONZE: { id: 1, name: "青铜宝箱" },
  },
  y = { START_HOUR: 6, END_HOUR: 22, MAX_FIGHTS: 3 },
  I = { WEEKLY: 4001, MONTHLY: 4002, PERMANENT: 4003 },
  G = 4,
  A = 3,
  O = 3,
  F = 3,
  b = 4,
  q = 10,
  X = [0, 1, 3, 4],
  D = new Map([
    ["400190", "没有可领取的签到奖励"],
    ["2300190", "今日已完成签到"],
    ["1000020", "该奖励今日已领取"],
    ["12000116", "今日免费奖励已领取"],
    ["1400010", "没有购买该月卡,不能领取每日奖励"],
    ["3300050", "购买数量超出限制"],
    ["2600040", "未知错误"],
    ["200750", "临时错误"],
    ["700020", "任务条件未满足，无法领取"],
    ["200020", "请求过于频繁，请稍后重试"],
    ["1300050", "黑市采购次数异常"],
    ["1500020", "能量不足"],
    ["3500020", "暂无可领取奖励"],
    ["200160", "模块未开启无法领取"],
    ["700010", "任务未达成无法领取"],
    ["4100040", "推关未达标，无法解锁领取"],
    ["1100010", "已购买过青铜宝箱"],
    ["400010", "数量不足"],
    ["2000150", "无对应罐子，无法领取"],
    ["400030", "已领取，无需重复操作"],
    ["2300070", "未加入俱乐部"],
    ["2300250", "俱乐部BOSS次数已用完"],
    ["3300060", "灯神扫荡条件不满足"],
  ]),
  P = {
    dreamWorld: { 200160: "该账号未达到关卡无法解锁梦境" },
    arena: { 200020: "推关关卡未达标无法解锁竞技场" },
    blackMarket: { 1300040: "未解锁关卡，无法使用采购功能" },
    formation: { 200020: "该账号阵容未解锁" },
    genie: { 200020: "该账号灯神扫荡条件未满足" },
    hangUp: { 200020: "加钟请求过于频繁，请稍后重试" },
  },
  S = {
    arenaFormation: 1,
    bossFormation: 1,
    bossTimes: 2,
    claimBottle: !0,
    payRecruit: !0,
    openBox: !0,
    arenaEnable: !0,
    claimHangUp: !0,
    claimEmail: !0,
    blackMarketPurchase: !0,
    blackMarketStandalonePurchase: !1,
  },
  p = (s) => new Promise((e) => setTimeout(e, s)),
  x = (s, e) => p(s + Math.random() * (e - s)),
  C = (s) => {
    const t = (typeof s == "string" ? s : (s == null ? void 0 : s.message) || "").match(/\d{6,7}/);
    return t ? t[0] : "";
  },
  $ = (s, e = "") => {
    var a;
    const t = C(s);
    return e && (a = P[e]) != null && a[t]
      ? P[e][t]
      : D.has(t)
        ? D.get(t)
        : (s == null ? void 0 : s.message) || "未知错误";
  },
  N = (s) => D.has(C(s)),
  U = (s) => {
    const e = (s == null ? void 0 : s.message) || "";
    return e.includes("连接") || e.includes("WebSocket");
  },
  v = (s) => {
    if (!s) return !0;
    const e = new Date().toDateString(),
      t = new Date(s * 1e3).toDateString();
    return e !== t;
  },
  Y = () => [9904, 9905, 9901, 9902, 9903, 9904, 9905][new Date().getDay()],
  j = () => X.includes(new Date().getDay()),
  f = (s, e, t = null) => e.split(".").reduce((a, r) => (a && a[r] !== void 0 ? a[r] : t), s),
  z = (s) => (s ? (Array.isArray(s) ? s : s.rankList || s.roleList || s.targets || s.targetList || s.list || []) : []),
  L = (s) => ({
    targetId: s.roleId || s.id || s.targetId || f(s, "info.roleId"),
    targetName: s.name || f(s, "info.name", "未知"),
    targetRank: s.rank || f(s, "info.rank", 0),
    targetPower: s.power || f(s, "info.power", 0),
  }),
  K = (s, e) => {
    const t = s.power || f(s, "info.power", 0),
      a = e.power || f(e, "info.power", 0);
    return t - a;
  },
  Z = (s, e = {}) => {
    if (!s) return null;
    const t = z(s);
    if (t.length === 0 && (s.roleId || s.id || s.targetId)) return L(s);
    if (t.length === 0) return null;
    const a = e.rank || 0;
    let r = t.filter((i) => {
      const o = i.rank || f(i, "info.rank", 0);
      return !(a > 0 && o < a);
    });
    r.length === 0 && (r = t);
    const n = [...r].sort(K);
    return L(n[0]);
  };
class ne {
  constructor(e, t = null, a = null) {
    ((this.tokenStore = e),
      (this.delaySettings = { commandDelay: 500, taskDelay: 500, ...t }),
      (this.batchSettings = a || {}),
      (this.callbacks = {}),
      (this.settings = {}),
      (this.tokenId = ""),
      (this.originalFormation = null));
  }
  log(e, t = "info") {
    var a, r;
    (r = (a = this.callbacks) == null ? void 0 : a.onLog) == null ||
      r.call(a, { time: new Date().toLocaleTimeString(), message: e, type: t });
  }
  success(e) {
    this.log(e, "success");
  }
  warn(e) {
    this.log(e, "warning");
  }
  error(e) {
    this.log(e, "error");
  }
  info(e) {
    this.log(e, "info");
  }
  loadSettings(e) {
    try {
      const t = localStorage.getItem(`daily-settings:${e}`);
      return t ? { ...S, ...JSON.parse(t) } : { ...S };
    } catch (t) {
      return (console.error("设置加载失败:", t), { ...S });
    }
  }
  getTimeout(e) {
    return e.includes("fight") || e.includes("tower") || e.includes("evo") || e.includes("arena")
      ? this.batchSettings.battleCommandTimeout || 15e3
      : this.batchSettings.defaultCommandTimeout || 5e3;
  }
  getRetryCount() {
    return this.batchSettings.defaultRetryCount !== void 0 ? this.batchSettings.defaultRetryCount : 2;
  }
  getRetryDelay() {
    return this.batchSettings.retryDelay || 1e3;
  }
  isConnected() {
    var e, t;
    return (
      ((t = (e = this.tokenStore.wsConnections) == null ? void 0 : e[this.tokenId]) == null ? void 0 : t.status) ===
      "connected"
    );
  }
  async ensureConnection(e = 0) {
    if (this.isConnected()) return !0;
    if (e >= 3)
      return (this.error("连接失败次数已达上限 (3次)"), this.tokenStore.closeWebSocketConnection(this.tokenId), !1);
    this.warn(`连接异常，尝试刷新Token (${e + 1}/3)`);
    try {
      if (await this.tokenStore.attemptTokenRefresh(this.tokenId, !0)) {
        if ((await p(2e3), this.isConnected())) return (this.success("连接已恢复"), !0);
        this.warn("Token刷新成功但连接未建立");
      } else this.error("Token刷新失败");
      return !1;
    } catch (a) {
      return (this.error(`刷新Token出错: ${a.message}`), !1);
    }
  }
  async sendCommand(e, t = {}, a = {}) {
    const { description: r = "", timeout: n, context: i = "", silentErrors: o = !1, retryCount: c = 0 } = a,
      m = n || this.getTimeout(e),
      d = 3;
    try {
      if (!(await this.ensureConnection(c))) throw new Error("连接异常");
      const l = await this.tokenStore.sendMessageWithPromise(this.tokenId, e, t, m);
      return (await p(this.delaySettings.commandDelay), r && this.success(`${r} - 成功`), l);
    } catch (l) {
      if (U(l) && c < d)
        return (
          this.warn(`[连接错误] ${r}，重试 (${c + 1}/${d})`),
          await p(1e3),
          this.sendCommand(e, t, { ...a, retryCount: c + 1 })
        );
      if (o && N(l)) {
        const u = $(l, i);
        return (this.info(u), { success: !0, silent: !0 });
      }
      if (r) {
        const u = $(l, i);
        N(l) || this.error(`${r} - 失败: ${u}`);
      }
      throw l;
    }
  }
  async sendCommandSafe(e, t = {}, a = {}) {
    return this.sendCommand(e, t, { ...a, silentErrors: !0 });
  }
  async getCurrentFormation() {
    try {
      const e = await this.sendCommand("presetteam_getinfo", {}, { description: "获取阵容信息" });
      return f(e, "presetTeamInfo.useTeamId");
    } catch {
      return null;
    }
  }
  async switchFormation(e) {
    try {
      return (
        await this.sendCommand(
          "presetteam_saveteam",
          { teamId: e },
          { description: `切换到阵容${e}`, context: "formation" },
        ),
        this.success(`已切换到阵容${e}`),
        !0
      );
    } catch (t) {
      return (this.warn(`切换阵容失败: ${$(t, "formation")}`), !1);
    }
  }
  async switchFormationIfNeeded(e, t = "") {
    const a = await this.getCurrentFormation();
    return a === e
      ? (this.info(`当前已是${t}${e}，无需切换`), !1)
      : (this.info(`切换阵容: ${a} → ${e}`), this.switchFormation(e));
  }
  async restoreFormation() {
    if (this.originalFormation)
      try {
        (await this.sendCommand(
          "presetteam_saveteam",
          { teamId: this.originalFormation },
          { description: "恢复原阵容", context: "formation", timeout: this.getTimeout("presetteam_saveteam") },
        ),
          this.success(`已恢复阵容${this.originalFormation}`));
      } catch (e) {
        C(e) === "200020"
          ? this.info(`阵容${this.originalFormation}已是当前阵容`)
          : this.error(`恢复阵容失败: ${e.message}`);
      }
  }
  async tryOpenBox(e, t) {
    try {
      const a = await this.tokenStore.sendMessageWithPromise(
        this.tokenId,
        "item_openbox",
        { itemId: e, number: 10 },
        3e3,
      );
      return (await p(this.delaySettings.commandDelay), this.success(`开启${t}10个 - 成功`), !0);
    } catch (a) {
      return ((a.message || "").includes("400010"), !1);
    }
  }
  buildBasicTasks(e, t, a) {
    const r = [],
      n = (o) => e[o] === -1,
      i = (o) => v(a[o]);
    if (
      (n(2) ||
        r.push(() =>
          this.sendCommand("system_mysharecallback", { isSkipShareCard: !0, type: 2 }, { description: "分享游戏" }),
        ),
      n(3) || r.push(() => this.sendCommand("friend_batch", {}, { description: "赠送好友金币" })),
      n(4) ||
        (r.push(() =>
          this.sendCommandSafe("hero_recruit", { recruitType: M.FREE, recruitNumber: 1 }, { description: "免费招募" }),
        ),
        this.settings.payRecruit &&
          r.push(() =>
            this.sendCommand("hero_recruit", { recruitType: M.PAID, recruitNumber: 1 }, { description: "付费招募" }),
          )),
      !n(6) && i("buy:gold"))
    )
      for (let o = 0; o < F; o++)
        r.push(() => this.sendCommand("system_buygold", { buyNum: 1 }, { description: `免费点金 ${o + 1}/${F}` }));
    return (
      !n(5) &&
        this.settings.claimHangUp &&
        r.push(async () => {
          try {
            const o = await this.getHangUpStatus({ checkAddTime: !0, thresholdSeconds: 3600, maxHangUpTime: 36e3 }),
              c = 21600;
            if (!(o.hasData && o.elapsedTime >= c)) {
              const d = o.elapsedTime || 0;
              (this.info(`挂机时间${this.formatTime(d)}，未达到${this.formatTime(c)}，跳过领取`),
                await this.sendCommand("role_getroleinfo", {}, { timeout: this.getTimeout("role_getroleinfo") }));
              return;
            }
            if (
              (this.info(`挂机时间${this.formatTime(o.elapsedTime)}，满足领取条件，开始领取...`),
              await this.sendCommand(
                "system_mysharecallback",
                {},
                { description: "初始化挂机奖励", timeout: this.getTimeout("system_mysharecallback") },
              ),
              await this.sendCommand(
                "system_claimhangupreward",
                {},
                { description: "领取挂机奖励", timeout: this.getTimeout("system_claimhangupreward") },
              ),
              o.needAddTime)
            ) {
              this.info(`${o.addTimeMessage}，开始加钟...`);
              for (let d = 0; d < b; d++)
                await this.sendCommandSafe(
                  "system_mysharecallback",
                  { isSkipShareCard: !0, type: 2 },
                  {
                    description: `挂机加钟 ${d + 1}/${b}`,
                    timeout: this.getTimeout("system_mysharecallback"),
                    context: "hangUp",
                  },
                );
            } else this.info(`${o.addTimeMessage}，跳过加钟`);
          } catch (o) {
            (this.warn(`获取挂机状态失败，执行默认领取加钟流程: ${o.message}`),
              await this.sendCommand(
                "system_mysharecallback",
                {},
                { description: "初始化挂机奖励", timeout: this.getTimeout("system_mysharecallback") },
              ),
              await this.sendCommand(
                "system_claimhangupreward",
                {},
                { description: "领取挂机奖励", timeout: this.getTimeout("system_claimhangupreward") },
              ));
            for (let c = 0; c < b; c++)
              await this.sendCommandSafe(
                "system_mysharecallback",
                { isSkipShareCard: !0, type: 2 },
                {
                  description: `挂机加钟 ${c + 1}/${b}`,
                  timeout: this.getTimeout("system_mysharecallback"),
                  context: "hangUp",
                },
              );
          }
        }),
      !n(7) &&
        this.settings.openBox &&
        r.push(async () => {
          (await this.tryOpenBox(_.DIAMOND.id, _.DIAMOND.name)) || (await this.tryOpenBox(_.WOODEN.id, _.WOODEN.name));
        }),
      r
    );
  }
  buildSaltBottleTasks(e) {
    const t = [],
      a = (r) => e[r] === -1;
    return (
      t.push(
        () => this.sendCommand("bottlehelper_stop", {}, { description: "停止盐罐计时" }),
        () => this.sendCommand("bottlehelper_start", {}, { description: "开始盐罐计时" }),
      ),
      !a(14) &&
        this.settings.claimBottle &&
        t.push(() => this.sendCommandSafe("bottlehelper_claim", {}, { description: "领取盐罐奖励" })),
      t
    );
  }
  buildArenaTask() {
    return this.settings.arenaEnable
      ? [
          async () => {
            const e = new Date().getHours();
            if (e < y.START_HOUR || e > y.END_HOUR) {
              this.warn(`竞技场未开放 (${y.START_HOUR}:00-${y.END_HOUR}:00)`);
              return;
            }
            this.info("开始竞技场战斗流程");
            const t = await this.switchFormationIfNeeded(this.settings.arenaFormation);
            t && (await p(5e3));
            try {
              try {
                await this.sendCommand(
                  "arena_startarea",
                  {},
                  { description: "开始竞技场", timeout: this.getTimeout("arena_startarea"), context: "arena" },
                );
              } catch (a) {
                if (C(a) === "200020") {
                  this.warn("关卡未达标，无法开启竞技场");
                  return;
                }
                throw a;
              }
              for (let a = 1; a <= y.MAX_FIGHTS; a++)
                (await this.executeArenaFight(a), a < y.MAX_FIGHTS && (await p(1e3)));
              this.success("竞技场战斗流程完成");
            } finally {
              t && (await this.restoreFormation());
            }
          },
        ]
      : [];
  }
  async executeArenaFight(e) {
    this.info(`竞技场战斗 ${e}/${y.MAX_FIGHTS}`);
    let t;
    try {
      t = await this.sendCommand("arena_getareatarget", {}, { description: `获取目标${e}` });
    } catch (n) {
      this.error(`获取目标失败: ${n.message}`);
      return;
    }
    if (!t || (z(t).length === 0 && !t.roleId && !t.id && !t.targetId)) {
      this.warn(`战斗${e} - 无可用目标`);
      return;
    }
    const a = f(this.tokenStore, "gameData.roleInfo.role", {}),
      r = Z(t, a);
    if (!(r != null && r.targetId)) {
      this.warn(`战斗${e} - 未找到合适目标`);
      return;
    }
    this.info(`目标: ${r.targetName} (排名:${r.targetRank})`);
    for (let n = 0; n <= 1; n++)
      try {
        (n > 0 && (this.warn(`战斗${e} - 重试中...`), await p(15e3)),
          await this.sendCommand(
            "fight_startareaarena",
            { targetId: r.targetId },
            { description: `竞技场战斗${e}`, timeout: this.getTimeout("fight_startareaarena") },
          ));
        return;
      } catch (i) {
        if (C(i) !== "200750" || n >= 1) {
          this.error(`战斗失败: ${i.message}`);
          return;
        }
      }
  }
  buildBossTasks(e, t) {
    const a = [];
    let r = e["legion:boss"] ?? 0;
    v(t["legion:boss"]) && (r = 0);
    const n = Math.max(this.settings.bossTimes - r, 0);
    if (n > 0) {
      let o = !1;
      a.push(async () => {
        o = await this.switchFormationIfNeeded(this.settings.bossFormation, "BOSS阵容");
      });
      for (let c = 0; c < n; c++)
        a.push(() => this.sendCommandSafe("fight_startlegionboss", {}, { description: `军团BOSS ${c + 1}/${n}` }));
      a.push(async () => {
        o && (await this.restoreFormation());
      });
    }
    let i = e.boss ?? 0;
    return (
      v(t.boss) && (i = 0),
      i < 1 &&
        (a.push(() => this.switchFormationIfNeeded(this.settings.bossFormation, "BOSS阵容")),
        a.push(() => this.sendCommand("fight_startboss", { bossId: Y() }, { description: "每日BOSS" }))),
      a
    );
  }
  buildFixedRewardTasks() {
    const e = [];
    e.push(() => this.sendCommandSafe("legion_signin", {}, { description: "俱乐部" }));
    const t = [
      { name: "福利签到", cmd: "system_signinreward" },
      { name: "每日礼包", cmd: "discount_claimreward" },
      { name: "每日免费奖励", cmd: "collection_claimfreereward" },
      { name: "免费礼包", cmd: "card_claimreward" },
      { name: "周卡礼包", cmd: "card_claimreward", params: { cardId: I.WEEKLY } },
      { name: "月卡礼包", cmd: "card_claimreward", params: { cardId: I.MONTHLY } },
      { name: "永久卡礼包", cmd: "card_claimreward", params: { cardId: I.PERMANENT } },
    ];
    return (
      this.settings.claimEmail && t.push({ name: "邮件奖励", cmd: "mail_claimallattachment" }),
      t.forEach(({ name: a, cmd: r, params: n = {}, context: i }) => {
        e.push(() => this.sendCommand(r, n, { description: a, context: i }));
      }),
      e.push(
        () => this.sendCommand("collection_goodslist", {}, { description: "珍宝阁列表" }),
        () => this.sendCommand("collection_claimfreereward", {}, { description: "珍宝阁免费礼包" }),
      ),
      e
    );
  }
  buildActivityTasks(e, t) {
    const a = [];
    if (v(e["artifact:normal:lottery:time"]))
      for (let n = 0; n < A; n++)
        a.push(() =>
          this.sendCommand(
            "artifact_lottery",
            { lotteryNumber: 1, newFree: !0, type: 1 },
            { description: `免费钓鱼 ${n + 1}/${A}` },
          ),
        );
    const r = ["魏国", "蜀国", "吴国", "群雄"];
    for (let n = 1; n <= G; n++)
      if (v(t[`genie:daily:free:${n}`])) {
        const i = r[n - 1];
        a.push(() =>
          this.sendCommandSafe(
            "genie_sweep",
            { genieId: n },
            { description: `${i}灯神扫荡`, timeout: this.getTimeout("genie_sweep"), context: "genie" },
          ),
        );
      }
    for (let n = 0; n < O; n++)
      a.push(() => this.sendCommand("genie_buysweep", {}, { description: `免费扫荡卷 ${n + 1}/${O}` }));
    return a;
  }
  buildBlackMarketTask() {
    return this.settings.blackMarketPurchase
      ? [
          async () => {
            var e, t, a, r, n;
            try {
              const i = await this.sendCommand("store_purchase", { goodsId: 1 }, { context: "blackMarket" });
              if (
                i &&
                (((e = i.buyList) == null ? void 0 : e.length) ||
                  ((t = i.goodsList) == null ? void 0 : t.length) ||
                  ((a = i.items) == null ? void 0 : a.length) ||
                  ((r = i.reward) == null ? void 0 : r.length) ||
                  ((n = i.rewards) == null ? void 0 : n.length) ||
                  i.code === 0 ||
                  i.ret === 0)
              ) {
                this.success("黑市购买成功");
                return;
              }
              throw new Error("未购买到物品");
            } catch {
              this.warn("黑市采购失败，尝试兜底...");
              try {
                (await this.sendCommand(
                  "store_buy",
                  { goodsId: _.BRONZE.id },
                  { description: "青铜宝箱(兜底)", timeout: this.getTimeout("store_buy") },
                ),
                  this.success("兜底购买成功"));
              } catch (o) {
                C(o) === "1100010" ? this.info("青铜宝箱已购买过") : this.error(`兜底购买失败: ${o.message}`);
              }
            }
          },
        ]
      : [];
  }
  buildDreamWorldTask() {
    return j()
      ? [
          () =>
            this.sendCommand(
              "dungeon_selecthero",
              { battleTeam: { 0: 107 } },
              { description: "咸王梦境", context: "dreamWorld" },
            ),
        ]
      : [];
  }
  buildDeepSeaLampTask(e) {
    return new Date().getDay() !== 1 || !v(e["genie:daily:free:5"])
      ? []
      : [() => this.sendCommand("genie_sweep", { genieId: 5, sweepCnt: 1 }, { description: "深海灯神" })];
  }
  buildRewardTasks() {
    const e = [];
    for (let t = 1; t <= q; t++)
      e.push(() => this.sendCommand("task_claimdailypoint", { taskId: t }, { description: `任务奖励${t}` }));
    return (
      e.push(
        async () => {
          (await this.sendCommand("task_claimdailyreward", {}, { description: "日常奖励" }), await x(2e3, 3e3));
        },
        async () => {
          (await this.sendCommand("task_claimweekreward", {}, { description: "周常奖励" }), await x(2e3, 3e3));
        },
        () => this.sendCommand("activity_recyclewarorderrewardclaim", { actId: 1 }, { description: "通行证奖励" }),
      ),
      e
    );
  }
  async fetchRoleData() {
    try {
      const e = await this.tokenStore.sendGetRoleInfo(this.tokenId);
      if ((this.success("角色信息获取成功"), !(e != null && e.role))) throw new Error("角色数据不存在");
      return e.role;
    } catch (e) {
      if (U(e)) {
        if ((this.warn("获取角色信息失败，尝试刷新Token"), !(await this.ensureConnection(1)))) throw e;
        const t = await this.tokenStore.sendGetRoleInfo(this.tokenId);
        if ((this.success("角色信息获取成功"), !(t != null && t.role))) throw new Error("角色数据不存在");
        return t.role;
      }
      throw e;
    }
  }
  async getHangUpStatus(e = {}) {
    const { checkAddTime: t = !1, thresholdSeconds: a = 3600, maxHangUpTime: r = 36e3 } = e;
    try {
      const n = await this.fetchRoleData(),
        i = n == null ? void 0 : n.hangUp;
      if (!i) return { hasData: !1, message: "无挂机数据", needAddTime: !1, addTimeMessage: "" };
      const o = Date.now() / 1e3,
        c = i.lastTime || 0,
        m = i.hangUpTime || 0,
        d = o - c,
        l = d <= m,
        u = l ? Math.floor(m - d) : 0,
        w = Math.floor(l ? d : m),
        T = m > 0 ? Math.min(100, Math.floor((w / m) * 100)) : 0;
      let g = !1,
        h = "";
      t &&
        (l
          ? u < 7200
            ? ((g = !0), (h = `剩余时间不足2小时(${this.formatTime(u)})，建议加钟`))
            : m < r && u < 14400
              ? ((g = !0), (h = `挂机时间${this.formatTime(m)}，剩余${this.formatTime(u)}，可以加钟`))
              : ((g = !1),
                (h =
                  m >= r
                    ? `挂机时间已达${this.formatTime(r)}，剩余${this.formatTime(u)}，无需加钟`
                    : `挂机时间${this.formatTime(m)}，剩余${this.formatTime(u)}，充足，无需加钟`))
          : ((g = !0), (h = "挂机已完成，立即加钟")));
      const k = {
        hasData: !0,
        isActive: l,
        lastTime: c,
        hangUpTime: m,
        elapsedTime: w,
        remainingTime: u,
        progress: T,
        needAddTime: g,
        addTimeMessage: h,
        message: l ? `挂机中：${this.formatTime(w)}/${this.formatTime(m)}` : "挂机已完成",
      };
      return (t ? this.info(`挂机状态: ${k.message} | ${h}`) : this.info(`挂机状态: ${k.message}`), k);
    } catch (n) {
      return (
        this.error(`获取挂机状态失败: ${n.message}`),
        { hasData: !1, message: `获取失败: ${n.message}`, needAddTime: !1, addTimeMessage: "" }
      );
    }
  }
  formatTime(e) {
    if (!e || e <= 0) return "0秒";
    const t = Math.floor(e / 3600),
      a = Math.floor((e % 3600) / 60),
      r = Math.floor(e % 60),
      n = [];
    return (
      t > 0 && n.push(`${t}小时`),
      a > 0 && n.push(`${a}分钟`),
      (r > 0 || n.length === 0) && n.push(`${r}秒`),
      n.join("")
    );
  }
  checkActivity(e) {
    var r, n;
    const t = ((r = e.dailyTask) == null ? void 0 : r.dailyPoint) ?? 0,
      a = 100;
    return (
      this.info(`活跃度: ${t}/${a}`),
      t >= a
        ? (this.success(`活跃度已满 (${t}/${a})，无需执行任务`),
          (n = this.callbacks) != null && n.onProgress && this.callbacks.onProgress(100),
          !0)
        : !1
    );
  }
  async run(e, t = {}, a = null) {
    var l, u, w, T, g, h, k;
    if (
      ((this.tokenId = e),
      (this.callbacks = t),
      (this.settings = a || this.loadSettings(e) || { ...S }),
      this.info("检查连接状态..."),
      !(await this.ensureConnection()))
    )
      throw (this.error("连接失败，无法执行任务"), new Error("连接异常"));
    this.info("获取角色信息...");
    const r = await this.fetchRoleData();
    if (this.checkActivity(r)) {
      (u = (l = this.callbacks) == null ? void 0 : l.onProgress) == null || u.call(l, 100);
      return;
    }
    (this.info("开始执行每日任务"),
      (this.originalFormation = await this.getCurrentFormation()),
      this.originalFormation && this.info(`当前阵容: ${this.originalFormation}`));
    const n = ((w = r.dailyTask) == null ? void 0 : w.complete) ?? {},
      i = r.statistics ?? {},
      o = r.statisticsTime ?? {},
      m = [
        () => this.buildBasicTasks(n, i, o),
        () => this.buildSaltBottleTasks(n),
        () => this.buildArenaTask(),
        () => this.buildBossTasks(i, o),
        () => this.buildFixedRewardTasks(),
        () => this.buildActivityTasks(i, o),
        () => this.buildBlackMarketTask(),
        () => this.buildDreamWorldTask(),
        () => this.buildDeepSeaLampTask(o),
        () => (this.originalFormation ? [() => this.restoreFormation()] : []),
        () => this.buildRewardTasks(),
      ].flatMap((E) => E()),
      d = m.length;
    this.info(`共 ${d} 个任务待执行`);
    for (let E = 0; E < m.length; E++)
      try {
        (await m[E](),
          (g = (T = this.callbacks) == null ? void 0 : T.onProgress) == null ||
            g.call(T, Math.floor(((E + 1) / d) * 100)),
          await p(this.delaySettings.taskDelay));
      } catch {}
    ((k = (h = this.callbacks) == null ? void 0 : h.onProgress) == null || k.call(h, 100),
      this.success("所有任务执行完成"));
  }
}
const se = {
    101: { name: "司马懿", type: "魏国", avatar: "/team/simayi.png" },
    102: { name: "郭嘉", type: "魏国", avatar: "/team/guojia.png" },
    103: { name: "关羽", type: "蜀国", avatar: "/team/guanyu.png" },
    104: { name: "诸葛亮", type: "蜀国", avatar: "/team/zhugeliang.png" },
    105: { name: "周瑜", type: "吴国", avatar: "/team/zhouyu.png" },
    106: { name: "太史慈", type: "吴国", avatar: "/team/taishici.png" },
    107: { name: "吕布", type: "群雄", avatar: "/team/lvbu.png" },
    108: { name: "华佗", type: "群雄", avatar: "/team/huatuo.png" },
    109: { name: "甄姬", type: "魏国", avatar: "/team/zhenji.png" },
    110: { name: "黄月英", type: "蜀国", avatar: "/team/huangyueying.png" },
    111: { name: "孙策", type: "吴国", avatar: "/team/sunce.png" },
    112: { name: "贾诩", type: "群雄", avatar: "/team/jiaxu.png" },
    113: { name: "曹仁", type: "魏国", avatar: "/team/caoren.png" },
    114: { name: "姜维", type: "蜀国", avatar: "/team/jiangwei.png" },
    115: { name: "孙坚", type: "吴国", avatar: "/team/sunjian.png" },
    116: { name: "公孙瓒", type: "群雄", avatar: "/team/gongsunzan.png" },
    117: { name: "典韦", type: "魏国", avatar: "/team/dianwei.png" },
    118: { name: "赵云", type: "蜀国", avatar: "/team/zhaoyun.png" },
    119: { name: "大乔", type: "吴国", avatar: "/team/daqiao.png" },
    120: { name: "张角", type: "群雄", avatar: "/team/zhangjiao.png" },
    121: { name: "鲁肃", type: "吴国", avatar: "/team/lusu.png" },
    201: { name: "徐晃", type: "魏国", avatar: "/team/xuhuang.png" },
    202: { name: "荀彧", type: "魏国", avatar: "/team/xunyu.png" },
    203: { name: "典韦", type: "魏国", avatar: "/team/xiaodianwei.png" },
    204: { name: "张飞", type: "蜀国", avatar: "/team/zhangfei.png" },
    205: { name: "赵云", type: "蜀国", avatar: "/team/xiaozhaoyun.png" },
    206: { name: "庞统", type: "蜀国", avatar: "/team/pangtong.png" },
    207: { name: "鲁肃", type: "吴国", avatar: "/team/xiaolusu.png" },
    208: { name: "陆逊", type: "吴国", avatar: "/team/luxun.png" },
    209: { name: "甘宁", type: "吴国", avatar: "/team/ganning.png" },
    210: { name: "貂蝉", type: "群雄", avatar: "/team/diaochan.png" },
    211: { name: "董卓", type: "群雄", avatar: "/team/dongzhuo.png" },
    212: { name: "张角", type: "群雄", avatar: "/team/xiaozhangjiao.png" },
    213: { name: "张辽", type: "魏国", avatar: "/team/zhangliao.png" },
    214: { name: "夏侯惇", type: "魏国", avatar: "/team/xiahoudun.png" },
    215: { name: "许褚", type: "魏国", avatar: "/team/xuzhu.png" },
    216: { name: "夏侯渊", type: "魏国", avatar: "/team/xiahouyuan.png" },
    217: { name: "魏延", type: "蜀国", avatar: "/team/weiyan.png" },
    218: { name: "黄忠", type: "蜀国", avatar: "/team/huangzhong.png" },
    219: { name: "马超", type: "蜀国", avatar: "/team/machao.png" },
    220: { name: "马岱", type: "蜀国", avatar: "/team/madai.png" },
    221: { name: "吕蒙", type: "吴国", avatar: "/team/lvmeng.png" },
    222: { name: "黄盖", type: "吴国", avatar: "/team/huanggai.png" },
    223: { name: "蔡文姬", type: "魏国", avatar: "/team/caiwenji.png" },
    224: { name: "小乔", type: "吴国", avatar: "/team/xiaoqiao.png" },
    225: { name: "袁绍", type: "群雄", avatar: "/team/yuanshao.png" },
    226: { name: "华雄", type: "群雄", avatar: "/team/huaxiong.png" },
    227: { name: "颜良", type: "群雄", avatar: "/team/yanliang.png" },
    228: { name: "文丑", type: "群雄", avatar: "/team/wenchou.png" },
    301: { name: "周泰", type: "吴国", avatar: "/team/zhoutai.png" },
    302: { name: "许攸", type: "魏国", avatar: "/team/xuyou.png" },
    303: { name: "于禁", type: "魏国", avatar: "/team/yujin.png" },
    304: { name: "张星彩", type: "蜀国", avatar: "/team/zhangxingcai.png" },
    305: { name: "关银屏", type: "蜀国", avatar: "/team/guanyinping.png" },
    306: { name: "关平", type: "蜀国", avatar: "/team/guanping.png" },
    307: { name: "程普", type: "吴国", avatar: "/team/chengpu.png" },
    308: { name: "张昭", type: "吴国", avatar: "/team/zhangzhao.png" },
    309: { name: "陆绩", type: "吴国", avatar: "/team/luji.png" },
    310: { name: "吕玲绮", type: "群雄", avatar: "/team/lvlingqi.png" },
    311: { name: "潘凤", type: "群雄", avatar: "/team/panfeng.png" },
    312: { name: "邢道荣", type: "群雄", avatar: "/team/xingdaorong.png" },
    313: { name: "祝融夫人", type: "蜀国", avatar: "/team/zhurongfuren.png" },
    314: { name: "孟获", type: "蜀国", avatar: "/team/menghuo.png" },
  },
  J = [
    { name: "吴国", required: [106, 111], colorProps: { color: "#f5222d", textColor: "#fff" } },
    { name: "姜维", required: [114, 111], colorProps: { color: "#237804", textColor: "#fff" } },
    { name: "毒爆", required: [108, 112, 120], colorProps: { color: "#722ed1", textColor: "#fff" } },
    { name: "吕赵", required: [107, 116, 118], colorProps: { color: "#faad14", textColor: "#fff" } },
    { name: "三蜀", required: [104, 110, 118], colorProps: { color: "#389e0d", textColor: "#fff" } },
    { name: "典韦", required: [117, 113], colorProps: { color: "#40a9ff", textColor: "#fff" } },
    { name: "司马懿", required: [101, 113], colorProps: { color: "#0050b3", textColor: "#fff" } },
    { name: "关羽", required: [103], colorProps: { color: "#73d13d", textColor: "#fff" } },
    { name: "吕布", required: [107, 116], forbidden: [118], colorProps: { color: "#f06f44ff", textColor: "#fff" } },
    { name: "控制毒", required: [120, 104, 110], colorProps: { color: "#722ed1", textColor: "#fff" } },
    { name: "控制吴", required: [105, 104, 110], colorProps: { color: "#f5222d", textColor: "#fff" } },
  ],
  re = (s) => {
    const e = new Set(s.map((a) => parseInt(a.heroId))),
      t = (a) => e.has(a);
    for (const a of J)
      if (
        !(a.required && !a.required.every((r) => t(r))) &&
        !(a.forbidden && a.forbidden.some((r) => t(r))) &&
        !(a.oneOf && !a.oneOf.every((n) => n.some((i) => t(i))))
      )
        return a.name;
    return "其他";
  },
  B = {
    1033007: { name: "碎盾" },
    1033008: { name: "冥想" },
    1033009: { name: "定心" },
    1033010: { name: "冰清" },
    1033011: { name: "攻心" },
    1033012: { name: "强权" },
    1033013: { name: "盾击" },
    1033014: { name: "合力" },
    1033015: { name: "仁心" },
    1033016: { name: "游龙" },
    1033017: { name: "回元" },
  },
  V = {
    1201: { name: "龙鱼·幽影" },
    1202: { name: "龙鱼·青龙" },
    1203: { name: "龙鱼·火镰" },
    1204: { name: "龙鱼·无双" },
    1205: { name: "龙鱼·永霜" },
    1206: { name: "龙鱼·八卦" },
    1207: { name: "龙鱼·紫电" },
    1208: { name: "龙鱼·青囊" },
    1209: { name: "龙鱼·洛神" },
    1210: { name: "龙鱼·机神" },
    1211: { name: "龙鱼·霸王" },
    1212: { name: "龙鱼·蚀骨" },
    1213: { name: "龙鱼·坚盾" },
    1214: { name: "龙鱼·麒麟" },
    1215: { name: "龙鱼·古锭" },
    1216: { name: "龙鱼·义从" },
    1217: { name: "龙鱼·恶来" },
    1218: { name: "龙鱼·龙胆" },
    1219: { name: "龙鱼·国色" },
    1220: { name: "龙鱼·天公" },
    1301: { name: "月尾" },
    1302: { name: "焰神" },
    1303: { name: "红蝶" },
    1304: { name: "赤羽" },
    1305: { name: "千年笛" },
    1401: { name: "四带胡椒" },
    1402: { name: "鬼狮子鱼" },
    1403: { name: "黑斑雀鲷" },
    1404: { name: "诅咒花椒" },
    1405: { name: "九斑刺豚" },
    1406: { name: "魔鬼刺镰" },
    1407: { name: "黄背刺鲷" },
    1408: { name: "黑鳍刺鲷" },
    1409: { name: "长棘刺鲷" },
    1410: { name: "粒突箱鲀" },
    1411: { name: "大跳跳鱼" },
    1412: { name: "蓝心胖头" },
    1501: { name: "钱胡椒" },
    1502: { name: "狮子鱼" },
    1503: { name: "塔雀鲷" },
    1504: { name: "紫斑鳅" },
    1505: { name: "密刺豚" },
    1506: { name: "长鳍镰" },
    1601: { name: "胖头鱼" },
    1602: { name: "青刺鲷" },
    1603: { name: "跳跳鱼" },
    1604: { name: "箱豚鱼" },
    1101: { name: "黄金锦鲤" },
    1102: { name: "利刃" },
    1103: { name: "惊涛" },
    1104: { name: "骇浪" },
    1105: { name: "星驰" },
    1106: { name: "公同心" },
    1107: { name: "母同心" },
    1108: { name: "公协力" },
    1109: { name: "母协力" },
    1110: { name: "月光" },
    1111: { name: "公铁血" },
    1112: { name: "母铁血" },
    1113: { name: "公丹心" },
    1114: { name: "母丹心" },
    1115: { name: "巨灵" },
    1116: { name: "公剑胆" },
    1117: { name: "母剑胆" },
    1118: { name: "璇玑" },
    1119: { name: "公琴心" },
    1120: { name: "母琴心" },
    1121: { name: "回响" },
  },
  Q = {
    1: { color: "白色", value: "white" },
    2: { color: "绿色", value: "green" },
    3: { color: "蓝色", value: "blue" },
    4: { color: "紫色", value: "purple" },
    5: { color: "橙色", value: "orange" },
    6: { color: "红色", value: "red" },
  },
  ee = {
    1: "一支穿云箭",
    2: "皮鞋手机",
    3: "懦弱百合",
    4: "正义喇叭",
    5: "祖传大饼",
    6: "冰镇啤酒",
    7: "导演话筒",
    8: "驱蚊花露水",
    9: "止痒花露水",
  },
  ie = {
    1: { name: "虾米", value: "green" },
    2: { name: "入门", value: "blue" },
    3: { name: "高手", value: "purple" },
    4: { name: "宗师", value: "orange" },
    5: { name: "泰斗", value: "red" },
    6: { name: "至尊", value: "gold" },
    7: { name: "珍·至尊", value: "gold" },
  },
  oe = (s) => ee[s],
  ce = (s) => {
    let e = {};
    return (
      s &&
        s.heroes &&
        typeof s.heroes == "object" &&
        Object.values(s.heroes).forEach((t) => {
          ((e[t.artifactId] = { FishInfo: V[(t.artifactId + "").substring(0, 4)], artifactId: t.artifactId }),
            t.appendSkill &&
              Array.isArray(t.appendSkill) &&
              t.appendSkill.forEach((a) => {
                B[a.skillId] && (e[t.artifactId].PearlSkill = B[a.skillId]);
              }));
        }),
      s &&
        s.pearlMap &&
        typeof s.pearlMap == "object" &&
        Object.values(s.pearlMap).forEach((t) => {
          e[t.artifactId] &&
            t.slotMap &&
            typeof t.slotMap == "object" &&
            (e[t.artifactId].slotMap = Object.values(t.slotMap).map((a) => Object.assign({}, a, Q[a.colorId])));
        }),
      e
    );
  },
  me = {
    101: 60,
    102: 50,
    103: 40,
    104: 30,
    105: 20,
    106: 20,
    107: 20,
    108: 20,
    109: 30,
    110: 30,
    111: 30,
    112: 30,
    113: 30,
    114: 30,
    201: 60,
    202: 50,
    203: 40,
    204: 30,
    205: 20,
    206: 20,
    207: 20,
    208: 20,
    209: 30,
    210: 30,
    211: 30,
    212: 30,
    213: 30,
    214: 30,
    301: 60,
    302: 50,
    303: 40,
    304: 30,
    305: 20,
    306: 20,
    307: 20,
    308: 20,
    309: 30,
    310: 30,
    311: 30,
    312: 30,
    313: 30,
    314: 30,
    401: 60,
    402: 50,
    403: 40,
    404: 30,
    405: 20,
    406: 20,
    407: 20,
    408: 20,
    409: 30,
    410: 30,
    411: 30,
    412: 30,
    413: 30,
    414: 30,
    501: 60,
    502: 50,
    503: 40,
    504: 30,
    505: 20,
    506: 20,
    507: 20,
    508: 20,
    509: 30,
    510: 30,
    511: 30,
    512: 30,
    513: 30,
    514: 30,
    601: 60,
    602: 50,
    603: 40,
    604: 30,
    605: 20,
    606: 20,
    607: 20,
    608: 20,
    609: 30,
    610: 30,
    611: 30,
    612: 30,
    613: 30,
    614: 30,
  },
  le = {
    1: [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114],
    2: [201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214],
    3: [301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314],
    4: [401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414],
    5: [501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514],
    6: [601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614],
  },
  de = {
    1: [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114],
    2: [601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614],
    3: [501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514],
    4: [201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214],
    5: [401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414],
    6: [301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314],
  },
  ue = { 1: "战士", 2: "法师", 3: "射手", 4: "刺客", 5: "辅助", 6: "肉盾" },
  he = {
    101: "战士生命",
    102: "战士攻击力",
    103: "战士暴击",
    104: "战士格挡",
    105: "战士技能伤害",
    106: "战士速度",
    107: "战士体质",
    108: "战士心智",
    109: "战士抵抗",
    110: "法师抵抗",
    111: "射手抵抗",
    112: "刺客抵抗",
    113: "辅助抵抗",
    114: "肉盾抵抗",
    201: "法师生命",
    202: "法师攻击力",
    203: "法师暴击",
    204: "法师精准",
    205: "法师技能伤害",
    206: "法师速度",
    207: "法师体质",
    208: "法师心智",
    209: "战士抵抗",
    210: "法师抵抗",
    211: "射手抵抗",
    212: "刺客抵抗",
    213: "辅助抵抗",
    214: "肉盾抵抗",
    301: "射手生命",
    302: "射手攻击力",
    303: "射手格挡",
    304: "射手精准",
    305: "射手技能伤害",
    306: "射手速度",
    307: "射手体质",
    308: "射手心智",
    309: "战士抵抗",
    310: "法师抵抗",
    311: "射手抵抗",
    312: "刺客抵抗",
    313: "辅助抵抗",
    314: "肉盾抵抗",
    401: "刺客生命",
    402: "刺客暴击伤害",
    403: "刺客暴击",
    404: "刺客破甲",
    405: "刺客技能伤害",
    406: "刺客速度",
    407: "刺客体质",
    408: "刺客心智",
    409: "战士抵抗",
    410: "法师抵抗",
    411: "射手抵抗",
    412: "刺客抵抗",
    413: "辅助抵抗",
    414: "肉盾抵抗",
    501: "辅助生命",
    502: "辅助格挡",
    503: "辅助暴击",
    504: "辅助速度1",
    505: "辅助技能伤害",
    506: "辅助速度",
    507: "辅助体质",
    508: "辅助心智",
    509: "战士抵抗",
    510: "法师抵抗",
    511: "射手抵抗",
    512: "刺客抵抗",
    513: "辅助抵抗",
    514: "肉盾抵抗",
    601: "肉盾生命",
    602: "肉盾格挡1",
    603: "肉盾暴击",
    604: "肉盾格挡2",
    605: "肉盾技能伤害",
    606: "肉盾速度",
    607: "肉盾体质",
    608: "肉盾心智",
    609: "战士抵抗",
    610: "法师抵抗",
    611: "射手抵抗",
    612: "刺客抵抗",
    613: "辅助抵抗",
    614: "肉盾抵抗",
  },
  pe = {
    1: { name: "初级商人", items: ["进阶石", "精铁", "木质宝箱", "青铜宝箱", "普通鱼竿", "咸神门票", "咸神火把"] },
    2: {
      name: "中级商人",
      items: ["梦魇晶石", "进阶石", "精铁", "黄金宝箱", "黄金鱼竿", "招募令", "橙将碎片", "紫将碎片"],
    },
    3: {
      name: "高级商人",
      items: ["梦魇晶石", "铂金宝箱", "黄金鱼竿", "招募令", "红将碎片", "橙将碎片", "红将碎片", "普通鱼竿"],
    },
  },
  fe = { 1: [5, 6], 2: [6, 7], 3: [5, 6, 7] };
function ge() {
  const e = new Date().getDay();
  return e === 0 || e === 1 || e === 3 || e === 4;
}
const ye = (s, e) =>
    new Promise((t, a) => {
      try {
        s.toBlob
          ? s.toBlob((r) => {
              if (!r) {
                (console.error("Canvas转换Blob失败"), R(s, e).then(t).catch(a));
                return;
              }
              window.Capacitor !== void 0
                ? W(r, e)
                    .then(t)
                    .catch(() => {
                      H(r, e).then(t).catch(a);
                    })
                : H(r, e).then(t).catch(a);
            }, "image/png")
          : R(s, e).then(t).catch(a);
      } catch (r) {
        (console.error("导出图片出错:", r), R(s, e).then(t).catch(a));
      }
    }),
  H = (s, e) =>
    new Promise((t, a) => {
      try {
        const r = URL.createObjectURL(s),
          n = document.createElement("a");
        if (
          ((n.href = r),
          (n.download = e),
          (n.style.display = "none"),
          document.body.appendChild(n),
          document.createEvent)
        ) {
          const i = document.createEvent("MouseEvents");
          (i.initMouseEvent("click", !0, !0, window, 1, 0, 0, 0, 0, !1, !1, !1, !1, 0, null), n.dispatchEvent(i));
        } else n.fireEvent ? n.fireEvent("onclick") : n.click();
        setTimeout(() => {
          (document.body.removeChild(n), URL.revokeObjectURL(r), t(!0));
        }, 100);
      } catch (r) {
        (console.error("下载失败:", r), a(r));
      }
    }),
  R = (s, e) =>
    new Promise((t, a) => {
      try {
        const r = s.toDataURL("image/png"),
          n = document.createElement("a");
        if (
          ((n.href = r),
          (n.download = e),
          (n.style.display = "none"),
          document.body.appendChild(n),
          document.createEvent)
        ) {
          const i = document.createEvent("MouseEvents");
          (i.initMouseEvent("click", !0, !0, window, 1, 0, 0, 0, 0, !1, !1, !1, !1, 0, null), n.dispatchEvent(i));
        } else n.fireEvent ? n.fireEvent("onclick") : n.click();
        setTimeout(() => {
          (document.body.removeChild(n), t(!0));
        }, 100);
      } catch (r) {
        (console.error("DataURL导出失败:", r), a(r));
      }
    }),
  W = async (s, e) => {
    try {
      if (!window.Capacitor) throw new Error("Capacitor not available");
      const t = window.Capacitor.getPlatform();
      console.log("[downloadInApk] Platform:", t);
      const a = new FileReader(),
        r = await new Promise((n, i) => {
          ((a.onloadend = () => n(a.result.split(",")[1])), (a.onerror = i), a.readAsDataURL(s));
        });
      if (window.Capacitor.Plugins && window.Capacitor.Plugins.Filesystem) {
        const n = window.Capacitor.Plugins.Filesystem;
        try {
          console.log("[downloadInApk] Writing to External directory");
          let i,
            o = !0;
          try {
            ((i = await n.writeFile({ path: e, data: r, directory: "EXTERNAL", recursive: !0 })),
              console.log("File saved to External:", i.uri));
          } catch (c) {
            (console.warn("External directory failed, trying Documents:", c),
              (o = !1),
              (i = await n.writeFile({ path: e, data: r, directory: "DOCUMENTS", recursive: !0 })),
              console.log("File saved to Documents:", i.uri));
          }
          if (window.Capacitor.Plugins.Share) {
            const c = window.Capacitor.Plugins.Share;
            try {
              const m = i.uri;
              return (
                await c.share({ title: "导出文件", text: `文件: ${e}`, url: m, dialogTitle: "保存或分享文件" }),
                console.log("Share dialog shown"),
                !0
              );
            } catch (m) {
              return (
                console.warn("Share failed:", m),
                console.log("File saved but share failed. URI:", i.uri),
                alert(
                  o
                    ? `文件已保存到外部存储:
${i.uri}`
                    : `文件已保存，但无法分享。
请尝试使用文件管理器访问应用文档目录。`,
                ),
                !0
              );
            }
          }
          return !0;
        } catch (i) {
          throw (console.error("Filesystem write failed:", i), i);
        }
      }
      throw new Error("Filesystem plugin not available");
    } catch (t) {
      throw (console.error("APK download failed:", t), t);
    }
  },
  we = async (s, e) => {
    try {
      return window.Capacitor !== void 0
        ? (console.log("[downloadFile] APK environment detected, using share"), await W(s, e))
        : (console.log("[downloadFile] Web/EXE environment, using direct download"),
          await new Promise((a, r) => {
            try {
              const n = URL.createObjectURL(s),
                i = document.createElement("a");
              if (
                ((i.href = n),
                (i.download = e),
                (i.style.display = "none"),
                document.body.appendChild(i),
                document.createEvent)
              ) {
                const o = document.createEvent("MouseEvents");
                (o.initMouseEvent("click", !0, !0, window, 1, 0, 0, 0, 0, !1, !1, !1, !1, 0, null), i.dispatchEvent(o));
              } else i.fireEvent ? i.fireEvent("onclick") : i.click();
              setTimeout(() => {
                (document.body.removeChild(i), URL.revokeObjectURL(n), a(!0));
              }, 100);
            } catch (n) {
              (console.error("下载失败:", n), r(n));
            }
          }));
    } catch (t) {
      return (console.error("下载失败:", t), !1);
    }
  };
export {
  ne as D,
  V as F,
  ce as H,
  J as L,
  B as P,
  se as a,
  fe as b,
  ue as c,
  ye as d,
  le as e,
  oe as f,
  re as g,
  he as h,
  ge as i,
  me as j,
  Q as k,
  ie as l,
  pe as m,
  de as n,
  we as o,
  ee as w,
};
