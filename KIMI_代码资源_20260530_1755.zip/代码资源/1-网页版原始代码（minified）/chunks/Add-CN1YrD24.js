import { k as e, c as n, h as t, a as o } from "./index-UoU16364.js";
const r = {
    xmlns: "http://www.w3.org/2000/svg",
    "xmlns:xlink": "http://www.w3.org/1999/xlink",
    viewBox: "0 0 512 512",
  },
  s = o(
    "path",
    {
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "32",
      d: "M256 112v288",
    },
    null,
    -1,
  ),
  l = o(
    "path",
    {
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "32",
      d: "M400 256H112",
    },
    null,
    -1,
  ),
  d = [s, l],
  h = e({
    name: "Add",
    render: function (c, a) {
      return (t(), n("svg", r, d));
    },
  });
export { h as A };
